# 주말 자동 DPD 실험 — 시작 문구 (Claude Code 에 붙여 넣기)

이 폴더의 CLAUDE.md 를 먼저 끝까지 읽어. 그다음 아래대로 주말 내내 자동 DPD 실험을 지휘해 줘.

- 사용자는 DPD 탭 9 카드 [▶ 큐 시작] 을 이미 눌렀어. 큐 폴더: %APPDATA%\PADPDTester\queue
- 너의 역할은 지휘: 실험 파일 쓰기 · 결과 분석 · 보고서. 장비를 직접 제어하거나 프로그램 · psu_panel.py · 바이어스를 건드리지 마.
- 목표: GMP 계열 (기지국용) 로 Pout 42 dBm, 400 MHz 2CC 에서 D 를 −40 → −45 쪽으로. 핵심은 B 의 인접 칸 (지금 GMP −35, 신경망 −41).
- 순서:
  1. status.json · results.jsonl 확인. 큐가 비었으면 첫 묶음 (CLAUDE.md §7 의 1 번: 볼테라 교차 항 · ACLR 가중 10) 을 queue_examples 를 참고해 넣어.
     ILC 는 첫 실험에서 한 번 (steps 에 "ilc") 하고, 그 뒤 실험들은 "ilcm" 으로 같은 ILC 를 써서 비교해.
  2. 1 ~ 2 시간마다: dpd-analyst 로 분석 → 다음 실험 3 ~ 6 개 작성 (한 번에 한 가지만 바꿈) → 큐에 넣기. 대기 실험이 2 개 아래로 떨어지지 않게.
  3. 새 모델 아이디어가 필요하면 dpd-modeler 로 작업 사본에서 만들고 가짜 PA 로 검증 → proposals\ 에만 둬 (월요일 확인).
  4. 매일 밤 · 일요일 밤에 dpd-reporter 로 보고서 (CLAUDE.md §8-3).
  5. status.json 의 state 가 wait_bias 오래 · fail 이 연속 3 번 · on=false 면 실험 추가를 멈추고 보고서에 이유를 써.
- 일요일 밤 (자정 전) 에 큐 폴더에 STOP 파일을 만들어 마무리하고 최종 보고서를 완성해.
- 주기적으로 깨어나려면 Claude Code 의 반복 실행 (/loop 또는 예약 작업) 을 1 시간 간격으로 써.
