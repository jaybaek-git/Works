"""확장 모델 예시 — GMP 항 고르기 (SparseGMPModel) 에 새 후보 항을 더하는 꼴.

규칙 (CLAUDE.md §8-4):
  - make_model(p, eng, C) 가 모델 객체를 돌려줌. C = dpd_core 모듈, eng = 엔진 (eng.aclr_bands(), eng.aclr_band_w(), eng.sig.fs, eng.log 사용 가능).
  - 모델은 fit(u, d, n_fit=40000, rng=None, **kw) -> (w, 학습 오차 dB), apply(x, w=None) -> 같은 길이 복소 배열 이 있어야 함.
    (_basis_seg(u, s0, n) 이 있으면 ILC→모델 의 ACLR 가중 학습도 자동으로 됨)
  - 장비 · 파일 · 바이어스는 건드리지 않음 (계산만).
"""
VERSION = "ex-1"
DESC = "OMP 1 단계 후보에 |x(n-e)|^j 를 두 번 곱한 5 차 교차 항 추가 (예시)"


def make_model(p, eng, C):
    class XLagOMP(C.SparseGMPModel):
        def candidates(self):
            out = super().candidates()
            for m in range(4):                         # 예: x(n-m)|x(n-e1)|^2|x(n-e2)|^2 (서로 다른 시점 · 5 차)
                for e1 in range(m - 3, m + 4):
                    for e2 in range(e1 + 1, m + 4):
                        out.append(("c", m, e1, e2, 2, 2))
            return list(dict.fromkeys(out))           # 겹치는 후보 빼기

    m = XLagOMP(int(p.get("K", 9)), int(p.get("M", 16)), int(p.get("L", 8)), float(p.get("lam", 1e-6)),
                nmax=int(p.get("omp_n", 300) or 300), odd_only=bool(p.get("odd_only", False)))
    m.log = eng.log
    sig = getattr(eng, "sig", None)
    if sig is not None:
        m.set_carriers(C.find_carriers(sig.x, sig.fs), sig.fs)
        aw = float(p.get("nn_aclr_w", 0) or 0)
        if aw > 1 and eng.aclr_bands():
            m.fw = lambda: (sig.fs, eng.aclr_band_w(aw), aw)
    return m
