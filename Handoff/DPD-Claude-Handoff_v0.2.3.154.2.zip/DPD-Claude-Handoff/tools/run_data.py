"""분석 에이전트용: 실행 기록 파일 (results.jsonl 의 run_file · %APPDATA%\\PADPDTester\\runs\\<id>.json.gz) 을 읽어 측정마다 요약.
    python tools\\run_data.py <run_id 또는 파일 경로> [--full]
측정 하나 = dict: label · kind · sg · pout · pin · gain · evm · pae · de · aclr_l · aclr_u · aclr_pos (반송파별 인접) ·
              papr · nmse · 스펙트럼 (f · psd) · AM-AM · AM-PM 점 등 (파일에 있는 키 그대로 --full 로 확인)
"""
import gzip, json, os, sys

R = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "PADPDTester", "runs")


def load(arg):
    p = arg if os.path.exists(arg) else os.path.join(R, "%s.json.gz" % arg)
    with gzip.open(p, "rt", encoding="utf-8") as f:
        return json.load(f)


if __name__ == "__main__":
    data = load(sys.argv[1])
    if "--full" in sys.argv:
        print(json.dumps(data[:1], ensure_ascii=False)[:4000])
        print("키:", sorted(set().union(*[set(d) for d in data])))
    for i, d in enumerate(data):
        print("%3d %-28s Pout %6s  ACLR %6s / %6s  EVM %5s  PAE %5s  NMSE %6s" % (
            i, str(d.get("label"))[:28], d.get("pout"), d.get("aclr_l"), d.get("aclr_u"), d.get("evm"), d.get("pae"), d.get("nmse")))
