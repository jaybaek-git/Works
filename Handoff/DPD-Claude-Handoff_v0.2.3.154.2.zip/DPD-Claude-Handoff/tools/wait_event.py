"""지휘 에이전트용: 큐에 '일이 생길 때까지' 기다렸다가 무엇이 바뀌었는지 JSON 한 줄로 알려줌.
    python tools\\wait_event.py [--max 540]
깨어나는 경우: 실험 · 단계가 끝나 results.jsonl 에 줄이 늘어남 / 큐 상태가 바뀜 (빔 · 바이어스 꺼짐 · 꺼짐) /
             대기 실험이 2 개 아래 / --max 초 지남 (Claude Code 명령 시간 제한 10 분 안으로 기본 540 초)
"""
import json, os, sys, time

Q = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "PADPDTester", "queue")


def snap():
    st = {}
    try:
        with open(os.path.join(Q, "status.json"), encoding="utf-8") as f:
            st = json.load(f)
    except Exception:
        pass
    try:
        n = sum(1 for _ in open(os.path.join(Q, "results.jsonl"), encoding="utf-8"))
    except Exception:
        n = 0
    return st, n


def main():
    mx = 540
    if "--max" in sys.argv:
        mx = int(sys.argv[sys.argv.index("--max") + 1])
    st0, n0 = snap()
    t0 = time.time()
    why = "시간"
    while time.time() - t0 < mx:
        time.sleep(5)
        st, n = snap()
        if n > n0:
            why = "결과 %d 줄 새로" % (n - n0)
            break
        if st.get("state") != st0.get("state") or st.get("on") != st0.get("on"):
            why = "상태 %s → %s" % (st0.get("state"), st.get("state"))
            break
        if st.get("on") and (st.get("waiting") or 0) < 2 and (st0.get("waiting") or 0) >= 2:
            why = "대기 실험 %s 개" % st.get("waiting")
            break
    st, n = snap()
    new = []
    if n > n0:
        with open(os.path.join(Q, "results.jsonl"), encoding="utf-8") as f:
            lines = f.readlines()[n0:]
        for ln in lines:
            try:
                r = json.loads(ln)
                new.append({k: r.get(k) for k in ("time", "file", "do", "status", "D", "B", "T", "ext_model", "fsw_att", "iq_avg", "run_id")})
            except ValueError:
                pass
    print(json.dumps({"why": why, "waited_s": int(time.time() - t0), "status": st, "new_results": new}, ensure_ascii=False))


if __name__ == "__main__":
    main()
