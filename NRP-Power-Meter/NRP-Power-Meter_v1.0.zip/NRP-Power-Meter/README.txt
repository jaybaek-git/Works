﻿NRP Power Meter v1.0  (R&S NRP50S 파워 읽기 - 읽기 전용)
=======================================================
R&S NRP50S (NRPxxS 3-path diode power sensor) 의 평균 파워를 PC 에서 큰 숫자로 계속 읽습니다.
나중에 PA Bench Monitor (Mod. 측정 효율 계산) 에 넣을 수 있게 화면 · 읽기 코드는 nrp_panel.py 에 따로 있습니다.

■ 처음 한 번 (PC 준비)
  1. R&S NRP Toolkit 설치 (센서 USB 드라이버) - Rohde & Schwarz 홈페이지에서 무료 (이미 Power Viewer 를 쓰고 있으면 설치돼 있음)
  2. VISA: R&S VISA 또는 Keysight IO Libraries Suite 또는 NI-VISA 중 하나 (PA Bench Monitor 때문에 이미 있으면 그대로)
  3. python -m pip install pyvisa      (exe 로 빌드하면 필요 없음)
  ※ R&S Power Viewer 등 다른 프로그램이 센서를 쓰고 있으면 연결이 안 됩니다 → 닫고 연결

■ 사용
  1. [찾기] → 주소 목록에서 USB0::0x0AAD::...::INSTR (R&S 센서 후보가 맨 위) 고르기 → [연결]
     (장비 없이 시험: 주소에 DEMO)
  2. 연결되면 자동으로 [계속 읽기] 시작 - 큰 숫자 dBm, 아래 W (mW · µW), 최소 · 최대 · 평균
  3. 측정 설정 → [설정 보내기] (또는 칸에서 Enter)
     · 주파수 (GHz): 센서 주파수 보정 - 신호 주파수와 같게 (꼭 맞춰야 정확)
     · 평균 횟수 (기본 16) 또는 자동: 크게 하면 덜 흔들리지만 한 번 읽는 데 오래 걸림
     · 오프셋 (dB): 감쇠기 · 커플러 · 케이블 손실 보정 (예: 30 dB 감쇠기 → 30), 0 = 끔
     · 읽기 간격 (초)
  4. [영점 (Zero)...]: SG RF 를 끄고 (센서에 신호 없음) 실행 - 몇 초 걸림
  5. 추이 그래프 (최근 60 초), 기록 창 (보낸 명령 · 오류)

■ 센서에 보내는 명령 (SCPI)
  연결 시: *CLS · INIT:CONT OFF · SENS:FUNC "POW:AVG" · SENS:AVER:STAT ON · SENS:AVER:TCON REP · TRIG:SOUR IMM
  설정:   SENS:FREQ · SENS:AVER:COUN(:AUTO) · SENS:CORR:OFFS · SENS:CORR:OFFS:STAT
  읽기:   INIT:IMM → *OPC? → FETC?  (W 로 받아서 dBm 으로 바꿈)
  영점:   CAL:ZERO:AUTO ONCE

■ 실행
  · run_without_build.bat : 파이썬으로 바로 실행
  · build_exe.bat         : exe 만들기 → dist\NRP-Power-Meter_v1.0.exe (exe 도 VISA · NRP Toolkit 은 필요)

■ PA Bench Monitor 에 넣을 때 (예정)
  nrp_panel.App(root, container=프레임, settings=설정, on_value=함수(dBm, 시각)) 로 화면을 넣고,
  Mod. 측정에서 DUT Pout = 파워미터 dBm (+ 오프셋) 으로 효율 계산
