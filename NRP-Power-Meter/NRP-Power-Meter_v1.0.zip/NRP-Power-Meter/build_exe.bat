@echo off
cd /d %~dp0
echo ============================================
echo  NRP Power Meter v1.0 - EXE build
echo ============================================
python --version
if errorlevel 1 (
  echo [ERROR] Python not found.
  pause
  exit /b 1
)
python -m pip install --upgrade pyinstaller pyvisa
python -m PyInstaller --noconfirm --clean --onefile --windowed --name "NRP-Power-Meter_v1.0" --collect-submodules pyvisa --copy-metadata pyvisa --hidden-import pyvisa.ctwrapper --hidden-import nrp_panel nrp_power_meter.py
if errorlevel 1 (
  echo [ERROR] Build failed.
  pause
  exit /b 1
)
echo.
echo  DONE:  dist\NRP-Power-Meter_v1.0.exe
pause
