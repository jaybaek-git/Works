"""
R&S NRP50S (NRPxxS 3-path diode power sensor) 파워 읽기
  · USB (USBTMC) 로 연결 - PC 에 VISA (R&S VISA / Keysight IO Libraries / NI-VISA) + R&S NRP Toolkit 필요
  · 주소 예: USB0::0x0AAD::0x0138::101234::INSTR   (장비 없이 시험: DEMO)
  · 읽기 전용 (설정: 주파수 보정 · 평균 · 오프셋 · 영점)

나중에 PA Bench Monitor 에 넣을 수 있게 화면(App)과 읽기(Worker)를 나눠 둠:
  App(root, container=frame, settings=dict, on_value=fn(dBm, t))
"""
import collections
import math
import queue
import random
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox

APP = "NRP Power Meter"
VERSION = "v1.0"


def fnum(x, default=float("nan")):
    try:
        return float(str(x).strip().split(",")[0])
    except (TypeError, ValueError):
        return default


def w_to_dbm(w):
    return 10.0 * math.log10(w * 1e3) if w and w > 0 else float("-inf")


# ---------------------------------------------------------------- 장비 없이 시험용
class DemoNRP:
    def __init__(self):
        self.freq, self.avg, self.offs, self.offs_on = 3.5e9, 16, 0.0, False
        self.p_dbm = 10.0
        self.t0 = time.time()

    def write(self, cmd):
        c = cmd.strip().upper()
        val = cmd.split(" ", 1)[1].strip() if " " in cmd else ""
        if c.startswith("SENS:FREQ "):
            self.freq = fnum(val)
        elif c.startswith("SENS:AVER:COUN ") and "AUTO" not in c:
            self.avg = int(fnum(val, 16))
        elif c.startswith("SENS:CORR:OFFS ") and "STAT" not in c:
            self.offs = fnum(val, 0.0)
        elif c.startswith("SENS:CORR:OFFS:STAT "):
            self.offs_on = val.upper() in ("1", "ON")

    def query(self, cmd):
        c = cmd.strip().upper()
        time.sleep(0.01)
        if c == "*IDN?":
            return "Rohde&Schwarz,NRP50S,101234,02.40.21040301 (DEMO)"
        if c == "*OPC?":
            return "1"
        if c.startswith("SYST:ERR"):
            return '0,"No error"'
        if c.startswith("SENS:FREQ?"):
            return "%.6E" % self.freq
        if c.startswith("FETC") or c.startswith("READ") or c.startswith("MEAS"):
            # 데모: 변조 신호처럼 평균 파워가 천천히 움직임, 평균이 클수록 덜 흔들림
            t = time.time() - self.t0
            p = self.p_dbm + 3.0 * math.sin(t / 6.0) + random.gauss(0, 0.25 / math.sqrt(max(1, self.avg)))
            if self.offs_on:
                p += self.offs
            return "%.9E" % (10 ** (p / 10.0) / 1e3)
        return "0"

    def close(self):
        pass


# ---------------------------------------------------------------- VISA
class Visa:
    def __init__(self):
        self.rm = None
        self.err = ""

    def open_rm(self):
        if self.rm is not None:
            return True
        try:
            import pyvisa
        except ImportError:
            self.err = "pyvisa 가 없습니다.  명령 프롬프트에서:  python -m pip install pyvisa"
            return False
        for lib in ("", "@ivi", "@py"):
            try:
                self.rm = pyvisa.ResourceManager(lib) if lib else pyvisa.ResourceManager()
                return True
            except Exception as e:
                self.err = "VISA 를 찾지 못했습니다 (%s). R&S VISA 또는 Keysight IO Libraries / NI-VISA 설치 필요" % e
        return False

    def list(self):
        if not self.open_rm():
            return []
        try:
            return list(self.rm.list_resources("?*::INSTR"))
        except Exception:
            try:
                return list(self.rm.list_resources())
            except Exception:
                return []

    def open(self, addr, timeout_ms=5000):
        if addr.strip().upper().startswith("DEMO"):
            return DemoNRP()
        if not self.open_rm():
            raise RuntimeError(self.err)
        inst = self.rm.open_resource(addr.strip())
        inst.timeout = timeout_ms
        inst.read_termination = "\n"
        inst.write_termination = "\n"
        return inst


# ---------------------------------------------------------------- 읽기 쓰레드
class Worker(threading.Thread):
    def __init__(self, app):
        super().__init__(daemon=True)
        self.app = app
        self.tasks = queue.Queue()
        self.stop = False

    def run(self):
        nxt = 0.0
        while not self.stop:
            try:
                fn = self.tasks.get(timeout=0.02)
                try:
                    fn()
                except Exception as e:
                    self.app.post("log", "오류: %s" % e, "err")
                continue
            except queue.Empty:
                pass
            a = self.app
            if a.inst is not None and a.running and time.time() >= nxt:
                nxt = time.time() + a.dt
                try:
                    a.measure_once()
                except Exception as e:
                    a.post("log", "읽기 오류: %s" % e, "err")
                    a.post("err_read")
                    nxt = time.time() + 1.0


# ---------------------------------------------------------------- 화면
class App:
    def __init__(self, root, container=None, settings=None, on_value=None):
        self.root = root
        self.embedded = container is not None
        if container is None:
            root.title("%s %s - R&S NRP50S 파워 읽기" % (APP, VERSION))
            root.geometry("860x760")
            root.option_add("*Font", ("맑은 고딕", 9))
            container = ttk.Frame(root)
            container.pack(fill="both", expand=True)
        self.box = container
        self.s = settings if settings is not None else {}
        self.on_value = on_value
        self.q = queue.Queue()
        self.visa = Visa()
        self.inst = None
        self.running = False
        self.dt = 0.2
        self.last = (float("nan"), 0.0)        # (dBm, 시각) - PA Bench Monitor 가 읽어 감
        self.hist = collections.deque(maxlen=3000)
        self.stats = []
        self.worker = Worker(self)
        self.worker.start()
        self.build()
        root.after(100, self.pump)
        root.after(300, self.scan)
        if not self.embedded:
            root.protocol("WM_DELETE_WINDOW", self.on_close)

    def post(self, *m):
        self.q.put(m)

    # ------------------------------------------------ 화면 구성
    def build(self):
        s = self.s
        pad = dict(padx=4, pady=3)
        top = ttk.LabelFrame(self.box, text=" 연결 (USB · VISA) ", padding=6)
        top.pack(fill="x", padx=8, pady=(8, 4))
        self.lbl_visa = ttk.Label(top, text="VISA 확인 중...", foreground="#666")
        self.lbl_visa.grid(row=0, column=0, columnspan=6, sticky="w")
        ttk.Label(top, text="주소").grid(row=1, column=0, sticky="e", **pad)
        self.var_addr = tk.StringVar(value=s.get("nrp_addr", ""))
        self.cb_addr = ttk.Combobox(top, textvariable=self.var_addr, width=46)
        self.cb_addr.grid(row=1, column=1, sticky="we", **pad)
        ttk.Button(top, text="찾기", command=self.scan).grid(row=1, column=2, **pad)
        self.btn_conn = ttk.Button(top, text="연결", command=self.toggle_conn)
        self.btn_conn.grid(row=1, column=3, **pad)
        top.columnconfigure(1, weight=1)
        self.lbl_idn = ttk.Label(top, text="연결 안 됨", foreground="#666")
        self.lbl_idn.grid(row=2, column=0, columnspan=6, sticky="w", padx=4)
        ttk.Label(top, text="※ R&S Power Viewer 같은 다른 프로그램이 센서를 쓰고 있으면 연결이 안 됩니다 (닫고 연결). "
                            "장비 없이 시험: 주소에 DEMO", foreground="#888").grid(row=3, column=0, columnspan=6, sticky="w", padx=4)

        # 큰 숫자 (측정 장비 화면처럼)
        BG, LCD = "#2b3138", "#0a0f14"
        pnl = tk.Frame(self.box, bg=BG, bd=3, relief="raised")
        pnl.pack(fill="x", padx=8, pady=4)
        hd = tk.Frame(pnl, bg=BG)
        hd.pack(fill="x", padx=8, pady=(6, 2))
        tk.Label(hd, text="R&S NRP50S", bg=BG, fg="#e8e8e8", font=("Arial", 11, "bold")).pack(side="left")
        tk.Label(hd, text="  3-Path Diode Power Sensor · Avg Power", bg=BG, fg="#c9cdd2", font=("Arial", 8)).pack(side="left")
        self.lbl_state = tk.Label(hd, text=" 정지 ", bg="#555", fg="white", font=("맑은 고딕", 8, "bold"))
        self.lbl_state.pack(side="right")
        scr = tk.Frame(pnl, bg=LCD, bd=2, relief="sunken")
        scr.pack(fill="x", padx=8, pady=(0, 8))
        self.lbl_dbm = tk.Label(scr, text="---.-- dBm", bg=LCD, fg="#69f0ae", font=("Consolas", 44, "bold"), anchor="e")
        self.lbl_dbm.pack(fill="x", padx=14, pady=(6, 0))
        self.lbl_w = tk.Label(scr, text="", bg=LCD, fg="#b0bec5", font=("Consolas", 14), anchor="e")
        self.lbl_w.pack(fill="x", padx=14)
        self.lbl_info = tk.Label(scr, text="", bg=LCD, fg="#78909c", font=("Consolas", 9), anchor="w")
        self.lbl_info.pack(fill="x", padx=8, pady=(4, 6))

        # 설정
        cf = ttk.LabelFrame(self.box, text=" 측정 설정 (보내면 센서에 바로 적용) ", padding=6)
        cf.pack(fill="x", padx=8, pady=4)
        self.var_freq = tk.StringVar(value=s.get("nrp_freq", "3.5"))
        self.var_avg = tk.StringVar(value=s.get("nrp_avg", "16"))
        self.var_avg_auto = tk.BooleanVar(value=bool(s.get("nrp_avg_auto", False)))
        self.var_offs = tk.StringVar(value=s.get("nrp_offs", "0"))
        self.var_dt = tk.StringVar(value=s.get("nrp_dt", "0.2"))
        r = 0
        ttk.Label(cf, text="주파수").grid(row=r, column=0, sticky="e", **pad)
        e = ttk.Entry(cf, textvariable=self.var_freq, width=9, justify="right")
        e.grid(row=r, column=1, sticky="w", **pad)
        e.bind("<Return>", lambda ev: self.apply())
        ttk.Label(cf, text="GHz  (센서 주파수 보정 - 신호 주파수와 같게)").grid(row=r, column=2, columnspan=3, sticky="w")
        r += 1
        ttk.Label(cf, text="평균 횟수").grid(row=r, column=0, sticky="e", **pad)
        e = ttk.Entry(cf, textvariable=self.var_avg, width=9, justify="right")
        e.grid(row=r, column=1, sticky="w", **pad)
        e.bind("<Return>", lambda ev: self.apply())
        ttk.Checkbutton(cf, text="자동 (센서가 잡음에 맞춰 정함)", variable=self.var_avg_auto).grid(row=r, column=2, sticky="w")
        r += 1
        ttk.Label(cf, text="오프셋").grid(row=r, column=0, sticky="e", **pad)
        e = ttk.Entry(cf, textvariable=self.var_offs, width=9, justify="right")
        e.grid(row=r, column=1, sticky="w", **pad)
        e.bind("<Return>", lambda ev: self.apply())
        ttk.Label(cf, text="dB  (감쇠기 · 커플러 · 케이블 손실 보정, 0 = 끔)").grid(row=r, column=2, columnspan=3, sticky="w")
        r += 1
        ttk.Label(cf, text="읽기 간격").grid(row=r, column=0, sticky="e", **pad)
        ttk.Entry(cf, textvariable=self.var_dt, width=9, justify="right").grid(row=r, column=1, sticky="w", **pad)
        ttk.Label(cf, text="초  (평균 횟수가 크면 한 번 읽는 데 더 걸림)").grid(row=r, column=2, columnspan=3, sticky="w")
        r += 1
        bf = ttk.Frame(cf)
        bf.grid(row=r, column=0, columnspan=5, sticky="w", pady=(6, 0))
        ttk.Button(bf, text="설정 보내기", command=self.apply).pack(side="left", padx=2)
        self.btn_run = ttk.Button(bf, text="▶ 계속 읽기", command=self.toggle_run)
        self.btn_run.pack(side="left", padx=2)
        ttk.Button(bf, text="한 번 읽기", command=lambda: self.worker.tasks.put(self.measure_once)).pack(side="left", padx=2)
        ttk.Button(bf, text="통계 초기화", command=self.reset_stats).pack(side="left", padx=2)
        ttk.Button(bf, text="영점 (Zero)...", command=self.zero).pack(side="left", padx=(14, 2))

        # 추이 그래프
        gf = ttk.LabelFrame(self.box, text=" 추이 (최근 60 초) ", padding=4)
        gf.pack(fill="both", expand=True, padx=8, pady=4)
        self.cv = tk.Canvas(gf, bg="#0a0f14", height=170, highlightthickness=0)
        self.cv.pack(fill="both", expand=True)
        self.cv.bind("<Configure>", lambda e: self.draw())

        lf = ttk.LabelFrame(self.box, text=" 기록 ", padding=4)
        lf.pack(fill="x", padx=8, pady=(4, 8))
        self.log = tk.Text(lf, height=6, font=("Consolas", 9))
        self.log.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(lf, command=self.log.yview)
        sb.pack(side="right", fill="y")
        self.log.configure(yscrollcommand=sb.set)
        self.log.tag_configure("err", foreground="#c62828")
        self.log.tag_configure("ok", foreground="#2e7d32")

    # ------------------------------------------------ 연결
    def scan(self):
        def job():
            ok = self.visa.open_rm()
            res = self.visa.list() if ok else []
            self.post("scan", ok, res)
        self.worker.tasks.put(job)

    def toggle_conn(self):
        if self.inst is not None:
            self.disconnect()
            return
        addr = self.var_addr.get().strip()
        if not addr:
            messagebox.showwarning(APP, "주소를 고르거나 입력하세요 ([찾기] 또는 DEMO).")
            return

        def job():
            inst = self.visa.open(addr)
            idn = inst.query("*IDN?").strip()
            self.inst = inst
            self.post("conn", addr, idn)
            self.setup_sensor()
        self.worker.tasks.put(job)

    def disconnect(self):
        self.running = False
        inst, self.inst = self.inst, None
        try:
            if inst is not None:
                inst.close()
        except Exception:
            pass
        self.post("disc")

    def setup_sensor(self):
        """평균 파워 측정으로 설정 (트리거: 한 번씩 INIT → FETCh?)"""
        i = self.inst
        for c in ("*CLS", "INIT:CONT OFF", 'SENS:FUNC "POW:AVG"', "SENS:AVER:STAT ON", "SENS:AVER:TCON REP",
                  "TRIG:SOUR IMM"):
            try:
                i.write(c)
            except Exception as e:
                self.post("log", "%s → %s" % (c, e), "err")
        self.apply_job()

    def apply(self):
        if self.inst is None:
            messagebox.showwarning(APP, "먼저 연결하세요.")
            return
        self.worker.tasks.put(self.apply_job)

    def apply_job(self):
        i = self.inst
        if i is None:
            return
        f = fnum(self.var_freq.get())
        n = int(fnum(self.var_avg.get(), 16) or 16)
        off = fnum(self.var_offs.get(), 0.0)
        cmds = []
        if f == f and f > 0:
            cmds.append("SENS:FREQ %.6E" % (f * 1e9))
        if self.var_avg_auto.get():
            cmds += ["SENS:AVER:COUN:AUTO ON"]
        else:
            cmds += ["SENS:AVER:COUN:AUTO OFF", "SENS:AVER:COUN %d" % max(1, min(n, 1048576))]
        cmds += ["SENS:CORR:OFFS %.4f" % (off if off == off else 0.0),
                 "SENS:CORR:OFFS:STAT %s" % ("ON" if (off == off and abs(off) > 1e-9) else "OFF")]
        for c in cmds:
            i.write(c)
        err = i.query("SYST:ERR?").strip()
        ok = err.startswith(("0", "+0"))
        self.post("log", "설정: %s  (SYST:ERR? %s)" % (" · ".join(cmds), err), "ok" if ok else "err")
        self.post("cfg")

    # ------------------------------------------------ 읽기
    def toggle_run(self):
        if self.inst is None:
            messagebox.showwarning(APP, "먼저 연결하세요.")
            return
        self.dt = max(0.05, fnum(self.var_dt.get(), 0.2))
        self.running = not self.running
        self.post("run")

    def measure_once(self):
        i = self.inst
        if i is None:
            return
        i.write("INIT:IMM")
        try:
            i.query("*OPC?")
        except Exception:
            time.sleep(0.05)
        raw = i.query("FETC?").strip()
        v = fnum(raw)
        if v != v:
            raise RuntimeError("값을 읽지 못함: %r" % raw)
        dbm = w_to_dbm(v) if v > 0 else (v if v < 0 else float("-inf"))   # 기본 단위 W → dBm
        self.post("val", dbm, v if v > 0 else 10 ** (dbm / 10) / 1e3, time.time())

    def zero(self):
        if self.inst is None:
            messagebox.showwarning(APP, "먼저 연결하세요.")
            return
        if not messagebox.askokcancel(APP, "영점 (Zero)\n\n센서에 RF 가 들어가지 않는 상태여야 합니다 (SG RF OFF).\n"
                                           "몇 초 걸립니다. 진행할까요?"):
            return
        was = self.running
        self.running = False

        def job():
            self.post("log", "영점 시작 (CAL:ZERO:AUTO ONCE)...")
            old = getattr(self.inst, "timeout", None)
            try:
                if old is not None:
                    self.inst.timeout = 20000
                self.inst.write("CAL:ZERO:AUTO ONCE")
                self.inst.query("*OPC?")
                err = self.inst.query("SYST:ERR?").strip()
                self.post("log", "영점 완료 (SYST:ERR? %s)" % err, "ok" if err.startswith(("0", "+0")) else "err")
            finally:
                if old is not None:
                    self.inst.timeout = old
                if was:
                    self.running = True
                    self.post("run")
        self.worker.tasks.put(job)

    def reset_stats(self):
        self.stats = []

    # ------------------------------------------------ 화면 갱신
    def pump(self):
        try:
            while True:
                self.handle(self.q.get_nowait())
        except queue.Empty:
            pass
        self.root.after(50, self.pump)

    def handle(self, m):
        k = m[0]
        if k == "log":
            tag = m[2] if len(m) > 2 else ""
            self.log.insert("end", time.strftime("%H:%M:%S ") + m[1] + "\n", tag)
            self.log.see("end")
        elif k == "scan":
            ok, res = m[1], m[2]
            if not ok:
                self.lbl_visa.configure(text=self.visa.err, foreground="#c62828")
            else:
                nrp = [r for r in res if "0X0AAD" in r.upper() or "NRP" in r.upper()]
                self.lbl_visa.configure(text="VISA OK · 주소 %d개%s" % (len(res), (" · R&S 센서 후보 %d개" % len(nrp)) if nrp else ""),
                                        foreground="#1f4f8f")
                vals = nrp + [r for r in res if r not in nrp] + ["DEMO"]
                self.cb_addr.configure(values=vals)
                if not self.var_addr.get() and nrp:
                    self.var_addr.set(nrp[0])
        elif k == "conn":
            self.btn_conn.configure(text="연결 해제")
            self.lbl_idn.configure(text="%s  ·  %s" % (m[1], m[2]), foreground="#1f4f8f")
            self.post("log", "연결: %s  %s" % (m[1], m[2]), "ok")
            self.s["nrp_addr"] = m[1]
            if not self.running:
                self.toggle_run()
        elif k == "disc":
            self.btn_conn.configure(text="연결")
            self.lbl_idn.configure(text="연결 안 됨", foreground="#666")
            self.handle(("run",))
        elif k == "run":
            self.btn_run.configure(text="■ 읽기 정지" if self.running else "▶ 계속 읽기")
            self.lbl_state.configure(text=" 읽는 중 " if self.running else " 정지 ", bg="#2e7d32" if self.running else "#555")
        elif k == "err_read":
            self.lbl_state.configure(text=" 오류 ", bg="#c62828")
        elif k == "cfg":
            self.update_info()
        elif k == "val":
            dbm, w, t = m[1], m[2], m[3]
            self.last = (dbm, t)
            self.hist.append((t, dbm))
            if dbm == dbm and dbm > -200:
                self.stats.append(dbm)
            self.lbl_dbm.configure(text=("%.2f dBm" % dbm) if dbm > -200 else "-∞ dBm")
            self.lbl_w.configure(text=self.fmt_w(w))
            self.update_info()
            self.draw()
            if self.on_value:
                try:
                    self.on_value(dbm, t)
                except Exception:
                    pass

    @staticmethod
    def fmt_w(w):
        if w is None or w != w:
            return ""
        if w >= 1:
            return "%.3f W" % w
        if w >= 1e-3:
            return "%.3f mW" % (w * 1e3)
        if w >= 1e-6:
            return "%.3f µW" % (w * 1e6)
        return "%.3f nW" % (w * 1e9)

    def update_info(self):
        st = self.stats[-2000:]
        txt = "주파수 %s GHz · 평균 %s · 오프셋 %s dB" % (self.var_freq.get(), "자동" if self.var_avg_auto.get() else self.var_avg.get(),
                                                   self.var_offs.get())
        if st:
            txt += "   |   최소 %.2f · 최대 %.2f · 평균 %.2f dBm (%d개)" % (min(st), max(st), sum(st) / len(st), len(st))
        self.lbl_info.configure(text=txt)

    def draw(self):
        cv = self.cv
        cv.delete("all")
        W, H = cv.winfo_width(), cv.winfo_height()
        if W < 80 or H < 50:
            return
        L, R, T, B = 52, 10, 10, 20
        pw, ph = W - L - R, H - T - B
        now = time.time()
        pts = [(t, p) for t, p in self.hist if now - t <= 60 and p == p and p > -200]
        if pts:
            lo, hi = min(p for _, p in pts), max(p for _, p in pts)
        else:
            lo, hi = -10, 10
        if hi - lo < 1:
            c = (hi + lo) / 2
            lo, hi = c - 0.5, c + 0.5
        m = (hi - lo) * 0.1
        lo, hi = lo - m, hi + m
        cv.create_rectangle(L, T, L + pw, T + ph, outline="#37474f")
        for k in range(5):
            y = T + ph - ph * k / 4
            cv.create_line(L, y, L + pw, y, fill="#1c262f")
            cv.create_text(L - 4, y, text="%.1f" % (lo + (hi - lo) * k / 4), anchor="e", fill="#78909c", font=("Consolas", 8))
        cv.create_text(L - 4, T + ph + 10, text="dBm", anchor="e", fill="#78909c", font=("Consolas", 8))
        if len(pts) > 1:
            xy = []
            for t, p in pts:
                xy += [L + pw - (now - t) / 60.0 * pw, T + ph - (p - lo) / (hi - lo) * ph]
            cv.create_line(*xy, fill="#69f0ae", width=2)
        cv.create_text(L, T + ph + 3, text="-60 s", anchor="nw", fill="#78909c", font=("Consolas", 8))
        cv.create_text(L + pw, T + ph + 3, text="지금", anchor="ne", fill="#78909c", font=("맑은 고딕", 8))

    def get_settings(self):
        return {"nrp_addr": self.var_addr.get().strip(), "nrp_freq": self.var_freq.get(), "nrp_avg": self.var_avg.get(),
                "nrp_avg_auto": self.var_avg_auto.get(), "nrp_offs": self.var_offs.get(), "nrp_dt": self.var_dt.get()}

    def shutdown(self):
        self.running = False
        self.worker.stop = True
        try:
            if self.inst is not None:
                self.inst.close()
        except Exception:
            pass

    def on_close(self):
        self.shutdown()
        try:
            import json
            import os
            p = os.path.join(os.path.expanduser("~"), ".nrp_power_meter.json")
            with open(p, "w", encoding="utf-8") as f:
                json.dump(self.get_settings(), f, ensure_ascii=False, indent=1)
        except Exception:
            pass
        self.root.destroy()
