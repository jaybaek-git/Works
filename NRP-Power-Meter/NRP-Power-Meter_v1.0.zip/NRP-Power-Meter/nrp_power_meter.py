"""NRP Power Meter - R&S NRP50S 파워 읽기 (단독 실행). 화면 · 읽기 코드는 nrp_panel.py (PA Bench Monitor 에도 넣을 예정)"""
import json
import os
import tkinter as tk

import nrp_panel


def main():
    s = {}
    try:
        with open(os.path.join(os.path.expanduser("~"), ".nrp_power_meter.json"), encoding="utf-8") as f:
            s = json.load(f)
    except Exception:
        pass
    root = tk.Tk()
    nrp_panel.App(root, settings=s)
    root.mainloop()


if __name__ == "__main__":
    main()
