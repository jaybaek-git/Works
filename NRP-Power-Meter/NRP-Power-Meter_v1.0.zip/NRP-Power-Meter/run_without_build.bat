@echo off
cd /d %~dp0
REM First time only:  python -m pip install pyvisa
python nrp_power_meter.py
if errorlevel 1 pause
