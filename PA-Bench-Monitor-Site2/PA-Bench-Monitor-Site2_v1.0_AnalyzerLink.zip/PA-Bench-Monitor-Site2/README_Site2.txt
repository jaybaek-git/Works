PA Bench Monitor Site2 v1.0  (PA Bench Monitor v2.5.84 기반 · PA Analyzer 연동판)

■ 무엇이 다른가
  - Vdd 파워서플라이를 2 대 (예: Keysight E3632A × 2, GPIB) 로 쓰는 자리용.
    예) 24 V + 24 V 를 직렬로 이어 48 V
  - 프로그램 안에서는 2 대가 1 대 (Vdd · Id) 로 보임 → 효율 (DE · PAE) 은 두 대 전력 합으로 계산
        DC 전력 = V1 × I1 + V2 × I2
        직렬: Vdd = V1 + V2,  Id = (V1×I1 + V2×I2) / Vdd   (직렬이라 두 전류는 거의 같음)
        병렬: Vdd = 두 전압 평균,  Id = I1 + I2
  - 나머지 (Pulse · Mod. · DPD · PA Analyzer · RTO) 는 PA Bench Monitor 와 같음
  - 바이어스 자동 순서 (psu_panel.py) 는 그대로 (장비를 여는 곳만 바깥에서 감쌈)

■ 연결 (GPIB)
  1. PC 에 USB-GPIB 어댑터 (Keysight 82357B · NI GPIB-USB 등) + Keysight IO Libraries (또는 NI-VISA) 설치
  2. E3632A 앞면 I/O Config → 인터페이스 GPIB · 주소를 두 대가 겹치지 않게 (예: 5 · 6)
  3. 파워서플라이 화면 [장비 찾기] 로 주소 확인 (GPIB0::5::INSTR 처럼)
  4. 'E36155A (Vdd) 주소' 칸에 두 주소를 이어서 넣고 [연결]
        직렬 (Vdd 합):   GPIB0::5::INSTR + GPIB0::6::INSTR
        병렬 (전류 합):  GPIB0::5::INSTR || GPIB0::6::INSTR
        장비 없이 시험:  DEMO + DEMO
     → 연결 정보에 'Site2 직렬 2 대 … : (1 번 장비) + (2 번 장비)' 로 나오면 됨
  5. 게이트 바이어스 (N6705C) 는 예전처럼 'N6705C 주소' 칸에 (E3632A 는 + 전압 한 채널이라 게이트는 못 맡음)

■ 설정 값이 어떻게 나뉘나
  - Vdd 설정: 직렬 = 각 대에 Vdd / 2 (48 V → 24 V 씩), 병렬 = 각 대에 Vdd
  - 전류 제한: 직렬 = 각 대 그대로, 병렬 = 반씩 (각 장비 최대값을 넘지 않게)
  - 출력 켜기 · 끄기: 두 대 같이 (켤 때 1 → 2, 끌 때 2 → 1). 한 대라도 켜져 있으면 '켜짐' 으로 보임 → 끄면 둘 다 꺼짐
  - E3632A 는 켰을 때 15 V 범위 (최대 15 V · 7 A) → 연결할 때 출력이 꺼져 있으면 30 V 범위 (최대 30 V · 4 A) 로 바꿔 둠
    (출력이 켜져 있으면 안 바꿈 → 15 V 넘게 못 냄. 그때는 출력을 끄고 다시 [연결])

■ 주의
  - E3632A 는 최대 30 V: 48 V 는 직렬 2 대로만. Vdd 안전 한계를 자리에 맞게 넣으세요
  - GPIB 로 읽기는 LAN 보다 조금 느림 (한 번 읽는 데 수백 ms) → 화면 갱신이 약간 늦을 수 있음
  - 설정 폴더는 PA Bench Monitor 와 같음 (%APPDATA%\PABenchMonitor) → 같은 PC 에서 두 프로그램을 같이 쓰면 설정을 같이 씀

■ 실행
  - EXE 만들기: build_exe_site2.bat  → dist\PA-Bench-Monitor-Site2_v1.0\PA-Bench-Monitor-Site2_v1.0.exe
  - 빌드 없이: run_without_build_site2.bat  (python pa_bench_monitor_site2.py)
