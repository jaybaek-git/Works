"""
site2  -  PA Bench Monitor Site2 용: Vdd 파워서플라이 2 대 (예: Keysight E3632A × 2, GPIB) 를 1 대처럼

  · 파워서플라이 화면의 'E36155A (Vdd) 주소' 칸에 두 주소를 이어서 넣음
        직렬 (24 V + 24 V = 48 V):   GPIB0::5::INSTR + GPIB0::6::INSTR
        병렬 (같은 전압, 전류 합):    GPIB0::5::INSTR || GPIB0::6::INSTR
        장비 없이 시험:              DEMO + DEMO
  · 프로그램에는 1 대 (Vdd · Id) 로 보임 → 효율 (DE · PAE) 은 두 대 전력 합으로 정확히
        DC 전력 = V1·I1 + V2·I2
        직렬: Vdd = V1 + V2,  Id = (V1·I1 + V2·I2) / Vdd   (직렬이라 두 전류는 거의 같음)
        병렬: Vdd = (V1 + V2) / 2,  Id = I1 + I2
  · 설정: 직렬이면 각 대에 Vdd / 2, 병렬이면 각 대에 Vdd. 전류 제한은 직렬 = 각 대 그대로, 병렬 = 반씩
  · E3632A 는 처음에 15 V 범위 (최대 15 V · 7 A) 라서 출력이 꺼져 있으면 30 V 범위 (최대 30 V · 4 A) 로 바꿔 둠

psu_panel.py (바이어스 자동 순서) 는 고치지 않음: 장비를 여는 곳 (Visa.open) 만 바깥에서 감싸서 2 대를 1 대처럼 보이게 함.
"""
import math

SITE = "Site2"
SITE_VER = "v1.0"


def _f(s):
    try:
        return float(str(s).strip().split(",")[0])
    except ValueError:
        return float("nan")


class DualPSU:
    """두 대를 1 대 (E36155A 와 같은 SCPI) 처럼. query · write · close 만 씀 (psu_panel 이 쓰는 것)"""

    def __init__(self, a, b, mode="series", names=("A", "B"), log=None):
        self.d = [a, b]
        self.mode = mode
        self.names = names
        self.log = log or (lambda *_: None)
        self.imax = [float("nan"), float("nan")]
        self.idn = []
        for i, x in enumerate(self.d):
            try:
                self.idn.append(x.query("*IDN?").strip())
            except Exception as e:
                self.idn.append("? (%s)" % e)
        self._prep()

    # --- 처음 연결: E3632A 범위 · 최대 전류
    def _prep(self):
        for i, x in enumerate(self.d):
            idn = self.idn[i].upper()
            if "E363" in idn:                               # E3632A · E3633A · E3634A: 범위가 둘
                try:
                    if x.query("OUTP?").strip() in ("0", "OFF"):
                        x.write("VOLT:RANG P30V" if "E3632" in idn else "VOLT:RANG HIGH")
                except Exception:
                    pass
            try:
                self.imax[i] = _f(x.query("CURR? MAX"))
            except Exception:
                pass

    @property
    def timeout(self):
        return getattr(self.d[0], "timeout", 3000)

    @timeout.setter
    def timeout(self, v):
        for x in self.d:
            try:
                x.timeout = v
            except Exception:
                pass

    def _both(self, q):
        return [x.query(q).strip() for x in self.d]

    def query(self, cmd):
        c = cmd.strip().upper()
        if c == "*IDN?":
            return "%s %s 2 대 (E361 호환 · %s): %s  +  %s" % (SITE, "직렬" if self.mode == "series" else "병렬",
                                                          "Vdd 합" if self.mode == "series" else "전류 합", self.idn[0], self.idn[1])
        if c.startswith("SYST:ERR"):
            r = self._both(cmd)
            for x in r:
                if not x.startswith(("+0", "0")):
                    return x
            return r[0]
        if c.startswith("MEAS:VOLT") or c.startswith("MEAS:CURR"):
            v = [_f(x) for x in self._both("MEAS:VOLT?")]
            i = [_f(x) for x in self._both("MEAS:CURR?")]
            if c.startswith("MEAS:VOLT"):
                return "%+.6E" % (v[0] + v[1] if self.mode == "series" else (v[0] + v[1]) / 2)
            if self.mode == "series":
                vs = v[0] + v[1]
                p = v[0] * i[0] + v[1] * i[1]
                return "%+.6E" % (p / vs if vs > 0.05 else (i[0] + i[1]) / 2)
            return "%+.6E" % (i[0] + i[1])
        if c.startswith("VOLT?"):
            v = [_f(x) for x in self._both(cmd)]
            return "%+.6E" % (v[0] + v[1] if self.mode == "series" else (v[0] + v[1]) / 2)
        if c.startswith("CURR?"):
            i = [_f(x) for x in self._both(cmd)]
            return "%+.6E" % (min(i) if self.mode == "series" else i[0] + i[1])
        if c.startswith("OUTP?"):
            r = self._both(cmd)
            return "1" if any(x in ("1", "ON") for x in r) else "0"      # 한 대라도 켜져 있으면 켜짐 (끌 때 둘 다 끄게)
        return self.d[0].query(cmd)

    def write(self, cmd):
        c = cmd.strip()
        cu = c.upper()
        parts = cu.split()
        if cu.startswith("VOLT ") and len(parts) > 1 and not cu.startswith("VOLT:"):
            v = _f(parts[1])
            each = v / 2 if self.mode == "series" else v
            for x in self.d:
                x.write("VOLT %.4f" % each)
            return
        if cu.startswith("CURR ") and len(parts) > 1 and not cu.startswith("CURR:"):
            a = _f(parts[1])
            each = a if self.mode == "series" else a / 2
            for k, x in enumerate(self.d):
                m = self.imax[k]
                x.write("CURR %.4f" % (min(each, m) if m == m and m > 0 else each))
            return
        if cu.startswith("OUTP"):
            on = len(parts) > 1 and parts[1] in ("ON", "1")
            order = self.d if on else list(reversed(self.d))
            for x in order:                                 # 켤 땐 A → B, 끌 땐 B → A (거의 동시에)
                x.write("OUTP %s" % ("ON" if on else "OFF"))
            return
        for x in self.d:                                    # *CLS 등: 둘 다
            x.write(cmd)

    def close(self):
        for x in self.d:
            try:
                x.close()
            except Exception:
                pass


def split_addr(res):
    r = (res or "").strip()
    for sep, mode in (("||", "parallel"), ("+", "series")):
        if sep in r:
            parts = [p.strip() for p in r.split(sep) if p.strip()]
            if len(parts) == 2:
                return parts, mode
    return None, None


def install():
    """psu_panel 의 장비 열기를 감쌈: 주소에 '+' (직렬) · '||' (병렬) 이 있으면 2 대를 1 대로"""
    import psu_panel as P
    if getattr(P.Visa, "_site2", False):
        return
    orig_open = P.Visa.open

    def open2(self, res, timeout_ms=3000):
        parts, mode = split_addr(res)
        if parts is None:
            return orig_open(self, res, timeout_ms)
        insts = []
        try:
            for i, a in enumerate(parts):
                if a.upper().startswith("DEMO"):
                    d = P.DemoInst("E36155A")
                    d.ev = 24.0 if mode == "series" else 48.0
                    d.ei = 3.0 if mode == "series" else 1.5
                    if getattr(self, "demo", {}).get("N6705C") is not None:
                        d.peer = self.demo["N6705C"]
                    self.demo = getattr(self, "demo", {})
                    self.demo["E36155A"] = d
                    insts.append(d)
                else:
                    insts.append(orig_open(self, P.fix_addr(a), timeout_ms))
        except Exception:
            for x in insts:
                try:
                    x.close()
                except Exception:
                    pass
            raise
        return DualPSU(insts[0], insts[1], mode)

    P.Visa.open = open2
    P.Visa._site2 = True
    # 주소 칸 자동 고침이 '+' · '||' 를 망가뜨리지 않게: 각 주소만 고침
    orig_fix = P.fix_addr

    def fix2(a):
        parts, mode = split_addr(a)
        if parts is None:
            return orig_fix(a)
        return (" + " if mode == "series" else " || ").join(orig_fix(p) for p in parts)
    P.fix_addr = fix2
