PA Bench Monitor Site2 v1.1  (PA Bench Monitor v2.5.84 기반 · PA Analyzer 연동판)

■ v1.1 변경점 - Site2 게이트 · Vdd 장비 구성 · 바이어스 자동 순서
  - 게이트 3 곳을 장비 3 대에서: 캐리어 = N6705C CH1 · 드라이버 = E3631A (1) +6V · 피킹 = E3631A (2) +6V (둘 다 반대로 연결)
  - 드라이버 앰프 전원 (N6705C CH3): 바이어스 ON 때 맨 먼저 켜고, 바이어스 OFF 때 게이트를 다 끈 뒤 맨 마지막에 끔
  - Vdd (E3632A × 2 직렬, GPIB 8 · 9): 앞 장비 (8 번) 를 먼저 24 V 까지 → 그 다음 뒤 장비 (9 번) 24 V → 합 48 V
    · 한 대에 24 V 넘게는 절대 안 걸음 (48 V 넘게 요청해도 48 V) · 내릴 땐 뒤 장비 먼저
    · 연결할 때 한 대라도 24 V 넘게 맞춰져 있으면 24 V 로 내림
  - 바이어스 자동 순서 (psu_panel.py) 는 그대로: 게이트 ON (핀치오프) → Vdd 0 → 48 V → 캐리어 → 드라이버 게이트로 목표 Id
    (프로그램이 보는 게이트 · Vdd 는 예전과 같은 1 대 · 4 채널. 장비를 여는 곳만 바깥에서 감싸 나눠 보냄)

■ v1.0
  - Vdd 파워서플라이 2 대를 1 대처럼 (직렬 Vdd 합 / 병렬 전류 합) · 효율 = 두 대 전력 합 (V1×I1 + V2×I2)

■ 장비 · 주소 (모두 GPIB · USB-GPIB 어댑터 + Keysight IO Libraries 또는 NI-VISA)
  파워서플라이 화면에서:
  - 'E36155A (Vdd) 주소' 칸:
        GPIB0::8::INSTR + GPIB0::9::INSTR          (직렬 · 앞 = 먼저 24 V 올리는 장비)
  - 'N6705C 주소' 칸:
        N6705C=GPIB0::5::INSTR, DRV=GPIB0::6::INSTR, PK=GPIB0::7::INSTR
        (주소 번호는 그 자리에 맞게 · 캐리어 채널 · 드라이버 앰프 전원 채널을 바꿀 땐 뒤에 , CA_CH=1, DA_CH=3)
  - 장비 없이 시험:  Vdd 'DEMO + DEMO' · 게이트 'N6705C=DEMO, DRV=DEMO, PK=DEMO'
  → [연결] 하면 연결 정보에 'Site2 직렬 2 대 …' · 'Site2 게이트 (… CH1 DRV=E3631A · CH2 CA=N6705C CH1 · CH3 PK=E3631A) …' 로 나옴

  프로그램 화면의 게이트 채널 (예전과 같은 이름):
        CH1 DRV (노랑) = E3631A (1) +6V      CH2 CA (초록) = N6705C CH1      CH3 PK (파랑) = E3631A (2) +6V
        CH4 = N6705C 의 남는 채널 (CH4)       드라이버 앰프 전원 N6705C CH3 = 화면에 안 나옴 (자동으로 켜고 끔)

■ 꼭 확인
  - E3631A 는 출력 켜기 · 끄기가 세 출력 (+6V · +25V · −25V) 같이 됨 → 연결할 때 출력이 꺼져 있으면 +25V · −25V 를 0 V 로 둠.
    그 출력에 다른 것을 연결해 쓰고 있으면 안 됨
  - 게이트는 +6V 출력을 반대로 연결 → 화면 · 설정 값은 + (예: 3.20 = 게이트 −3.20 V). 예전 N6705C 와 같은 방식
  - 드라이버 앰프 전원 (N6705C CH3) 전압은 N6705C 에 미리 맞춰 두세요 (프로그램은 켜기 · 끄기만)
  - E3632A 는 처음 15 V 범위 → 연결할 때 출력이 꺼져 있으면 30 V 범위로 바꿈. 켜진 채로 연결하면 못 바꿔서 15 V 까지만 → 끄고 다시 [연결]
  - Vdd 목표 · 안전 한계는 48 V 이하로 (장비가 24 V + 24 V 까지만)
  - GPIB 는 LAN 보다 조금 느림 (장비 5 대 → 한 번 읽는 데 1 초 가까이 걸릴 수 있음)
  - 설정 폴더는 PA Bench Monitor 와 같음 (%APPDATA%\PABenchMonitor)

■ 실행
  - EXE 만들기: build_exe_site2.bat  → dist\PA-Bench-Monitor-Site2_v1.1\PA-Bench-Monitor-Site2_v1.1.exe
  - 빌드 없이: run_without_build_site2.bat  (python pa_bench_monitor_site2.py)
