"""PA Bench Monitor Site2 - Vdd 파워서플라이 2 대 (예: E3632A × 2, GPIB) 를 1 대처럼 (직렬 24 V + 24 V 등)
나머지는 PA Bench Monitor 와 같음. 자세한 것: site2.py · README_Site2.txt"""
import site2
site2.install()                      # psu_panel 의 장비 열기만 감쌈 (바이어스 자동 순서는 그대로)
import pa_bench_monitor as bm

bm.APP_NAME = "PA Bench Monitor %s" % site2.SITE
bm.VERSION = "%s (%s %s)" % (bm.VERSION, site2.SITE, site2.SITE_VER)

if __name__ == "__main__":
    bm.main()
