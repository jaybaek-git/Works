"""
site2  -  PA Bench Monitor Site2 용: Vdd 파워서플라이 2 대 (예: Keysight E3632A × 2, GPIB) 를 1 대처럼

  · 파워서플라이 화면의 'E36155A (Vdd) 주소' 칸에 두 주소를 이어서 넣음
        직렬 (24 V + 24 V = 48 V):   GPIB0::5::INSTR + GPIB0::6::INSTR
        병렬 (같은 전압, 전류 합):    GPIB0::5::INSTR || GPIB0::6::INSTR
        장비 없이 시험:              DEMO + DEMO
  · 프로그램에는 1 대 (Vdd · Id) 로 보임 → 효율 (DE · PAE) 은 두 대 전력 합으로 정확히
        DC 전력 = V1·I1 + V2·I2
        직렬: Vdd = V1 + V2,  Id = (V1·I1 + V2·I2) / Vdd   (직렬이라 두 전류는 거의 같음)
        병렬: Vdd = (V1 + V2) / 2,  Id = I1 + I2
  · 설정 (직렬): 앞 주소 장비를 먼저 24 V 까지 올리고, 그 다음 뒤 장비를 24 V 까지 → 합 48 V
        Vdd 30 V → 24 V + 6 V · 48 V → 24 V + 24 V · 한 대에 24 V 넘게는 절대 안 걸음 (48 V 넘게 요청해도 48 V)
        내릴 땐 반대로 (뒤 장비 먼저 0 V 쪽으로)
    병렬이면 각 대에 Vdd. 전류 제한은 직렬 = 각 대 그대로, 병렬 = 반씩
  · E3632A 는 처음에 15 V 범위 (최대 15 V · 7 A) 라서 출력이 꺼져 있으면 30 V 범위 (최대 30 V · 4 A) 로 바꿔 둠

게이트 (Site2): 캐리어 = N6705C CH1 · 드라이버 = E3631A (1) +6V 출력 (반대로 연결) · 피킹 = E3631A (2) +6V 출력 (반대로 연결)
  · 'N6705C 주소' 칸에:  N6705C=GPIB0::5::INSTR, DRV=GPIB0::7::INSTR, PK=GPIB0::8::INSTR
        (장비 없이: N6705C=DEMO, DRV=DEMO, PK=DEMO · 바꿀 때: CA_CH=1 · DA_CH=3)
  · 프로그램에는 예전처럼 N6705C 4 채널로 보임: CH1 = DRV (E3631A 1) · CH2 = CA (N6705C CH1) · CH3 = PK (E3631A 2) · CH4 = N6705C CH4
  · 드라이버 앰프 전원 (N6705C CH3): 게이트를 켤 때 맨 먼저 켜고, 게이트를 다 끈 뒤 맨 마지막에 끔 (전압은 N6705C 에 미리 맞춰 둔 값)
  · E3631A 는 출력 켜기 · 끄기가 세 출력 (+6V · +25V · −25V) 같이 → 연결할 때 출력이 꺼져 있으면 +25V · −25V 를 0 V 로 둠

psu_panel.py (바이어스 자동 순서) 는 고치지 않음: 장비를 여는 곳 (Visa.open) 만 바깥에서 감싸서 2 대를 1 대처럼 보이게 함.
"""
import math

SITE = "Site2"
EACH_MAX = 24.0          # 직렬 Vdd: 한 대에 절대 이 값 넘게 안 걸음 (Site2 = 24 V + 24 V = 48 V)
SITE_VER = "v1.1"


def _f(s):
    try:
        return float(str(s).strip().split(",")[0])
    except ValueError:
        return float("nan")


class DualPSU:
    """두 대를 1 대 (E36155A 와 같은 SCPI) 처럼. query · write · close 만 씀 (psu_panel 이 쓰는 것)"""

    def __init__(self, a, b, mode="series", names=("A", "B"), log=None):
        self.d = [a, b]
        self.mode = mode
        self.names = names
        self.log = log or (lambda *_: None)
        self.imax = [float("nan"), float("nan")]
        self.idn = []
        for i, x in enumerate(self.d):
            try:
                self.idn.append(x.query("*IDN?").strip())
            except Exception as e:
                self.idn.append("? (%s)" % e)
        self._prep()

    # --- 처음 연결: E3632A 범위 · 최대 전류
    def _prep(self):
        for i, x in enumerate(self.d):
            idn = self.idn[i].upper()
            if "E363" in idn:                               # E3632A · E3633A · E3634A: 범위가 둘
                try:
                    if x.query("OUTP?").strip() in ("0", "OFF"):
                        x.write("VOLT:RANG P30V" if "E3632" in idn else "VOLT:RANG HIGH")
                except Exception:
                    pass
            try:
                self.imax[i] = _f(x.query("CURR? MAX"))
            except Exception:
                pass
            if self.mode == "series":                       # 이미 24 V 넘게 맞춰져 있으면 24 V 로 (안전)
                try:
                    if _f(x.query("VOLT?")) > EACH_MAX + 1e-6:
                        x.write("VOLT %.4f" % EACH_MAX)
                        self.log("Vdd %d 번 장비 설정이 %.0f V 를 넘어 %.0f V 로 내림" % (i + 1, EACH_MAX, EACH_MAX))
                except Exception:
                    pass

    @property
    def timeout(self):
        return getattr(self.d[0], "timeout", 3000)

    @timeout.setter
    def timeout(self, v):
        for x in self.d:
            try:
                x.timeout = v
            except Exception:
                pass

    def _both(self, q):
        return [x.query(q).strip() for x in self.d]

    def query(self, cmd):
        c = cmd.strip().upper()
        if c == "*IDN?":
            return "%s %s 2 대 (E361 호환 · %s): %s  +  %s" % (SITE, "직렬" if self.mode == "series" else "병렬",
                                                          "Vdd 합" if self.mode == "series" else "전류 합", self.idn[0], self.idn[1])
        if c.startswith("SYST:ERR"):
            r = self._both(cmd)
            for x in r:
                if not x.startswith(("+0", "0")):
                    return x
            return r[0]
        if c.startswith("MEAS:VOLT") or c.startswith("MEAS:CURR"):
            v = [_f(x) for x in self._both("MEAS:VOLT?")]
            i = [_f(x) for x in self._both("MEAS:CURR?")]
            if c.startswith("MEAS:VOLT"):
                return "%+.6E" % (v[0] + v[1] if self.mode == "series" else (v[0] + v[1]) / 2)
            if self.mode == "series":
                vs = v[0] + v[1]
                p = v[0] * i[0] + v[1] * i[1]
                return "%+.6E" % (p / vs if vs > 0.05 else (i[0] + i[1]) / 2)
            return "%+.6E" % (i[0] + i[1])
        if c.startswith("VOLT?"):
            v = [_f(x) for x in self._both(cmd)]
            return "%+.6E" % (v[0] + v[1] if self.mode == "series" else (v[0] + v[1]) / 2)
        if c.startswith("CURR?"):
            i = [_f(x) for x in self._both(cmd)]
            return "%+.6E" % (min(i) if self.mode == "series" else i[0] + i[1])
        if c.startswith("OUTP?"):
            r = self._both(cmd)
            return "1" if any(x in ("1", "ON") for x in r) else "0"      # 한 대라도 켜져 있으면 켜짐 (끌 때 둘 다 끄게)
        return self.d[0].query(cmd)

    def write(self, cmd):
        c = cmd.strip()
        cu = c.upper()
        parts = cu.split()
        if cu.startswith("VOLT ") and len(parts) > 1 and not cu.startswith("VOLT:"):
            v = _f(parts[1])
            if self.mode == "series":
                v = max(0.0, min(v, 2 * EACH_MAX))
                va = min(v, EACH_MAX)                        # 앞 장비 먼저 24 V 까지
                vb = min(max(v - EACH_MAX, 0.0), EACH_MAX)   # 그 다음 뒤 장비
                try:
                    up = v >= _f(self.query("VOLT?")) - 1e-6
                except Exception:
                    up = True
                order = [(0, va), (1, vb)] if up else [(1, vb), (0, va)]   # 올릴 땐 앞 → 뒤 · 내릴 땐 뒤 → 앞
                for j, (k, vv) in enumerate(order):
                    try:
                        old = _f(self.d[k].query("VOLT?"))
                    except Exception:
                        old = float("nan")
                    self.d[k].write("VOLT %.4f" % vv)
                    if j == 0 and abs(vv - old) > 1.0 and abs(order[1][1] - _f(self.d[order[1][0]].query("VOLT?"))) > 1e-3:
                        time.sleep(0.4)                     # 앞 장비가 다 올라간 (내려간) 뒤 다음 장비
                return
            for x in self.d:
                x.write("VOLT %.4f" % v)
            return
        if cu.startswith("CURR ") and len(parts) > 1 and not cu.startswith("CURR:"):
            a = _f(parts[1])
            each = a if self.mode == "series" else a / 2
            for k, x in enumerate(self.d):
                m = self.imax[k]
                x.write("CURR %.4f" % (min(each, m) if m == m and m > 0 else each))
            return
        if cu.startswith("OUTP"):
            on = len(parts) > 1 and parts[1] in ("ON", "1")
            order = self.d if on else list(reversed(self.d))
            for x in order:                                 # 켤 땐 A → B, 끌 땐 B → A (거의 동시에)
                x.write("OUTP %s" % ("ON" if on else "OFF"))
            return
        for x in self.d:                                    # *CLS 등: 둘 다
            x.write(cmd)

    def close(self):
        for x in self.d:
            try:
                x.close()
            except Exception:
                pass


import re
import time


def _chs(cmd):
    """'(@1,2,3)' · '(@1:4)' → [1, 2, 3]"""
    m = re.search(r"\(@([^)]*)\)", cmd)
    if not m:
        return None
    out = []
    for part in m.group(1).split(","):
        part = part.strip()
        if ":" in part:
            a, b = part.split(":")
            out += list(range(int(a), int(b) + 1))
        elif part:
            out.append(int(part))
    return out


class Demo3631:
    """가상 E3631A (+6V · +25V · −25V, 출력 켜기는 세 출력 같이)"""

    def __init__(self):
        self.out = False
        self.sel = "P6V"
        self.v = {"P6V": 0.0, "P25V": 3.0, "N25V": -2.0}
        self.i = {"P6V": 1.0, "P25V": 1.0, "N25V": 1.0}

    def query(self, cmd):
        import random
        c = cmd.strip().upper()
        if c == "*IDN?":
            return "HEWLETT-PACKARD,E3631A,0,2.1-5.0-1.0 (DEMO)"
        if c.startswith("SYST:ERR"):
            return '+0,"No error"'
        if c.startswith("OUTP?"):
            return "1" if self.out else "0"
        if c.startswith("INST:SEL?") or c.startswith("INST?"):
            return self.sel
        o = c.split()[-1] if c.startswith("MEAS") and " " in c else self.sel
        if c.startswith("MEAS:VOLT"):
            return "%+.6E" % ((self.v[o] + random.uniform(-0.0005, 0.0005)) if self.out else 0.0)
        if c.startswith("MEAS:CURR"):
            return "%+.6E" % (random.uniform(0, 2e-4) if self.out else 0.0)
        if c.startswith("VOLT?"):
            return "%+.6E" % self.v[self.sel]
        if c.startswith("CURR?"):
            return "%+.6E" % self.i[self.sel]
        return "0"

    def write(self, cmd):
        c = cmd.strip().upper()
        val = c.split()[1] if " " in c else ""
        if c.startswith("OUTP"):
            self.out = val in ("ON", "1")
        elif c.startswith("INST:SEL") or c.startswith("INST "):
            self.sel = val
        elif c.startswith("VOLT ") and not c.startswith("VOLT:"):
            self.v[self.sel] = float(val)
        elif c.startswith("CURR ") and not c.startswith("CURR:"):
            self.i[self.sel] = float(val)

    def close(self):
        pass


class GateMux:
    """게이트 3 곳 (N6705C · E3631A × 2) 을 N6705C 1 대 (4 채널) 처럼.
    가상 CH1 = DRV (E3631A 1 · +6V) · CH2 = CA (N6705C ca_ch) · CH3 = PK (E3631A 2 · +6V) · CH4 = N6705C CH4
    드라이버 앰프 전원 N6705C da_ch: 게이트를 켤 때 맨 먼저 ON · 게이트가 다 꺼지면 맨 마지막에 OFF"""
    OUT = "P6V"

    def __init__(self, n, drv, pk, ca_ch=1, da_ch=3, log=None):
        self.n, self.drv, self.pk = n, drv, pk
        self.ca_ch, self.da_ch = int(ca_ch), int(da_ch)
        self.log = log or (lambda *_: None)
        free = [c for c in (4, 2, 1, 3) if c not in (self.ca_ch, self.da_ch)]
        self.map = {1: ("e", drv), 2: ("n", self.ca_ch), 3: ("e", pk), 4: ("n", free[0] if free else None)}
        self.idn = {}
        for nm, d in (("N6705C", n), ("DRV", drv), ("PK", pk)):
            try:
                self.idn[nm] = d.query("*IDN?").strip()
            except Exception as e:
                self.idn[nm] = "? (%s)" % e
        for d in (drv, pk):                                 # 안 쓰는 +25V · −25V 는 0 V (출력이 꺼져 있을 때만)
            try:
                if d.query("OUTP?").strip() in ("0", "OFF"):
                    for o in ("P25V", "N25V"):
                        d.write("INST:SEL %s" % o)
                        d.write("VOLT 0")
                d.write("INST:SEL %s" % self.OUT)
            except Exception:
                pass

    @property
    def timeout(self):
        return getattr(self.n, "timeout", 3000)

    @timeout.setter
    def timeout(self, v):
        for d in (self.n, self.drv, self.pk):
            try:
                d.timeout = v
            except Exception:
                pass

    # 가상 장비 (데모 Vdd 전류 계산용): out · vset
    @property
    def out(self):
        return {c: self._one("OUTP?", c) in ("1", "ON") for c in (1, 2, 3, 4)}

    @property
    def vset(self):
        return {c: _f(self._one("VOLT?", c)) for c in (1, 2, 3, 4)}

    def _one(self, head, c):
        kind, x = self.map.get(c, ("n", None))
        if x is None:
            return "0" if head.startswith("OUTP") else "+0.000000E+00"
        if kind == "n":
            return self.n.query("%s (@%d)" % (head, x)).strip()
        if head.startswith("OUTP"):
            return x.query("OUTP?").strip()
        if head.startswith("MEAS:"):
            return x.query("%s %s" % (head, self.OUT)).strip()
        x.write("INST:SEL %s" % self.OUT)
        return x.query(head).strip()

    def query(self, cmd):
        c = cmd.strip().upper()
        if c == "*IDN?":
            return "Site2 게이트 (N67 호환 · CH1 DRV=E3631A · CH2 CA=N6705C CH%d · CH3 PK=E3631A): %s | %s | %s" % (
                self.ca_ch, self.idn["N6705C"], self.idn["DRV"], self.idn["PK"])
        if c.startswith("SYST:ERR"):
            for d in (self.n, self.drv, self.pk):
                r = d.query(cmd).strip()
                if not r.startswith(("+0", "0")):
                    return r
            return '+0,"No error"'
        if c.startswith("SYST:CHAN:COUN"):
            return "4"
        chs = _chs(c)
        if c.startswith("SYST:CHAN:MOD"):
            nm = []
            for ch in chs or [1, 2, 3, 4]:
                kind, x = self.map[ch]
                if kind == "e":
                    nm.append("E3631A +6V")
                elif x is None:
                    nm.append("-")
                else:
                    try:
                        nm.append(self.n.query("SYST:CHAN:MOD? (@%d)" % x).strip().strip('"'))
                    except Exception:
                        nm.append("N6705C CH%d" % x)
            return ",".join(nm)
        if chs is None:
            return self.n.query(cmd)
        head = c.split()[0]
        return ",".join(self._one(head, ch) for ch in chs)

    def _gates_on(self):
        return any(self._one("OUTP?", c) in ("1", "ON") for c in (1, 2, 3))

    def write(self, cmd):
        c = cmd.strip()
        cu = c.upper()
        chs = _chs(cu)
        if chs is None:
            self.n.write(cmd)
            return
        head = cu.split()[0]
        val = cu.split()[1].split(",")[0] if " " in cu else ""
        if head == "OUTP":
            on = val in ("ON", "1")
            if on:                                          # 드라이버 앰프 전원: 맨 먼저
                if self.n.query("OUTP? (@%d)" % self.da_ch).strip() not in ("1", "ON"):
                    self.n.write("OUTP ON,(@%d)" % self.da_ch)
                    self.log("드라이버 앰프 전원 ON (N6705C CH%d) - 게이트보다 먼저" % self.da_ch)
                    time.sleep(0.2)
            for ch in chs:
                kind, x = self.map.get(ch, ("n", None))
                if x is None:
                    continue
                if kind == "n":
                    self.n.write("OUTP %s,(@%d)" % ("ON" if on else "OFF", x))
                else:
                    x.write("OUTP %s" % ("ON" if on else "OFF"))
            if not on and not self._gates_on():             # 게이트가 다 꺼짐 → 드라이버 앰프 전원 맨 마지막에
                time.sleep(0.2)
                self.n.write("OUTP OFF,(@%d)" % self.da_ch)
                self.log("드라이버 앰프 전원 OFF (N6705C CH%d) - 게이트를 다 끈 뒤 마지막" % self.da_ch)
            return
        if head in ("VOLT", "CURR"):
            for ch in chs:
                kind, x = self.map.get(ch, ("n", None))
                if x is None:
                    continue
                if kind == "n":
                    self.n.write("%s %s,(@%d)" % (head, val, x))
                else:
                    x.write("INST:SEL %s" % self.OUT)
                    x.write("%s %s" % (head, val))
            return
        # 그 밖에 채널 붙은 명령: N6705C 채널만 바꿔서
        for ch in chs:
            kind, x = self.map.get(ch, ("n", None))
            if kind == "n" and x is not None:
                self.n.write(re.sub(r"\(@[^)]*\)", "(@%d)" % x, c))

    def close(self):
        for d in (self.n, self.drv, self.pk):
            try:
                d.close()
            except Exception:
                pass


def gate_addr(res):
    """'N6705C=GPIB0::5::INSTR, DRV=GPIB0::7::INSTR, PK=GPIB0::8::INSTR [, CA_CH=1, DA_CH=3]' → dict · 아니면 None"""
    r = (res or "").strip()
    if "=" not in r:
        return None
    d = {}
    for part in re.split(r"[,;]", r):
        if "=" in part:
            k, v = part.split("=", 1)
            d[k.strip().upper()] = v.strip()
    if not all(k in d for k in ("N6705C", "DRV", "PK")):
        return None
    return d


def split_addr(res):
    r = (res or "").strip()
    for sep, mode in (("||", "parallel"), ("+", "series")):
        if sep in r:
            parts = [p.strip() for p in r.split(sep) if p.strip()]
            if len(parts) == 2:
                return parts, mode
    return None, None


def install():
    """psu_panel 의 장비 열기를 감쌈: 주소에 '+' (직렬) · '||' (병렬) 이 있으면 2 대를 1 대로"""
    import psu_panel as P
    if getattr(P.Visa, "_site2", False):
        return
    orig_open = P.Visa.open

    def one(self, a, kind, timeout_ms):
        if a.upper().startswith("DEMO"):
            if kind == "3631":
                return Demo3631()
            d = P.DemoInst("N6705C")
            d.out = {1: False, 2: False, 3: False, 4: False}      # 데모: 처음엔 다 꺼짐 (실제 장비처럼)
            d.vset[3] = 5.0                                         # CH3 = 드라이버 앰프 전원 (데모 값)
            return d
        return orig_open(self, P.fix_addr(a), timeout_ms)

    def open2(self, res, timeout_ms=3000):
        g = gate_addr(res)
        if g is not None:
            opened = []
            try:
                n = one(self, g["N6705C"], "n", timeout_ms)
                opened.append(n)
                drv = one(self, g["DRV"], "3631", timeout_ms)
                opened.append(drv)
                pk = one(self, g["PK"], "3631", timeout_ms)
                opened.append(pk)
            except Exception:
                for x in opened:
                    try:
                        x.close()
                    except Exception:
                        pass
                raise
            gm = GateMux(n, drv, pk, int(g.get("CA_CH", 1) or 1), int(g.get("DA_CH", 3) or 3))
            self.demo = getattr(self, "demo", {})
            self.demo["N6705C"] = gm
            for v_ in getattr(self, "demo_vdd", []):          # 데모 Vdd 전류가 게이트를 따라가게
                v_.peer = gm
            return gm
        parts, mode = split_addr(res)
        if parts is None:
            return orig_open(self, res, timeout_ms)
        insts = []
        try:
            for i, a in enumerate(parts):
                if a.upper().startswith("DEMO"):
                    d = P.DemoInst("E36155A")
                    d.ev = 24.0 if mode == "series" else 48.0
                    d.ei = 3.0 if mode == "series" else 1.5
                    if getattr(self, "demo", {}).get("N6705C") is not None:
                        d.peer = self.demo["N6705C"]
                    self.demo = getattr(self, "demo", {})
                    self.demo["E36155A"] = d
                    self.demo_vdd = getattr(self, "demo_vdd", []) + [d]
                    insts.append(d)
                else:
                    insts.append(orig_open(self, P.fix_addr(a), timeout_ms))
        except Exception:
            for x in insts:
                try:
                    x.close()
                except Exception:
                    pass
            raise
        return DualPSU(insts[0], insts[1], mode)

    P.Visa.open = open2
    P.Visa._site2 = True
    # 주소 칸 자동 고침이 '+' · '||' 를 망가뜨리지 않게: 각 주소만 고침
    orig_fix = P.fix_addr

    def fix2(a):
        if gate_addr(a) is not None:                      # 게이트 여러 대 주소는 그대로
            return a.strip()
        parts, mode = split_addr(a)
        if parts is None:
            return orig_fix(a)
        return (" + " if mode == "series" else " || ").join(orig_fix(p) for p in parts)
    P.fix_addr = fix2
