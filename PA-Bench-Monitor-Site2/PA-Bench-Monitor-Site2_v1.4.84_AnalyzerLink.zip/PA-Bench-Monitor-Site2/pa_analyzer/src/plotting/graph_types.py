"""Graph registry. Adding a graph = adding one GraphSpec.

The UI builds its graph selector from GRAPHS, so new entries appear
automatically. `enabled=False` keeps future graphs defined but hidden.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

from core.quantities import QUANTITIES


@dataclass(frozen=True)
class GraphSpec:
    key: str
    x: str                                  # quantity key on X
    y: str                                  # quantity key on Y
    default_xlim: Tuple[float, float] = (20.0, 50.0)
    default_ylim: Optional[Tuple[float, float]] = None   # None -> auto
    enabled: bool = True
    # 두 값을 한 Plot 에 (Mod 화면): y2 = 두 번째 값 (점선) · dual = 오른쪽 축 (따로 범위) / False = 같은 축
    y2: Optional[str] = None
    dual: bool = False
    default_y2lim: Optional[Tuple[float, float]] = None
    name: str = ""                          # 제목 (빈칸 = 'Y vs. X')

    @property
    def title(self) -> str:
        if self.name:
            return f"{self.name} vs. {QUANTITIES[self.x].label}"
        return f"{QUANTITIES[self.y].label} vs. {QUANTITIES[self.x].label}"

    @property
    def short_name(self) -> str:
        return f"{self.name or QUANTITIES[self.y].label} vs {QUANTITIES[self.x].label}"

    @property
    def file_stem(self) -> str:
        return f"{QUANTITIES[self.y].label}_vs_{QUANTITIES[self.x].label}".replace(" ", "").replace(".", "").replace("-", "")

    @property
    def x_label(self) -> str:
        return QUANTITIES[self.x].axis_label

    @property
    def y_label(self) -> str:
        if self.y2 and not self.dual and self.name:
            return f"{self.name} ({QUANTITIES[self.y].unit})"
        return QUANTITIES[self.y].axis_label

    @property
    def y2_label(self) -> str:
        return QUANTITIES[self.y2].axis_label if (self.y2 and self.dual) else ""


GRAPHS: Dict[str, GraphSpec] = {}


def register_graph(g: GraphSpec) -> GraphSpec:
    GRAPHS[g.key] = g
    return g


# ---- MVP ------------------------------------------------------------------
register_graph(GraphSpec("pae_vs_pout", "pout", "pae", (26.0, 54.0), (0.0, 70.0)))
register_graph(GraphSpec("gain_vs_pout", "pout", "gain", (26.0, 52.0), (20.0, 40.0)))
# ---- Mod 화면 (변조 신호 측정): Gain · PAE 한 Plot (PAE = 오른쪽 축 · 점선) | ACLR L · U 한 Plot (U = 점선)
register_graph(GraphSpec("gain_pae_vs_pout", "pout", "gain", (26.0, 52.0), (20.0, 40.0),
                         y2="pae", dual=True, default_y2lim=(0.0, 70.0), name="Gain · PAE"))
register_graph(GraphSpec("aclr_lu_vs_pout", "pout", "aclr_l", (26.0, 52.0), (-70.0, -20.0),
                         y2="aclr_u", dual=False, name="ACLR L · U"))

# ---- Future (defined, hidden until validated) -------------------------------
register_graph(GraphSpec("pout_vs_pin", "pin", "pout", (0.0, 40.0), (20.0, 50.0), enabled=False))
register_graph(GraphSpec("de_vs_pout", "pout", "de", (20.0, 50.0), (0.0, 80.0), enabled=False))
register_graph(GraphSpec("idd_vs_pout", "pout", "idd", (20.0, 50.0), None, enabled=False))
register_graph(GraphSpec("aclr_vs_pout", "pout", "aclr", (20.0, 50.0), (-70.0, -20.0), enabled=False))
register_graph(GraphSpec("evm_vs_pout", "pout", "evm", (20.0, 50.0), (0.0, 10.0), enabled=False))
register_graph(GraphSpec("ampm_vs_pout", "pout", "ampm", (20.0, 50.0), None, enabled=False))


def enabled_graphs():
    return [g for g in GRAPHS.values() if g.enabled]
