# -*- coding: utf-8 -*-
"""
PA Bench Monitor v1.0.3.1
R&S SMW200A (신호발생기) + FSW (스펙트럼 분석기) + RTO2044 (오실로스코프 전류)
세 장비의 값을 한 화면에 실시간 표시하고, SMW 파워가 바뀔 때마다 자동으로 표에 기록.

- 장비에는 아무것도 설치하지 않음 (LAN, SCPI raw socket 5025)
- IP 칸에 demo 입력 시 장비 없이 동작 확인 가능 (세 장비 모두 demo 로 두면 서로 연동된 가상 PA)
"""
import collections
import csv
import datetime
import json
import math
import os
import queue
import socket
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import rto_current_meter as rto

APP_NAME = "PA Bench Monitor"
VERSION = "v1.0.3.1"

BG = "#0b0f14"
FG_DIM = "#7d8a99"
C_SMW = "#ffb74d"
C_FSW = "#4fc3f7"
C_CUR = "#39ff88"
C_GAIN = "#e0e0e0"


def settings_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(base, "PABenchMonitor")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "settings.json")


DEFAULTS = {
    "smw_host": "192.168.0.11", "smw_port": 5025, "smw_gtl": True, "smw_poll": 300,
    "smw_step": "1", "smw_max": "10",
    "fsw_host": "192.168.0.12", "fsw_port": 5025, "fsw_gtl": True, "fsw_poll": 300,
    "fsw_marker": 1,
    "settle": "1.0", "avg": "1.0", "vdd": "",
    "loss_table": [],  # [[GHz, input loss dB, output loss dB], ...]
    "in_loss": "0", "out_loss": "0", "freq_ghz": "",
    "auto_rec": True, "geometry": "1560x900", "tab": 0, "min_id": "250", "sa_q": True,
    "pae_ax": ["20", "80", "10"], "gain_ax": ["20", "40", "2.5"], "loss_dir": "",
}


def load_settings():
    s = dict(DEFAULTS)
    try:
        with open(settings_path(), "r", encoding="utf-8") as f:
            s.update(json.load(f))
    except Exception:
        pass
    return s


def save_settings(s):
    try:
        with open(settings_path(), "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def fnum(text, default=None):
    try:
        return float(str(text).strip())
    except (ValueError, TypeError):
        return default


def fmt_freq(hz):
    if hz is None or not math.isfinite(hz):
        return "---"
    if hz >= 1e9:
        return "%.6g GHz" % (hz / 1e9)
    if hz >= 1e6:
        return "%.6g MHz" % (hz / 1e6)
    return "%.6g kHz" % (hz / 1e3)


def quantize_half(v):
    """SA 기록값: 소수 둘째 자리에서 반올림(→ 소수 1자리) 후 가장 가까운 0.5 단위로.
    예) 12.24 → 12.2 → 12.0,  12.26 → 12.3 → 12.5,  -10.74 → -10.7 → -10.5,  -10.76 → -10.8 → -11.0"""
    from decimal import Decimal, ROUND_HALF_UP
    d = Decimal(repr(v)).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
    q = (d * 2).quantize(Decimal("1"), rounding=ROUND_HALF_UP) / 2
    return float(q)


def dbm_to_w(dbm):
    return 10 ** ((dbm - 30) / 10.0)


# ============================================================ 가상 장비 (demo)
DEMO = {"pin": -40.0, "freq": 3.5e9, "rf": True}


def demo_pout(pin):
    """가상 PA: 이득 28 dB, Psat 약 44 dBm (부드러운 압축)."""
    df = (DEMO["freq"] - 3.5e9) / 1e9  # 주파수에 따라 이득/Psat 조금씩 다르게
    lin = dbm_to_w(pin + 28.0 - 8 * df)
    psat = dbm_to_w(44.0 - 4 * df)
    p = 2.0  # Rapp 모델
    out = lin / (1 + (lin / psat) ** p) ** (1.0 / p)
    return 10 * math.log10(out) + 30


def _demo_amp(self):
    if not DEMO["rf"]:
        return 0.25
    pw = dbm_to_w(demo_pout(DEMO["pin"]))
    return 0.25 + 1.6 * math.sqrt(pw / dbm_to_w(44.0))


rto.DemoScope._amp = _demo_amp  # 오실로스코프 demo 전류를 가상 PA 와 연동


class DemoSMW:
    def write(self, cmd):
        c = cmd.upper()
        val = cmd.split(" ", 1)[1].strip() if " " in cmd else ""
        if c.startswith("SOUR1:POW ") or c.startswith("SOURCE1:POWER "):
            DEMO["pin"] = float(val)
        elif c.startswith("SOUR1:FREQ "):
            DEMO["freq"] = float(val)
        elif c.startswith("OUTP1:STAT ") or c.startswith("OUTP1 "):
            DEMO["rf"] = val.upper() in ("1", "ON")

    def query(self, cmd):
        c = cmd.upper()
        time.sleep(0.005)
        if c == "*IDN?":
            return "Rohde&Schwarz,SMW200A (DEMO),1412.0000K02/000000,5.30"
        if c.startswith("SOUR1:FREQ"):
            return "%.1f" % DEMO["freq"]
        if c.startswith("SOUR1:POW"):
            return "%.2f" % DEMO["pin"]
        if c.startswith("OUTP1"):
            return "1" if DEMO["rf"] else "0"
        if c.startswith("SYST:ERR"):
            return '0,"No error"'
        return "1"

    def close(self):
        pass


class DemoFSW:
    def __init__(self):
        self.cent = 3.5e9
        self.span = 10e6
        self.mx = {1: 3.5e9}
        self.mon = {1: True}

    def write(self, cmd):
        c = cmd.upper()
        val = cmd.split(" ", 1)[1].strip() if " " in cmd else ""
        n = int("".join(ch for ch in c.split(":MARK")[1][:2] if ch.isdigit()) or 1) if ":MARK" in c else 1
        if c.startswith("FREQ:CENT ") or c.startswith("SENS:FREQ:CENT "):
            self.cent = float(val)
        elif ":X " in c:
            self.mx[n] = float(val)
            self.mon[n] = True
        elif ":STAT " in c and ":MARK" in c:
            self.mon[n] = val.upper() in ("1", "ON")
        elif c.endswith(":MAX"):
            self.mx[n] = DEMO["freq"]
            self.mon[n] = True

    def query(self, cmd):
        c = cmd.upper()
        time.sleep(0.005)
        n = int("".join(ch for ch in c.split(":MARK")[1][:2] if ch.isdigit()) or 1) if ":MARK" in c else 1
        if c == "*IDN?":
            return "Rohde&Schwarz,FSW-50 (DEMO),1331.5003K50/000000,5.00"
        if "FREQ:CENT?" in c:
            return "%.1f" % self.cent
        if "FREQ:SPAN?" in c:
            return "%.1f" % self.span
        if ":STAT?" in c:
            return "1" if self.mon.get(n) else "0"
        if c.endswith(":X?"):
            return "%.1f" % self.mx.get(n, self.cent)
        if c.endswith(":Y?"):
            off = abs(self.mx.get(n, 0) - DEMO["freq"]) / 1e6
            p = demo_pout(DEMO["pin"]) - 40.0 if DEMO["rf"] else -90.0  # 40 dB 감쇠기 가정
            import random
            return "%.3f" % (p - 3.0 * off ** 2 + random.gauss(0, 0.03))
        if c.startswith("SYST:ERR"):
            return '0,"No error"'
        return "1"

    def close(self):
        pass


# ============================================================ 공용 통신 스레드
class InstWorker(threading.Thread):
    """장비 하나당 하나의 통신 스레드. 결과는 (name, kind, ...) 로 out_q 에 보냄."""

    def __init__(self, name, out_q, demo_cls):
        super().__init__(daemon=True)
        self.name = name
        self.out = out_q
        self.demo_cls = demo_cls
        self.tasks = queue.Queue()
        self.inst = None
        self.interval = 0.3
        self.gtl = True
        self.alive = True
        self.poll_fn = None
        self.init_fn = None

    def post(self, *msg):
        self.out.put((self.name,) + msg)

    def close(self):
        if self.inst:
            try:
                if self.gtl:
                    self.inst.write("&GTL")
            except Exception:
                pass
            self.inst.close()
        self.inst = None

    def run(self):
        while self.alive:
            t0 = time.time()
            try:
                while True:
                    try:
                        task = self.tasks.get_nowait()
                    except queue.Empty:
                        break
                    kind = task[0]
                    if kind == "connect":
                        self.close()
                        host, port = task[1].strip(), task[2]
                        self.post("status", "연결 중... %s" % host)
                        if host.lower() == "demo":
                            self.inst = self.demo_cls()
                        else:
                            self.inst = rto.ScpiSocket(host, port, timeout=5.0)
                        idn = self.inst.query("*IDN?")
                        self.inst.write("*CLS")
                        if self.init_fn:
                            self.init_fn(self)
                        self.post("connected", idn)
                    elif kind == "disconnect":
                        self.close()
                        self.post("disconnected")
                    elif kind == "call":
                        if not self.inst:
                            raise ConnectionError("먼저 장비에 연결하세요.")
                        task[1](self)
                if self.inst and self.poll_fn:
                    self.poll_fn(self)
                    if self.gtl:
                        self.inst.write("&GTL")  # 앞 패널을 바로 쓸 수 있도록 Local 로 복귀
            except (socket.timeout, TimeoutError):
                self.post("error", "응답 시간 초과 - 연결이 끊어졌습니다. (IP / LAN / 장비 상태 확인)")
                self.close()
                self.post("disconnected")
            except (ConnectionError, OSError) as e:
                self.post("error", str(e))
                self.close()
                self.post("disconnected")
            except Exception as e:
                self.post("error", str(e))
            wait = self.interval - (time.time() - t0)
            time.sleep(max(wait, 0.03))


def q_float(inst, cmd):
    r = inst.query(cmd)
    try:
        v = float(r.split(",")[0])
    except ValueError:
        return float("nan")
    if abs(v) > 1e30:
        return float("nan")
    return v


# ---------- SMW200A
def smw_poll(w):
    f = q_float(w.inst, "SOUR1:FREQ?")
    p = q_float(w.inst, "SOUR1:POW?")
    rf = w.inst.query("OUTP1:STAT?").strip().upper() in ("1", "ON")
    w.post("val", f, p, rf)


# ---------- FSW
def fsw_read_cfg(w):
    n = w.marker
    cent = q_float(w.inst, "SENS:FREQ:CENT?")
    span = q_float(w.inst, "SENS:FREQ:SPAN?")
    on = w.inst.query("CALC1:MARK%d:STAT?" % n).strip().upper() in ("1", "ON")
    mx = q_float(w.inst, "CALC1:MARK%d:X?" % n) if on else float("nan")
    w.marker_on = on
    w.post("cfg", cent, span, n, on, mx)


def fsw_init(w):
    try:
        w.inst.write("SYST:DISP:UPD ON")
        w.inst.query("*OPC?")
    except Exception:
        pass
    fsw_read_cfg(w)
    w.cfg_t = time.time()


def fsw_poll(w):
    if time.time() - getattr(w, "cfg_t", 0) > 2.0:  # 사용자가 장비에서 바꾼 설정 반영
        fsw_read_cfg(w)
        w.cfg_t = time.time()
    if w.marker_on:
        y = q_float(w.inst, "CALC1:MARK%d:Y?" % w.marker)
        w.post("val", y)
    else:
        w.post("val", float("nan"))



# ============================================================ 그래프 (Tk Canvas, 추가 설치 불필요)
PALETTE = ["#1f77b4", "#d62728", "#2ca02c", "#ff7f0e", "#9467bd", "#17becf",
           "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22"]


def nice_ticks(lo, hi, n=6):
    if not (math.isfinite(lo) and math.isfinite(hi)):
        return []
    if hi - lo < 1e-12:
        lo, hi = lo - 1, hi + 1
    raw = (hi - lo) / n
    e = 10 ** math.floor(math.log10(raw))
    step = min((m * e for m in (1, 2, 2.5, 5, 10) if m * e >= raw), default=10 * e)
    t = math.ceil(lo / step - 1e-9) * step
    out = []
    while t <= hi + 1e-9 * step:
        out.append(round(t, 10))
        t += step
    return out


class XYPlot(tk.Canvas):
    def __init__(self, parent, title, xlabel, ylabel, **kw):
        super().__init__(parent, bg="white", highlightthickness=0, **kw)
        self.title, self.xlabel, self.ylabel = title, xlabel, ylabel
        self.series = []       # [(label, color, [(x, y), ...]), ...]
        self.xrange = None     # 두 그래프 x축 맞춤용
        self.yaxis = None      # (min, max, step) 고정 Y축, None 이면 자동
        self.note = ""
        self.bind("<Configure>", lambda e: self.redraw())

    def set_data(self, series, xrange=None, note="", yaxis=None):
        self.series, self.xrange, self.note, self.yaxis = series, xrange, note, yaxis
        self.redraw()

    def redraw(self):
        self.delete("all")
        W, H = self.winfo_width(), self.winfo_height()
        if W < 50 or H < 50:
            return
        L, R, T, B = 62, 16, 26, 40
        pw, ph = W - L - R, H - T - B
        pts = [pt for _, _, d in self.series for pt in d]
        if self.xrange:
            x0, x1 = self.xrange
        elif pts:
            x0, x1 = min(p[0] for p in pts), max(p[0] for p in pts)
        else:
            x0, x1 = 0, 1
        if x1 - x0 < 1e-9:
            x0, x1 = x0 - 1, x1 + 1
        mx = (x1 - x0) * 0.04
        x0, x1 = x0 - mx, x1 + mx
        if self.yaxis:
            y0, y1, ystep = self.yaxis
            yticks = []
            v = y0
            while v <= y1 + 1e-9 * max(1, abs(ystep)) and len(yticks) < 200:
                yticks.append(round(v, 10))
                v += ystep
        else:
            if pts:
                y0, y1 = min(p[1] for p in pts), max(p[1] for p in pts)
            else:
                y0, y1 = 0, 1
            if y1 - y0 < 1e-9:
                y0, y1 = y0 - 1, y1 + 1
            my = (y1 - y0) * 0.08
            y0, y1 = y0 - my, y1 + my
            yticks = nice_ticks(y0, y1, max(3, ph // 40))

        def X(v):
            return L + (v - x0) / (x1 - x0) * pw

        def Y(v):
            return T + ph - (v - y0) / (y1 - y0) * ph

        for tx in nice_ticks(x0, x1, max(3, pw // 70)):
            self.create_line(X(tx), T, X(tx), T + ph, fill="#e6e6e6")
        for ty in yticks:
            self.create_line(L, Y(ty), L + pw, Y(ty), fill="#e6e6e6")
        for label, color, data in self.series:
            xy = [(X(a), Y(b)) for a, b in data]
            if len(xy) > 1:
                self.create_line(*[c for pt in xy for c in pt], fill=color, width=2)
            for cx, cy in xy:
                self.create_oval(cx - 3, cy - 3, cx + 3, cy + 3, fill=color, outline=color)
        # 그래프 영역 밖으로 나간 선/점 가리기
        for box in ((0, 0, W, T), (0, T + ph, W, H), (0, 0, L, H), (L + pw, 0, W, H)):
            self.create_rectangle(*box, fill="white", outline="white")
        self.create_text(L + pw / 2, 12, text=self.title, font=("맑은 고딕", 10, "bold"))
        self.create_text(L + pw / 2, H - 10, text=self.xlabel, font=("맑은 고딕", 9))
        self.create_text(14, T + ph / 2, text=self.ylabel, angle=90, font=("맑은 고딕", 9))
        for tx in nice_ticks(x0, x1, max(3, pw // 70)):
            self.create_text(X(tx), T + ph + 12, text="%g" % tx, font=("Consolas", 8))
        for ty in yticks:
            self.create_text(L - 6, Y(ty), text="%g" % ty, anchor="e", font=("Consolas", 8))
        self.create_rectangle(L, T, L + pw, T + ph, outline="#888")
        # 범례 (흰 배경 상자)
        ly = T + 8
        if self.series:
            wmax = max(len(lb) for lb, _, _ in self.series) * 7 + 45
            self.create_rectangle(L + 4, T + 1, L + 4 + wmax, T + 4 + 16 * len(self.series),
                                  fill="white", outline="#cccccc")
        for label, color, data in self.series:
            self.create_line(L + 10, ly, L + 30, ly, fill=color, width=3)
            self.create_text(L + 35, ly, text=label, anchor="w", font=("맑은 고딕", 9))
            ly += 16
        if self.note:
            self.create_text(L + pw / 2, T + ph / 2, text=self.note, fill="#999", font=("맑은 고딕", 11))


class PlotPanel(ttk.Frame):
    """PAE vs Pout (위), Gain vs Pout (아래). 주파수별 색상."""

    def __init__(self, parent):
        super().__init__(parent)
        pw = ttk.PanedWindow(self, orient="vertical")
        pw.pack(fill="both", expand=True)
        self.p1 = XYPlot(pw, "PAE vs. Pout", "DUT Pout (dBm)", "PAE (%)", height=260)
        self.p2 = XYPlot(pw, "Gain vs. Pout", "DUT Pout (dBm)", "Gain (dB)", height=260)
        pw.add(self.p1, weight=1)
        pw.add(self.p2, weight=1)

    def update_rows(self, rows, axes=(None, None)):
        groups = collections.OrderedDict()
        for r in rows:
            if r.get("pout") is None:
                continue
            key = round(r["freq"], 6) if r.get("freq") is not None else None
            groups.setdefault(key, []).append(r)
        s1, s2, xs = [], [], []
        for i, (key, rs) in enumerate(sorted(groups.items(), key=lambda kv: (kv[0] is None, kv[0] or 0))):
            color = PALETTE[i % len(PALETTE)]
            rs = sorted(rs, key=lambda r: r["sg"] if r.get("sg") is not None else r["pout"])  # 입력 파워 순으로 선 연결
            label = ("%.6g GHz" % key) if key is not None else "주파수 없음"
            pae = [(r["pout"], r["pae"]) for r in rs if r.get("pae") is not None]
            gain = [(r["pout"], r["gain"]) for r in rs if r.get("gain") is not None]
            xs += [r["pout"] for r in rs]
            if pae:
                s1.append((label, color, pae))
            if gain:
                s2.append((label, color, gain))
        xr = (min(xs), max(xs)) if xs else None
        note1 = "" if s1 else ("Vdd 를 입력하면 PAE 가 표시됩니다" if rows else "기록된 데이터가 없습니다")
        note2 = "" if s2 else "기록된 데이터가 없습니다"
        self.p1.set_data(s1, xr, note1, axes[0])
        self.p2.set_data(s2, xr, note2, axes[1])


def make_icon(root, kind):
    """16x16 아이콘: save(디스켓) / open(폴더)."""
    img = tk.PhotoImage(master=root, width=16, height=16)

    def box(x0, y0, x1, y1, color):
        img.put(color, to=(x0, y0, x1, y1))

    if kind == "save":
        box(1, 1, 15, 15, "#2f5d8a")      # 몸체
        box(4, 1, 12, 6, "#dfe8f1")       # 셔터
        box(9, 2, 11, 5, "#2f5d8a")
        box(3, 9, 13, 15, "#ffffff")      # 라벨
        box(4, 11, 12, 12, "#9fb3c8")
    else:
        box(1, 3, 7, 5, "#c99a2e")        # 탭
        box(1, 5, 15, 14, "#e8b84a")      # 폴더
        box(1, 7, 15, 8, "#c99a2e")
    return img


# ============================================================ 메인 화면
class BenchApp:
    COLS = [("no", "No", 36), ("time", "시간", 66), ("freq", "주파수(GHz)", 80),
            ("sg", "SG(dBm)", 68), ("sa", "SA(dBm)", 68), ("inl", "In loss(dB)", 74), ("outl", "Out loss(dB)", 80),
            ("pin", "DUT Pin(dBm)", 88), ("pout", "DUT Pout(dBm)", 92), ("gain", "Gain(dB)", 66),
            ("id", "Id(mA)", 68), ("pdc", "Pdc(W)", 64), ("de", "DE(%)", 58), ("pae", "PAE(%)", 62)]

    def __init__(self, root):
        self.root = root
        self.s = load_settings()
        self.q = queue.Queue()
        self.rows = []
        # 실시간 값
        self.smw = {"conn": False, "f": None, "p": None, "rf": False, "t": 0}
        self.fsw = {"conn": False, "y": None, "mx": None, "t": 0}
        self.cur_samples = collections.deque(maxlen=2000)  # (t, A)
        self.fsw_samples = collections.deque(maxlen=2000)  # (t, dBm)
        # 자동 기록 상태
        self.rec_on = False
        self.last_pin = None
        self.change_t = None
        self.pending = False

        root.title("%s %s" % (APP_NAME, VERSION))
        geo = self.s.get("geometry") or "1560x900"
        try:
            gw = int(geo.split("x")[0])
            if gw < 1400:
                geo = "1560x900"
        except ValueError:
            geo = "1560x900"
        root.geometry(geo)
        root.minsize(900, 600)
        try:
            ttk.Style().theme_use("vista")
        except Exception:
            pass
        root.option_add("*Font", ("맑은 고딕", 9))

        self.smw_w = InstWorker("smw", self.q, DemoSMW)
        self.smw_w.poll_fn = smw_poll
        self.fsw_w = InstWorker("fsw", self.q, DemoFSW)
        self.fsw_w.poll_fn = fsw_poll
        self.fsw_w.init_fn = fsw_init
        self.fsw_w.marker = int(self.s.get("fsw_marker", 1))
        self.fsw_w.marker_on = False
        for w in (self.smw_w, self.fsw_w):
            w.start()

        self.var_smw_step = tk.StringVar(value=self.s["smw_step"])
        self.var_smw_max = tk.StringVar(value=self.s["smw_max"])
        self.build_dashboard()
        self.nb = ttk.Notebook(root)
        self.nb.pack(side="top", fill="both", expand=True, padx=4, pady=4)
        self.build_log_tab()
        self.build_smw_tab()
        self.build_fsw_tab()
        self.build_scope_tab()
        try:
            self.nb.select(int(self.s.get("tab", 0)))
        except Exception:
            pass
        self.apply_worker_opts()
        menubar = tk.Menu(root)
        mfile = tk.Menu(menubar, tearoff=0)
        mfile.add_command(label="케이블 손실 표 불러오기...", command=self.loss_load)
        mfile.add_command(label="케이블 손실 표 저장...", command=self.loss_save)
        mfile.add_separator()
        mfile.add_command(label="측정 기록 CSV 저장...", command=self.save_csv)
        mfile.add_command(label="측정 기록 엑셀용 복사", command=self.copy_rows)
        mfile.add_separator()
        mfile.add_command(label="종료", command=self.on_close)
        menubar.add_cascade(label="파일", menu=mfile)
        root.config(menu=menubar)
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(100, self.tick)
        root.after(300, self.refresh_plots)

    # ------------------------------------------------ 상단 실시간 표시
    def build_dashboard(self):
        d = tk.Frame(self.root, bg=BG)
        d.pack(side="top", fill="x")
        self.dash = d
        cols = tk.Frame(d, bg=BG)
        cols.pack(side="top", fill="x", padx=6, pady=(6, 0))
        self.big = {}
        spec = [("smw", "신호발생기 출력 (SMW200A)", C_SMW),
                ("fsw", "스펙트럼 분석기 (FSW)", C_FSW),
                ("cur", "전류 (RTO 오실로스코프)", C_CUR),
                ("gain", "DUT Gain / PAE (손실 보정)", C_GAIN)]
        for i, (key, title, color) in enumerate(spec):
            cols.columnconfigure(i, weight=1, uniform="c")
            box = tk.Frame(cols, bg=BG, highlightthickness=1, highlightbackground="#1f2a36")
            box.grid(row=0, column=i, sticky="nsew", padx=3)
            tk.Label(box, text=title, bg=BG, fg=FG_DIM, font=("맑은 고딕", 10)).pack(anchor="w", padx=8, pady=(4, 0))
            v = tk.Label(box, text="---", bg=BG, fg=color, font=("Consolas", 30, "bold"))
            v.pack(fill="x", padx=4)
            sub = tk.Label(box, text="", bg=BG, fg=FG_DIM, font=("Consolas", 10))
            sub.pack(fill="x", padx=4, pady=(0, 6))
            self.big[key] = (v, sub)
        bar = tk.Frame(d, bg=BG)
        bar.pack(side="top", fill="x", padx=6, pady=6)
        mk = dict(relief="flat", padx=12, pady=3, activeforeground="#ffffff")
        tk.Button(bar, text="모두 연결", command=self.connect_all, bg="#1c2530", fg="#c8d3de",
                  activebackground="#2a3644", **mk).pack(side="left", padx=3)
        tk.Button(bar, text="▶ 전류 측정 시작/정지", command=self.toggle_current, bg="#1c2530", fg="#c8d3de",
                  activebackground="#2a3644", **mk).pack(side="left", padx=3)
        self.btn_rec = tk.Button(bar, text="● 자동 기록 시작", command=self.toggle_rec, bg="#7a1f1f",
                                 fg="#ffffff", activebackground="#a52a2a", **mk)
        self.btn_rec.pack(side="left", padx=3)
        tk.Button(bar, text="지금 기록", command=lambda: self.record(manual=True), bg="#1c2530", fg="#c8d3de",
                  activebackground="#2a3644", **mk).pack(side="left", padx=3)
        self.lbl_rec = tk.Label(bar, text="", bg=BG, fg="#d4a017", font=("맑은 고딕", 10))
        self.lbl_rec.pack(side="left", padx=10)
        self.lbl_status = tk.Label(bar, text="", bg=BG, fg=FG_DIM, anchor="e")
        self.lbl_status.pack(side="right", fill="x", expand=True)
        d.bind("<Configure>", self.on_dash_resize)

    def on_dash_resize(self, event=None):
        w = max(self.dash.winfo_width(), 400)
        size = int(max(18, min(44, w / 4 / 11 * 1.45)))
        for key, (v, sub) in self.big.items():
            v.configure(font=("Consolas", size, "bold"))

    # ------------------------------------------------ 탭: 측정 기록
    def build_log_tab(self):
        s = self.s
        f = ttk.Frame(self.nb, padding=6)
        self.nb.add(f, text="  측정 기록  ")
        pad = dict(padx=4, pady=2)
        top = ttk.Frame(f)
        top.pack(fill="x")
        left = ttk.Frame(top)
        left.pack(side="left", fill="both", expand=True)

        # 주파수 / 파워
        g1 = ttk.LabelFrame(left, text=" 주파수 / 파워 ", padding=6)
        g1.pack(fill="x")
        ttk.Label(g1, text="주파수(GHz)").grid(row=0, column=0, sticky="e", **pad)
        self.var_freq = tk.StringVar(value=s.get("freq_ghz", ""))
        e = ttk.Entry(g1, textvariable=self.var_freq, width=10)
        e.grid(row=0, column=1, **pad)
        e.bind("<Return>", lambda ev: self.apply_freq())
        ttk.Button(g1, text="SG + SA 주파수 함께 변경", command=self.apply_freq).grid(
            row=0, column=2, columnspan=3, sticky="w", **pad)
        ttk.Label(g1, text="(SG 주파수, SA Center·마커를 같은 주파수로)", foreground="#666").grid(
            row=0, column=5, columnspan=4, sticky="w", **pad)
        ttk.Label(g1, text="SG 레벨(dBm)").grid(row=1, column=0, sticky="e", **pad)
        self.var_lvl2 = tk.StringVar(value="")
        e2 = ttk.Entry(g1, textvariable=self.var_lvl2, width=10)
        e2.grid(row=1, column=1, **pad)
        e2.bind("<Return>", lambda ev: self.smw_set_level(fnum(self.var_lvl2.get())))
        ttk.Button(g1, text="설정", width=6,
                   command=lambda: self.smw_set_level(fnum(self.var_lvl2.get()))).grid(row=1, column=2, **pad)
        ttk.Label(g1, text="스텝(dB)").grid(row=1, column=3, sticky="e", **pad)
        ttk.Entry(g1, textvariable=self.var_smw_step, width=5).grid(row=1, column=4, **pad)
        ttk.Button(g1, text="▲ 올리기", command=lambda: self.smw_step(+1)).grid(row=1, column=5, **pad)
        ttk.Button(g1, text="● 기록", command=lambda: self.record(manual=True)).grid(row=1, column=6, **pad)
        ttk.Button(g1, text="▼ 내리기", command=lambda: self.smw_step(-1)).grid(row=1, column=7, **pad)
        ttk.Label(g1, text="최대 허용(dBm)").grid(row=1, column=8, sticky="e", **pad)
        ttk.Entry(g1, textvariable=self.var_smw_max, width=6).grid(row=1, column=9, **pad)
        ttk.Label(g1, text="※ 같은 주파수·같은 SG 파워를 다시 기록하면 최신 값으로 덮어씀",
                  foreground="#666").grid(row=2, column=0, columnspan=10, sticky="w", **pad)

        # 기록 조건
        g2 = ttk.LabelFrame(left, text=" 자동 기록 조건 / 효율 계산 ", padding=6)
        g2.pack(fill="x", pady=(4, 0))
        ttk.Label(g2, text="SG 파워가 바뀌면").grid(row=0, column=0, sticky="e", **pad)
        self.var_settle = tk.StringVar(value=s["settle"])
        ttk.Entry(g2, textvariable=self.var_settle, width=5).grid(row=0, column=1, **pad)
        ttk.Label(g2, text="초 기다린 뒤").grid(row=0, column=2, sticky="w", **pad)
        self.var_avg = tk.StringVar(value=s["avg"])
        ttk.Entry(g2, textvariable=self.var_avg, width=5).grid(row=0, column=3, **pad)
        ttk.Label(g2, text="초 평균해서 기록").grid(row=0, column=4, sticky="w", **pad)
        ttk.Label(g2, text="Vdd(V)").grid(row=1, column=0, sticky="e", **pad)
        self.var_vdd = tk.StringVar(value=s["vdd"])
        ttk.Entry(g2, textvariable=self.var_vdd, width=6).grid(row=1, column=1, **pad)
        ttk.Label(g2, text="효율 계산 최소 Id(mA)").grid(row=1, column=2, columnspan=2, sticky="e", **pad)
        self.var_minid = tk.StringVar(value=s.get("min_id", "250"))
        ttk.Entry(g2, textvariable=self.var_minid, width=6).grid(row=1, column=4, sticky="w", **pad)
        self.lbl_vdd = ttk.Label(g2, text="", foreground="#c0504d")
        self.lbl_vdd.grid(row=1, column=5, columnspan=4, sticky="w", **pad)
        self.var_saq = tk.BooleanVar(value=bool(s.get("sa_q", True)))
        ttk.Checkbutton(g2, text="SA 값은 0.5 dB 단위로 기록 (소수 둘째 자리 반올림 → 가까운 0.5)",
                        variable=self.var_saq).grid(row=4, column=0, columnspan=8, sticky="w", **pad)
        ttk.Label(g2, text="(이 전류 미만이면 PAE·DE 는 비워두고 Gain 그래프에만 표시)",
                  foreground="#666").grid(row=3, column=0, columnspan=8, sticky="w", **pad)
        ttk.Label(g2, text="DUT Pin = SG − In loss  ·  DUT Pout = SA + Out loss  ·  Gain = Pout − Pin\n"
                           "PAE = (Pout − Pin)[W] / (Vdd·Id) × 100  ·  DE = Pout[W] / (Vdd·Id) × 100",
                  foreground="#666").grid(row=2, column=0, columnspan=8, sticky="w", **pad)

        # 케이블 손실 표 (주파수별)
        g3 = ttk.LabelFrame(top, text=" 케이블 손실 (주파수별, dB) ", padding=6)
        g3.pack(side="left", fill="y", padx=(6, 0))
        self.loss_tree = ttk.Treeview(g3, columns=("f", "i", "o"), show="headings", height=5)
        for k, t, wd in (("f", "주파수(GHz)", 80), ("i", "In loss", 60), ("o", "Out loss", 64)):
            self.loss_tree.heading(k, text=t)
            self.loss_tree.column(k, width=wd, anchor="center")
        self.loss_tree.grid(row=0, column=0, columnspan=6, sticky="nsew")
        self.loss_tree.bind("<<TreeviewSelect>>", self.loss_selected)
        self.var_lf = tk.StringVar()
        self.var_li = tk.StringVar(value=s.get("in_loss", "0"))
        self.var_lo = tk.StringVar(value=s.get("out_loss", "0"))
        for col, (lab, var, wd) in enumerate((("GHz", self.var_lf, 7), ("In", self.var_li, 5),
                                              ("Out", self.var_lo, 5))):
            ttk.Label(g3, text=lab).grid(row=1, column=col * 2, sticky="e", padx=2, pady=3)
            ttk.Entry(g3, textvariable=var, width=wd).grid(row=1, column=col * 2 + 1, sticky="w", padx=2, pady=3)
        bf3 = ttk.Frame(g3)
        bf3.grid(row=2, column=0, columnspan=6, sticky="w")
        ttk.Button(bf3, text="추가/수정", command=self.loss_add).pack(side="left", padx=2)
        ttk.Button(bf3, text="삭제", command=self.loss_del).pack(side="left", padx=2)
        self.icon_save = make_icon(self.root, "save")
        self.icon_open = make_icon(self.root, "open")
        ttk.Button(bf3, text="저장", image=self.icon_save, compound="left",
                   command=self.loss_save).pack(side="left", padx=(8, 2))
        ttk.Button(bf3, text="불러오기", image=self.icon_open, compound="left",
                   command=self.loss_load).pack(side="left", padx=2)
        self.lbl_loss = ttk.Label(g3, text="", foreground="#1f4f8f")
        self.lbl_loss.grid(row=3, column=0, columnspan=6, sticky="w", pady=(3, 0))
        ttk.Label(g3, text="표의 주파수 사이는 직선 보간,\n표가 비어 있으면 In/Out 칸 값 사용",
                  foreground="#666").grid(row=4, column=0, columnspan=6, sticky="w")
        self.loss_table = [list(map(float, r)) for r in s.get("loss_table", [])]
        self.refresh_loss_tree()

        split = ttk.PanedWindow(f, orient="horizontal")
        split.pack(fill="both", expand=True, pady=(6, 0))
        leftp = ttk.Frame(split)
        rightp = ttk.Frame(split)
        split.add(leftp, weight=3)
        split.add(rightp, weight=2)

        tf = ttk.Frame(leftp)
        tf.pack(fill="both", expand=True, pady=(0, 4))
        self.tree = ttk.Treeview(tf, columns=[c[0] for c in self.COLS], show="headings", height=12)
        for key, title, wd in self.COLS:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=wd, minwidth=40, anchor="center", stretch=False)
        sb = ttk.Scrollbar(tf, orient="vertical", command=self.tree.yview)
        sbx = ttk.Scrollbar(tf, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=sb.set, xscrollcommand=sbx.set)
        sbx.pack(side="bottom", fill="x")
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        # 오른쪽: 위 PAE, 아래 Gain
        axf = ttk.Frame(rightp)
        axf.pack(fill="x", padx=(4, 0), pady=(0, 2))
        pae_ax = self.s.get("pae_ax", ["20", "80", "10"])
        gain_ax = self.s.get("gain_ax", ["20", "40", "2.5"])
        self.var_pae_ax = [tk.StringVar(value=str(v)) for v in pae_ax]
        self.var_gain_ax = [tk.StringVar(value=str(v)) for v in gain_ax]
        for r, (name, vars_) in enumerate((("PAE(%)", self.var_pae_ax), ("Gain(dB)", self.var_gain_ax))):
            ttk.Label(axf, text="%s Y축" % name, width=11).grid(row=r, column=0, sticky="w")
            for c, (lab, var) in enumerate(zip(("최소", "최대", "간격"), vars_)):
                ttk.Label(axf, text=lab).grid(row=r, column=1 + c * 2, sticky="e", padx=(4, 1))
                e = ttk.Entry(axf, textvariable=var, width=6)
                e.grid(row=r, column=2 + c * 2, sticky="w")
                e.bind("<Return>", lambda ev: self.refresh_plots())
        ttk.Button(axf, text="축 적용", command=self.refresh_plots).grid(row=0, column=7, rowspan=2, padx=6)
        ttk.Label(axf, text="빈 칸 = 자동", foreground="#666").grid(row=0, column=8, rowspan=2, sticky="w")
        self.plots = [PlotPanel(rightp)]
        self.plots[0].pack(fill="both", expand=True, padx=(4, 0))
        ttk.Button(rightp, text="그래프 새 창으로 보기", command=self.open_plot_window).pack(anchor="e", pady=2)

        bf = ttk.Frame(leftp)
        bf.pack(fill="x")
        ttk.Button(bf, text="엑셀용 복사 (Ctrl+V 로 붙여넣기)", command=self.copy_rows).pack(side="left", padx=3)
        ttk.Button(bf, text="CSV 저장", command=self.save_csv).pack(side="left", padx=3)
        ttk.Button(bf, text="Vdd·손실 바꾼 값으로 전체 다시 계산", command=self.recalc_rows).pack(side="left", padx=3)
        ttk.Button(bf, text="선택 행 삭제", command=self.delete_selected).pack(side="left", padx=3)
        ttk.Button(bf, text="전체 지우기", command=self.clear_rows).pack(side="left", padx=3)
        ttk.Label(bf, text=VERSION, foreground="#999").pack(side="right")
        self.tree.bind("<Control-c>", lambda e: self.copy_rows())

    # ------------------------------------------------ 탭: SMW
    def build_smw_tab(self):
        s = self.s
        f = ttk.Frame(self.nb, padding=10)
        self.nb.add(f, text="  SMW200A (신호발생기)  ")
        pad = dict(padx=4, pady=4)
        g = ttk.LabelFrame(f, text=" 연결 (LAN) ", padding=8)
        g.pack(fill="x")
        ttk.Label(g, text="IP").grid(row=0, column=0, **pad)
        self.var_smw_host = tk.StringVar(value=s["smw_host"])
        ttk.Entry(g, textvariable=self.var_smw_host, width=18).grid(row=0, column=1, **pad)
        ttk.Label(g, text="Port").grid(row=0, column=2, **pad)
        self.var_smw_port = tk.StringVar(value=str(s["smw_port"]))
        ttk.Entry(g, textvariable=self.var_smw_port, width=6).grid(row=0, column=3, **pad)
        self.btn_smw = ttk.Button(g, text="연결", command=self.smw_connect, width=10)
        self.btn_smw.grid(row=0, column=4, **pad)
        self.lbl_smw_idn = ttk.Label(g, text="(IP에 demo 입력 시 장비 없이 테스트)", foreground="#666")
        self.lbl_smw_idn.grid(row=1, column=0, columnspan=6, sticky="w", **pad)
        self.var_smw_gtl = tk.BooleanVar(value=bool(s["smw_gtl"]))
        ttk.Checkbutton(g, text="읽은 뒤 바로 Local 복귀 (&GTL) - 장비 앞 패널로 파워 조절 가능하게",
                        variable=self.var_smw_gtl, command=self.apply_worker_opts).grid(
            row=2, column=0, columnspan=6, sticky="w", **pad)
        ttk.Label(g, text="읽기 주기(ms)").grid(row=3, column=0, **pad)
        self.var_smw_poll = tk.StringVar(value=str(s["smw_poll"]))
        ttk.Spinbox(g, from_=100, to=5000, increment=100, textvariable=self.var_smw_poll, width=7,
                    command=self.apply_worker_opts).grid(row=3, column=1, sticky="w", **pad)

        g2 = ttk.LabelFrame(f, text=" 파워 조절 (선택 사항 - 장비 앞 패널에서 직접 올려도 됨) ", padding=8)
        g2.pack(fill="x", pady=8)
        ttk.Label(g2, text="레벨(dBm)").grid(row=0, column=0, **pad)
        self.var_smw_lvl = tk.StringVar(value="")
        ttk.Entry(g2, textvariable=self.var_smw_lvl, width=8).grid(row=0, column=1, **pad)
        ttk.Button(g2, text="설정", command=self.smw_set_level).grid(row=0, column=2, **pad)
        ttk.Label(g2, text="스텝(dB)").grid(row=0, column=3, **pad)
        ttk.Entry(g2, textvariable=self.var_smw_step, width=5).grid(row=0, column=4, **pad)
        ttk.Button(g2, text="▲ 올리기", command=lambda: self.smw_step(+1)).grid(row=0, column=5, **pad)
        ttk.Button(g2, text="▼ 내리기", command=lambda: self.smw_step(-1)).grid(row=0, column=6, **pad)
        ttk.Label(g2, text="최대 허용(dBm)").grid(row=1, column=0, **pad)
        ttk.Entry(g2, textvariable=self.var_smw_max, width=8).grid(row=1, column=1, **pad)
        ttk.Label(g2, text="※ 이 값보다 높게는 프로그램에서 설정하지 않음 (DUT 보호)", foreground="#666").grid(
            row=1, column=2, columnspan=5, sticky="w", **pad)
        self.lbl_smw_read = ttk.Label(f, text="", foreground="#1f4f8f")
        self.lbl_smw_read.pack(anchor="w", pady=4)

    # ------------------------------------------------ 탭: FSW
    def build_fsw_tab(self):
        s = self.s
        f = ttk.Frame(self.nb, padding=10)
        self.nb.add(f, text="  FSW (스펙트럼 분석기)  ")
        pad = dict(padx=4, pady=4)
        g = ttk.LabelFrame(f, text=" 연결 (LAN) ", padding=8)
        g.pack(fill="x")
        ttk.Label(g, text="IP").grid(row=0, column=0, **pad)
        self.var_fsw_host = tk.StringVar(value=s["fsw_host"])
        ttk.Entry(g, textvariable=self.var_fsw_host, width=18).grid(row=0, column=1, **pad)
        ttk.Label(g, text="Port").grid(row=0, column=2, **pad)
        self.var_fsw_port = tk.StringVar(value=str(s["fsw_port"]))
        ttk.Entry(g, textvariable=self.var_fsw_port, width=6).grid(row=0, column=3, **pad)
        self.btn_fsw = ttk.Button(g, text="연결", command=self.fsw_connect, width=10)
        self.btn_fsw.grid(row=0, column=4, **pad)
        self.lbl_fsw_idn = ttk.Label(g, text="(IP에 demo 입력 시 장비 없이 테스트)", foreground="#666")
        self.lbl_fsw_idn.grid(row=1, column=0, columnspan=6, sticky="w", **pad)
        self.var_fsw_gtl = tk.BooleanVar(value=bool(s["fsw_gtl"]))
        ttk.Checkbutton(g, text="읽은 뒤 바로 Local 복귀 (&GTL) - 장비 앞 패널도 계속 조작 가능하게",
                        variable=self.var_fsw_gtl, command=self.apply_worker_opts).grid(
            row=2, column=0, columnspan=6, sticky="w", **pad)
        ttk.Label(g, text="읽기 주기(ms)").grid(row=3, column=0, **pad)
        self.var_fsw_poll = tk.StringVar(value=str(s["fsw_poll"]))
        ttk.Spinbox(g, from_=100, to=5000, increment=100, textvariable=self.var_fsw_poll, width=7,
                    command=self.apply_worker_opts).grid(row=3, column=1, sticky="w", **pad)

        g2 = ttk.LabelFrame(f, text=" 주파수 / 마커  (연결하면 장비에 지금 설정된 값을 불러옴) ", padding=8)
        g2.pack(fill="x", pady=8)
        ttk.Label(g2, text="Center(GHz)").grid(row=0, column=0, **pad)
        self.var_fsw_cent = tk.StringVar(value="")
        ttk.Entry(g2, textvariable=self.var_fsw_cent, width=12).grid(row=0, column=1, **pad)
        ttk.Label(g2, text="Span(MHz)").grid(row=0, column=2, **pad)
        self.var_fsw_span = tk.StringVar(value="")
        ttk.Entry(g2, textvariable=self.var_fsw_span, width=10).grid(row=0, column=3, **pad)
        ttk.Label(g2, text="마커 번호").grid(row=1, column=0, **pad)
        self.var_fsw_mk = tk.StringVar(value=str(s["fsw_marker"]))
        cb = ttk.Combobox(g2, textvariable=self.var_fsw_mk, values=[str(i) for i in range(1, 17)],
                          width=4, state="readonly")
        cb.grid(row=1, column=1, sticky="w", **pad)
        cb.bind("<<ComboboxSelected>>", lambda e: self.fsw_marker_changed())
        ttk.Label(g2, text="마커 주파수(GHz)").grid(row=1, column=2, **pad)
        self.var_fsw_mx = tk.StringVar(value="")
        ttk.Entry(g2, textvariable=self.var_fsw_mx, width=12).grid(row=1, column=3, **pad)
        bf = ttk.Frame(g2)
        bf.grid(row=2, column=0, columnspan=6, sticky="w", pady=(6, 0))
        ttk.Button(bf, text="장비에 적용", command=self.fsw_apply).pack(side="left", padx=3)
        ttk.Button(bf, text="마커 피크 찾기", command=self.fsw_peak).pack(side="left", padx=3)
        ttk.Button(bf, text="장비 값 다시 불러오기", command=self.fsw_reload).pack(side="left", padx=3)
        ttk.Label(g2, text="※ 빈 칸은 장비에 보내지 않음. 마커는 Window 1 기준.", foreground="#666").grid(
            row=3, column=0, columnspan=6, sticky="w", **pad)
        self.lbl_fsw_read = ttk.Label(f, text="", foreground="#1f4f8f")
        self.lbl_fsw_read.pack(anchor="w", pady=4)

    # ------------------------------------------------ 탭: 오실로스코프 (기존 전류계 그대로)
    def build_plot_tab(self):
        f = ttk.Frame(self.nb, padding=4)
        self.nb.add(f, text="  그래프 (PAE·Gain vs Pout)  ")
        bar = ttk.Frame(f)
        bar.pack(fill="x")
        ttk.Button(bar, text="새 창으로 보기 (기록하면서 옆에 띄우기)", command=self.open_plot_window).pack(side="left")
        ttk.Label(bar, text="  기록이 추가·삭제될 때마다 자동으로 다시 그림 · 주파수별 색상",
                  foreground="#666").pack(side="left")
        self.plots = [PlotPanel(f)]
        self.plots[0].pack(fill="both", expand=True, pady=(4, 0))

    def open_plot_window(self):
        win = tk.Toplevel(self.root)
        win.title("%s - 그래프" % APP_NAME)
        win.geometry("640x760")
        panel = PlotPanel(win)
        panel.pack(fill="both", expand=True)
        self.plots.append(panel)

        def closed():
            if panel in self.plots:
                self.plots.remove(panel)
            win.destroy()

        win.protocol("WM_DELETE_WINDOW", closed)
        win.after(100, lambda: panel.update_rows(self.rows, self.plot_axes()))

    def plot_axes(self):
        out = []
        for vars_ in (self.var_pae_ax, self.var_gain_ax):
            lo, hi, st = (fnum(v.get()) for v in vars_)
            if lo is None or hi is None or hi <= lo:
                out.append(None)
                continue
            if st is None or st <= 0 or (hi - lo) / st > 100:
                st = (nice_ticks(lo, hi, 6)[1] - nice_ticks(lo, hi, 6)[0]) if len(nice_ticks(lo, hi, 6)) > 1 else (hi - lo)
            out.append((lo, hi, st))
        return tuple(out)

    # ------------------------------------------------ 케이블 손실 표 파일
    def loss_save(self):
        if not self.loss_table:
            messagebox.showinfo(APP_NAME, "저장할 손실 데이터가 없습니다.")
            return
        path = filedialog.asksaveasfilename(
            title="케이블 손실 표 저장", defaultextension=".csv",
            initialdir=self.s.get("loss_dir") or None,
            initialfile="cable_loss_%s.csv" % datetime.datetime.now().strftime("%Y%m%d"),
            filetypes=[("CSV", "*.csv"), ("모든 파일", "*.*")])
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["Freq(GHz)", "In loss(dB)", "Out loss(dB)"])
            for fg, li, lo in sorted(self.loss_table):
                w.writerow(["%.6g" % fg, "%.3f" % li, "%.3f" % lo])
        self.s["loss_dir"] = os.path.dirname(path)
        self.status("케이블 손실 표 저장됨: " + path, "#39ff88")

    def loss_load(self):
        path = filedialog.askopenfilename(
            title="케이블 손실 표 불러오기", initialdir=self.s.get("loss_dir") or None,
            filetypes=[("CSV / 텍스트", "*.csv *.txt"), ("모든 파일", "*.*")])
        if not path:
            return
        rows = []
        try:
            with open(path, "r", encoding="utf-8-sig") as f:
                for line in f:
                    parts = [x.strip() for x in line.replace("\t", ",").replace(";", ",").split(",")]
                    vals = [fnum(x) for x in parts if x != ""]
                    if len(vals) >= 3 and None not in vals[:3]:
                        rows.append(vals[:3])
        except Exception as e:
            messagebox.showerror(APP_NAME, "파일을 읽지 못했습니다.\n%s" % e)
            return
        if not rows:
            messagebox.showwarning(APP_NAME, "읽을 수 있는 행이 없습니다.\n형식: 주파수(GHz), In loss(dB), Out loss(dB)")
            return
        self.loss_table = rows
        self.refresh_loss_tree()
        self.s["loss_dir"] = os.path.dirname(path)
        self.status("케이블 손실 표 불러옴: %d개 주파수 (%s)" % (len(rows), os.path.basename(path)), "#39ff88")

    def refresh_plots(self):
        for pnl in list(self.plots):
            try:
                pnl.update_rows(self.rows, self.plot_axes())
            except tk.TclError:
                self.plots.remove(pnl)

    def build_scope_tab(self):
        f = ttk.Frame(self.nb)
        self.nb.add(f, text="  RTO2044 (전류)  ")
        self.scope = rto.App(self.root, container=f)
        orig = self.scope.show_value
        bench = self

        def hooked(raw, t):
            amps = raw * bench.scope.conv_factor() if math.isfinite(raw) else float("nan")
            if math.isfinite(amps) and not getattr(bench.scope, "stale", False):
                bench.cur_samples.append((t, amps))
            bench.cur_last = (t, amps)
            orig(raw, t)

        self.scope.show_value = hooked
        self.cur_last = (0, float("nan"))

    # ------------------------------------------------ 동작
    def apply_worker_opts(self):
        self.smw_w.gtl = self.var_smw_gtl.get()
        self.fsw_w.gtl = self.var_fsw_gtl.get()
        self.smw_w.interval = max(100, fnum(self.var_smw_poll.get(), 300)) / 1000.0
        self.fsw_w.interval = max(100, fnum(self.var_fsw_poll.get(), 300)) / 1000.0

    def connect_all(self):
        if not self.smw["conn"]:
            self.smw_connect()
        if not self.fsw["conn"]:
            self.fsw_connect()
        if not self.scope.connected:
            self.scope.on_connect()

    def toggle_current(self):
        if not self.scope.connected:
            self.status("오실로스코프가 연결되지 않았습니다 - 'RTO2044 (전류)' 탭 확인", "#ff6b6b")
            return
        self.scope.on_run()

    def smw_connect(self):
        if self.smw["conn"]:
            self.smw_w.tasks.put(("disconnect",))
            return
        self.apply_worker_opts()
        self.smw_w.tasks.put(("connect", self.var_smw_host.get(), int(fnum(self.var_smw_port.get(), 5025))))

    def fsw_connect(self):
        if self.fsw["conn"]:
            self.fsw_w.tasks.put(("disconnect",))
            return
        self.apply_worker_opts()
        self.fsw_w.marker = int(self.var_fsw_mk.get())
        self.fsw_w.tasks.put(("connect", self.var_fsw_host.get(), int(fnum(self.var_fsw_port.get(), 5025))))

    def smw_set_level(self, lvl=None):
        if not self.smw["conn"]:
            messagebox.showinfo(APP_NAME, "SMW200A 가 연결되지 않았습니다.")
            return
        if lvl is None:
            lvl = fnum(self.var_smw_lvl.get())
            if lvl is None:
                messagebox.showwarning(APP_NAME, "레벨(dBm)에 숫자를 입력하세요.")
                return
        mx = fnum(self.var_smw_max.get(), 10.0)
        if lvl > mx + 1e-9:
            messagebox.showwarning(APP_NAME, "최대 허용 레벨(%.2f dBm)을 넘습니다." % mx)
            return
        self.var_smw_lvl.set("%.2f" % lvl)
        self.smw_w.tasks.put(("call", lambda w: w.inst.write("SOUR1:POW %.2f" % lvl)))

    def smw_step(self, sign):
        p = self.smw["p"]
        if p is None or not math.isfinite(p):
            messagebox.showinfo(APP_NAME, "SMW 현재 레벨을 아직 못 읽었습니다.")
            return
        st = fnum(self.var_smw_step.get(), 1.0)
        self.smw_set_level(round(p + sign * st, 2))

    def fsw_marker_changed(self):
        n = int(self.var_fsw_mk.get())
        self.fsw_w.tasks.put(("call", lambda w: (setattr(w, "marker", n), fsw_read_cfg(w))))
        self.fsw_samples.clear()

    def fsw_apply(self):
        if not self.fsw["conn"]:
            messagebox.showinfo(APP_NAME, "FSW 가 연결되지 않았습니다.")
            return
        n = int(self.var_fsw_mk.get())
        cent = fnum(self.var_fsw_cent.get())
        span = fnum(self.var_fsw_span.get())
        mx = fnum(self.var_fsw_mx.get())

        def job(w):
            w.marker = n
            if cent is not None:
                w.inst.write("SENS:FREQ:CENT %.6f" % (cent * 1e9))
            if span is not None:
                w.inst.write("SENS:FREQ:SPAN %.6f" % (span * 1e6))
            w.inst.write("CALC1:MARK%d:STAT ON" % n)
            if mx is not None:
                w.inst.write("CALC1:MARK%d:X %.6f" % (n, mx * 1e9))
            w.inst.query("*OPC?")
            errs = []
            for _ in range(10):
                e = w.inst.query("SYST:ERR?")
                if e.startswith("0") or e.startswith("+0"):
                    break
                errs.append(e)
            if errs:
                w.post("error", "FSW 오류: " + " / ".join(errs))
            fsw_read_cfg(w)
            w.post("filled")

        self.fsw_samples.clear()
        self.fsw_w.tasks.put(("call", job))

    def fsw_peak(self):
        if not self.fsw["conn"]:
            return
        n = int(self.var_fsw_mk.get())

        def job(w):
            w.marker = n
            w.inst.write("CALC1:MARK%d:STAT ON" % n)
            w.inst.write("CALC1:MARK%d:MAX" % n)
            w.inst.query("*OPC?")
            fsw_read_cfg(w)
            w.post("fill_fields")

        self.fsw_samples.clear()
        self.fsw_w.tasks.put(("call", job))

    def fsw_reload(self):
        if not self.fsw["conn"]:
            return
        self.fsw_w.tasks.put(("call", lambda w: (fsw_read_cfg(w), w.post("fill_fields"))))

    # ------------------------------------------------ 주파수 / 케이블 손실
    def apply_freq(self):
        g = fnum(self.var_freq.get())
        if g is None or g <= 0:
            messagebox.showwarning(APP_NAME, "주파수(GHz)를 입력하세요.")
            return
        hz = g * 1e9
        done = []
        if self.smw["conn"]:
            self.smw_w.tasks.put(("call", lambda w: w.inst.write("SOUR1:FREQ %.3f" % hz)))
            done.append("SG")
        if self.fsw["conn"]:
            n = int(self.var_fsw_mk.get())

            def job(w):
                w.marker = n
                w.inst.write("SENS:FREQ:CENT %.3f" % hz)
                w.inst.write("CALC1:MARK%d:STAT ON" % n)
                w.inst.write("CALC1:MARK%d:X %.3f" % (n, hz))
                w.inst.query("*OPC?")
                fsw_read_cfg(w)
                w.post("fill_fields")

            self.fsw_w.tasks.put(("call", job))
            done.append("SA")
        self.fsw_samples.clear()
        self.cur_samples.clear()
        if done:
            self.status("%s 주파수 → %.6g GHz" % (" + ".join(done), g), "#39ff88")
        else:
            self.status("SG / SA 가 연결되지 않았습니다.", "#ff6b6b")

    def refresh_loss_tree(self):
        self.loss_table.sort(key=lambda r: r[0])
        self.loss_tree.delete(*self.loss_tree.get_children())
        for i, (fg, li, lo) in enumerate(self.loss_table):
            self.loss_tree.insert("", "end", iid=str(i), values=("%.6g" % fg, "%.2f" % li, "%.2f" % lo))

    def loss_selected(self, event=None):
        sel = self.loss_tree.selection()
        if sel:
            fg, li, lo = self.loss_table[int(sel[0])]
            self.var_lf.set("%.6g" % fg)
            self.var_li.set("%.2f" % li)
            self.var_lo.set("%.2f" % lo)

    def loss_add(self):
        fg, li, lo = fnum(self.var_lf.get()), fnum(self.var_li.get()), fnum(self.var_lo.get())
        if fg is None:
            f_now = self.smw.get("f")
            if f_now:
                fg = f_now / 1e9
                self.var_lf.set("%.6g" % fg)
        if fg is None or li is None or lo is None:
            messagebox.showwarning(APP_NAME, "주파수(GHz), In loss, Out loss 를 숫자로 입력하세요.")
            return
        self.loss_table = [r for r in self.loss_table if abs(r[0] - fg) > 1e-9]
        self.loss_table.append([fg, li, lo])
        self.refresh_loss_tree()

    def loss_del(self):
        sel = self.loss_tree.selection()
        if not sel:
            return
        idx = {int(i) for i in sel}
        self.loss_table = [r for i, r in enumerate(self.loss_table) if i not in idx]
        self.refresh_loss_tree()

    def losses_at(self, hz):
        """주파수(Hz)의 (In loss, Out loss). 표 사이는 직선 보간, 범위 밖은 끝값, 표가 없으면 입력칸 값."""
        t = self.loss_table
        if not t or hz is None or not math.isfinite(hz):
            return fnum(self.var_li.get(), 0.0), fnum(self.var_lo.get(), 0.0)
        g = hz / 1e9
        if g <= t[0][0]:
            return t[0][1], t[0][2]
        if g >= t[-1][0]:
            return t[-1][1], t[-1][2]
        for a, b in zip(t, t[1:]):
            if a[0] <= g <= b[0]:
                k = (g - a[0]) / (b[0] - a[0]) if b[0] > a[0] else 0
                return a[1] + k * (b[1] - a[1]), a[2] + k * (b[2] - a[2])
        return t[-1][1], t[-1][2]

    def dut_calc(self, sg, sa, amps, hz):
        """DUT Pin/Pout/Gain/Pdc/DE/PAE 계산. 값이 없으면 None."""
        li, lo = self.losses_at(hz)
        pin = sg - li if (sg is not None and math.isfinite(sg)) else None
        pout = sa + lo if (sa is not None and math.isfinite(sa)) else None
        gain = pout - pin if (pin is not None and pout is not None) else None
        vdd = fnum(self.var_vdd.get())
        pdc = vdd * amps if (vdd is not None and amps is not None and math.isfinite(amps)) else None
        de = pae = None
        min_a = fnum(self.var_minid.get(), 0.0) / 1e3 if hasattr(self, "var_minid") else 0.0
        low_id = amps is not None and math.isfinite(amps) and amps < min_a
        if pdc is not None and pdc > 0 and pout is not None and not low_id:
            de = dbm_to_w(pout) / pdc * 100.0
            if pin is not None:
                pae = (dbm_to_w(pout) - dbm_to_w(pin)) / pdc * 100.0
        return dict(inl=li, outl=lo, pin=pin, pout=pout, gain=gain, pdc=pdc, de=de, pae=pae)

    # ------------------------------------------------ 기록
    def toggle_rec(self):
        self.rec_on = not self.rec_on
        if self.rec_on:
            self.btn_rec.configure(text="■ 자동 기록 중지", bg="#a52a2a")
            # 시작 시점의 현재 파워도 한 줄 기록
            self.last_pin = None
            self.change_t = time.time()
            self.pending = True
        else:
            self.btn_rec.configure(text="● 자동 기록 시작", bg="#7a1f1f")
            self.pending = False
            self.lbl_rec.configure(text="")

    def window_avg(self, samples, t1, t2, db=False):
        vals = [v for (t, v) in samples if t1 <= t <= t2 and math.isfinite(v)]
        if not vals:
            return None, 0
        if db:  # dBm → 선형 평균
            lin = sum(10 ** (v / 10.0) for v in vals) / len(vals)
            return 10 * math.log10(lin), len(vals)
        return sum(vals) / len(vals), len(vals)

    def record(self, manual=False, t1=None, t2=None):
        now = time.time()
        avg_s = max(0.0, fnum(self.var_avg.get(), 1.0))
        if t2 is None:
            t2 = now
        if t1 is None:
            t1 = t2 - max(avg_s, 0.3)
        pin_raw = self.smw["p"]
        freq = self.smw["f"]
        pout_raw, nf = self.window_avg(self.fsw_samples, t1, t2, db=True)
        if pout_raw is None and self.fsw["y"] is not None and math.isfinite(self.fsw["y"]):
            pout_raw = self.fsw["y"]
        cur, nc = self.window_avg(self.cur_samples, t1, t2)
        if cur is None:
            t, a = self.cur_last
            if now - t < 3 and math.isfinite(a):
                cur = a
        if pout_raw is not None and math.isfinite(pout_raw) and self.var_saq.get():
            pout_raw = quantize_half(pout_raw)
        c = self.dut_calc(pin_raw, pout_raw, cur, freq)
        row = {
            "no": len(self.rows) + 1,
            "time": datetime.datetime.now().strftime("%H:%M:%S"),
            "freq": freq / 1e9 if freq else None,
            "sg": pin_raw if (pin_raw is not None and math.isfinite(pin_raw)) else None,
            "sa": pout_raw,
            "id": cur * 1e3 if cur is not None else None,
        }
        row.update(c)
        pin, pout = c["pin"], c["pout"]
        replaced = None
        if row["sg"] is not None:
            key = (round(row["freq"] or 0, 6), round(row["sg"], 2))
            for i, r in enumerate(self.rows):
                if r.get("sg") is not None and (round(r["freq"] or 0, 6), round(r["sg"], 2)) == key:
                    replaced = i
                    break
        if replaced is not None:
            row["no"] = self.rows[replaced]["no"]
            self.rows[replaced] = row
            self.tree.item(str(row["no"]), values=self.row_values(row))
        else:
            self.rows.append(row)
            self.tree.insert("", "end", iid=str(row["no"]), values=self.row_values(row))
        self.tree.see(str(row["no"]))
        self.tree.selection_set(str(row["no"]))
        self.refresh_plots()
        miss = []
        if pin is None:
            miss.append("SMW")
        if pout is None:
            miss.append("FSW")
        if cur is None:
            miss.append("전류")
        if fnum(self.var_vdd.get()) is None:
            miss.append("Vdd 미입력 → PAE")
        msg = "%s #%d  DUT Pin %s dBm" % ("덮어씀" if replaced is not None else "기록", row["no"], self.fmt(pin, 2))
        if cur is not None and row["pae"] is None and fnum(self.var_vdd.get()) is not None:
            msg += "  · Id < %s mA → PAE 제외" % self.var_minid.get()
        if miss:
            msg += "  (값 없음: %s)" % ", ".join(miss)
        self.status(msg, "#d4a017" if miss else "#39ff88")

    @staticmethod
    def fmt(v, d):
        return "" if v is None else ("%.*f" % (d, v))

    def row_values(self, r):
        f = self.fmt
        return (r["no"], r["time"], f(r["freq"], 4), f(r["sg"], 2), f(r["sa"], 2), f(r["inl"], 2), f(r["outl"], 2),
                f(r["pin"], 2), f(r["pout"], 2), f(r["gain"], 2), f(r["id"], 1), f(r["pdc"], 3),
                f(r["de"], 2), f(r["pae"], 2))

    def table_text(self):
        lines = ["\t".join(c[1] for c in self.COLS)]
        for r in self.rows:
            lines.append("\t".join(str(x) for x in self.row_values(r)))
        return "\n".join(lines)

    def copy_rows(self):
        if not self.rows:
            self.status("기록된 행이 없습니다.", "#d4a017")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(self.table_text())
        self.status("%d행 복사됨 - 엑셀에서 Ctrl+V" % len(self.rows), "#39ff88")

    def save_csv(self):
        if not self.rows:
            return
        name = "PA_bench_%s.csv" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=name,
                                            filetypes=[("CSV", "*.csv")])
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow([c[1] for c in self.COLS])
            for r in self.rows:
                w.writerow(self.row_values(r))
        self.status("저장됨: " + path, "#39ff88")

    def recalc_rows(self):
        """기록된 SG·SA·Id 원본값으로 DUT Pin/Pout/Gain/PAE 를 현재 Vdd·손실로 다시 계산."""
        for r in self.rows:
            amps = r["id"] / 1e3 if r.get("id") is not None else None
            hz = r["freq"] * 1e9 if r.get("freq") is not None else None
            r.update(self.dut_calc(r.get("sg"), r.get("sa"), amps, hz))
        self.renumber()
        self.status("%d행 다시 계산됨 (Vdd %s V)" % (len(self.rows), self.var_vdd.get() or "미입력"), "#39ff88")

    def delete_selected(self):
        sel = set(self.tree.selection())
        if not sel:
            return
        self.rows = [r for r in self.rows if str(r["no"]) not in sel]
        self.renumber()

    def clear_rows(self):
        if self.rows and messagebox.askyesno(APP_NAME, "기록을 모두 지울까요?"):
            self.rows = []
            self.renumber()

    def renumber(self):
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(self.rows, 1):
            r["no"] = i
            self.tree.insert("", "end", iid=str(i), values=self.row_values(r))
        self.refresh_plots()

    def status(self, text, color=FG_DIM):
        self.lbl_status.configure(text=text, fg=color)

    # ------------------------------------------------ 주기 처리
    def tick(self):
        try:
            while True:
                msg = self.q.get_nowait()
                self.handle(msg)
        except queue.Empty:
            pass
        self.update_dashboard()
        self.auto_record_step()
        self.root.after(100, self.tick)

    def handle(self, msg):
        name, kind = msg[0], msg[1]
        now = time.time()
        if name == "smw":
            if kind == "val":
                _, _, f, p, rf = msg
                self.smw.update(f=f, p=p, rf=rf, t=now)
                self.lbl_smw_read.configure(text="현재: %s · %s dBm · RF %s" % (
                    fmt_freq(f), self.fmt(p, 2) if math.isfinite(p) else "---", "ON" if rf else "OFF"))
            elif kind == "connected":
                self.smw["conn"] = True
                self.btn_smw.configure(text="연결 해제")
                self.lbl_smw_idn.configure(text=msg[2], foreground="#1f4f8f")
                self.status("SMW200A 연결됨", "#39ff88")
            elif kind == "disconnected":
                self.smw.update(conn=False, p=None)
                self.btn_smw.configure(text="연결")
            elif kind == "error":
                self.status("SMW: " + msg[2], "#ff6b6b")
            elif kind == "status":
                self.status("SMW: " + msg[2])
        elif name == "fsw":
            if kind == "val":
                y = msg[2]
                self.fsw.update(y=y, t=now)
                if math.isfinite(y):
                    self.fsw_samples.append((now, y))
            elif kind == "cfg":
                _, _, cent, span, n, on, mx = msg
                self.fsw.update(mx=mx, cent=cent, span=span, mon=on)
                first = not self.fsw.get("filled_once")
                self.lbl_fsw_read.configure(text="장비 현재: Center %s · Span %s · M%d %s" % (
                    fmt_freq(cent), fmt_freq(span), n, fmt_freq(mx) if on else "꺼짐"))
                if first:
                    self.fill_fsw_fields()
                    self.fsw["filled_once"] = True
            elif kind == "fill_fields":
                self.fill_fsw_fields()
            elif kind == "filled":
                self.fill_fsw_fields()
                self.status("FSW 설정 적용됨", "#39ff88")
            elif kind == "connected":
                self.fsw["conn"] = True
                self.fsw["filled_once"] = False
                self.btn_fsw.configure(text="연결 해제")
                self.lbl_fsw_idn.configure(text=msg[2], foreground="#1f4f8f")
                self.status("FSW 연결됨 - 장비 설정값을 불러왔습니다", "#39ff88")
            elif kind == "disconnected":
                self.fsw.update(conn=False, y=None)
                self.btn_fsw.configure(text="연결")
            elif kind == "error":
                self.status("FSW: " + msg[2], "#ff6b6b")
            elif kind == "status":
                self.status("FSW: " + msg[2])

    def fill_fsw_fields(self):
        cent, span, mx = self.fsw.get("cent"), self.fsw.get("span"), self.fsw.get("mx")
        if cent is not None and math.isfinite(cent):
            self.var_fsw_cent.set("%.6g" % (cent / 1e9))
        if span is not None and math.isfinite(span):
            self.var_fsw_span.set("%.6g" % (span / 1e6))
        if mx is not None and math.isfinite(mx):
            self.var_fsw_mx.set("%.6g" % (mx / 1e9))

    def update_dashboard(self):
        now = time.time()
        # SMW
        v, sub = self.big["smw"]
        p = self.smw["p"]
        if self.smw["conn"] and p is not None and math.isfinite(p):
            v.configure(text="%.2f dBm" % p, fg=C_SMW if self.smw["rf"] else FG_DIM)
            sub.configure(text="%s · RF %s" % (fmt_freq(self.smw["f"]), "ON" if self.smw["rf"] else "OFF"))
        else:
            v.configure(text="---", fg=FG_DIM)
            sub.configure(text="연결 안 됨" if not self.smw["conn"] else "")
        # FSW
        v, sub = self.big["fsw"]
        y = self.fsw["y"]
        if self.fsw["conn"] and y is not None and math.isfinite(y):
            v.configure(text="%.2f dBm" % y, fg=C_FSW)
            sub.configure(text="M%s @ %s" % (self.var_fsw_mk.get(), fmt_freq(self.fsw["mx"])))
        else:
            v.configure(text="---", fg=FG_DIM)
            sub.configure(text="연결 안 됨" if not self.fsw["conn"] else "마커 꺼짐 / 값 없음")
        # 전류
        v, sub = self.big["cur"]
        t, a = self.cur_last
        if self.scope.running and math.isfinite(a) and now - t < 3:
            v.configure(text=self.scope.format_value(a), fg=C_CUR if not getattr(self.scope, "stale", False) else FG_DIM)
            sub.configure(text=self.scope.lbl_info.cget("text")[:40])
        else:
            v.configure(text="---", fg=FG_DIM)
            sub.configure(text="측정 정지" if self.scope.connected else "연결 안 됨")
        # DUT Gain / PAE (실시간, 케이블 손실 포함)
        v, sub = self.big["gain"]
        amps = a if (math.isfinite(a) and now - t < 3 and self.scope.running) else None
        if (p is not None and y is not None and math.isfinite(p) and math.isfinite(y)
                and self.smw["conn"] and self.fsw["conn"]):
            c = self.dut_calc(p, y, amps, self.smw["f"])
            v.configure(text="%.2f dB" % c["gain"], fg=C_GAIN)
            txt = "Pin %.2f · Pout %.2f dBm" % (c["pin"], c["pout"])
            if c["pae"] is not None:
                txt += " · PAE %.1f%%" % c["pae"]
            sub.configure(text=txt)
        else:
            v.configure(text="---", fg=FG_DIM)
            sub.configure(text="")
        # 케이블 손실 / Vdd 안내
        li, lo = self.losses_at(self.smw["f"])
        self.lbl_loss.configure(text="현재 적용: In %.2f / Out %.2f dB%s" % (
            li, lo, (" @ %.6g GHz" % (self.smw["f"] / 1e9)) if self.smw["f"] else ""))
        self.lbl_vdd.configure(text="" if fnum(self.var_vdd.get()) else "← Vdd 를 입력해야 Pdc · DE · PAE 가 계산됩니다")
        if p is not None and math.isfinite(p) and not self.var_lvl2.get():
            self.var_lvl2.set("%.2f" % p)

    def auto_record_step(self):
        if not self.rec_on:
            return
        p = self.smw["p"]
        now = time.time()
        if p is None or not math.isfinite(p):
            self.lbl_rec.configure(text="SMW 값 대기 중...")
            return
        if self.last_pin is None:
            self.last_pin = p
        elif abs(p - self.last_pin) > 0.004:
            self.last_pin = p
            self.change_t = now
            self.pending = True
        if self.pending:
            settle = max(0.0, fnum(self.var_settle.get(), 1.0))
            avg = max(0.2, fnum(self.var_avg.get(), 1.0))
            left = self.change_t + settle + avg - now
            if left > 0:
                stage = "안정화" if now < self.change_t + settle else "평균 중"
                self.lbl_rec.configure(text="Pin %.2f dBm  %s... %.1f초" % (p, stage, left))
            else:
                self.record(t1=self.change_t + settle, t2=now)
                self.pending = False
                self.lbl_rec.configure(text="다음 파워 변경 대기 중 (Pin %.2f dBm 기록됨)" % p)

    # ------------------------------------------------ 종료
    def on_close(self):
        s = self.s
        s.update(
            smw_host=self.var_smw_host.get(), smw_port=int(fnum(self.var_smw_port.get(), 5025)),
            smw_gtl=self.var_smw_gtl.get(), smw_poll=int(fnum(self.var_smw_poll.get(), 300)),
            smw_step=self.var_smw_step.get(), smw_max=self.var_smw_max.get(),
            fsw_host=self.var_fsw_host.get(), fsw_port=int(fnum(self.var_fsw_port.get(), 5025)),
            fsw_gtl=self.var_fsw_gtl.get(), fsw_poll=int(fnum(self.var_fsw_poll.get(), 300)),
            fsw_marker=int(self.var_fsw_mk.get()),
            settle=self.var_settle.get(), avg=self.var_avg.get(), vdd=self.var_vdd.get(),
            loss_table=self.loss_table, in_loss=self.var_li.get(), out_loss=self.var_lo.get(),
            freq_ghz=self.var_freq.get(), min_id=self.var_minid.get(), sa_q=self.var_saq.get(),
            pae_ax=[v.get() for v in self.var_pae_ax], gain_ax=[v.get() for v in self.var_gain_ax],
            geometry=self.root.geometry(), tab=self.nb.index("current"))
        save_settings(s)
        if self.rows:
            # 실수로 닫아도 기록이 남도록 자동 백업
            try:
                d = os.path.join(os.path.dirname(settings_path()), "backup")
                os.makedirs(d, exist_ok=True)
                path = os.path.join(d, "PA_bench_%s.csv" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
                with open(path, "w", newline="", encoding="utf-8-sig") as f:
                    w = csv.writer(f)
                    w.writerow([c[1] for c in self.COLS])
                    for r in self.rows:
                        w.writerow(self.row_values(r))
            except Exception:
                pass
        for w in (self.smw_w, self.fsw_w):
            w.alive = False
            w.close()
        self.scope.shutdown()
        self.root.destroy()


def main():
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    BenchApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
