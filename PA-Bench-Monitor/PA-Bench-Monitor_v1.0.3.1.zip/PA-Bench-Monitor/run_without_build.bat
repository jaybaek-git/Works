@echo off
cd /d %~dp0
python pa_bench_monitor.py
if errorlevel 1 pause
