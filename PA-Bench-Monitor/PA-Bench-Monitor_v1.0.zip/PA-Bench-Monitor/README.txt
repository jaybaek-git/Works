﻿PA Bench Monitor v1.0
=====================
R&S SMW200A(신호발생기) · FSW(스펙트럼 분석기) · RTO2044(오실로스코프 전류)
세 장비 값을 한 화면에 실시간으로 띄우고, SMW 파워가 바뀔 때마다 자동으로 표에 기록합니다.

■ 장비에는 아무것도 설치하지 않음
  세 장비 모두 LAN(SCPI, TCP 5025 포트)으로 접속. IP만 입력하면 됩니다.
  IP 칸에 demo 입력 → 장비 없이 동작 확인 (세 장비 모두 demo면 서로 연동된 가상 PA)

■ 빌드
  build_exe.bat → dist\PA-Bench-Monitor_v1.0.exe
  (빌드 없이 실행: run_without_build.bat)
  * rto_current_meter.py 가 같은 폴더에 있어야 합니다 (전류 측정 부분, exe 에는 자동 포함)

■ 화면 구성
  [상단 실시간]  SMW 출력 파워 | FSW 마커 파워 | 전류 | Gain / PAE
  [탭]
   - 측정 기록  : 자동 기록 표, 엑셀용 복사, CSV 저장
   - SMW200A    : IP 연결, (선택) 레벨 설정 / ▲▼ 스텝
   - FSW        : IP 연결, Center / Span / 마커 번호 / 마커 주파수
                  → 연결하면 장비에 지금 설정된 값을 그대로 불러와 초기값으로 사용
                  → 바꾸고 싶을 때만 [장비에 적용], [마커 피크 찾기]
   - RTO2044    : 기존 RTO Current Meter 그대로 (구간, 트리거 추적, 스케일 자동 등)

■ 측정 순서 (예)
  1. 각 탭에서 IP 입력 → 상단 [모두 연결]
  2. 상단 [▶ 전류 측정 시작/정지]  (또는 RTO2044 탭에서 ▶ 측정 시작)
  3. 상단 [● 자동 기록 시작]  → 현재 파워가 먼저 한 줄 기록됨
  4. SMW 에서 파워를 1 dB 씩 올림 (장비 앞 패널 또는 SMW 탭의 ▲ 버튼)
     → 파워가 바뀔 때마다: [안정화 시간] 기다린 뒤 [평균 시간] 동안
        FSW 파워·전류를 평균해서 한 줄 자동 기록
  5. 측정 기록 탭 [엑셀용 복사] → 엑셀에서 Ctrl+V  (DRM 엑셀에도 붙여넣기 가능)
  * [지금 기록] : 파워 변경 없이 바로 한 줄 기록 (최근 평균 시간 구간)

■ 기록 항목
  No · 시간 · 주파수(SMW) · Pin · Pout · Gain · Id(mA) · Pdc · PAE · 마커 주파수
  Pin  = SMW 레벨 + 입력 보정(dB)   (케이블/커플러 손실 보정용, 기본 0)
  Pout = FSW 마커 + 출력 보정(dB)   (감쇠기 등, FSW 에 Ref offset 이 이미 있으면 0)
  Vdd(V) 입력 시: Pdc = Vdd × Id,  PAE = (Pout − Pin)[W] / Pdc × 100
  FSW 파워는 선형(mW)으로 평균한 뒤 dBm 으로 환산

■ 장비 앞 패널 잠금 관련
  원격 명령을 받으면 R&S 장비는 REMOTE 상태가 되어 앞 패널이 잠깁니다.
  "읽은 뒤 바로 Local 복귀(&GTL)" (기본 켜짐) → 매번 읽은 직후 Local 로 돌려
  SMW 앞 패널로 파워를 계속 조절할 수 있게 합니다.
  손잡이 조작이 가끔 씹히면 SMW 탭의 [읽기 주기]를 500~1000 ms 로 늘리세요.

■ 안전
  SMW 탭의 레벨 설정/▲ 버튼은 "최대 허용(dBm)" 보다 높게 설정하지 않습니다.
  프로그램이 RF ON/OFF 는 건드리지 않습니다.

■ 기타
  - 설정은 종료 시 자동 저장 (%APPDATA%\PABenchMonitor)
  - 기록이 남아 있는 상태로 종료하면 %APPDATA%\PABenchMonitor\backup 에 CSV 자동 백업
  - 사용 명령: SMW  SOUR1:FREQ? / SOUR1:POW? / OUTP1:STAT? (SOUR1:POW <lvl>)
               FSW  SENS:FREQ:CENT? / SPAN? / CALC1:MARK<n>:STAT? / X? / Y? (MAX)
