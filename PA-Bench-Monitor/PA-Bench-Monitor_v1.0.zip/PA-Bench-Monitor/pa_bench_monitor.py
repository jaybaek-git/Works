# -*- coding: utf-8 -*-
"""
PA Bench Monitor v1.0
R&S SMW200A (신호발생기) + FSW (스펙트럼 분석기) + RTO2044 (오실로스코프 전류)
세 장비의 값을 한 화면에 실시간 표시하고, SMW 파워가 바뀔 때마다 자동으로 표에 기록.

- 장비에는 아무것도 설치하지 않음 (LAN, SCPI raw socket 5025)
- IP 칸에 demo 입력 시 장비 없이 동작 확인 가능 (세 장비 모두 demo 로 두면 서로 연동된 가상 PA)
"""
import collections
import csv
import datetime
import json
import math
import os
import queue
import socket
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import rto_current_meter as rto

APP_NAME = "PA Bench Monitor"
VERSION = "v1.0"

BG = "#0b0f14"
FG_DIM = "#7d8a99"
C_SMW = "#ffb74d"
C_FSW = "#4fc3f7"
C_CUR = "#39ff88"
C_GAIN = "#e0e0e0"


def settings_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(base, "PABenchMonitor")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "settings.json")


DEFAULTS = {
    "smw_host": "192.168.0.11", "smw_port": 5025, "smw_gtl": True, "smw_poll": 300,
    "smw_step": "1", "smw_max": "10",
    "fsw_host": "192.168.0.12", "fsw_port": 5025, "fsw_gtl": True, "fsw_poll": 300,
    "fsw_marker": 1,
    "settle": "1.0", "avg": "1.0", "vdd": "", "in_off": "0", "out_off": "0",
    "auto_rec": True, "geometry": "1180x860", "tab": 0,
}


def load_settings():
    s = dict(DEFAULTS)
    try:
        with open(settings_path(), "r", encoding="utf-8") as f:
            s.update(json.load(f))
    except Exception:
        pass
    return s


def save_settings(s):
    try:
        with open(settings_path(), "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def fnum(text, default=None):
    try:
        return float(str(text).strip())
    except (ValueError, TypeError):
        return default


def fmt_freq(hz):
    if hz is None or not math.isfinite(hz):
        return "---"
    if hz >= 1e9:
        return "%.6g GHz" % (hz / 1e9)
    if hz >= 1e6:
        return "%.6g MHz" % (hz / 1e6)
    return "%.6g kHz" % (hz / 1e3)


def dbm_to_w(dbm):
    return 10 ** ((dbm - 30) / 10.0)


# ============================================================ 가상 장비 (demo)
DEMO = {"pin": -40.0, "freq": 3.5e9, "rf": True}


def demo_pout(pin):
    """가상 PA: 이득 28 dB, Psat 약 44 dBm (부드러운 압축)."""
    lin = dbm_to_w(pin + 28.0)
    psat = dbm_to_w(44.0)
    p = 2.0  # Rapp 모델
    out = lin / (1 + (lin / psat) ** p) ** (1.0 / p)
    return 10 * math.log10(out) + 30


def _demo_amp(self):
    if not DEMO["rf"]:
        return 0.25
    pw = dbm_to_w(demo_pout(DEMO["pin"]))
    return 0.25 + 1.6 * math.sqrt(pw / dbm_to_w(44.0))


rto.DemoScope._amp = _demo_amp  # 오실로스코프 demo 전류를 가상 PA 와 연동


class DemoSMW:
    def write(self, cmd):
        c = cmd.upper()
        val = cmd.split(" ", 1)[1].strip() if " " in cmd else ""
        if c.startswith("SOUR1:POW ") or c.startswith("SOURCE1:POWER "):
            DEMO["pin"] = float(val)
        elif c.startswith("OUTP1:STAT ") or c.startswith("OUTP1 "):
            DEMO["rf"] = val.upper() in ("1", "ON")

    def query(self, cmd):
        c = cmd.upper()
        time.sleep(0.005)
        if c == "*IDN?":
            return "Rohde&Schwarz,SMW200A (DEMO),1412.0000K02/000000,5.30"
        if c.startswith("SOUR1:FREQ"):
            return "%.1f" % DEMO["freq"]
        if c.startswith("SOUR1:POW"):
            return "%.2f" % DEMO["pin"]
        if c.startswith("OUTP1"):
            return "1" if DEMO["rf"] else "0"
        if c.startswith("SYST:ERR"):
            return '0,"No error"'
        return "1"

    def close(self):
        pass


class DemoFSW:
    def __init__(self):
        self.cent = 3.5e9
        self.span = 10e6
        self.mx = {1: 3.5e9}
        self.mon = {1: True}

    def write(self, cmd):
        c = cmd.upper()
        val = cmd.split(" ", 1)[1].strip() if " " in cmd else ""
        n = int("".join(ch for ch in c.split(":MARK")[1][:2] if ch.isdigit()) or 1) if ":MARK" in c else 1
        if c.startswith("FREQ:CENT ") or c.startswith("SENS:FREQ:CENT "):
            self.cent = float(val)
        elif ":X " in c:
            self.mx[n] = float(val)
            self.mon[n] = True
        elif ":STAT " in c and ":MARK" in c:
            self.mon[n] = val.upper() in ("1", "ON")
        elif c.endswith(":MAX"):
            self.mx[n] = DEMO["freq"]
            self.mon[n] = True

    def query(self, cmd):
        c = cmd.upper()
        time.sleep(0.005)
        n = int("".join(ch for ch in c.split(":MARK")[1][:2] if ch.isdigit()) or 1) if ":MARK" in c else 1
        if c == "*IDN?":
            return "Rohde&Schwarz,FSW-50 (DEMO),1331.5003K50/000000,5.00"
        if "FREQ:CENT?" in c:
            return "%.1f" % self.cent
        if "FREQ:SPAN?" in c:
            return "%.1f" % self.span
        if ":STAT?" in c:
            return "1" if self.mon.get(n) else "0"
        if c.endswith(":X?"):
            return "%.1f" % self.mx.get(n, self.cent)
        if c.endswith(":Y?"):
            off = abs(self.mx.get(n, 0) - DEMO["freq"]) / 1e6
            p = demo_pout(DEMO["pin"]) - 40.0 if DEMO["rf"] else -90.0  # 40 dB 감쇠기 가정
            import random
            return "%.3f" % (p - 3.0 * off ** 2 + random.gauss(0, 0.03))
        if c.startswith("SYST:ERR"):
            return '0,"No error"'
        return "1"

    def close(self):
        pass


# ============================================================ 공용 통신 스레드
class InstWorker(threading.Thread):
    """장비 하나당 하나의 통신 스레드. 결과는 (name, kind, ...) 로 out_q 에 보냄."""

    def __init__(self, name, out_q, demo_cls):
        super().__init__(daemon=True)
        self.name = name
        self.out = out_q
        self.demo_cls = demo_cls
        self.tasks = queue.Queue()
        self.inst = None
        self.interval = 0.3
        self.gtl = True
        self.alive = True
        self.poll_fn = None
        self.init_fn = None

    def post(self, *msg):
        self.out.put((self.name,) + msg)

    def close(self):
        if self.inst:
            try:
                if self.gtl:
                    self.inst.write("&GTL")
            except Exception:
                pass
            self.inst.close()
        self.inst = None

    def run(self):
        while self.alive:
            t0 = time.time()
            try:
                while True:
                    try:
                        task = self.tasks.get_nowait()
                    except queue.Empty:
                        break
                    kind = task[0]
                    if kind == "connect":
                        self.close()
                        host, port = task[1].strip(), task[2]
                        self.post("status", "연결 중... %s" % host)
                        if host.lower() == "demo":
                            self.inst = self.demo_cls()
                        else:
                            self.inst = rto.ScpiSocket(host, port, timeout=5.0)
                        idn = self.inst.query("*IDN?")
                        self.inst.write("*CLS")
                        if self.init_fn:
                            self.init_fn(self)
                        self.post("connected", idn)
                    elif kind == "disconnect":
                        self.close()
                        self.post("disconnected")
                    elif kind == "call":
                        if not self.inst:
                            raise ConnectionError("먼저 장비에 연결하세요.")
                        task[1](self)
                if self.inst and self.poll_fn:
                    self.poll_fn(self)
                    if self.gtl:
                        self.inst.write("&GTL")  # 앞 패널을 바로 쓸 수 있도록 Local 로 복귀
            except (socket.timeout, TimeoutError):
                self.post("error", "응답 시간 초과 - 연결이 끊어졌습니다. (IP / LAN / 장비 상태 확인)")
                self.close()
                self.post("disconnected")
            except (ConnectionError, OSError) as e:
                self.post("error", str(e))
                self.close()
                self.post("disconnected")
            except Exception as e:
                self.post("error", str(e))
            wait = self.interval - (time.time() - t0)
            time.sleep(max(wait, 0.03))


def q_float(inst, cmd):
    r = inst.query(cmd)
    try:
        v = float(r.split(",")[0])
    except ValueError:
        return float("nan")
    if abs(v) > 1e30:
        return float("nan")
    return v


# ---------- SMW200A
def smw_poll(w):
    f = q_float(w.inst, "SOUR1:FREQ?")
    p = q_float(w.inst, "SOUR1:POW?")
    rf = w.inst.query("OUTP1:STAT?").strip().upper() in ("1", "ON")
    w.post("val", f, p, rf)


# ---------- FSW
def fsw_read_cfg(w):
    n = w.marker
    cent = q_float(w.inst, "SENS:FREQ:CENT?")
    span = q_float(w.inst, "SENS:FREQ:SPAN?")
    on = w.inst.query("CALC1:MARK%d:STAT?" % n).strip().upper() in ("1", "ON")
    mx = q_float(w.inst, "CALC1:MARK%d:X?" % n) if on else float("nan")
    w.marker_on = on
    w.post("cfg", cent, span, n, on, mx)


def fsw_init(w):
    try:
        w.inst.write("SYST:DISP:UPD ON")
        w.inst.query("*OPC?")
    except Exception:
        pass
    fsw_read_cfg(w)
    w.cfg_t = time.time()


def fsw_poll(w):
    if time.time() - getattr(w, "cfg_t", 0) > 2.0:  # 사용자가 장비에서 바꾼 설정 반영
        fsw_read_cfg(w)
        w.cfg_t = time.time()
    if w.marker_on:
        y = q_float(w.inst, "CALC1:MARK%d:Y?" % w.marker)
        w.post("val", y)
    else:
        w.post("val", float("nan"))


# ============================================================ 메인 화면
class BenchApp:
    COLS = [("no", "No", 40), ("time", "시간", 80), ("freq", "주파수(GHz)", 90),
            ("pin", "Pin(dBm)", 80), ("pout", "Pout(dBm)", 85), ("gain", "Gain(dB)", 75),
            ("id", "Id(mA)", 80), ("pdc", "Pdc(W)", 70), ("pae", "PAE(%)", 70),
            ("mfreq", "마커(GHz)", 90)]

    def __init__(self, root):
        self.root = root
        self.s = load_settings()
        self.q = queue.Queue()
        self.rows = []
        # 실시간 값
        self.smw = {"conn": False, "f": None, "p": None, "rf": False, "t": 0}
        self.fsw = {"conn": False, "y": None, "mx": None, "t": 0}
        self.cur_samples = collections.deque(maxlen=2000)  # (t, A)
        self.fsw_samples = collections.deque(maxlen=2000)  # (t, dBm)
        # 자동 기록 상태
        self.rec_on = False
        self.last_pin = None
        self.change_t = None
        self.pending = False

        root.title("%s %s" % (APP_NAME, VERSION))
        root.geometry(self.s.get("geometry") or "1180x860")
        root.minsize(900, 600)
        try:
            ttk.Style().theme_use("vista")
        except Exception:
            pass
        root.option_add("*Font", ("맑은 고딕", 9))

        self.smw_w = InstWorker("smw", self.q, DemoSMW)
        self.smw_w.poll_fn = smw_poll
        self.fsw_w = InstWorker("fsw", self.q, DemoFSW)
        self.fsw_w.poll_fn = fsw_poll
        self.fsw_w.init_fn = fsw_init
        self.fsw_w.marker = int(self.s.get("fsw_marker", 1))
        self.fsw_w.marker_on = False
        for w in (self.smw_w, self.fsw_w):
            w.start()

        self.build_dashboard()
        self.nb = ttk.Notebook(root)
        self.nb.pack(side="top", fill="both", expand=True, padx=4, pady=4)
        self.build_log_tab()
        self.build_smw_tab()
        self.build_fsw_tab()
        self.build_scope_tab()
        try:
            self.nb.select(int(self.s.get("tab", 0)))
        except Exception:
            pass
        self.apply_worker_opts()
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(100, self.tick)

    # ------------------------------------------------ 상단 실시간 표시
    def build_dashboard(self):
        d = tk.Frame(self.root, bg=BG)
        d.pack(side="top", fill="x")
        self.dash = d
        cols = tk.Frame(d, bg=BG)
        cols.pack(side="top", fill="x", padx=6, pady=(6, 0))
        self.big = {}
        spec = [("smw", "신호발생기 출력 (SMW200A)", C_SMW),
                ("fsw", "스펙트럼 분석기 (FSW)", C_FSW),
                ("cur", "전류 (RTO 오실로스코프)", C_CUR),
                ("gain", "Gain / PAE", C_GAIN)]
        for i, (key, title, color) in enumerate(spec):
            cols.columnconfigure(i, weight=1, uniform="c")
            box = tk.Frame(cols, bg=BG, highlightthickness=1, highlightbackground="#1f2a36")
            box.grid(row=0, column=i, sticky="nsew", padx=3)
            tk.Label(box, text=title, bg=BG, fg=FG_DIM, font=("맑은 고딕", 10)).pack(anchor="w", padx=8, pady=(4, 0))
            v = tk.Label(box, text="---", bg=BG, fg=color, font=("Consolas", 30, "bold"))
            v.pack(fill="x", padx=4)
            sub = tk.Label(box, text="", bg=BG, fg=FG_DIM, font=("Consolas", 10))
            sub.pack(fill="x", padx=4, pady=(0, 6))
            self.big[key] = (v, sub)
        bar = tk.Frame(d, bg=BG)
        bar.pack(side="top", fill="x", padx=6, pady=6)
        mk = dict(relief="flat", padx=12, pady=3, activeforeground="#ffffff")
        tk.Button(bar, text="모두 연결", command=self.connect_all, bg="#1c2530", fg="#c8d3de",
                  activebackground="#2a3644", **mk).pack(side="left", padx=3)
        tk.Button(bar, text="▶ 전류 측정 시작/정지", command=self.toggle_current, bg="#1c2530", fg="#c8d3de",
                  activebackground="#2a3644", **mk).pack(side="left", padx=3)
        self.btn_rec = tk.Button(bar, text="● 자동 기록 시작", command=self.toggle_rec, bg="#7a1f1f",
                                 fg="#ffffff", activebackground="#a52a2a", **mk)
        self.btn_rec.pack(side="left", padx=3)
        tk.Button(bar, text="지금 기록", command=lambda: self.record(manual=True), bg="#1c2530", fg="#c8d3de",
                  activebackground="#2a3644", **mk).pack(side="left", padx=3)
        self.lbl_rec = tk.Label(bar, text="", bg=BG, fg="#d4a017", font=("맑은 고딕", 10))
        self.lbl_rec.pack(side="left", padx=10)
        self.lbl_status = tk.Label(bar, text="", bg=BG, fg=FG_DIM, anchor="e")
        self.lbl_status.pack(side="right", fill="x", expand=True)
        d.bind("<Configure>", self.on_dash_resize)

    def on_dash_resize(self, event=None):
        w = max(self.dash.winfo_width(), 400)
        size = int(max(18, min(44, w / 4 / 11 * 1.45)))
        for key, (v, sub) in self.big.items():
            v.configure(font=("Consolas", size, "bold"))

    # ------------------------------------------------ 탭: 측정 기록
    def build_log_tab(self):
        s = self.s
        f = ttk.Frame(self.nb, padding=6)
        self.nb.add(f, text="  측정 기록  ")
        top = ttk.Frame(f)
        top.pack(fill="x")
        pad = dict(padx=4, pady=2)
        self.var_auto = tk.BooleanVar(value=bool(s["auto_rec"]))
        ttk.Label(top, text="SMW 파워가 바뀌면").grid(row=0, column=0, sticky="e", **pad)
        self.var_settle = tk.StringVar(value=s["settle"])
        ttk.Entry(top, textvariable=self.var_settle, width=5).grid(row=0, column=1, **pad)
        ttk.Label(top, text="초 기다린 뒤").grid(row=0, column=2, sticky="w", **pad)
        self.var_avg = tk.StringVar(value=s["avg"])
        ttk.Entry(top, textvariable=self.var_avg, width=5).grid(row=0, column=3, **pad)
        ttk.Label(top, text="초 동안 평균해서 기록 (FSW 파워·전류)").grid(row=0, column=4, sticky="w", **pad)
        ttk.Label(top, text="Vdd(V)").grid(row=0, column=5, sticky="e", padx=(20, 4))
        self.var_vdd = tk.StringVar(value=s["vdd"])
        ttk.Entry(top, textvariable=self.var_vdd, width=6).grid(row=0, column=6, **pad)
        ttk.Label(top, text="입력 보정(dB)").grid(row=1, column=0, sticky="e", **pad)
        self.var_inoff = tk.StringVar(value=s["in_off"])
        ttk.Entry(top, textvariable=self.var_inoff, width=5).grid(row=1, column=1, **pad)
        ttk.Label(top, text="출력 보정(dB)").grid(row=1, column=2, sticky="e", **pad)
        self.var_outoff = tk.StringVar(value=s["out_off"])
        ttk.Entry(top, textvariable=self.var_outoff, width=5).grid(row=1, column=3, **pad)
        ttk.Label(top, text="Pin = SMW 레벨 + 입력 보정,  Pout = FSW 마커 + 출력 보정  (Vdd 입력 시 Pdc·PAE 계산)",
                  foreground="#666").grid(row=1, column=4, columnspan=3, sticky="w", **pad)

        tf = ttk.Frame(f)
        tf.pack(fill="both", expand=True, pady=(6, 4))
        self.tree = ttk.Treeview(tf, columns=[c[0] for c in self.COLS], show="headings", height=12)
        for key, title, wd in self.COLS:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=wd, anchor="center")
        sb = ttk.Scrollbar(tf, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        bf = ttk.Frame(f)
        bf.pack(fill="x")
        ttk.Button(bf, text="엑셀용 복사 (Ctrl+V 로 붙여넣기)", command=self.copy_rows).pack(side="left", padx=3)
        ttk.Button(bf, text="CSV 저장", command=self.save_csv).pack(side="left", padx=3)
        ttk.Button(bf, text="선택 행 삭제", command=self.delete_selected).pack(side="left", padx=3)
        ttk.Button(bf, text="전체 지우기", command=self.clear_rows).pack(side="left", padx=3)
        ttk.Label(bf, text=VERSION, foreground="#999").pack(side="right")
        self.tree.bind("<Control-c>", lambda e: self.copy_rows())

    # ------------------------------------------------ 탭: SMW
    def build_smw_tab(self):
        s = self.s
        f = ttk.Frame(self.nb, padding=10)
        self.nb.add(f, text="  SMW200A (신호발생기)  ")
        pad = dict(padx=4, pady=4)
        g = ttk.LabelFrame(f, text=" 연결 (LAN) ", padding=8)
        g.pack(fill="x")
        ttk.Label(g, text="IP").grid(row=0, column=0, **pad)
        self.var_smw_host = tk.StringVar(value=s["smw_host"])
        ttk.Entry(g, textvariable=self.var_smw_host, width=18).grid(row=0, column=1, **pad)
        ttk.Label(g, text="Port").grid(row=0, column=2, **pad)
        self.var_smw_port = tk.StringVar(value=str(s["smw_port"]))
        ttk.Entry(g, textvariable=self.var_smw_port, width=6).grid(row=0, column=3, **pad)
        self.btn_smw = ttk.Button(g, text="연결", command=self.smw_connect, width=10)
        self.btn_smw.grid(row=0, column=4, **pad)
        self.lbl_smw_idn = ttk.Label(g, text="(IP에 demo 입력 시 장비 없이 테스트)", foreground="#666")
        self.lbl_smw_idn.grid(row=1, column=0, columnspan=6, sticky="w", **pad)
        self.var_smw_gtl = tk.BooleanVar(value=bool(s["smw_gtl"]))
        ttk.Checkbutton(g, text="읽은 뒤 바로 Local 복귀 (&GTL) - 장비 앞 패널로 파워 조절 가능하게",
                        variable=self.var_smw_gtl, command=self.apply_worker_opts).grid(
            row=2, column=0, columnspan=6, sticky="w", **pad)
        ttk.Label(g, text="읽기 주기(ms)").grid(row=3, column=0, **pad)
        self.var_smw_poll = tk.StringVar(value=str(s["smw_poll"]))
        ttk.Spinbox(g, from_=100, to=5000, increment=100, textvariable=self.var_smw_poll, width=7,
                    command=self.apply_worker_opts).grid(row=3, column=1, sticky="w", **pad)

        g2 = ttk.LabelFrame(f, text=" 파워 조절 (선택 사항 - 장비 앞 패널에서 직접 올려도 됨) ", padding=8)
        g2.pack(fill="x", pady=8)
        ttk.Label(g2, text="레벨(dBm)").grid(row=0, column=0, **pad)
        self.var_smw_lvl = tk.StringVar(value="")
        ttk.Entry(g2, textvariable=self.var_smw_lvl, width=8).grid(row=0, column=1, **pad)
        ttk.Button(g2, text="설정", command=self.smw_set_level).grid(row=0, column=2, **pad)
        ttk.Label(g2, text="스텝(dB)").grid(row=0, column=3, **pad)
        self.var_smw_step = tk.StringVar(value=s["smw_step"])
        ttk.Entry(g2, textvariable=self.var_smw_step, width=5).grid(row=0, column=4, **pad)
        ttk.Button(g2, text="▲ 올리기", command=lambda: self.smw_step(+1)).grid(row=0, column=5, **pad)
        ttk.Button(g2, text="▼ 내리기", command=lambda: self.smw_step(-1)).grid(row=0, column=6, **pad)
        ttk.Label(g2, text="최대 허용(dBm)").grid(row=1, column=0, **pad)
        self.var_smw_max = tk.StringVar(value=s["smw_max"])
        ttk.Entry(g2, textvariable=self.var_smw_max, width=8).grid(row=1, column=1, **pad)
        ttk.Label(g2, text="※ 이 값보다 높게는 프로그램에서 설정하지 않음 (DUT 보호)", foreground="#666").grid(
            row=1, column=2, columnspan=5, sticky="w", **pad)
        self.lbl_smw_read = ttk.Label(f, text="", foreground="#1f4f8f")
        self.lbl_smw_read.pack(anchor="w", pady=4)

    # ------------------------------------------------ 탭: FSW
    def build_fsw_tab(self):
        s = self.s
        f = ttk.Frame(self.nb, padding=10)
        self.nb.add(f, text="  FSW (스펙트럼 분석기)  ")
        pad = dict(padx=4, pady=4)
        g = ttk.LabelFrame(f, text=" 연결 (LAN) ", padding=8)
        g.pack(fill="x")
        ttk.Label(g, text="IP").grid(row=0, column=0, **pad)
        self.var_fsw_host = tk.StringVar(value=s["fsw_host"])
        ttk.Entry(g, textvariable=self.var_fsw_host, width=18).grid(row=0, column=1, **pad)
        ttk.Label(g, text="Port").grid(row=0, column=2, **pad)
        self.var_fsw_port = tk.StringVar(value=str(s["fsw_port"]))
        ttk.Entry(g, textvariable=self.var_fsw_port, width=6).grid(row=0, column=3, **pad)
        self.btn_fsw = ttk.Button(g, text="연결", command=self.fsw_connect, width=10)
        self.btn_fsw.grid(row=0, column=4, **pad)
        self.lbl_fsw_idn = ttk.Label(g, text="(IP에 demo 입력 시 장비 없이 테스트)", foreground="#666")
        self.lbl_fsw_idn.grid(row=1, column=0, columnspan=6, sticky="w", **pad)
        self.var_fsw_gtl = tk.BooleanVar(value=bool(s["fsw_gtl"]))
        ttk.Checkbutton(g, text="읽은 뒤 바로 Local 복귀 (&GTL) - 장비 앞 패널도 계속 조작 가능하게",
                        variable=self.var_fsw_gtl, command=self.apply_worker_opts).grid(
            row=2, column=0, columnspan=6, sticky="w", **pad)
        ttk.Label(g, text="읽기 주기(ms)").grid(row=3, column=0, **pad)
        self.var_fsw_poll = tk.StringVar(value=str(s["fsw_poll"]))
        ttk.Spinbox(g, from_=100, to=5000, increment=100, textvariable=self.var_fsw_poll, width=7,
                    command=self.apply_worker_opts).grid(row=3, column=1, sticky="w", **pad)

        g2 = ttk.LabelFrame(f, text=" 주파수 / 마커  (연결하면 장비에 지금 설정된 값을 불러옴) ", padding=8)
        g2.pack(fill="x", pady=8)
        ttk.Label(g2, text="Center(GHz)").grid(row=0, column=0, **pad)
        self.var_fsw_cent = tk.StringVar(value="")
        ttk.Entry(g2, textvariable=self.var_fsw_cent, width=12).grid(row=0, column=1, **pad)
        ttk.Label(g2, text="Span(MHz)").grid(row=0, column=2, **pad)
        self.var_fsw_span = tk.StringVar(value="")
        ttk.Entry(g2, textvariable=self.var_fsw_span, width=10).grid(row=0, column=3, **pad)
        ttk.Label(g2, text="마커 번호").grid(row=1, column=0, **pad)
        self.var_fsw_mk = tk.StringVar(value=str(s["fsw_marker"]))
        cb = ttk.Combobox(g2, textvariable=self.var_fsw_mk, values=[str(i) for i in range(1, 17)],
                          width=4, state="readonly")
        cb.grid(row=1, column=1, sticky="w", **pad)
        cb.bind("<<ComboboxSelected>>", lambda e: self.fsw_marker_changed())
        ttk.Label(g2, text="마커 주파수(GHz)").grid(row=1, column=2, **pad)
        self.var_fsw_mx = tk.StringVar(value="")
        ttk.Entry(g2, textvariable=self.var_fsw_mx, width=12).grid(row=1, column=3, **pad)
        bf = ttk.Frame(g2)
        bf.grid(row=2, column=0, columnspan=6, sticky="w", pady=(6, 0))
        ttk.Button(bf, text="장비에 적용", command=self.fsw_apply).pack(side="left", padx=3)
        ttk.Button(bf, text="마커 피크 찾기", command=self.fsw_peak).pack(side="left", padx=3)
        ttk.Button(bf, text="장비 값 다시 불러오기", command=self.fsw_reload).pack(side="left", padx=3)
        ttk.Label(g2, text="※ 빈 칸은 장비에 보내지 않음. 마커는 Window 1 기준.", foreground="#666").grid(
            row=3, column=0, columnspan=6, sticky="w", **pad)
        self.lbl_fsw_read = ttk.Label(f, text="", foreground="#1f4f8f")
        self.lbl_fsw_read.pack(anchor="w", pady=4)

    # ------------------------------------------------ 탭: 오실로스코프 (기존 전류계 그대로)
    def build_scope_tab(self):
        f = ttk.Frame(self.nb)
        self.nb.add(f, text="  RTO2044 (전류)  ")
        self.scope = rto.App(self.root, container=f)
        orig = self.scope.show_value
        bench = self

        def hooked(raw, t):
            amps = raw * bench.scope.conv_factor() if math.isfinite(raw) else float("nan")
            if math.isfinite(amps) and not getattr(bench.scope, "stale", False):
                bench.cur_samples.append((t, amps))
            bench.cur_last = (t, amps)
            orig(raw, t)

        self.scope.show_value = hooked
        self.cur_last = (0, float("nan"))

    # ------------------------------------------------ 동작
    def apply_worker_opts(self):
        self.smw_w.gtl = self.var_smw_gtl.get()
        self.fsw_w.gtl = self.var_fsw_gtl.get()
        self.smw_w.interval = max(100, fnum(self.var_smw_poll.get(), 300)) / 1000.0
        self.fsw_w.interval = max(100, fnum(self.var_fsw_poll.get(), 300)) / 1000.0

    def connect_all(self):
        if not self.smw["conn"]:
            self.smw_connect()
        if not self.fsw["conn"]:
            self.fsw_connect()
        if not self.scope.connected:
            self.scope.on_connect()

    def toggle_current(self):
        if not self.scope.connected:
            self.status("오실로스코프가 연결되지 않았습니다 - 'RTO2044 (전류)' 탭 확인", "#ff6b6b")
            return
        self.scope.on_run()

    def smw_connect(self):
        if self.smw["conn"]:
            self.smw_w.tasks.put(("disconnect",))
            return
        self.apply_worker_opts()
        self.smw_w.tasks.put(("connect", self.var_smw_host.get(), int(fnum(self.var_smw_port.get(), 5025))))

    def fsw_connect(self):
        if self.fsw["conn"]:
            self.fsw_w.tasks.put(("disconnect",))
            return
        self.apply_worker_opts()
        self.fsw_w.marker = int(self.var_fsw_mk.get())
        self.fsw_w.tasks.put(("connect", self.var_fsw_host.get(), int(fnum(self.var_fsw_port.get(), 5025))))

    def smw_set_level(self, lvl=None):
        if not self.smw["conn"]:
            messagebox.showinfo(APP_NAME, "SMW200A 가 연결되지 않았습니다.")
            return
        if lvl is None:
            lvl = fnum(self.var_smw_lvl.get())
            if lvl is None:
                messagebox.showwarning(APP_NAME, "레벨(dBm)에 숫자를 입력하세요.")
                return
        mx = fnum(self.var_smw_max.get(), 10.0)
        if lvl > mx + 1e-9:
            messagebox.showwarning(APP_NAME, "최대 허용 레벨(%.2f dBm)을 넘습니다." % mx)
            return
        self.var_smw_lvl.set("%.2f" % lvl)
        self.smw_w.tasks.put(("call", lambda w: w.inst.write("SOUR1:POW %.2f" % lvl)))

    def smw_step(self, sign):
        p = self.smw["p"]
        if p is None or not math.isfinite(p):
            messagebox.showinfo(APP_NAME, "SMW 현재 레벨을 아직 못 읽었습니다.")
            return
        st = fnum(self.var_smw_step.get(), 1.0)
        self.smw_set_level(round(p + sign * st, 2))

    def fsw_marker_changed(self):
        n = int(self.var_fsw_mk.get())
        self.fsw_w.tasks.put(("call", lambda w: (setattr(w, "marker", n), fsw_read_cfg(w))))
        self.fsw_samples.clear()

    def fsw_apply(self):
        if not self.fsw["conn"]:
            messagebox.showinfo(APP_NAME, "FSW 가 연결되지 않았습니다.")
            return
        n = int(self.var_fsw_mk.get())
        cent = fnum(self.var_fsw_cent.get())
        span = fnum(self.var_fsw_span.get())
        mx = fnum(self.var_fsw_mx.get())

        def job(w):
            w.marker = n
            if cent is not None:
                w.inst.write("SENS:FREQ:CENT %.6f" % (cent * 1e9))
            if span is not None:
                w.inst.write("SENS:FREQ:SPAN %.6f" % (span * 1e6))
            w.inst.write("CALC1:MARK%d:STAT ON" % n)
            if mx is not None:
                w.inst.write("CALC1:MARK%d:X %.6f" % (n, mx * 1e9))
            w.inst.query("*OPC?")
            errs = []
            for _ in range(10):
                e = w.inst.query("SYST:ERR?")
                if e.startswith("0") or e.startswith("+0"):
                    break
                errs.append(e)
            if errs:
                w.post("error", "FSW 오류: " + " / ".join(errs))
            fsw_read_cfg(w)
            w.post("filled")

        self.fsw_samples.clear()
        self.fsw_w.tasks.put(("call", job))

    def fsw_peak(self):
        if not self.fsw["conn"]:
            return
        n = int(self.var_fsw_mk.get())

        def job(w):
            w.marker = n
            w.inst.write("CALC1:MARK%d:STAT ON" % n)
            w.inst.write("CALC1:MARK%d:MAX" % n)
            w.inst.query("*OPC?")
            fsw_read_cfg(w)
            w.post("fill_fields")

        self.fsw_samples.clear()
        self.fsw_w.tasks.put(("call", job))

    def fsw_reload(self):
        if not self.fsw["conn"]:
            return
        self.fsw_w.tasks.put(("call", lambda w: (fsw_read_cfg(w), w.post("fill_fields"))))

    # ------------------------------------------------ 기록
    def toggle_rec(self):
        self.rec_on = not self.rec_on
        if self.rec_on:
            self.btn_rec.configure(text="■ 자동 기록 중지", bg="#a52a2a")
            # 시작 시점의 현재 파워도 한 줄 기록
            self.last_pin = None
            self.change_t = time.time()
            self.pending = True
        else:
            self.btn_rec.configure(text="● 자동 기록 시작", bg="#7a1f1f")
            self.pending = False
            self.lbl_rec.configure(text="")

    def window_avg(self, samples, t1, t2, db=False):
        vals = [v for (t, v) in samples if t1 <= t <= t2 and math.isfinite(v)]
        if not vals:
            return None, 0
        if db:  # dBm → 선형 평균
            lin = sum(10 ** (v / 10.0) for v in vals) / len(vals)
            return 10 * math.log10(lin), len(vals)
        return sum(vals) / len(vals), len(vals)

    def record(self, manual=False, t1=None, t2=None):
        now = time.time()
        avg_s = max(0.0, fnum(self.var_avg.get(), 1.0))
        if t2 is None:
            t2 = now
        if t1 is None:
            t1 = t2 - max(avg_s, 0.3)
        pin_raw = self.smw["p"]
        freq = self.smw["f"]
        pout_raw, nf = self.window_avg(self.fsw_samples, t1, t2, db=True)
        if pout_raw is None and self.fsw["y"] is not None and math.isfinite(self.fsw["y"]):
            pout_raw = self.fsw["y"]
        cur, nc = self.window_avg(self.cur_samples, t1, t2)
        if cur is None:
            t, a = self.cur_last
            if now - t < 3 and math.isfinite(a):
                cur = a
        in_off = fnum(self.var_inoff.get(), 0.0)
        out_off = fnum(self.var_outoff.get(), 0.0)
        pin = pin_raw + in_off if pin_raw is not None and math.isfinite(pin_raw) else None
        pout = pout_raw + out_off if pout_raw is not None else None
        gain = pout - pin if (pin is not None and pout is not None) else None
        vdd = fnum(self.var_vdd.get())
        pdc = vdd * cur if (vdd is not None and cur is not None) else None
        pae = None
        if pdc and pin is not None and pout is not None and pdc > 0:
            pae = (dbm_to_w(pout) - dbm_to_w(pin)) / pdc * 100.0
        row = {
            "no": len(self.rows) + 1,
            "time": datetime.datetime.now().strftime("%H:%M:%S"),
            "freq": freq / 1e9 if freq else None,
            "pin": pin, "pout": pout, "gain": gain,
            "id": cur * 1e3 if cur is not None else None,
            "pdc": pdc, "pae": pae,
            "mfreq": self.fsw["mx"] / 1e9 if self.fsw["mx"] and math.isfinite(self.fsw["mx"]) else None,
        }
        self.rows.append(row)
        self.tree.insert("", "end", iid=str(row["no"]), values=self.row_values(row))
        self.tree.see(str(row["no"]))
        miss = []
        if pin is None:
            miss.append("SMW")
        if pout is None:
            miss.append("FSW")
        if cur is None:
            miss.append("전류")
        msg = "기록 #%d  Pin %s dBm" % (row["no"], self.fmt(pin, 2))
        if miss:
            msg += "  (값 없음: %s)" % ", ".join(miss)
        self.status(msg, "#d4a017" if miss else "#39ff88")

    @staticmethod
    def fmt(v, d):
        return "" if v is None else ("%.*f" % (d, v))

    def row_values(self, r):
        return (r["no"], r["time"], self.fmt(r["freq"], 4), self.fmt(r["pin"], 2), self.fmt(r["pout"], 2),
                self.fmt(r["gain"], 2), self.fmt(r["id"], 1), self.fmt(r["pdc"], 3), self.fmt(r["pae"], 1),
                self.fmt(r["mfreq"], 4))

    def table_text(self):
        lines = ["\t".join(c[1] for c in self.COLS)]
        for r in self.rows:
            lines.append("\t".join(str(x) for x in self.row_values(r)))
        return "\n".join(lines)

    def copy_rows(self):
        if not self.rows:
            self.status("기록된 행이 없습니다.", "#d4a017")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(self.table_text())
        self.status("%d행 복사됨 - 엑셀에서 Ctrl+V" % len(self.rows), "#39ff88")

    def save_csv(self):
        if not self.rows:
            return
        name = "PA_bench_%s.csv" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=name,
                                            filetypes=[("CSV", "*.csv")])
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow([c[1] for c in self.COLS])
            for r in self.rows:
                w.writerow(self.row_values(r))
        self.status("저장됨: " + path, "#39ff88")

    def delete_selected(self):
        sel = set(self.tree.selection())
        if not sel:
            return
        self.rows = [r for r in self.rows if str(r["no"]) not in sel]
        self.renumber()

    def clear_rows(self):
        if self.rows and messagebox.askyesno(APP_NAME, "기록을 모두 지울까요?"):
            self.rows = []
            self.renumber()

    def renumber(self):
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(self.rows, 1):
            r["no"] = i
            self.tree.insert("", "end", iid=str(i), values=self.row_values(r))

    def status(self, text, color=FG_DIM):
        self.lbl_status.configure(text=text, fg=color)

    # ------------------------------------------------ 주기 처리
    def tick(self):
        try:
            while True:
                msg = self.q.get_nowait()
                self.handle(msg)
        except queue.Empty:
            pass
        self.update_dashboard()
        self.auto_record_step()
        self.root.after(100, self.tick)

    def handle(self, msg):
        name, kind = msg[0], msg[1]
        now = time.time()
        if name == "smw":
            if kind == "val":
                _, _, f, p, rf = msg
                self.smw.update(f=f, p=p, rf=rf, t=now)
                self.lbl_smw_read.configure(text="현재: %s · %s dBm · RF %s" % (
                    fmt_freq(f), self.fmt(p, 2) if math.isfinite(p) else "---", "ON" if rf else "OFF"))
            elif kind == "connected":
                self.smw["conn"] = True
                self.btn_smw.configure(text="연결 해제")
                self.lbl_smw_idn.configure(text=msg[2], foreground="#1f4f8f")
                self.status("SMW200A 연결됨", "#39ff88")
            elif kind == "disconnected":
                self.smw.update(conn=False, p=None)
                self.btn_smw.configure(text="연결")
            elif kind == "error":
                self.status("SMW: " + msg[2], "#ff6b6b")
            elif kind == "status":
                self.status("SMW: " + msg[2])
        elif name == "fsw":
            if kind == "val":
                y = msg[2]
                self.fsw.update(y=y, t=now)
                if math.isfinite(y):
                    self.fsw_samples.append((now, y))
            elif kind == "cfg":
                _, _, cent, span, n, on, mx = msg
                self.fsw.update(mx=mx, cent=cent, span=span, mon=on)
                first = not self.fsw.get("filled_once")
                self.lbl_fsw_read.configure(text="장비 현재: Center %s · Span %s · M%d %s" % (
                    fmt_freq(cent), fmt_freq(span), n, fmt_freq(mx) if on else "꺼짐"))
                if first:
                    self.fill_fsw_fields()
                    self.fsw["filled_once"] = True
            elif kind == "fill_fields":
                self.fill_fsw_fields()
            elif kind == "filled":
                self.fill_fsw_fields()
                self.status("FSW 설정 적용됨", "#39ff88")
            elif kind == "connected":
                self.fsw["conn"] = True
                self.fsw["filled_once"] = False
                self.btn_fsw.configure(text="연결 해제")
                self.lbl_fsw_idn.configure(text=msg[2], foreground="#1f4f8f")
                self.status("FSW 연결됨 - 장비 설정값을 불러왔습니다", "#39ff88")
            elif kind == "disconnected":
                self.fsw.update(conn=False, y=None)
                self.btn_fsw.configure(text="연결")
            elif kind == "error":
                self.status("FSW: " + msg[2], "#ff6b6b")
            elif kind == "status":
                self.status("FSW: " + msg[2])

    def fill_fsw_fields(self):
        cent, span, mx = self.fsw.get("cent"), self.fsw.get("span"), self.fsw.get("mx")
        if cent is not None and math.isfinite(cent):
            self.var_fsw_cent.set("%.6g" % (cent / 1e9))
        if span is not None and math.isfinite(span):
            self.var_fsw_span.set("%.6g" % (span / 1e6))
        if mx is not None and math.isfinite(mx):
            self.var_fsw_mx.set("%.6g" % (mx / 1e9))

    def update_dashboard(self):
        now = time.time()
        # SMW
        v, sub = self.big["smw"]
        p = self.smw["p"]
        if self.smw["conn"] and p is not None and math.isfinite(p):
            v.configure(text="%.2f dBm" % p, fg=C_SMW if self.smw["rf"] else FG_DIM)
            sub.configure(text="%s · RF %s" % (fmt_freq(self.smw["f"]), "ON" if self.smw["rf"] else "OFF"))
        else:
            v.configure(text="---", fg=FG_DIM)
            sub.configure(text="연결 안 됨" if not self.smw["conn"] else "")
        # FSW
        v, sub = self.big["fsw"]
        y = self.fsw["y"]
        if self.fsw["conn"] and y is not None and math.isfinite(y):
            v.configure(text="%.2f dBm" % y, fg=C_FSW)
            sub.configure(text="M%s @ %s" % (self.var_fsw_mk.get(), fmt_freq(self.fsw["mx"])))
        else:
            v.configure(text="---", fg=FG_DIM)
            sub.configure(text="연결 안 됨" if not self.fsw["conn"] else "마커 꺼짐 / 값 없음")
        # 전류
        v, sub = self.big["cur"]
        t, a = self.cur_last
        if self.scope.running and math.isfinite(a) and now - t < 3:
            v.configure(text=self.scope.format_value(a), fg=C_CUR if not getattr(self.scope, "stale", False) else FG_DIM)
            sub.configure(text=self.scope.lbl_info.cget("text")[:40])
        else:
            v.configure(text="---", fg=FG_DIM)
            sub.configure(text="측정 정지" if self.scope.connected else "연결 안 됨")
        # Gain / PAE (실시간, 보정 포함)
        v, sub = self.big["gain"]
        in_off = fnum(self.var_inoff.get(), 0.0)
        out_off = fnum(self.var_outoff.get(), 0.0)
        if p is not None and y is not None and math.isfinite(p) and math.isfinite(y) and self.smw["conn"] and self.fsw["conn"]:
            pin, pout = p + in_off, y + out_off
            v.configure(text="%.2f dB" % (pout - pin), fg=C_GAIN)
            vdd = fnum(self.var_vdd.get())
            if vdd and math.isfinite(a) and a > 0 and now - t < 3:
                pae = (dbm_to_w(pout) - dbm_to_w(pin)) / (vdd * a) * 100
                sub.configure(text="Pout %.2f dBm · PAE %.1f %%" % (pout, pae))
            else:
                sub.configure(text="Pout %.2f dBm  (Vdd 입력 시 PAE)" % pout)
        else:
            v.configure(text="---", fg=FG_DIM)
            sub.configure(text="")

    def auto_record_step(self):
        if not self.rec_on:
            return
        p = self.smw["p"]
        now = time.time()
        if p is None or not math.isfinite(p):
            self.lbl_rec.configure(text="SMW 값 대기 중...")
            return
        if self.last_pin is None:
            self.last_pin = p
        elif abs(p - self.last_pin) > 0.004:
            self.last_pin = p
            self.change_t = now
            self.pending = True
        if self.pending:
            settle = max(0.0, fnum(self.var_settle.get(), 1.0))
            avg = max(0.2, fnum(self.var_avg.get(), 1.0))
            left = self.change_t + settle + avg - now
            if left > 0:
                stage = "안정화" if now < self.change_t + settle else "평균 중"
                self.lbl_rec.configure(text="Pin %.2f dBm  %s... %.1f초" % (p, stage, left))
            else:
                self.record(t1=self.change_t + settle, t2=now)
                self.pending = False
                self.lbl_rec.configure(text="다음 파워 변경 대기 중 (Pin %.2f dBm 기록됨)" % p)

    # ------------------------------------------------ 종료
    def on_close(self):
        s = self.s
        s.update(
            smw_host=self.var_smw_host.get(), smw_port=int(fnum(self.var_smw_port.get(), 5025)),
            smw_gtl=self.var_smw_gtl.get(), smw_poll=int(fnum(self.var_smw_poll.get(), 300)),
            smw_step=self.var_smw_step.get(), smw_max=self.var_smw_max.get(),
            fsw_host=self.var_fsw_host.get(), fsw_port=int(fnum(self.var_fsw_port.get(), 5025)),
            fsw_gtl=self.var_fsw_gtl.get(), fsw_poll=int(fnum(self.var_fsw_poll.get(), 300)),
            fsw_marker=int(self.var_fsw_mk.get()),
            settle=self.var_settle.get(), avg=self.var_avg.get(), vdd=self.var_vdd.get(),
            in_off=self.var_inoff.get(), out_off=self.var_outoff.get(),
            geometry=self.root.geometry(), tab=self.nb.index("current"))
        save_settings(s)
        if self.rows:
            # 실수로 닫아도 기록이 남도록 자동 백업
            try:
                d = os.path.join(os.path.dirname(settings_path()), "backup")
                os.makedirs(d, exist_ok=True)
                path = os.path.join(d, "PA_bench_%s.csv" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
                with open(path, "w", newline="", encoding="utf-8-sig") as f:
                    w = csv.writer(f)
                    w.writerow([c[1] for c in self.COLS])
                    for r in self.rows:
                        w.writerow(self.row_values(r))
            except Exception:
                pass
        for w in (self.smw_w, self.fsw_w):
            w.alive = False
            w.close()
        self.scope.shutdown()
        self.root.destroy()


def main():
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    BenchApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
