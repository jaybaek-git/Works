"""Single source of the program version (title bar, About, build zip name, smoke-test report)."""
__version__ = "2.14.3"
VERSION_LABEL = "v2.14.3"
