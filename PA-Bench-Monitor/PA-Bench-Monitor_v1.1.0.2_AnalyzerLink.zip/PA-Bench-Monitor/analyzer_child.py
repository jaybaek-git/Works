# -*- coding: utf-8 -*-
"""
PA Bench Monitor → RF PA Analyzer 그래프 창 (별도 프로세스)

PA Bench Monitor 가  "<exe> --analyzer-child <port>"  (또는 python pa_bench_monitor.py --analyzer-child <port>)
로 실행. RF PA Analyzer 의 실제 PA 화면(MainWindow: 메뉴 · Datasets · Marker · Back-off · Copy Plot …)을
그대로 띄우고, Bench 가 127.0.0.1:<port> 로 보내는 측정 데이터를 Dataset 으로 넣고 갱신한다.

메시지 (JSON 한 줄씩)
  {"op":"set", "key":k, "name":"S1 3.5GHz", "display":"S1 · 3.5 GHz", "rows":[[...], ...]}
  {"op":"remove", "key":k}      {"op":"reset"}      {"op":"show"}      {"op":"bye"}
"""
import json
import os
import socket
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))


def analyzer_src():
    """RF PA Analyzer 소스 폴더 (개발: pa_analyzer/src, exe: 번들 안 — 모듈은 이미 포함됨)."""
    for cand in (os.path.join(HERE, "pa_analyzer", "src"),
                 os.path.join(getattr(sys, "_MEIPASS", HERE), "pa_analyzer", "src")):
        if os.path.isdir(cand):
            return cand
    return None


def main(port):
    app, win, bridge = build(port)
    return app.exec()


def build(port):
    if sys.stdout is None or sys.stderr is None:   # 창 모드 exe: 콘솔 없음 → 로그 파일
        try:
            d = os.path.dirname(os.path.abspath(sys.executable)) if getattr(sys, "frozen", False) else HERE
            log = open(os.path.join(d, "PA-Analyzer-graph.log"), "a", encoding="utf-8", buffering=1)
        except OSError:
            log = open(os.devnull, "w")
        sys.stdout = sys.stdout or log
        sys.stderr = sys.stderr or log
    os.environ.setdefault("QT_API", "pyside6")
    if os.name == "nt" and not os.environ.get("QT_QPA_FONTDIR"):
        os.environ["QT_QPA_FONTDIR"] = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
    src = analyzer_src()
    if src and src not in sys.path:
        sys.path.insert(0, src)

    from PySide6.QtCore import QSettings, QTimer
    from PySide6.QtWidgets import QApplication, QMessageBox
    import matplotlib
    matplotlib.use("QtAgg")
    from app.controller import AppController
    from excel.reader import RawSheet
    from measurement.loader import MeasurementFile
    from ui.main_window import MainWindow
    from utils.paths import bundle_root, default_simulation_root, example_simulation_root

    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName("PA Measurement Analyzer")
    app.setOrganizationName("PA-Measurement-Analyzer")
    app.setStyle("Fusion")
    for ico in (os.path.join(bundle_root(), "assets", "app.ico"),
                os.path.join(src or HERE, "..", "assets", "app.ico")):
        if os.path.isfile(ico):
            from PySide6.QtGui import QIcon
            app.setWindowIcon(QIcon(ico))
            break

    # 설정은 RF PA Analyzer 와 같은 곳 (조건 표시 · 시뮬레이션 파일 등 그대로)
    settings = QSettings("PA-Measurement-Analyzer", "PA-Measurement-Analyzer")
    sim_root = str(settings.value("sim_root", "") or "")
    if not sim_root or not os.path.isdir(sim_root):
        sim_root = default_simulation_root()
    example = os.path.normcase(os.path.abspath(example_simulation_root()))
    if os.path.normcase(os.path.abspath(sim_root)) == example:
        # 예제 시뮬레이션은 실측과 겹쳐 보이면 헷갈리므로 빈 폴더 사용 (메뉴에서 직접 불러올 수 있음)
        import tempfile
        sim_root = tempfile.mkdtemp(prefix="pa_bench_nosim_")
    controller = AppController(sim_root=sim_root)
    saved = [f for f in str(settings.value("sim_files", "") or "").split("|") if f]
    if saved and all(os.path.isfile(f) for f in saved):
        try:
            controller.load_simulation_files(saved)
        except Exception:
            traceback.print_exc()

    class BenchWindow(MainWindow):
        """Analyzer PA 화면 그대로. 닫을 때: Bench 데이터만 있으면 묻지 않고 닫음."""

        def closeEvent(self, event):
            mf = self.c.measurement
            own = [s for s in (mf.sheets if mf else []) if s.sheet_name not in bridge.names.values()]
            if own and not self._confirm_discard():
                event.ignore()
                return
            event.accept()
            app.quit()

    win = BenchWindow(controller, settings)
    base_title = win.windowTitle()

    class Bridge:
        def __init__(self):
            self.names = {}        # Bench key -> 내부 dataset 이름
            self.buf = b""
            self.sock = socket.create_connection(("127.0.0.1", port), timeout=5)
            self.sock.setblocking(False)
            self.timer = QTimer()
            self.timer.timeout.connect(self.poll)
            self.timer.start(120)

        # ---- Bench → 여기
        def poll(self):
            if app.activeModalWidget() is not None or QApplication.activePopupWidget() is not None:
                return             # 대화상자 / 메뉴가 열려 있는 동안은 나중에 반영
            msgs = []
            while True:
                try:
                    chunk = self.sock.recv(1 << 16)
                except (BlockingIOError, InterruptedError):
                    break
                except OSError:
                    chunk = b""
                if not chunk:      # Bench 종료 → 같이 닫음
                    self.timer.stop()
                    app.quit()
                    return
                self.buf += chunk
            while b"\n" in self.buf:
                line, self.buf = self.buf.split(b"\n", 1)
                if line.strip():
                    try:
                        msgs.append(json.loads(line.decode("utf-8")))
                    except ValueError:
                        pass
            if not msgs:
                return
            changed = False
            for m in msgs:
                try:
                    changed |= self.apply(m)
                except Exception:
                    traceback.print_exc()
            if changed:
                try:
                    win.refresh(rerender=True)
                    mf = controller.measurement
                    win.setWindowTitle("%s — PA Bench 실시간 연동 (%d개 Dataset)" % (base_title, len(self.names)))
                    if mf is not None:
                        mf.dirty = bool([s for s in mf.sheets if s.sheet_name not in self.names.values()])
                except Exception:
                    traceback.print_exc()

        def measurement(self):
            if controller.measurement is None:
                controller.measurement = MeasurementFile("PA Bench Monitor (실시간)")
            return controller.measurement

        def apply(self, m):
            op = m.get("op")
            if op == "show":
                win.showNormal()
                win.raise_()
                win.activateWindow()
                return False
            if op == "bye":
                app.quit()
                return False
            if op == "reset":
                for name in list(self.names.values()):
                    controller.remove_sheet(name)
                self.names.clear()
                controller.__dict__.pop("_freq_colors", None)   # 주파수 색을 처음부터 (Bench 와 같은 순서)
                return True
            key = m.get("key")
            if op == "remove":
                name = self.names.pop(key, None)
                if name and controller.measurement and controller.measurement.sheet(name):
                    controller.remove_sheet(name)
                    return True
                return False
            if op != "set":
                return False
            mf = self.measurement()
            rows = [list(r) for r in m.get("rows", [])]
            name = self.names.get(key)
            old = mf.sheet(name) if name else None
            if old is not None:
                # 같은 Dataset 을 그 자리에서 새 데이터로 교체 (색 · 스타일 · 체크 · 순서 유지)
                from core.models import Source
                from excel.sheet_parser import parse_sheet
                res = parse_sheet(RawSheet(name, rows, "PA Bench"), Source.MEASUREMENT)
                res.display_name = m.get("display") if m.get("display") != name else None
                res.added_at, res.added_how = getattr(old, "added_at", ""), "PA Bench Monitor 실시간"
                mf.sheets = [res if s is old else s for s in mf.sheets]
                mf.__dict__.pop("_idx", None)
                return True
            raw = RawSheet(m.get("name") or "Bench", rows, "PA Bench")
            res = mf.add_raw_sheet(raw, None, display_name=m.get("display"), how="PA Bench Monitor 실시간")
            if res.sheet_name not in controller.checked:
                controller.checked.append(res.sheet_name)
            controller.sheet_name = res.sheet_name
            self.names[key] = res.sheet_name
            return True

    bridge = Bridge()
    win.show()
    win.raise_()

    def excepthook(exc_type, exc, tb):
        traceback.print_exception(exc_type, exc, tb)
        try:
            QMessageBox.critical(None, "PA Analyzer 그래프", "예기치 않은 오류:\n%s" % exc)
        except Exception:
            pass
    sys.excepthook = excepthook
    return app, win, bridge


if __name__ == "__main__":
    sys.exit(main(int(sys.argv[1])))
