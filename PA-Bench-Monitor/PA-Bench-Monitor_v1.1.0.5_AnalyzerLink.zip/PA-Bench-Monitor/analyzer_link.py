# -*- coding: utf-8 -*-
"""
PA Bench Monitor 쪽: RF PA Analyzer 그래프 창(별도 프로세스) 실행 · 데이터 전달.

Tk 화면과 Qt 화면이 서로 멈추게 하지 않도록 Analyzer 는 별도 프로세스로 띄우고
127.0.0.1 소켓으로 JSON 한 줄씩 보낸다. 바뀐 Dataset 만 보냄.
"""
import importlib.util
import json
import os
import queue
import socket
import subprocess
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))


def child_command(port):
    if getattr(sys, "frozen", False):
        return [sys.executable, "--analyzer-child", str(port)]
    exe = sys.executable
    if os.name == "nt" and exe.lower().endswith("python.exe"):
        w = exe[:-10] + "pythonw.exe"           # 콘솔 창 없이
        if os.path.isfile(w):
            exe = w
    return [exe, os.path.join(HERE, "pa_bench_monitor.py"), "--analyzer-child", str(port)]


def missing_packages():
    """개발 실행(python) 일 때 필요한 패키지 확인. exe 는 모두 포함."""
    if getattr(sys, "frozen", False):
        return []
    return [p for p in ("PySide6", "matplotlib", "numpy", "openpyxl") if importlib.util.find_spec(p) is None]


class AnalyzerLink:
    def __init__(self):
        self.proc = None
        self.srv = None
        self.conn = None
        self.sent = {}            # key -> 보낸 내용 (같으면 다시 안 보냄)
        self.q = queue.Queue()
        self.started = 0.0
        self.error = ""

    # ---------------------------------------------------- 상태
    def running(self):
        return self.proc is not None and self.proc.poll() is None

    def connected(self):
        return self.running() and self.conn is not None

    # ---------------------------------------------------- 실행
    def open(self):
        """창 열기 (이미 떠 있으면 앞으로). 반환: (ok, 메시지)"""
        if self.running():
            self.send({"op": "show"})
            return True, "PA Analyzer 그래프 창을 앞으로 가져왔습니다."
        miss = missing_packages()
        if miss:
            return False, ("PA Analyzer 그래프 창에 필요한 패키지가 없습니다: %s\n\n"
                           "명령 프롬프트에서:\n  python -m pip install PySide6 matplotlib numpy openpyxl\n\n"
                           "(exe 로 빌드한 프로그램은 설치 없이 동작)" % ", ".join(miss))
        self.close()
        self.srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.srv.bind(("127.0.0.1", 0))
        self.srv.listen(1)
        port = self.srv.getsockname()[1]
        flags = 0x08000000 if os.name == "nt" else 0      # CREATE_NO_WINDOW
        try:
            self.proc = subprocess.Popen(child_command(port), creationflags=flags, close_fds=True)
        except Exception as e:
            self.srv.close()
            self.srv = None
            return False, "PA Analyzer 그래프 창을 실행하지 못했습니다.\n%s" % e
        self.sent = {}
        self.q = queue.Queue()
        self.started = time.time()
        threading.Thread(target=self._serve, args=(self.srv, self.q, self.proc), daemon=True).start()
        return True, "PA Analyzer 그래프 창 여는 중… (처음엔 몇 초 걸림)"

    def _serve(self, srv, q, proc):
        srv.settimeout(1.0)
        conn = None
        t0 = time.time()
        while conn is None and proc.poll() is None and time.time() - t0 < 90:
            try:
                conn, _ = srv.accept()
            except socket.timeout:
                continue
            except OSError:
                return
        try:
            srv.close()
        except OSError:
            pass
        if conn is None:
            self.error = "PA Analyzer 그래프 창이 시작되지 않았습니다 (종료 코드 %s)" % proc.poll()
            return
        conn.settimeout(None)
        self.conn = conn
        while proc.poll() is None:
            try:
                msg = q.get(timeout=0.5)
            except queue.Empty:
                continue
            if msg is None:
                break
            try:
                conn.sendall((json.dumps(msg, ensure_ascii=False) + "\n").encode("utf-8"))
            except OSError:
                break
        try:
            conn.close()
        except OSError:
            pass
        if self.conn is conn:
            self.conn = None

    def send(self, msg):
        if self.running():
            self.q.put(msg)

    def close(self):
        if self.running():
            self.q.put({"op": "bye"})
            self.q.put(None)
            try:
                self.proc.wait(timeout=1.5)
            except Exception:
                try:
                    self.proc.terminate()
                except Exception:
                    pass
        self.proc = None
        self.conn = None

    # ---------------------------------------------------- 데이터
    def sync(self, datasets):
        """datasets: [(key, name, display, rows)] — 지금 Bench 에 있는 전체. 바뀐 것만 보냄."""
        if not self.running():
            return
        keys = set()
        for key, name, display, rows in datasets:
            k = json.dumps(key, ensure_ascii=False)
            keys.add(k)
            body = (name, display, rows)
            if self.sent.get(k) != body:
                self.sent[k] = body
                self.send({"op": "set", "key": k, "name": name, "display": display, "rows": rows})
        for k in [k for k in self.sent if k not in keys]:
            del self.sent[k]
            self.send({"op": "remove", "key": k})

    def reset(self):
        """기록 모두 지움 → Analyzer 쪽 Bench 데이터도 지우고 주파수 색 처음부터."""
        self.sent = {}
        self.send({"op": "reset"})
