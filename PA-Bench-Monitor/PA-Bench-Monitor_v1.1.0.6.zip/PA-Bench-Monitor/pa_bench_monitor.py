# -*- coding: utf-8 -*-
"""
PA Bench Monitor v1.1.0.6
R&S SMW200A (신호발생기) + FSW (스펙트럼 분석기) + RTO2044 (오실로스코프 전류)
세 장비의 값을 한 화면에 실시간 표시하고, SMW 파워가 바뀔 때마다 자동으로 표에 기록.

- 장비에는 아무것도 설치하지 않음 (LAN, SCPI raw socket 5025)
- IP 칸에 demo 입력 시 장비 없이 동작 확인 가능 (세 장비 모두 demo 로 두면 서로 연동된 가상 PA)
"""
import collections
import csv
import datetime
import json
import math
import os
import queue
import socket
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import rto_current_meter as rto
try:  # RF PA Analyzer 그래프 창 연동 (연동판에만 포함 · 단독판은 이 파일이 없음)
    from analyzer_link import AnalyzerLink
    HAS_ANALYZER = True
except ImportError:
    HAS_ANALYZER = False

    class AnalyzerLink:  # 단독판: 아무것도 안 함
        def running(self):
            return False

        def sync(self, datasets):
            pass

        def reset(self):
            pass

        def close(self):
            pass

APP_NAME = "PA Bench Monitor"
VERSION = "v1.1.0.6"

BG = "#0b0f14"
FG_DIM = "#7d8a99"
C_SMW = "#ffb74d"
C_FSW = "#4fc3f7"
C_CUR = "#39ff88"
C_GAIN = "#e0e0e0"


def settings_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(base, "PABenchMonitor")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "settings.json")


DEFAULTS = {
    "smw_host": "192.168.0.11", "smw_port": 5025, "smw_gtl": True, "smw_poll": 300,
    "smw_step": "1", "smw_max": "10",
    "fsw_host": "192.168.0.12", "fsw_port": 5025, "fsw_gtl": True, "fsw_poll": 300,
    "fsw_marker": 1,
    "settle": "1.0", "avg": "1.0", "vdd": "",
    "loss_table": [],  # [[GHz, input loss dB, output loss dB], ...]
    "in_loss": "0", "out_loss": "0", "freq_ghz": "",
    "auto_rec": True, "geometry": "1560x900", "tab": 0, "min_id": "250", "sa_q": True,
    "pae_ax": ["20", "80", "10"], "gain_ax": ["20", "40", "2.5"], "loss_dir": "",
    "x_ax": ["26", "54", "5", "1"], "sw_return": True, "sw_idmax": "",
    "ramp_dt": "1.0", "loss_open": True,
    "sw_retry": True, "tol_id": "15", "tol_pae": "5", "sample": "",
}


def load_settings():
    s = dict(DEFAULTS)
    try:
        with open(settings_path(), "r", encoding="utf-8") as f:
            s.update(json.load(f))
    except Exception:
        pass
    return s


def save_settings(s):
    try:
        with open(settings_path(), "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def fnum(text, default=None):
    try:
        return float(str(text).strip())
    except (ValueError, TypeError):
        return default


def fmt_freq(hz):
    if hz is None or not math.isfinite(hz):
        return "---"
    if hz >= 1e9:
        return "%.6g GHz" % (hz / 1e9)
    if hz >= 1e6:
        return "%.6g MHz" % (hz / 1e6)
    return "%.6g kHz" % (hz / 1e3)


def round_sa(v):
    """SA 기록값: 소수 둘째 자리에서 반올림 → 소수 첫째 자리.  예) 12.24 → 12.2, 12.25 → 12.3, -10.75 → -10.8"""
    from decimal import Decimal, ROUND_HALF_UP
    return float(Decimal(repr(v)).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP))


def dbm_to_w(dbm):
    return 10 ** ((dbm - 30) / 10.0)


# ============================================================ 가상 장비 (demo)
DEMO = {"pin": -40.0, "freq": 3.5e9, "rf": True}


def demo_pout(pin):
    """가상 PA: 이득 28 dB, Psat 약 44 dBm (부드러운 압축)."""
    df = (DEMO["freq"] - 3.5e9) / 1e9  # 주파수에 따라 이득/Psat 조금씩 다르게
    lin = dbm_to_w(pin + 28.0 - 8 * df)
    psat = dbm_to_w(44.0 - 4 * df)
    p = 2.0  # Rapp 모델
    out = lin / (1 + (lin / psat) ** p) ** (1.0 / p)
    return 10 * math.log10(out) + 30


def _demo_amp(self):
    if not DEMO["rf"]:
        return 0.25
    pw = dbm_to_w(demo_pout(DEMO["pin"]))
    return 0.25 + 1.6 * math.sqrt(pw / dbm_to_w(44.0))


rto.DemoScope._amp = _demo_amp  # 오실로스코프 demo 전류를 가상 PA 와 연동


class DemoSMW:
    def write(self, cmd):
        c = cmd.upper()
        val = cmd.split(" ", 1)[1].strip() if " " in cmd else ""
        if c.startswith("SOUR1:POW ") or c.startswith("SOURCE1:POWER "):
            DEMO["pin"] = float(val)
        elif c.startswith("SOUR1:FREQ "):
            DEMO["freq"] = float(val)
        elif c.startswith("OUTP1:STAT ") or c.startswith("OUTP1 "):
            DEMO["rf"] = val.upper() in ("1", "ON")

    def query(self, cmd):
        c = cmd.upper()
        time.sleep(0.005)
        if c == "*IDN?":
            return "Rohde&Schwarz,SMW200A (DEMO),1412.0000K02/000000,5.30"
        if c.startswith("SOUR1:FREQ"):
            return "%.1f" % DEMO["freq"]
        if c.startswith("SOUR1:POW"):
            return "%.2f" % DEMO["pin"]
        if c.startswith("OUTP1"):
            return "1" if DEMO["rf"] else "0"
        if c.startswith("SYST:ERR"):
            return '0,"No error"'
        return "1"

    def close(self):
        pass


class DemoFSW:
    def __init__(self):
        self.cent = 3.5e9
        self.span = 10e6
        self.mx = {1: 3.5e9}
        self.mon = {1: True}

    def write(self, cmd):
        c = cmd.upper()
        val = cmd.split(" ", 1)[1].strip() if " " in cmd else ""
        n = int("".join(ch for ch in c.split(":MARK")[1][:2] if ch.isdigit()) or 1) if ":MARK" in c else 1
        if c.startswith("FREQ:CENT ") or c.startswith("SENS:FREQ:CENT "):
            self.cent = float(val)
        elif ":X " in c:
            self.mx[n] = float(val)
            self.mon[n] = True
        elif ":STAT " in c and ":MARK" in c:
            self.mon[n] = val.upper() in ("1", "ON")
        elif c.endswith(":MAX"):
            self.mx[n] = DEMO["freq"]
            self.mon[n] = True

    def query(self, cmd):
        c = cmd.upper()
        time.sleep(0.005)
        n = int("".join(ch for ch in c.split(":MARK")[1][:2] if ch.isdigit()) or 1) if ":MARK" in c else 1
        if c == "*IDN?":
            return "Rohde&Schwarz,FSW-50 (DEMO),1331.5003K50/000000,5.00"
        if "FREQ:CENT?" in c:
            return "%.1f" % self.cent
        if "FREQ:SPAN?" in c:
            return "%.1f" % self.span
        if ":STAT?" in c:
            return "1" if self.mon.get(n) else "0"
        if c.endswith(":X?"):
            return "%.1f" % self.mx.get(n, self.cent)
        if c.endswith(":Y?"):
            off = abs(self.mx.get(n, 0) - DEMO["freq"]) / 1e6
            p = demo_pout(DEMO["pin"]) - 40.0 if DEMO["rf"] else -90.0  # 40 dB 감쇠기 가정
            import random
            return "%.3f" % (p - 3.0 * off ** 2 + random.gauss(0, 0.03))
        if c.startswith("SYST:ERR"):
            return '0,"No error"'
        return "1"

    def close(self):
        pass


# ============================================================ 공용 통신 스레드
class TaskQueue(queue.Queue):
    """명령이 들어오면 통신 스레드를 바로 깨움 (읽기 주기만큼 기다리지 않음)."""

    def __init__(self):
        super().__init__()
        self.wake = threading.Event()

    def put(self, item, block=True, timeout=None):
        super().put(item, block, timeout)
        self.wake.set()


class InstWorker(threading.Thread):
    """장비 하나당 하나의 통신 스레드. 결과는 (name, kind, ...) 로 out_q 에 보냄."""

    def __init__(self, name, out_q, demo_cls):
        super().__init__(daemon=True)
        self.name = name
        self.out = out_q
        self.demo_cls = demo_cls
        self.tasks = TaskQueue()
        self.inst = None
        self.interval = 0.3
        self.gtl = True
        self.alive = True
        self.poll_fn = None
        self.init_fn = None

    def post(self, *msg):
        self.out.put((self.name,) + msg)

    def close(self):
        if self.inst:
            try:
                if self.gtl:
                    self.inst.write("&GTL")
            except Exception:
                pass
            self.inst.close()
        self.inst = None

    def run(self):
        while self.alive:
            t0 = time.time()
            try:
                while True:
                    try:
                        task = self.tasks.get_nowait()
                    except queue.Empty:
                        break
                    kind = task[0]
                    if kind == "connect":
                        self.close()
                        host, port = task[1].strip(), task[2]
                        self.post("status", "연결 중... %s" % host)
                        if host.lower() == "demo":
                            self.inst = self.demo_cls()
                        else:
                            self.inst = rto.ScpiSocket(host, port, timeout=5.0)
                        idn = self.inst.query("*IDN?")
                        self.inst.write("*CLS")
                        if self.init_fn:
                            self.init_fn(self)
                        self.post("connected", idn)
                    elif kind == "disconnect":
                        self.close()
                        self.post("disconnected")
                    elif kind == "call":
                        if not self.inst:
                            raise ConnectionError("먼저 장비에 연결하세요.")
                        task[1](self)
                if self.inst and self.poll_fn:
                    self.poll_fn(self)
                    if self.gtl:
                        self.inst.write("&GTL")  # 앞 패널을 바로 쓸 수 있도록 Local 로 복귀
            except (socket.timeout, TimeoutError):
                self.post("error", "응답 시간 초과 - 연결이 끊어졌습니다. (IP / LAN / 장비 상태 확인)")
                self.close()
                self.post("disconnected")
            except (ConnectionError, OSError) as e:
                self.post("error", str(e))
                self.close()
                self.post("disconnected")
            except Exception as e:
                self.post("error", str(e))
            wait = self.interval - (time.time() - t0)
            self.tasks.wake.wait(max(wait, 0.03))
            self.tasks.wake.clear()


def q_float(inst, cmd):
    r = inst.query(cmd)
    try:
        v = float(r.split(",")[0])
    except ValueError:
        return float("nan")
    if abs(v) > 1e30:
        return float("nan")
    return v


# ---------- SMW200A
def smw_poll(w):
    f = q_float(w.inst, "SOUR1:FREQ?")
    p = q_float(w.inst, "SOUR1:POW?")
    rf = w.inst.query("OUTP1:STAT?").strip().upper() in ("1", "ON")
    w.post("val", f, p, rf)


# ---------- FSW
def fsw_read_cfg(w):
    n = w.marker
    cent = q_float(w.inst, "SENS:FREQ:CENT?")
    span = q_float(w.inst, "SENS:FREQ:SPAN?")
    on = w.inst.query("CALC1:MARK%d:STAT?" % n).strip().upper() in ("1", "ON")
    mx = q_float(w.inst, "CALC1:MARK%d:X?" % n) if on else float("nan")
    w.marker_on = on
    w.post("cfg", cent, span, n, on, mx)


def fsw_init(w):
    try:
        w.inst.write("SYST:DISP:UPD ON")
        w.inst.query("*OPC?")
    except Exception:
        pass
    fsw_read_cfg(w)
    w.cfg_t = time.time()


def fsw_poll(w):
    if time.time() - getattr(w, "cfg_t", 0) > 2.0:  # 사용자가 장비에서 바꾼 설정 반영
        fsw_read_cfg(w)
        w.cfg_t = time.time()
    if w.marker_on:
        y = q_float(w.inst, "CALC1:MARK%d:Y?" % w.marker)
        w.post("val", y)
    else:
        w.post("val", float("nan"))



# ============================================================ 그래프 (Tk Canvas, 추가 설치 불필요)
# 주파수 색상 · 마커: RF PA Analyzer (app/controller.py) 와 똑같은 표
FREQ_COLORS = ["#1f77b4", "#d62728", "#2ca02c", "#ff7f0e", "#9467bd", "#8c564b", "#e377c2",
               "#17becf", "#bcbd22", "#7f7f7f", "#003f5c", "#a05195"]
PALETTE = FREQ_COLORS
MEAS_MARKERS = ["o", "s", "^", "D", "v", "P"]   # 같은 주파수에 여러 측정(샘플) → 마커 모양


def distinct_colors(n):
    """각각색: Analyzer 의 distinct_colors 와 같음 (FREQ 12색 → 추가 8색 → 고르게 퍼진 색)."""
    base = FREQ_COLORS + ["#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4", "#42d4f4", "#f032e6", "#9a6324"]
    if n <= len(base):
        return base[:max(n, 1)]
    import colorsys
    extra = []
    for i in range(n - len(base)):
        h = (i * 0.618033988749895) % 1.0
        r, g, b = colorsys.hsv_to_rgb(h, 0.75, 0.80 if i % 2 else 0.60)
        extra.append("#%02x%02x%02x" % (int(r * 255), int(g * 255), int(b * 255)))
    return base + extra


def freq_key(r):
    return round(r["freq"], 6) if r.get("freq") is not None else None


def freq_colors(rows, cache=None):
    """RF PA Analyzer 와 같은 규칙: 그래프에 있는 주파수를 낮은 주파수부터 FREQ_COLORS 순서대로
    (가장 낮은 주파수 = 파랑, 다음 = 빨강, 초록, 주황 …). 화면 · 엑셀 · Analyzer 창 공통."""
    keys = sorted({freq_key(r) for r in rows if freq_key(r) is not None})
    out = collections.OrderedDict()
    for i, k in enumerate(keys):
        out[k] = FREQ_COLORS[i % len(FREQ_COLORS)]
    return out


DASHES = {"실선": None, "점선": (2, 3), "파선": (6, 4), "일점쇄선": (8, 3, 2, 3)}


def blend(color, k=0.6):
    """색을 흰색 쪽으로 k 만큼 흐리게 (선택 안 된 데이터셋 표시용)."""
    c = color.lstrip("#")
    r, g, b = int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)
    return "#%02x%02x%02x" % tuple(int(v + (255 - v) * k) for v in (r, g, b))


def ticks_by_step(lo, hi, step):
    if not step or step <= 0 or (hi - lo) / step > 400:
        return []
    return [round(k * step, 10) for k in range(int(math.ceil(lo / step - 1e-9)), int(math.floor(hi / step + 1e-9)) + 1)]


def nice_ticks(lo, hi, n=6):
    if not (math.isfinite(lo) and math.isfinite(hi)):
        return []
    if hi - lo < 1e-12:
        lo, hi = lo - 1, hi + 1
    raw = (hi - lo) / n
    e = 10 ** math.floor(math.log10(raw))
    step = min((m * e for m in (1, 2, 2.5, 5, 10) if m * e >= raw), default=10 * e)
    t = math.ceil(lo / step - 1e-9) * step
    out = []
    while t <= hi + 1e-9 * step:
        out.append(round(t, 10))
        t += step
    return out


def draw_marker(cv, shape, cx, cy, r, color):
    """Analyzer(matplotlib) 마커 모양: o 원 · s 사각 · ^ 삼각 · D 마름모 · v 역삼각 · P 굵은 +"""
    if shape == "s":
        cv.create_rectangle(cx - r * 0.9, cy - r * 0.9, cx + r * 0.9, cy + r * 0.9, fill=color, outline=color)
    elif shape == "^":
        cv.create_polygon(cx, cy - r * 1.2, cx - r * 1.1, cy + r * 0.8, cx + r * 1.1, cy + r * 0.8, fill=color, outline=color)
    elif shape == "v":
        cv.create_polygon(cx, cy + r * 1.2, cx - r * 1.1, cy - r * 0.8, cx + r * 1.1, cy - r * 0.8, fill=color, outline=color)
    elif shape == "D":
        cv.create_polygon(cx, cy - r * 1.25, cx + r * 0.9, cy, cx, cy + r * 1.25, cx - r * 0.9, cy, fill=color, outline=color)
    elif shape == "P":
        a, b = r * 1.15, r * 0.4
        cv.create_polygon(cx - b, cy - a, cx + b, cy - a, cx + b, cy - b, cx + a, cy - b, cx + a, cy + b, cx + b, cy + b,
                          cx + b, cy + a, cx - b, cy + a, cx - b, cy + b, cx - a, cy + b, cx - a, cy - b, cx - b, cy - b,
                          fill=color, outline=color)
    else:
        cv.create_oval(cx - r, cy - r, cx + r, cy + r, fill=color, outline=color)


PA_MIME = "application/x-rf-pa-analyzer-pa-datasets"   # RF PA Analyzer 의 Datasets 복사 형식


def win_clipboard_set(text, extra, hwnd=None):
    """Windows 클립보드에 글자(엑셀용) + 다른 형식(이름 → bytes)을 함께 넣음. 성공 시 True."""
    import ctypes
    from ctypes import wintypes
    u32 = ctypes.WinDLL("user32", use_last_error=True)
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    u32.OpenClipboard.argtypes = [wintypes.HWND]
    u32.OpenClipboard.restype = wintypes.BOOL
    u32.EmptyClipboard.restype = wintypes.BOOL
    u32.CloseClipboard.restype = wintypes.BOOL
    u32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
    u32.SetClipboardData.restype = wintypes.HANDLE
    u32.RegisterClipboardFormatW.argtypes = [wintypes.LPCWSTR]
    u32.RegisterClipboardFormatW.restype = wintypes.UINT
    k32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
    k32.GlobalAlloc.restype = wintypes.HGLOBAL
    k32.GlobalLock.argtypes = [wintypes.HGLOBAL]
    k32.GlobalLock.restype = ctypes.c_void_p
    k32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
    k32.GlobalFree.argtypes = [wintypes.HGLOBAL]

    def put(fmt, data):
        h = k32.GlobalAlloc(0x0002, len(data))          # GMEM_MOVEABLE
        if not h:
            return False
        p = k32.GlobalLock(h)
        ctypes.memmove(p, data, len(data))
        k32.GlobalUnlock(h)
        if not u32.SetClipboardData(fmt, h):
            k32.GlobalFree(h)
            return False
        return True

    for _ in range(10):                                  # 다른 프로그램이 잠깐 잡고 있으면 재시도
        if u32.OpenClipboard(hwnd):   # 창 핸들 필요 (None 이면 SetClipboardData 가 실패할 수 있음)
            break
        time.sleep(0.05)
    else:
        return False
    try:
        u32.EmptyClipboard()
        ok = put(13, text.replace("\n", "\r\n").encode("utf-16-le") + b"\x00\x00")   # CF_UNICODETEXT
        for name, data in extra.items():
            fmt = u32.RegisterClipboardFormatW(name)
            if fmt:
                put(fmt, data)
        return ok
    finally:
        u32.CloseClipboard()


class ScrollFrame(ttk.Frame):
    """창이 작아져 내용이 잘리면 스크롤바가 나타나는 틀. 내용은 .body 에 넣음.
    평소 높이 = 내용 높이 (natural_h), 경계선으로 줄이면 스크롤."""

    def __init__(self, parent, horizontal=True, **kw):
        super().__init__(parent, **kw)
        self.cv = tk.Canvas(self, highlightthickness=0, borderwidth=0, height=50, width=50)
        self.vsb = ttk.Scrollbar(self, orient="vertical", command=self.cv.yview)
        self.hsb = ttk.Scrollbar(self, orient="horizontal", command=self.cv.xview) if horizontal else None
        self.cv.configure(yscrollcommand=self.vsb.set, xscrollcommand=self.hsb.set if self.hsb else None)
        self.cv.grid(row=0, column=0, sticky="nsew")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.body = ttk.Frame(self.cv)
        try:
            self.cv.configure(background=ttk.Style().lookup("TFrame", "background") or None)
        except tk.TclError:
            pass
        self.win = self.cv.create_window(0, 0, window=self.body, anchor="nw")
        self.body.bind("<Configure>", lambda e: self._sync())
        self.cv.bind("<Configure>", lambda e: self._sync())
        self.bind("<Enter>", self._wheel_on)
        self.bind("<Leave>", self._wheel_off)

    def natural_h(self):
        return self.body.winfo_reqheight()

    def natural_w(self):
        return self.body.winfo_reqwidth()

    def _sync(self):
        bw, bh = self.body.winfo_reqwidth(), self.body.winfo_reqheight()
        cw, ch = self.cv.winfo_width(), self.cv.winfo_height()
        # 내용이 넓을 땐 원래 폭, 창이 넓으면 창 폭만큼 늘려서 그룹 틀이 꽉 차게
        self.cv.itemconfigure(self.win, width=max(bw, cw), height=max(bh, ch))
        self.cv.configure(scrollregion=(0, 0, max(bw, cw), max(bh, ch)),
                          height=bh, width=bw)
        need_v = ch > 1 and bh > ch + 1
        need_h = self.hsb is not None and cw > 1 and bw > cw + 1
        if need_v and not self.vsb.winfo_ismapped():
            self.vsb.grid(row=0, column=1, sticky="ns")
        elif not need_v and self.vsb.winfo_ismapped():
            self.vsb.grid_remove()
            self.cv.yview_moveto(0)
        if self.hsb is not None:
            if need_h and not self.hsb.winfo_ismapped():
                self.hsb.grid(row=1, column=0, sticky="ew")
            elif not need_h and self.hsb.winfo_ismapped():
                self.hsb.grid_remove()
                self.cv.xview_moveto(0)

    def _wheel(self, e):
        if not self.vsb.winfo_ismapped():
            return
        w = e.widget
        if isinstance(w, (ttk.Combobox, ttk.Treeview, tk.Listbox)):
            return       # 콤보·표 자체 스크롤 우선
        n = -1 if (getattr(e, "delta", 0) > 0 or getattr(e, "num", 0) == 4) else 1
        self.cv.yview_scroll(n * 2, "units")

    def _wheel_on(self, e=None):
        self.bind_all("<MouseWheel>", self._wheel, add="")
        self.bind_all("<Button-4>", self._wheel, add="")
        self.bind_all("<Button-5>", self._wheel, add="")

    def _wheel_off(self, e=None):
        # 안쪽 위젯으로 들어갈 때도 Leave 가 오므로 실제로 틀 밖으로 나갔을 때만 해제
        try:
            x, y = self.winfo_pointerxy()
            w = self.winfo_containing(x, y)
            while w is not None:
                if w is self:
                    return
                w = w.master
        except (tk.TclError, KeyError):
            pass
        for ev in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.unbind_all(ev)


class XYPlot(tk.Canvas):
    def __init__(self, parent, title, xlabel, ylabel, **kw):
        super().__init__(parent, bg="white", highlightthickness=0, **kw)
        self.title, self.xlabel, self.ylabel = title, xlabel, ylabel
        self.series = []       # [(label, color, [(x, y), ...]), ...]
        self.xrange = None     # 두 그래프 x축 맞춤용
        self.yaxis = None      # (min, max, step) 고정 Y축, None 이면 자동
        self.xaxis = None      # (min, max, 숫자 표시 간격, 눈금 간격)
        self.note = ""
        self.view = None       # 확대/이동 중인 범위 (x0, x1, y0, y1), None = 기본 범위
        self.partner = None    # X축을 같이 움직일 그래프 (PAE ↔ Gain)
        self._map = None
        self._drag = None
        self._pick = []        # [(key, px, py), ...] 클릭 선택용
        self.on_pick = None    # 콜백(key 또는 None, 추가선택 여부)
        # 마커: v = 세로선(두 그래프 공통 Pout), h = 가로선, m = 곡선 위 점
        self.vmarks = []       # [x, ...]  (PlotPanel 이 두 그래프에 같은 목록을 넣음)
        self.hmarks = []       # [y, ...]
        self.mmarks = []       # [(key, x, y), ...]
        self.leg_pos = None    # 범례 위치 (그래프 영역 안 왼쪽 위 기준 px), None = 기본
        self._legbox = None
        self.bind("<Configure>", lambda e: self.redraw())
        # 마우스: 휠 위 = 확대, 휠 아래 = 축소, 왼쪽 드래그 = 이동, 더블클릭 = 원래 범위
        self.bind("<MouseWheel>", lambda e: self.on_wheel(e, 1 if e.delta > 0 else -1))
        self.bind("<Button-4>", lambda e: self.on_wheel(e, 1))
        self.bind("<Button-5>", lambda e: self.on_wheel(e, -1))
        self.bind("<ButtonPress-1>", self.on_press)
        self.bind("<B1-Motion>", self.on_drag)
        self.bind("<ButtonRelease-1>", self.on_release)
        self.bind("<Double-Button-1>", lambda e: self.reset_view(both=True))

    # ----- 확대 / 이동
    def to_data(self, px, py):
        L, T, pw, ph, x0, x1, y0, y1 = self._map
        return x0 + (px - L) / pw * (x1 - x0), y0 + (T + ph - py) / ph * (y1 - y0)

    def current_range(self):
        m = self._map
        return (m[4], m[5], m[6], m[7]) if m else None

    def on_wheel(self, e, direction):
        if not self._map:
            return
        L, T, pw, ph = self._map[:4]
        if not (L <= e.x <= L + pw and T <= e.y <= T + ph):
            return
        cx, cy = self.to_data(e.x, e.y)
        x0, x1, y0, y1 = self.current_range()
        f = 0.8 if direction > 0 else 1.25
        nv = (cx - (cx - x0) * f, cx + (x1 - cx) * f, cy - (cy - y0) * f, cy + (y1 - cy) * f)
        self.set_view(nv)

    def on_press(self, e):
        if not self._map:
            return
        lb = self._legbox
        if lb and lb[0] <= e.x <= lb[2] and lb[1] <= e.y <= lb[3]:
            # 범례를 누른 채 끌기 → 위치 이동
            L, T = self._map[:2]
            self._drag = ("legend", e.x, e.y, (lb[0] - L, lb[1] - T))
            self.configure(cursor="fleur")
            return
        hit = self.marker_at(e.x, e.y)
        if hit:
            self._drag = ("marker", e.x, e.y, hit)
            self.configure(cursor="sb_h_double_arrow" if hit[0] == "v" else
                           "sb_v_double_arrow" if hit[0] == "h" else "hand2")
            return
        self._drag = (e.x, e.y, self.current_range())

    def on_release(self, e):
        d = self._drag
        self._drag = None
        if d and d[0] in ("legend", "marker"):
            self.configure(cursor="")
            return
        if not d or abs(e.x - d[0]) > 3 or abs(e.y - d[1]) > 3:
            return  # 드래그(이동)였음
        # 클릭: 가장 가까운 점(10 px 이내)의 데이터셋 선택. Ctrl/Shift 누르면 추가 선택
        best, bd = None, 10.0 ** 2
        for key, px, py in self._pick:
            dd = (px - e.x) ** 2 + (py - e.y) ** 2
            if dd <= bd:
                best, bd = key, dd
        additive = bool(e.state & 0x0001 or e.state & 0x0004)
        if self.on_pick:
            self.on_pick(best, additive)

    def on_drag(self, e):
        if not self._drag or not self._map:
            return
        if self._drag[0] == "legend":
            _, sx, sy, (ox, oy) = self._drag
            self.leg_pos = (ox + e.x - sx, oy + e.y - sy)
            self.redraw()
            return
        if self._drag[0] == "marker":
            self.move_marker(self._drag[3], e.x, e.y)
            return
        sx, sy, (x0, x1, y0, y1) = self._drag
        L, T, pw, ph = self._map[:4]
        dx = (e.x - sx) / pw * (x1 - x0)
        dy = (e.y - sy) / ph * (y1 - y0)
        self.set_view((x0 - dx, x1 - dx, y0 + dy, y1 + dy))

    # ----- 마커 (v: 세로선, h: 가로선, m: 곡선 위 점)
    def _px(self, x, y):
        L, T, pw, ph, x0, x1, y0, y1 = self._map
        return L + (x - x0) / (x1 - x0) * pw, T + ph - (y - y0) / (y1 - y0) * ph

    def nearest_point(self, px, py, limit=None):
        """화면 좌표에서 가장 가까운 데이터 점 (key, x, y)."""
        best, bd = None, float("inf")
        for sd in self.series:
            for x, y in sd["pts"]:
                cx, cy = self._px(x, y)
                dd = (cx - px) ** 2 + (cy - py) ** 2
                if dd < bd:
                    best, bd = (sd["key"], x, y), dd
        if limit is not None and bd > limit ** 2:
            return None
        return best

    def add_marker(self, kind, px, py):
        if not self._map:
            return False
        L, T, pw, ph = self._map[:4]
        if not (L <= px <= L + pw and T <= py <= T + ph):
            return False
        x, y = self.to_data(px, py)
        if kind == "v":
            self.vmarks.append(round(x, 2))
            self.redraw()
            if self.partner is not None:
                self.partner.redraw()
        elif kind == "h":
            self.hmarks.append(round(y, 2))
            self.redraw()
        elif kind == "m":
            pt = self.nearest_point(px, py)
            if pt is None:
                return False
            self.mmarks.append(pt)
            self.redraw()
        return True

    def marker_at(self, px, py, tol=6):
        """마우스 근처 마커 → (종류, 번호)"""
        if not self._map:
            return None
        L, T, pw, ph = self._map[:4]
        if not (L - tol <= px <= L + pw + tol and T - tol <= py <= T + ph + tol):
            return None
        for i, (k, x, y) in enumerate(self.mmarks):
            cx, cy = self._px(x, y)
            if abs(cx - px) <= tol + 2 and abs(cy - py) <= tol + 2:
                return ("m", i)
        for i, x in enumerate(self.vmarks):
            if abs(self._px(x, 0)[0] - px) <= tol:
                return ("v", i)
        for i, y in enumerate(self.hmarks):
            if abs(self._px(0, y)[1] - py) <= tol:
                return ("h", i)
        return None

    def move_marker(self, hit, px, py):
        kind, i = hit
        L, T, pw, ph = self._map[:4]
        px, py = min(max(px, L), L + pw), min(max(py, T), T + ph)
        x, y = self.to_data(px, py)
        if kind == "v" and i < len(self.vmarks):
            self.vmarks[i] = round(x, 2)
            if self.partner is not None:
                self.partner.redraw()
        elif kind == "h" and i < len(self.hmarks):
            self.hmarks[i] = round(y, 2)
        elif kind == "m" and i < len(self.mmarks):
            key = self.mmarks[i][0]          # 같은 곡선 위에서만 옮겨 다님
            best, bd = None, float("inf")
            for sd in self.series:
                if sd["key"] != key:
                    continue
                for xx, yy in sd["pts"]:
                    cx, cy = self._px(xx, yy)
                    dd = (cx - px) ** 2 + (cy - py) ** 2
                    if dd < bd:
                        best, bd = (key, xx, yy), dd
            if best:
                self.mmarks[i] = best
        self.redraw()

    def delete_marker(self, px=None, py=None, everything=False):
        if everything:
            del self.vmarks[:]
            self.hmarks, self.mmarks = [], []
        else:
            hit = self.marker_at(px, py, tol=15) if px is not None else None
            if hit is None:   # 근처에 없으면 마지막에 넣은 것
                for lst, kind in ((self.mmarks, "m"), (self.hmarks, "h"), (self.vmarks, "v")):
                    if lst:
                        hit = (kind, len(lst) - 1)
                        break
            if hit is None:
                return
            {"v": self.vmarks, "h": self.hmarks, "m": self.mmarks}[hit[0]].pop(hit[1])
        self.redraw()
        if self.partner is not None:
            self.partner.redraw()

    @staticmethod
    def _interp(pts, x):
        """곡선(Pout 순)에서 x 의 y 값 (범위 밖이면 None)"""
        p = sorted(pts)
        for (xa, ya), (xb, yb) in zip(p, p[1:]):
            if xa <= x <= xb and xb > xa:
                return ya + (yb - ya) * (x - xa) / (xb - xa)
        if len(p) == 1 and abs(p[0][0] - x) < 1e-9:
            return p[0][1]
        return None

    @staticmethod
    def _cross(pts, y):
        """곡선이 y 를 처음 지나는 x (Pout 순)"""
        p = sorted(pts)
        for (xa, ya), (xb, yb) in zip(p, p[1:]):
            if (ya - y) * (yb - y) <= 0 and yb != ya:
                return xa + (xb - xa) * (y - ya) / (yb - ya)
        return None

    def draw_markers(self):
        L, T, pw, ph, x0, x1, y0, y1 = self._map
        F = ("Consolas", 8)
        vis = [sd for sd in self.series if not sd.get("dim")] or self.series

        boxes = []

        def tag(x, y, text, color, anchor="w", dy=14):
            """값 상자: 다른 상자와 겹치면 위/아래로 비켜서 놓음"""
            t = self.create_text(x, y, text=text, anchor=anchor, fill=color, font=F)
            for k in range(12):
                bb = self.bbox(t)
                if not bb or not any(bb[0] < o[2] + 2 and bb[2] > o[0] - 2 and bb[1] < o[3] + 1 and bb[3] > o[1] - 1
                                     for o in boxes):
                    break
                step = dy * ((k // 2) + 1) * (1 if k % 2 == 0 else -1)
                self.coords(t, x, y + step)
            bb = self.bbox(t)
            if bb:
                boxes.append(bb)
                r = self.create_rectangle(bb[0] - 2, bb[1] - 1, bb[2] + 2, bb[3] + 1, fill="white", outline=color)
                self.tag_lower(r, t)
        for x in self.vmarks:
            if not (x0 <= x <= x1):
                continue
            px = self._px(x, y0)[0]
            self.create_line(px, T, px, T + ph, fill="#444", dash=(5, 3))
            tag(px, T + 2, " %.2f " % x, "#222", "n")
            used = []
            for sd in vis:
                y = self._interp(sd["pts"], x)
                if y is None or not (y0 <= y <= y1):
                    continue
                cx, cy = self._px(x, y)
                self.create_oval(cx - 4, cy - 4, cx + 4, cy + 4, outline=sd["color"], width=2)
                tag(cx + 7, cy, "%.2f" % y, sd["color"])
        for y in self.hmarks:
            if not (y0 <= y <= y1):
                continue
            py = self._px(x0, y)[1]
            self.create_line(L, py, L + pw, py, fill="#444", dash=(5, 3))
            tag(L + pw - 2, py - 8, " %.2f " % y, "#222", "e")
            used = []
            for sd in vis:
                x = self._cross(sd["pts"], y)
                if x is None or not (x0 <= x <= x1):
                    continue
                cx, cy = self._px(x, y)
                self.create_oval(cx - 4, cy - 4, cx + 4, cy + 4, outline=sd["color"], width=2)
                tag(cx, cy + 8, "%.2f" % x, sd["color"], "n")
        for key, x, y in self.mmarks:
            if not (x0 <= x <= x1 and y0 <= y <= y1):
                continue
            col = next((sd["color"] for sd in self.series if sd["key"] == key), "#000")
            cx, cy = self._px(x, y)
            self.create_polygon(cx, cy - 6, cx - 5, cy - 14, cx + 5, cy - 14, fill=col, outline="#000")
            self.create_oval(cx - 5, cy - 5, cx + 5, cy + 5, outline="#000", width=2)
            tag(cx + 8, cy - 14, "%.2f, %.2f" % (x, y), col)

    def set_view(self, v, sync=True):
        self.view = v
        self.redraw()
        if sync and self.partner is not None:   # 같은 Pout 범위로 다른 그래프도 맞춤
            pr = self.partner.current_range()
            if pr:
                self.partner.set_view((v[0], v[1], pr[2], pr[3]), sync=False)

    def reset_view(self, both=False):
        self.view = None
        self.redraw()
        if both and self.partner is not None:
            self.partner.reset_view()

    def set_data(self, series, xrange=None, note="", yaxis=None, xaxis=None):
        self.series, self.xrange, self.note, self.yaxis, self.xaxis = series, xrange, note, yaxis, xaxis
        self.redraw()

    def redraw(self):
        self.delete("all")
        W, H = self.winfo_width(), self.winfo_height()
        if W < 50 or H < 50:
            return
        L, R, T, B = 62, 16, 26, 40
        pw, ph = W - L - R, H - T - B
        pts = [pt for d in self.series for pt in d["pts"]]
        xminor = []
        if self.xaxis:
            x0, x1, xlab, xmin_step = self.xaxis
            xlabels = [round(k * xlab, 10) for k in range(int(math.ceil(x0 / xlab - 1e-9)),
                                                          int(math.floor(x1 / xlab + 1e-9)) + 1)]
            if xmin_step and xmin_step > 0 and (x1 - x0) / xmin_step <= 400:
                xminor = [round(k * xmin_step, 10) for k in range(int(math.ceil(x0 / xmin_step - 1e-9)),
                                                                  int(math.floor(x1 / xmin_step + 1e-9)) + 1)]
        else:
            if self.xrange:
                x0, x1 = self.xrange
            elif pts:
                x0, x1 = min(p[0] for p in pts), max(p[0] for p in pts)
            else:
                x0, x1 = 0, 1
            if x1 - x0 < 1e-9:
                x0, x1 = x0 - 1, x1 + 1
            mx = (x1 - x0) * 0.04
            x0, x1 = x0 - mx, x1 + mx
            xlabels = nice_ticks(x0, x1, max(3, pw // 70))
        if self.yaxis:
            y0, y1, ystep = self.yaxis
            yticks = []
            v = y0
            while v <= y1 + 1e-9 * max(1, abs(ystep)) and len(yticks) < 200:
                yticks.append(round(v, 10))
                v += ystep
        else:
            if pts:
                y0, y1 = min(p[1] for p in pts), max(p[1] for p in pts)
            else:
                y0, y1 = 0, 1
            if y1 - y0 < 1e-9:
                y0, y1 = y0 - 1, y1 + 1
            my = (y1 - y0) * 0.08
            y0, y1 = y0 - my, y1 + my
            yticks = nice_ticks(y0, y1, max(3, ph // 40))
        if self.view:
            # 확대/이동 중: 범위만 바꾸고 눈금 간격은 기본 설정 유지 (너무 촘촘하면 자동)
            x0, x1, y0, y1 = self.view
            xs_ = self.xaxis[2] if self.xaxis else None
            xlabels = ticks_by_step(x0, x1, xs_) if xs_ and (x1 - x0) / xs_ <= 14 else nice_ticks(x0, x1, max(3, pw // 70))
            xminor = ticks_by_step(x0, x1, self.xaxis[3]) if (self.xaxis and self.xaxis[3]) else []
            ys_ = self.yaxis[2] if self.yaxis else None
            yticks = ticks_by_step(y0, y1, ys_) if ys_ and (y1 - y0) / ys_ <= 16 else nice_ticks(y0, y1, max(3, ph // 40))
        self._map = (L, T, pw, ph, x0, x1, y0, y1)

        def X(v):
            return L + (v - x0) / (x1 - x0) * pw

        def Y(v):
            return T + ph - (v - y0) / (y1 - y0) * ph

        for tx in xlabels:
            self.create_line(X(tx), T, X(tx), T + ph, fill="#e6e6e6")
        for ty in yticks:
            self.create_line(L, Y(ty), L + pw, Y(ty), fill="#e6e6e6")
        # 흐린 것 → 보통 → 강조(선택·측정 중) 순서로 그려서 강조된 선이 위에 오게
        self._pick = []
        for sd in sorted(self.series, key=lambda d: d.get("emph", 0) - (1 if d.get("dim") else 0)):
            color = blend(sd["color"]) if sd.get("dim") else sd["color"]
            w = sd.get("width", 1.6) + (1.6 if sd.get("emph") else 0)
            mr = sd.get("marker", 3) + (1.2 if sd.get("emph") else 0)
            xy = [(X(a), Y(b)) for a, b in sd["pts"]]
            if len(xy) > 1:
                kw = {"dash": sd["dash"]} if sd.get("dash") else {}
                self.create_line(*[c for pt in xy for c in pt], fill=color, width=w, **kw)
            shape = sd.get("shape", "o")
            for cx, cy in xy:
                if mr > 0:
                    draw_marker(self, shape, cx, cy, mr, color)
                if L <= cx <= L + pw and T <= cy <= T + ph:
                    self._pick.append((sd["key"], cx, cy))
        self.draw_markers()
        # 그래프 영역 밖으로 나간 선/점 가리기
        for box in ((0, 0, W, T), (0, T + ph, W, H), (0, 0, L, H), (L + pw, 0, W, H)):
            self.create_rectangle(*box, fill="white", outline="white")
        self.create_text(L + pw / 2, 12, text=self.title, font=("맑은 고딕", 10, "bold"))
        self.create_text(L + 4, H - 10, text=self.xlabel, anchor="w", font=("맑은 고딕", 9))
        self.create_text(14, T + ph / 2, text=self.ylabel, angle=90, font=("맑은 고딕", 9))
        for tx in xminor:  # 1 단위 눈금
            big = any(abs(tx - lb) < 1e-9 for lb in xlabels)
            self.create_line(X(tx), T + ph, X(tx), T + ph - (7 if big else 4), fill="#888")
            self.create_line(X(tx), T, X(tx), T + (7 if big else 4), fill="#888")
        for tx in xlabels:
            self.create_text(X(tx), T + ph + 12, text="%g" % tx, font=("Consolas", 8))
        for ty in yticks:
            self.create_text(L - 6, Y(ty), text="%g" % ty, anchor="e", font=("Consolas", 8))
        self.create_rectangle(L, T, L + pw, T + ph, outline="#888")
        # 범례 (흰 배경 상자, 최대 10개)
        # (마우스로 범례를 끌어 옮길 수 있음, 그래프 안에서만)
        leg = self.series[:10]
        self._legbox = None
        if leg:
            wmax = max(len(d["label"]) for d in leg) * 7 + 45
            extra = len(self.series) - len(leg)
            hgt = 3 + 16 * (len(leg) + (1 if extra else 0))
            ox, oy = self.leg_pos if self.leg_pos else (4, 1)
            ox = min(max(ox, 0), max(0, pw - wmax))
            oy = min(max(oy, 0), max(0, ph - hgt))
            bx, by = L + ox, T + oy
            self._legbox = (bx, by, bx + wmax, by + hgt)
            self.create_rectangle(bx, by, bx + wmax, by + hgt, fill="white", outline="#cccccc")
            ly = by + 7
            for d in leg:
                color = blend(d["color"]) if d.get("dim") else d["color"]
                kw = {"dash": d["dash"]} if d.get("dash") else {}
                self.create_line(bx + 6, ly, bx + 26, ly, fill=color, width=3 if d.get("emph") else 2, **kw)
                if d.get("marker", 3) > 0:
                    draw_marker(self, d.get("shape", "o"), bx + 16, ly, 3.5, color)
                self.create_text(bx + 31, ly, text=d["label"], anchor="w",
                                 font=("맑은 고딕", 9, "bold" if d.get("emph") else "normal"))
                ly += 16
            if extra:
                self.create_text(bx + 31, ly, text="… 외 %d개" % extra, anchor="w", fill="#888", font=("맑은 고딕", 8))
        if self.note:
            self.create_text(L + pw / 2, T + ph / 2, text=self.note, fill="#999", font=("맑은 고딕", 11))
        hint = "휠: 확대/축소 · 드래그: 이동 · 더블클릭: 원래대로 · v/h/m: 마커 · Del: 마커 지우기"
        if self.view:
            hint = "확대 중 · " + hint
        if W >= 640:
            self.create_text(W - 4, H - 4, text=hint, anchor="se", fill="#a0a0a0", font=("맑은 고딕", 8))
        elif W >= 400:
            self.create_text(W - 4, H - 4, text=("확대 중 · " if self.view else "") + "v/h/m: 마커 · Del: 지우기",
                             anchor="se", fill="#a0a0a0", font=("맑은 고딕", 8))
        elif self.view:
            self.create_text(W - 4, H - 4, text="확대 중 (더블클릭: 원래대로)", anchor="se", fill="#a0a0a0",
                             font=("맑은 고딕", 8))


class PlotPanel(ttk.Frame):
    """PAE vs Pout (위), Gain vs Pout (아래). 주파수별 색상."""

    def __init__(self, parent):
        super().__init__(parent)
        pw = ttk.PanedWindow(self, orient="vertical")
        pw.pack(fill="both", expand=True)
        self.p1 = XYPlot(pw, "PAE vs. Pout", "DUT Pout (dBm)", "PAE (%)", height=260)
        self.p2 = XYPlot(pw, "Gain vs. Pout", "DUT Pout (dBm)", "Gain (dB)", height=260)
        pw.add(self.p1, weight=1)
        pw.add(self.p2, weight=1)
        self.p1.partner, self.p2.partner = self.p2, self.p1
        self.p2.vmarks = self.p1.vmarks          # 세로 마커는 두 그래프 같은 Pout 에

    def show(self, s1, s2, xr, notes, axes):
        xax = axes[2] if len(axes) > 2 else None
        self.p1.set_data(s1, xr, notes[0], axes[0], xax)
        self.p2.set_data(s2, xr, notes[1], axes[1], xax)

    def reset_view(self):
        self.p1.reset_view(both=True)


def make_icon(root, kind):
    """16x16 아이콘: save(디스켓) / open(폴더)."""
    img = tk.PhotoImage(master=root, width=16, height=16)

    def box(x0, y0, x1, y1, color):
        img.put(color, to=(x0, y0, x1, y1))

    if kind == "save":
        box(1, 1, 15, 15, "#2f5d8a")      # 몸체
        box(4, 1, 12, 6, "#dfe8f1")       # 셔터
        box(9, 2, 11, 5, "#2f5d8a")
        box(3, 9, 13, 15, "#ffffff")      # 라벨
        box(4, 11, 12, 12, "#9fb3c8")
    else:
        box(1, 3, 7, 5, "#c99a2e")        # 탭
        box(1, 5, 15, 14, "#e8b84a")      # 폴더
        box(1, 7, 15, 8, "#c99a2e")
    return img


# ============================================================ 메인 화면
class BenchApp:
    COLS = [("no", "No", 36), ("sample", "샘플", 56), ("time", "시간", 66), ("freq", "주파수(GHz)", 80),
            ("sg", "SG(dBm)", 68), ("sa", "SA(dBm)", 68), ("inl", "In loss(dB)", 74), ("outl", "Out loss(dB)", 80), ("lossf", "Loss 기준(GHz)", 92),
            ("pin", "DUT Pin(dBm)", 88), ("pout", "DUT Pout(dBm)", 92), ("gain", "Gain(dB)", 66),
            ("id", "Id(mA)", 68), ("pdc", "Pdc(W)", 64), ("de", "DE(%)", 58), ("pae", "PAE(%)", 62)]

    def __init__(self, root):
        self.root = root
        self.s = load_settings()
        self.q = queue.Queue()
        self.rows = []
        # 실시간 값
        self.smw = {"conn": False, "f": None, "p": None, "rf": False, "t": 0}
        self.fsw = {"conn": False, "y": None, "mx": None, "t": 0}
        self.cur_samples = collections.deque(maxlen=2000)  # (t, A)
        self.fsw_samples = collections.deque(maxlen=2000)  # (t, dBm)
        # 자동 기록 상태
        self.rec_on = False
        self.last_pin = None
        self.change_t = None
        self.pending = False

        root.title("%s %s%s" % (APP_NAME, VERSION, "  (PA Analyzer 연동판)" if HAS_ANALYZER else ""))
        geo = self.s.get("geometry") or "1560x900"
        try:
            gw = int(geo.split("x")[0])
            if gw < 1400:
                geo = "1560x900"
        except ValueError:
            geo = "1560x900"
        root.geometry(geo)
        root.minsize(900, 600)
        try:
            ttk.Style().theme_use("vista")
        except Exception:
            pass
        root.option_add("*Font", ("맑은 고딕", 9))

        self.smw_w = InstWorker("smw", self.q, DemoSMW)
        self.smw_w.poll_fn = smw_poll
        self.fsw_w = InstWorker("fsw", self.q, DemoFSW)
        self.fsw_w.poll_fn = fsw_poll
        self.fsw_w.init_fn = fsw_init
        self.fsw_w.marker = int(self.s.get("fsw_marker", 1))
        self.fsw_w.marker_on = False
        for w in (self.smw_w, self.fsw_w):
            w.start()

        self.var_smw_step = tk.StringVar(value=self.s["smw_step"])
        self.var_smw_max = tk.StringVar(value=self.s["smw_max"])
        self.ds_style, self.ds_hidden, self.ds_selected = {}, set(), set()
        self.color_mode = "freq"
        self.fcolor_cache = collections.OrderedDict()
        self.analyzer = AnalyzerLink()
        self.build_dashboard()
        self.nb = ttk.Notebook(root)
        self.nb.pack(side="top", fill="both", expand=True, padx=4, pady=4)
        self.build_log_tab()
        self.build_smw_tab()
        self.build_fsw_tab()
        self.build_scope_tab()
        try:
            self.nb.select(int(self.s.get("tab", 0)))
        except Exception:
            pass
        self.apply_worker_opts()
        menubar = tk.Menu(root)
        mfile = tk.Menu(menubar, tearoff=0)
        mfile.add_command(label="케이블 손실 표 불러오기 (txt)...", command=self.loss_load)
        mfile.add_command(label="케이블 손실 표 내보내기 (txt)...", command=self.loss_save)
        mfile.add_separator()
        mfile.add_command(label="측정 기록 엑셀 내보내기 (그래프 포함)...", command=self.export_excel)
        mfile.add_command(label="측정 기록 CSV 저장...", command=self.save_csv)
        mfile.add_command(label="선택 행 복사 (엑셀 · PA Analyzer 붙여넣기용)   Ctrl+C", command=self.copy_rows)
        mfile.add_command(label="선택 행 PA Analyzer 프로젝트(.pam)로 저장...", command=self.save_pam)
        mfile.add_separator()
        mfile.add_command(label="종료", command=self.on_close)
        menubar.add_cascade(label="파일", menu=mfile)
        mgr = tk.Menu(menubar, tearoff=0)
        if HAS_ANALYZER:
            mgr.add_command(label="PA Analyzer 그래프 창 열기 (실시간 연동)", command=self.open_analyzer)
        mgr.add_command(label="그래프 새 창", command=self.open_plot_window)
        menubar.add_cascade(label="그래프", menu=mgr)
        root.config(menu=menubar)
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(100, self.tick)
        root.after(300, self.refresh_plots)
        root.after(350, self.fit_ctrl_height)
        # 단축키: 4 = 파워 올리기, 5 = 기록, 6 = 파워 내리기 (숫자 키패드도 동일)
        self.p_change_t = 0.0
        self.rec_wait = None
        self.last_key_t = {}
        self.sweep = None
        self.ramp = None
        self.cur_mem = {}
        self.mem_freq = None
        self._live_key = None
        root.bind_all("<Escape>", lambda e: self.stop_sweep("Esc") if self.sweep else None)
        for keys, fn in ((("4", "KP_4"), lambda: self.smw_step(+1)),
                         (("5", "KP_5"), self.record_request),
                         (("6", "KP_6"), lambda: self.smw_step(-1))):
            for k in keys:
                root.bind_all("<KeyPress-%s>" % k, lambda e, fn=fn: self.on_hotkey(e, fn))
        # 그래프 위에 마우스를 두고 v / h / m = 마커, Delete = 근처 마커 지우기, Shift+Delete = 모두
        for k in ("v", "h", "m", "V", "H", "M"):
            root.bind_all("<KeyPress-%s>" % k, lambda e, k=k.lower(): self.on_marker_key(e, k))
        root.bind_all("<KeyPress-Delete>", lambda e: self.on_marker_key(e, "del"))
        root.bind_all("<Shift-KeyPress-Delete>", lambda e: self.on_marker_key(e, "delall"))

    # ------------------------------------------------ 상단 실시간 표시
    def build_dashboard(self):
        d = tk.Frame(self.root, bg=BG)
        d.pack(side="top", fill="x")
        self.dash = d
        cols = tk.Frame(d, bg=BG)
        cols.pack(side="top", fill="x", padx=6, pady=(6, 0))
        self.big = {}
        spec = [("smw", "신호발생기 출력 (SMW200A)", C_SMW),
                ("fsw", "스펙트럼 분석기 (FSW)", C_FSW),
                ("cur", "전류 (RTO 오실로스코프)", C_CUR),
                ("gain", "DUT Gain / PAE (손실 보정)", C_GAIN)]
        for i, (key, title, color) in enumerate(spec):
            cols.columnconfigure(i, weight=1, uniform="c")
            box = tk.Frame(cols, bg=BG, highlightthickness=1, highlightbackground="#1f2a36")
            box.grid(row=0, column=i, sticky="nsew", padx=3)
            tk.Label(box, text=title, bg=BG, fg=FG_DIM, font=("맑은 고딕", 10)).pack(anchor="w", padx=8, pady=(4, 0))
            v = tk.Label(box, text="---", bg=BG, fg=color, font=("Consolas", 30, "bold"))
            v.pack(fill="x", padx=4)
            sub = tk.Label(box, text="", bg=BG, fg=FG_DIM, font=("Consolas", 10))
            sub.pack(fill="x", padx=4, pady=(0, 6))
            self.big[key] = (v, sub)
        bar = tk.Frame(d, bg=BG)
        bar.pack(side="top", fill="x", padx=6, pady=6)
        mk = dict(relief="flat", padx=12, pady=3, activeforeground="#ffffff")
        tk.Button(bar, text="모두 연결", command=self.connect_all, bg="#1c2530", fg="#c8d3de",
                  activebackground="#2a3644", **mk).pack(side="left", padx=3)
        self.btn_cur = tk.Button(bar, text="▶ 전류 측정 시작", command=self.toggle_current, bg="#7d6a26", fg="#ffffff",
                                 activebackground="#93802f", **mk)
        self.btn_cur.pack(side="left", padx=3)
        self.btn_rec = tk.Button(bar, text="● 자동 측정 (SG 레벨 → 최대 허용)", command=self.toggle_sweep, bg="#7a1f1f",
                                 fg="#ffffff", activebackground="#a52a2a", **mk)
        self.btn_rec.pack(side="left", padx=3)
        tk.Button(bar, text="지금 기록 [5]", command=self.record_request, bg="#1c2530", fg="#c8d3de",
                  activebackground="#2a3644", **mk).pack(side="left", padx=3)
        self.lbl_lossbar = tk.Label(bar, text="", bg=BG, fg="#9fc5e8", font=("맑은 고딕", 9))
        self.lbl_lossbar.pack(side="left", padx=(12, 0))
        self.lbl_rec = tk.Label(bar, text="", bg=BG, fg="#d4a017", font=("맑은 고딕", 10))
        self.lbl_rec.pack(side="left", padx=10)
        self.lbl_status = tk.Label(bar, text="", bg=BG, fg=FG_DIM, anchor="e")
        self.lbl_status.pack(side="right", fill="x", expand=True)
        d.bind("<Configure>", self.on_dash_resize)

    def on_dash_resize(self, event=None):
        w = max(self.dash.winfo_width(), 400)
        size = int(max(18, min(44, w / 4 / 11 * 1.45)))
        for key, (v, sub) in self.big.items():
            v.configure(font=("Consolas", size, "bold"))

    # ------------------------------------------------ 탭: 측정 기록
    def build_log_tab(self):
        s = self.s
        f = ttk.Frame(self.nb, padding=6)
        self.nb.add(f, text="  측정 기록  ")
        pad = dict(padx=4, pady=2)
        hpan = ttk.PanedWindow(f, orient="horizontal")    # 왼쪽(데이터) / 오른쪽(그래프) 폭 조절
        hpan.pack(fill="both", expand=True)
        leftcol = ttk.PanedWindow(hpan, orient="vertical")  # 설정 / 기록 표 높이 조절
        hpan.add(leftcol, weight=3)
        rightp = ttk.Frame(hpan)
        hpan.add(rightp, weight=2)
        left = ttk.Frame(leftcol)
        leftcol.add(left, weight=0)
        self.leftcol, self.left_ctrl = leftcol, left

        toprow = ttk.Frame(left)
        toprow.pack(fill="both", expand=True)
        # 왼쪽: "주파수 / 파워" | "자동 기록 조건" 을 위아래 경계선으로 높이 조절, 잘리면 스크롤바
        lpan = ttk.PanedWindow(toprow, orient="vertical")
        self.sf_g1 = ScrollFrame(lpan)
        self.sf_g2 = ScrollFrame(lpan)
        lpan.add(self.sf_g1, weight=1)
        lpan.add(self.sf_g2, weight=1)
        self.lpan = lpan

        # 주파수 / 파워
        g1box, g1 = self.fold_group(self.sf_g1.body, "주파수 / 파워", "g1")
        g1box.pack(fill="x")
        ttk.Label(g1, text="주파수(GHz)").grid(row=0, column=0, sticky="e", **pad)
        self.var_freq = tk.StringVar(value=s.get("freq_ghz", ""))
        e = ttk.Entry(g1, textvariable=self.var_freq, width=9)
        e.grid(row=0, column=1, sticky="w", **pad)
        e.bind("<Return>", lambda ev: self.apply_freq())
        ttk.Button(g1, text="SG + SA 주파수 함께 변경", command=self.apply_freq).grid(
            row=0, column=2, columnspan=3, sticky="w", **pad)
        ttk.Label(g1, text="최대 허용(dBm)").grid(row=0, column=5, sticky="e", **pad)
        ttk.Entry(g1, textvariable=self.var_smw_max, width=6).grid(row=0, column=6, sticky="w", **pad)
        ttk.Label(g1, text="SG 레벨(dBm)").grid(row=1, column=0, sticky="e", **pad)
        self.var_lvl2 = tk.StringVar(value="")
        e2 = ttk.Entry(g1, textvariable=self.var_lvl2, width=9)
        e2.grid(row=1, column=1, sticky="w", **pad)
        e2.bind("<Return>", lambda ev: self.smw_set_level(fnum(self.var_lvl2.get())))
        ttk.Button(g1, text="설정", width=6,
                   command=lambda: self.smw_set_level(fnum(self.var_lvl2.get()))).grid(row=1, column=2, sticky="w", **pad)
        ttk.Label(g1, text="스텝(dB)").grid(row=1, column=3, sticky="e", **pad)
        ttk.Entry(g1, textvariable=self.var_smw_step, width=5).grid(row=1, column=4, sticky="w", **pad)
        btf = ttk.Frame(g1)
        btf.grid(row=2, column=0, columnspan=8, sticky="w", pady=(2, 0))
        ttk.Button(btf, text="▲ 올리기 [4]", command=lambda: self.smw_step(+1)).pack(side="left", padx=4)
        ttk.Button(btf, text="● 기록 [5]", command=self.record_request).pack(side="left", padx=4)
        ttk.Button(btf, text="▼ 내리기 [6]", command=lambda: self.smw_step(-1)).pack(side="left", padx=4)
        ttk.Label(btf, text="같은 주파수·파워 재기록 = 최신 값으로 덮어씀", foreground="#666").pack(side="left", padx=8)
        swf = ttk.Frame(g1)
        swf.grid(row=3, column=0, columnspan=8, sticky="w", pady=(4, 0))
        self.btn_sweep = ttk.Button(swf, text="● 자동 측정 시작 (SG 레벨 → 최대 허용)", command=self.toggle_sweep)
        self.btn_sweep.pack(side="left", padx=4)
        self.var_sw_ret = tk.BooleanVar(value=bool(s.get("sw_return", True)))
        ttk.Checkbutton(swf, text="끝나면 시작 레벨로 천천히 복귀", variable=self.var_sw_ret).pack(side="left", padx=6)
        swf2 = ttk.Frame(g1)
        swf2.grid(row=4, column=0, columnspan=8, sticky="w", pady=(2, 0))
        ttk.Label(swf2, text="Id 상한(mA, 넘으면 중지)").pack(side="left", padx=(4, 2))
        self.var_sw_idmax = tk.StringVar(value=s.get("sw_idmax", ""))
        ttk.Entry(swf2, textvariable=self.var_sw_idmax, width=7).pack(side="left")
        self.var_sat_on = tk.BooleanVar(value=bool(s.get("sat_on", True)))
        ttk.Checkbutton(swf2, text="SA 증가 ≤", variable=self.var_sat_on).pack(side="left", padx=(12, 2))
        self.var_sat_db = tk.StringVar(value=s.get("sat_db", "0.1"))
        ttk.Entry(swf2, textvariable=self.var_sat_db, width=4).pack(side="left")
        ttk.Label(swf2, text="dB 이면 확인").pack(side="left", padx=(2, 0))
        ttk.Label(swf2, text="   Esc = 중지", foreground="#666").pack(side="left")
        swf3 = ttk.Frame(g1)
        swf3.grid(row=5, column=0, columnspan=8, sticky="w", pady=(2, 0))
        self.var_sw_retry = tk.BooleanVar(value=bool(s.get("sw_retry", True)))
        ttk.Checkbutton(swf3, text="튀는 값 자동 재측정 (한 단계 아래부터 다시)",
                        variable=self.var_sw_retry).pack(side="left", padx=(4, 6))
        ttk.Label(swf3, text="Id ±").pack(side="left")
        self.var_tol_id = tk.StringVar(value=s.get("tol_id", "15"))
        ttk.Entry(swf3, textvariable=self.var_tol_id, width=4).pack(side="left")
        ttk.Label(swf3, text="%  PAE ±").pack(side="left")
        self.var_tol_pae = tk.StringVar(value=s.get("tol_pae", "5"))
        ttk.Entry(swf3, textvariable=self.var_tol_pae, width=4).pack(side="left")
        ttk.Label(swf3, text="%p", foreground="#000").pack(side="left")
        rpf = ttk.Frame(g1)
        rpf.grid(row=6, column=0, columnspan=8, sticky="w", pady=(4, 0))
        self.btn_ramp = ttk.Button(rpf, text="▼▼ 천천히 내리기 (현재 → SG 레벨)", command=self.toggle_ramp)
        self.btn_ramp.pack(side="left", padx=4)
        ttk.Label(rpf, text="간격(초)").pack(side="left", padx=(8, 2))
        self.var_ramp_dt = tk.StringVar(value=s.get("ramp_dt", "1.0"))
        ttk.Entry(rpf, textvariable=self.var_ramp_dt, width=5).pack(side="left")
        mmf = ttk.Frame(g1)
        mmf.grid(row=7, column=0, columnspan=8, sticky="w", pady=(4, 0))
        ttk.Button(mmf, text="전류 기억 초기화 (샘플 바꿀 때)", command=self.reset_memory).pack(side="left", padx=4)
        self.lbl_mem = ttk.Label(mmf, text="", foreground="#1f4f8f")
        self.lbl_mem.pack(side="left", padx=4)

        # 자동 기록 조건 / 효율 계산
        g2box, g2 = self.fold_group(self.sf_g2.body, "자동 기록 조건 / 효율 계산", "g2")
        g2box.pack(fill="x", pady=(2, 0))
        ttk.Label(g2, text="파워 변경 후 안정화").grid(row=0, column=0, sticky="e", **pad)
        self.var_settle = tk.StringVar(value=s["settle"])
        ttk.Entry(g2, textvariable=self.var_settle, width=5).grid(row=0, column=1, sticky="w", **pad)
        ttk.Label(g2, text="초,  평균").grid(row=0, column=2, sticky="w", **pad)
        self.var_avg = tk.StringVar(value=s["avg"])
        ttk.Entry(g2, textvariable=self.var_avg, width=5).grid(row=0, column=3, sticky="w", **pad)
        ttk.Label(g2, text="초").grid(row=0, column=4, sticky="w", **pad)
        self.var_autochg = tk.BooleanVar(value=False)
        ttk.Checkbutton(g2, text="손으로 SG 파워를 바꿀 때도 자동 기록", variable=self.var_autochg,
                        command=self.toggle_rec).grid(row=1, column=0, columnspan=6, sticky="w", **pad)
        ttk.Label(g2, text="Vdd(V)").grid(row=2, column=0, sticky="e", **pad)
        self.var_vdd = tk.StringVar(value=s["vdd"])
        ttk.Entry(g2, textvariable=self.var_vdd, width=6).grid(row=2, column=1, sticky="w", **pad)
        ttk.Label(g2, text="효율 계산 최소 Id(mA)").grid(row=2, column=2, columnspan=2, sticky="e", **pad)
        self.var_minid = tk.StringVar(value=s.get("min_id", "250"))
        ttk.Entry(g2, textvariable=self.var_minid, width=6).grid(row=2, column=4, sticky="w", **pad)
        self.lbl_vdd = ttk.Label(g2, text="", foreground="#c0504d")
        self.lbl_vdd.grid(row=3, column=0, columnspan=6, sticky="w", **pad)
        self.var_saq = tk.BooleanVar(value=bool(s.get("sa_q", True)))
        ttk.Checkbutton(g2, text="SA 값 소수 둘째 자리에서 반올림 (12.24 → 12.2)",
                        variable=self.var_saq).grid(row=4, column=0, columnspan=6, sticky="w", **pad)
        ttk.Label(g2, text="Id 가 최소 Id 미만이면 PAE·DE 빈칸 (Gain 그래프만 표시)\n"
                           "DUT Pin = SG − In loss,  DUT Pout = SA + Out loss,  Gain = Pout − Pin\n"
                           "PAE = (Pout − Pin)[W] / (Vdd·Id) × 100,  DE = Pout[W] / (Vdd·Id) × 100",
                  foreground="#666").grid(row=5, column=0, columnspan=6, sticky="w", **pad)

        # 오른쪽: 샘플 번호 (한 줄) + 케이블 손실, 잘리면 스크롤바
        self.sf_right = ScrollFrame(toprow, horizontal=False)
        self.sf_right.pack(side="right", fill="y", padx=(6, 0))   # 먼저 자리 잡기 → 창이 좁아져도 안 사라짐
        lpan.pack(side="left", fill="both", expand=True)
        rcol = self.sf_right.body
        smpf = ttk.Frame(rcol)
        smpf.pack(fill="x", pady=(4, 2))
        ttk.Label(smpf, text="샘플", font=("맑은 고딕", 9, "bold"), foreground="#1f3f66").pack(side="left", padx=(2, 4))
        self.var_sample = tk.StringVar(value=s.get("sample", ""))
        es = ttk.Entry(smpf, textvariable=self.var_sample, width=8, font=("맑은 고딕", 11, "bold"))
        es.pack(side="left")
        ttk.Label(smpf, text="표·엑셀·그래프에 표시", foreground="#666").pack(side="left", padx=6)
        self.var_sample.trace_add("write", lambda *a: self.on_sample_change())

        # 케이블 손실
        lossbox, g3 = self.fold_group(rcol, "케이블 손실 (주파수별, dB)", "loss")
        lossbox.pack(fill="both")
        g3.rowconfigure(0, weight=1)
        for c in range(6):
            g3.columnconfigure(c, weight=1)
        self.loss_tree = ttk.Treeview(g3, columns=("f", "i", "o"), show="headings", height=6)
        for k, t, wd in (("f", "주파수(GHz)", 80), ("i", "In loss", 60), ("o", "Out loss", 64)):
            self.loss_tree.heading(k, text=t)
            self.loss_tree.column(k, width=wd, anchor="center")
        self.loss_tree.grid(row=0, column=0, columnspan=6, sticky="nsew")
        self.loss_tree.bind("<<TreeviewSelect>>", self.loss_selected)
        self.loss_tree.tag_configure("used", background="#fff3a8")
        self.loss_hl = None
        self.var_lf = tk.StringVar()
        self.var_li = tk.StringVar(value=s.get("in_loss", "0"))
        self.var_lo = tk.StringVar(value=s.get("out_loss", "0"))
        for col, (lab, var, wd) in enumerate((("GHz", self.var_lf, 7), ("In", self.var_li, 5),
                                              ("Out", self.var_lo, 5))):
            ttk.Label(g3, text=lab).grid(row=1, column=col * 2, sticky="e", padx=2, pady=3)
            ttk.Entry(g3, textvariable=var, width=wd).grid(row=1, column=col * 2 + 1, sticky="w", padx=2, pady=3)
        bf3 = ttk.Frame(g3)
        bf3.grid(row=2, column=0, columnspan=6, sticky="w")
        ttk.Button(bf3, text="추가/수정", command=self.loss_add).pack(side="left", padx=2)
        ttk.Button(bf3, text="삭제", command=self.loss_del).pack(side="left", padx=2)
        bf4 = ttk.Frame(g3)
        bf4.grid(row=3, column=0, columnspan=6, sticky="w", pady=(2, 0))
        self.icon_save = make_icon(self.root, "save")
        self.icon_open = make_icon(self.root, "open")
        ttk.Button(bf4, text="내보내기", image=self.icon_save, compound="left",
                   command=self.loss_save).pack(side="left", padx=2)
        ttk.Button(bf4, text="불러오기", image=self.icon_open, compound="left",
                   command=self.loss_load).pack(side="left", padx=2)
        self.lbl_loss = ttk.Label(g3, text="", foreground="#1f4f8f")
        self.lbl_loss.grid(row=4, column=0, columnspan=6, sticky="w", pady=(3, 0))
        ttk.Label(g3, text="SG 주파수에 가장 가까운 행 사용\n(노란색 = 사용 중)",
                  foreground="#666").grid(row=5, column=0, columnspan=6, sticky="w")
        self.loss_table = [list(map(float, r)) for r in s.get("loss_table", [])]
        self.refresh_loss_tree()

        # SG RF 출력 (케이블 손실 아래)
        rfbox, g4 = self.fold_group(rcol, "SG RF 출력", "rf")
        rfbox.pack(fill="x", pady=(4, 0))
        self.btn_rf = tk.Button(g4, text="RF OFF", width=16, font=("맑은 고딕", 11, "bold"),
                                relief="raised", bd=2, command=self.toggle_rf)
        self.btn_rf.pack(fill="x", pady=(2, 4))
        self.var_rf_ramp_off = tk.BooleanVar(value=bool(s.get("rf_ramp_off", True)))
        ttk.Checkbutton(g4, text="천천히 내리기 끝나면 RF OFF", variable=self.var_rf_ramp_off).pack(anchor="w")
        self.var_rf_sweep_on = tk.BooleanVar(value=bool(s.get("rf_sweep_on", True)))
        ttk.Checkbutton(g4, text="자동 측정 시작 시 SG 레벨에서 RF ON", variable=self.var_rf_sweep_on).pack(anchor="w")
        self.lbl_rf = ttk.Label(g4, text="", foreground="#666")
        self.lbl_rf.pack(anchor="w")
        self.rf_cmd = None          # (원하는 상태, 보낸 시각) - 장비 읽기로 확인될 때까지 표시

        leftp = ttk.Frame(leftcol)
        leftcol.add(leftp, weight=1)

        tf = ttk.Frame(leftp)
        tf.pack(fill="both", expand=True, pady=(0, 4))
        self.tree = ttk.Treeview(tf, columns=[c[0] for c in self.COLS], show="headings", height=12)
        for key, title, wd in self.COLS:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=wd, minwidth=40, anchor="center", stretch=False)
        sb = ttk.Scrollbar(tf, orient="vertical", command=self.tree.yview)
        sbx = ttk.Scrollbar(tf, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=sb.set, xscrollcommand=sbx.set)
        sbx.pack(side="bottom", fill="x")
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        # 오른쪽: 위 PAE, 아래 Gain
        axf = ttk.Frame(rightp)
        axf.pack(fill="x", padx=(4, 0), pady=(0, 2))
        pae_ax = self.s.get("pae_ax", ["20", "80", "10"])
        gain_ax = self.s.get("gain_ax", ["20", "40", "2.5"])
        self.var_pae_ax = [tk.StringVar(value=str(v)) for v in pae_ax]
        self.var_gain_ax = [tk.StringVar(value=str(v)) for v in gain_ax]
        for r, (name, vars_) in enumerate((("PAE(%)", self.var_pae_ax), ("Gain(dB)", self.var_gain_ax))):
            ttk.Label(axf, text="%s Y축" % name, width=11).grid(row=r, column=0, sticky="w")
            for c, (lab, var) in enumerate(zip(("최소", "최대", "간격"), vars_)):
                ttk.Label(axf, text=lab).grid(row=r, column=1 + c * 2, sticky="e", padx=(4, 1))
                e = ttk.Entry(axf, textvariable=var, width=6)
                e.grid(row=r, column=2 + c * 2, sticky="w")
                e.bind("<Return>", lambda ev: self.refresh_plots())
        x_ax = self.s.get("x_ax", ["26", "54", "5", "1"])
        self.var_x_ax = [tk.StringVar(value=str(v)) for v in x_ax]
        ttk.Label(axf, text="Pout X축", width=11).grid(row=2, column=0, sticky="w")
        for c, (lab, var) in enumerate(zip(("최소", "최대", "숫자", "눈금"), self.var_x_ax)):
            ttk.Label(axf, text=lab).grid(row=2, column=1 + c * 2, sticky="e", padx=(4, 1))
            e = ttk.Entry(axf, textvariable=var, width=6)
            e.grid(row=2, column=2 + c * 2, sticky="w")
            e.bind("<Return>", lambda ev: self.refresh_plots())
        ttk.Button(axf, text="축 적용", command=self.refresh_plots).grid(row=0, column=9, rowspan=3, padx=6)
        ttk.Label(axf, text="빈 칸 = 자동", foreground="#666").grid(row=0, column=10, rowspan=3, sticky="w")
        tb = ttk.Frame(rightp)
        tb.pack(fill="x", padx=(4, 0), pady=(0, 2))
        ttk.Button(tb, text="축 초기화", command=self.plots_reset_view).pack(side="left", padx=2)
        ttk.Button(tb, text="각각색", command=lambda: self.set_color_mode("each")).pack(side="left", padx=2)
        ttk.Button(tb, text="주파수 색", command=lambda: self.set_color_mode("freq")).pack(side="left", padx=2)
        ttk.Button(tb, text="선 기본", command=self.reset_line_styles).pack(side="left", padx=2)
        ttk.Button(tb, text="그래프 새 창", command=self.open_plot_window).pack(side="right", padx=2)
        if HAS_ANALYZER:
            ttk.Button(tb, text="PA Analyzer 그래프 창", command=self.open_analyzer).pack(side="right", padx=2)

        # Datasets (왼쪽) | 그래프 (오른쪽) - 경계선으로 폭 조절
        dsp = ttk.PanedWindow(rightp, orient="horizontal")
        dsp.pack(fill="both", expand=True, padx=(4, 0))
        dsf = ttk.Frame(dsp)
        dsp.add(dsf, weight=0)
        self.build_datasets(dsf)
        self.plots = [PlotPanel(dsp)]
        dsp.add(self.plots[0], weight=1)
        self.hook_plot(self.plots[0])
        self.dsp, self.hpan = dsp, hpan
        self.root.after(400, self.init_sashes)

        bf = ttk.Frame(leftp)
        bf.pack(fill="x")
        ttk.Button(bf, text="복사 (엑셀 · PA Analyzer)", command=self.copy_rows).pack(side="left", padx=3)
        ttk.Button(bf, text=".pam 저장", command=self.save_pam).pack(side="left", padx=3)
        ttk.Button(bf, text="엑셀 내보내기 (그래프)", command=self.export_excel).pack(side="left", padx=3)
        ttk.Button(bf, text="CSV 저장", command=self.save_csv).pack(side="left", padx=3)
        ttk.Button(bf, text="Vdd·손실 바꾼 값으로 전체 다시 계산", command=self.recalc_rows).pack(side="left", padx=3)
        ttk.Button(bf, text="선택 행 삭제", command=self.delete_selected).pack(side="left", padx=3)
        ttk.Button(bf, text="전체 지우기", command=self.clear_rows).pack(side="left", padx=3)
        ttk.Label(bf, text=VERSION, foreground="#999").pack(side="right")
        self.tree.bind("<Control-c>", lambda e: self.copy_rows())
        self.tree.tag_configure("check", background="#ffd6d6")   # 재측정 후에도 이상한 점

    # ------------------------------------------------ 탭: SMW
    def build_smw_tab(self):
        s = self.s
        f = ttk.Frame(self.nb, padding=10)
        self.nb.add(f, text="  SMW200A (신호발생기)  ")
        pad = dict(padx=4, pady=4)
        g = ttk.LabelFrame(f, text=" 연결 (LAN) ", padding=8)
        g.pack(fill="x")
        ttk.Label(g, text="IP").grid(row=0, column=0, **pad)
        self.var_smw_host = tk.StringVar(value=s["smw_host"])
        ttk.Entry(g, textvariable=self.var_smw_host, width=18).grid(row=0, column=1, **pad)
        ttk.Label(g, text="Port").grid(row=0, column=2, **pad)
        self.var_smw_port = tk.StringVar(value=str(s["smw_port"]))
        ttk.Entry(g, textvariable=self.var_smw_port, width=6).grid(row=0, column=3, **pad)
        self.btn_smw = ttk.Button(g, text="연결", command=self.smw_connect, width=10)
        self.btn_smw.grid(row=0, column=4, **pad)
        self.lbl_smw_idn = ttk.Label(g, text="(IP에 demo 입력 시 장비 없이 테스트)", foreground="#666")
        self.lbl_smw_idn.grid(row=1, column=0, columnspan=6, sticky="w", **pad)
        self.var_smw_gtl = tk.BooleanVar(value=bool(s["smw_gtl"]))
        ttk.Checkbutton(g, text="읽은 뒤 바로 Local 복귀 (&GTL) - 장비 앞 패널로 파워 조절 가능하게",
                        variable=self.var_smw_gtl, command=self.apply_worker_opts).grid(
            row=2, column=0, columnspan=6, sticky="w", **pad)
        ttk.Label(g, text="읽기 주기(ms)").grid(row=3, column=0, **pad)
        self.var_smw_poll = tk.StringVar(value=str(s["smw_poll"]))
        ttk.Spinbox(g, from_=100, to=5000, increment=100, textvariable=self.var_smw_poll, width=7,
                    command=self.apply_worker_opts).grid(row=3, column=1, sticky="w", **pad)

        g2 = ttk.LabelFrame(f, text=" 파워 조절 (선택 사항 - 장비 앞 패널에서 직접 올려도 됨) ", padding=8)
        g2.pack(fill="x", pady=8)
        ttk.Label(g2, text="레벨(dBm)").grid(row=0, column=0, **pad)
        self.var_smw_lvl = tk.StringVar(value="")
        ttk.Entry(g2, textvariable=self.var_smw_lvl, width=8).grid(row=0, column=1, **pad)
        ttk.Button(g2, text="설정", command=self.smw_set_level).grid(row=0, column=2, **pad)
        ttk.Label(g2, text="스텝(dB)").grid(row=0, column=3, **pad)
        ttk.Entry(g2, textvariable=self.var_smw_step, width=5).grid(row=0, column=4, **pad)
        ttk.Button(g2, text="▲ 올리기", command=lambda: self.smw_step(+1)).grid(row=0, column=5, **pad)
        ttk.Button(g2, text="▼ 내리기", command=lambda: self.smw_step(-1)).grid(row=0, column=6, **pad)
        ttk.Label(g2, text="최대 허용(dBm)").grid(row=1, column=0, **pad)
        ttk.Entry(g2, textvariable=self.var_smw_max, width=8).grid(row=1, column=1, **pad)
        ttk.Label(g2, text="※ 이 값보다 높게는 프로그램에서 설정하지 않음 (DUT 보호)", foreground="#666").grid(
            row=1, column=2, columnspan=5, sticky="w", **pad)
        self.lbl_smw_read = ttk.Label(f, text="", foreground="#1f4f8f")
        self.lbl_smw_read.pack(anchor="w", pady=4)

    # ------------------------------------------------ 탭: FSW
    def build_fsw_tab(self):
        s = self.s
        f = ttk.Frame(self.nb, padding=10)
        self.nb.add(f, text="  FSW (스펙트럼 분석기)  ")
        pad = dict(padx=4, pady=4)
        g = ttk.LabelFrame(f, text=" 연결 (LAN) ", padding=8)
        g.pack(fill="x")
        ttk.Label(g, text="IP").grid(row=0, column=0, **pad)
        self.var_fsw_host = tk.StringVar(value=s["fsw_host"])
        ttk.Entry(g, textvariable=self.var_fsw_host, width=18).grid(row=0, column=1, **pad)
        ttk.Label(g, text="Port").grid(row=0, column=2, **pad)
        self.var_fsw_port = tk.StringVar(value=str(s["fsw_port"]))
        ttk.Entry(g, textvariable=self.var_fsw_port, width=6).grid(row=0, column=3, **pad)
        self.btn_fsw = ttk.Button(g, text="연결", command=self.fsw_connect, width=10)
        self.btn_fsw.grid(row=0, column=4, **pad)
        self.lbl_fsw_idn = ttk.Label(g, text="(IP에 demo 입력 시 장비 없이 테스트)", foreground="#666")
        self.lbl_fsw_idn.grid(row=1, column=0, columnspan=6, sticky="w", **pad)
        self.var_fsw_gtl = tk.BooleanVar(value=bool(s["fsw_gtl"]))
        ttk.Checkbutton(g, text="읽은 뒤 바로 Local 복귀 (&GTL) - 장비 앞 패널도 계속 조작 가능하게",
                        variable=self.var_fsw_gtl, command=self.apply_worker_opts).grid(
            row=2, column=0, columnspan=6, sticky="w", **pad)
        ttk.Label(g, text="읽기 주기(ms)").grid(row=3, column=0, **pad)
        self.var_fsw_poll = tk.StringVar(value=str(s["fsw_poll"]))
        ttk.Spinbox(g, from_=100, to=5000, increment=100, textvariable=self.var_fsw_poll, width=7,
                    command=self.apply_worker_opts).grid(row=3, column=1, sticky="w", **pad)

        g2 = ttk.LabelFrame(f, text=" 주파수 / 마커  (연결하면 장비에 지금 설정된 값을 불러옴) ", padding=8)
        g2.pack(fill="x", pady=8)
        ttk.Label(g2, text="Center(GHz)").grid(row=0, column=0, **pad)
        self.var_fsw_cent = tk.StringVar(value="")
        ttk.Entry(g2, textvariable=self.var_fsw_cent, width=12).grid(row=0, column=1, **pad)
        ttk.Label(g2, text="Span(MHz)").grid(row=0, column=2, **pad)
        self.var_fsw_span = tk.StringVar(value="")
        ttk.Entry(g2, textvariable=self.var_fsw_span, width=10).grid(row=0, column=3, **pad)
        ttk.Label(g2, text="마커 번호").grid(row=1, column=0, **pad)
        self.var_fsw_mk = tk.StringVar(value=str(s["fsw_marker"]))
        cb = ttk.Combobox(g2, textvariable=self.var_fsw_mk, values=[str(i) for i in range(1, 17)],
                          width=4, state="readonly")
        cb.grid(row=1, column=1, sticky="w", **pad)
        cb.bind("<<ComboboxSelected>>", lambda e: self.fsw_marker_changed())
        ttk.Label(g2, text="마커 주파수(GHz)").grid(row=1, column=2, **pad)
        self.var_fsw_mx = tk.StringVar(value="")
        ttk.Entry(g2, textvariable=self.var_fsw_mx, width=12).grid(row=1, column=3, **pad)
        bf = ttk.Frame(g2)
        bf.grid(row=2, column=0, columnspan=6, sticky="w", pady=(6, 0))
        ttk.Button(bf, text="장비에 적용", command=self.fsw_apply).pack(side="left", padx=3)
        ttk.Button(bf, text="마커 피크 찾기", command=self.fsw_peak).pack(side="left", padx=3)
        ttk.Button(bf, text="장비 값 다시 불러오기", command=self.fsw_reload).pack(side="left", padx=3)
        ttk.Label(g2, text="※ 빈 칸은 장비에 보내지 않음. 마커는 Window 1 기준.", foreground="#666").grid(
            row=3, column=0, columnspan=6, sticky="w", **pad)
        self.lbl_fsw_read = ttk.Label(f, text="", foreground="#1f4f8f")
        self.lbl_fsw_read.pack(anchor="w", pady=4)

    # ------------------------------------------------ 탭: 오실로스코프 (기존 전류계 그대로)
    def open_plot_window(self):
        win = tk.Toplevel(self.root)
        win.title("%s - 그래프" % APP_NAME)
        win.geometry("640x760")
        panel = PlotPanel(win)
        panel.pack(fill="both", expand=True)
        self.plots.append(panel)
        self.hook_plot(panel)

        def closed():
            if panel in self.plots:
                self.plots.remove(panel)
            win.destroy()

        win.protocol("WM_DELETE_WINDOW", closed)
        win.after(100, self.refresh_plots)

    # ------------------------------------------------ Datasets (샘플 × 주파수)
    @staticmethod
    def ds_key(r):
        return (r.get("sample") or "", freq_key(r))

    @staticmethod
    def ds_label(key):
        smp, fk = key
        f = ("%.6g GHz" % fk) if fk is not None else "주파수 없음"
        return ("%s · %s" % (smp, f)) if smp else f

    def ds_list(self):
        out = []
        for r in self.rows:
            k = self.ds_key(r)
            if k not in out:
                out.append(k)
        return out

    def ds_live(self):
        f = self.smw.get("f") if self.smw.get("conn") else None
        if not f:
            return None
        return ((self.var_sample.get() or "").strip(), round(f / 1e9, 6))

    def ds_visible(self, key):
        if key in self.ds_hidden:
            return False
        flt = self.var_dsfilter.get().strip().lower() if hasattr(self, "var_dsfilter") else ""
        if flt:
            return all(w in self.ds_label(key).lower() for w in flt.split())
        return True

    def ds_color(self, key):
        st = self.ds_style.get(key, {})
        if st.get("color"):
            return st["color"]
        if self.color_mode == "each":
            vis = [k for k in self.ds_list() if self.ds_visible(k)]
            idx = vis.index(key) if key in vis else self.ds_list().index(key) if key in self.ds_list() else 0
            return distinct_colors(max(len(vis), idx + 1))[idx]
        fc = freq_colors(self.rows, self.fcolor_cache)
        return fc.get(key[1], FREQ_COLORS[0])

    def ds_shape(self, key):
        """Analyzer 와 같음: 같은 주파수의 여러 측정(샘플)은 기록 순서대로 o · s · ^ · D · v · P"""
        st = self.ds_style.get(key, {})
        if st.get("shape"):
            return st["shape"]
        same = [k for k in self.ds_list() if k[1] == key[1]]
        if len(same) < 2 or key not in same:
            return "o"
        return MEAS_MARKERS[same.index(key) % len(MEAS_MARKERS)]

    def build_datasets(self, parent):
        top = ttk.Frame(parent)
        top.pack(fill="x")
        ttk.Label(top, text="Datasets", font=("맑은 고딕", 9, "bold")).pack(side="left")
        ttk.Label(top, text=" 필터").pack(side="left", padx=(6, 1))
        self.var_dsfilter = tk.StringVar()
        ef = ttk.Entry(top, textvariable=self.var_dsfilter, width=6)
        ef.pack(side="left", fill="x", expand=True)
        self.var_dsfilter.trace_add("write", lambda *a: self.refresh_plots())
        bt = ttk.Frame(parent)
        bt.pack(fill="x", pady=2)
        ttk.Button(bt, text="전체 표시", width=7, command=lambda: self.ds_show_all(True)).pack(side="left")
        ttk.Button(bt, text="숨김", width=4, command=lambda: self.ds_show_all(False)).pack(side="left", padx=1)
        ttk.Button(bt, text="선택 해제", width=7, command=self.ds_clear_sel).pack(side="left")
        tf = ttk.Frame(parent)
        tf.pack(fill="both", expand=True)
        self.dstree = ttk.Treeview(tf, columns=("v", "s", "f", "n"), show="headings", selectmode="extended", height=8)
        for k, t, w in (("v", "표시", 30), ("s", "샘플", 44), ("f", "GHz", 52), ("n", "점", 28)):
            self.dstree.heading(k, text=t)
            self.dstree.column(k, width=w, anchor="center", stretch=(k == "f"))
        sb = ttk.Scrollbar(tf, orient="vertical", command=self.dstree.yview)
        self.dstree.configure(yscrollcommand=sb.set)
        self.dstree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.dstree.bind("<<TreeviewSelect>>", self.on_ds_select)
        self.dstree.bind("<Button-1>", self.on_ds_click, add="+")
        self.dstree.bind("<Button-3>", self.on_ds_menu)
        ttk.Label(parent, text="클릭: 선택(진하게)\nCtrl/Shift: 여러 개\n'표시' 칸: 보이기/숨기기\n"
                               "우클릭: 색·굵기·선·마커\n그래프: Ctrl/Shift+클릭",
                  foreground="#777", font=("맑은 고딕", 8), justify="left").pack(fill="x", pady=(3, 0))
        self.ds_iid = {}   # iid → key
        self._ds_sync = False

    def refresh_datasets(self):
        if not hasattr(self, "dstree"):
            return
        keys = self.ds_list()
        counts = collections.Counter(self.ds_key(r) for r in self.rows)
        live = self.ds_live()
        self._ds_sync = True
        want = {}
        for k in keys:
            iid = "ds_%s_%s" % (k[0], k[1])
            want[iid] = k
        for iid in list(self.dstree.get_children()):
            if iid not in want:
                self.dstree.delete(iid)
        for i, (iid, k) in enumerate(want.items()):
            vals = ("☑" if k not in self.ds_hidden else "☐", k[0] or "-",
                    ("%.6g" % k[1]) if k[1] is not None else "-", counts.get(k, 0))
            tag = "c_%s" % self.ds_color(k).lstrip("#")
            self.dstree.tag_configure(tag, foreground=self.ds_color(k))
            tags = [tag] + (["live"] if k == live else []) + (["filtered"] if not self.ds_visible(k) and k not in self.ds_hidden else [])
            if self.dstree.exists(iid):
                self.dstree.item(iid, values=vals, tags=tags)
                self.dstree.move(iid, "", i)
            else:
                self.dstree.insert("", i, iid=iid, values=vals, tags=tags)
        self.dstree.tag_configure("live", font=("맑은 고딕", 9, "bold"))
        self.dstree.tag_configure("filtered", foreground="#bbbbbb")
        self.ds_iid = want
        sel = [iid for iid, k in want.items() if k in self.ds_selected]
        if tuple(sorted(sel)) != tuple(sorted(self.dstree.selection())):
            self.dstree.selection_set(sel)
        self._ds_sync = False

    def on_ds_select(self, event=None):
        if self._ds_sync:
            return
        self.ds_selected = {self.ds_iid[i] for i in self.dstree.selection() if i in self.ds_iid}
        self.refresh_plots(datasets=False)

    def on_ds_click(self, event):
        if self.dstree.identify_region(event.x, event.y) == "cell" and self.dstree.identify_column(event.x) == "#1":
            iid = self.dstree.identify_row(event.y)
            k = self.ds_iid.get(iid)
            if k is not None:
                if k in self.ds_hidden:
                    self.ds_hidden.discard(k)
                else:
                    self.ds_hidden.add(k)
                self.refresh_plots()
                return "break"

    def ds_show_all(self, show):
        self.ds_hidden = set() if show else set(self.ds_list())
        self.refresh_plots()

    def ds_clear_sel(self):
        self.ds_selected = set()
        self.refresh_plots()

    def on_plot_pick(self, key, additive):
        if key is None:
            if not additive:
                self.ds_selected = set()
        elif additive:
            self.ds_selected ^= {key}
        else:
            self.ds_selected = {key}
        self.refresh_plots()
        if key is not None:   # 선택한 데이터셋으로 목록 스크롤
            for iid, k in self.ds_iid.items():
                if k == key:
                    self.dstree.see(iid)
                    break

    def hook_plot(self, panel):
        panel.p1.on_pick = self.on_plot_pick
        panel.p2.on_pick = self.on_plot_pick

    def on_ds_menu(self, event):
        iid = self.dstree.identify_row(event.y)
        if not iid:
            return
        if iid not in self.dstree.selection():
            self.dstree.selection_set(iid)
            self.on_ds_select()
        keys = [self.ds_iid[i] for i in self.dstree.selection() if i in self.ds_iid]
        m = tk.Menu(self.root, tearoff=0)
        m.add_command(label="색상 바꾸기...", command=lambda: self.ds_pick_color(keys))
        mw = tk.Menu(m, tearoff=0)
        for w in (1, 1.6, 2.5, 3.5, 5):
            mw.add_command(label="%g" % w, command=lambda w=w: self.ds_set_style(keys, width=w))
        m.add_cascade(label="선 굵기", menu=mw)
        md = tk.Menu(m, tearoff=0)
        for name in DASHES:
            md.add_command(label=name, command=lambda n=name: self.ds_set_style(keys, dash=n))
        m.add_cascade(label="선 종류", menu=md)
        mm = tk.Menu(m, tearoff=0)
        for name, r in (("없음", 0), ("작게", 2), ("보통", 3), ("크게", 4.5)):
            mm.add_command(label=name, command=lambda r=r: self.ds_set_style(keys, marker=r))
        m.add_cascade(label="마커 크기", menu=mm)
        ms = tk.Menu(m, tearoff=0)
        for name, sh in (("● 원", "o"), ("■ 사각", "s"), ("▲ 삼각", "^"), ("◆ 마름모", "D"), ("▼ 역삼각", "v"), ("✚ 십자", "P")):
            ms.add_command(label=name, command=lambda sh=sh: self.ds_set_style(keys, shape=sh))
        m.add_cascade(label="마커 모양", menu=ms)
        m.add_separator()
        m.add_command(label="이것만 보기", command=lambda: self.ds_only(keys))
        m.add_command(label="숨기기", command=lambda: (self.ds_hidden.update(keys), self.refresh_plots()))
        m.add_command(label="스타일 기본으로", command=lambda: ([self.ds_style.pop(k, None) for k in keys],
                                                        self.refresh_plots()))
        m.tk_popup(event.x_root, event.y_root)

    def ds_pick_color(self, keys):
        from tkinter import colorchooser
        c = colorchooser.askcolor(color=self.ds_color(keys[0]) if keys else None, title="데이터셋 색상")
        if c and c[1]:
            self.ds_set_style(keys, color=c[1])

    def ds_set_style(self, keys, **kw):
        for k in keys:
            self.ds_style.setdefault(k, {}).update(kw)
        self.refresh_plots()

    def ds_only(self, keys):
        self.ds_hidden = set(self.ds_list()) - set(keys)
        self.refresh_plots()

    def set_color_mode(self, mode):
        """각각색: 지금 보이는 데이터셋마다 다른 색 / 주파수 색: 주파수마다 같은 색. (직접 고른 색은 초기화)"""
        self.color_mode = mode
        for st in self.ds_style.values():
            st.pop("color", None)
        self.refresh_plots()

    def reset_line_styles(self):
        for st in self.ds_style.values():
            for k in ("width", "dash", "marker", "shape"):
                st.pop(k, None)
        self.refresh_plots()

    def init_sashes(self):
        """처음 열 때: 그래프 쪽을 넓게(창의 약 45%), Datasets 목록은 좁게(약 170 px)."""
        try:
            self.root.update_idletasks()
            W = self.hpan.winfo_width()
            if W > 800 and not self.s.get("sash_set"):
                self.hpan.sashpos(0, int(W * 0.57))
            self.dsp.sashpos(0, 170)
        except tk.TclError:
            pass

    def plots_reset_view(self):
        for pnl in self.plots:
            try:
                pnl.reset_view()
            except tk.TclError:
                pass

    def build_series(self):
        """그래프용 시리즈 (PAE, Gain). 표시 체크된 데이터셋만, 선택·측정 중은 진하게."""
        groups = collections.OrderedDict()
        for r in self.rows:
            if r.get("pout") is None:
                continue
            groups.setdefault(self.ds_key(r), []).append(r)
        live = self.ds_live()
        sel = self.ds_selected
        s1, s2, xs = [], [], []
        for k, rs in groups.items():
            if not self.ds_visible(k):
                continue
            rs = sorted(rs, key=lambda r: r["sg"] if r.get("sg") is not None else r["pout"])
            st = self.ds_style.get(k, {})
            base = dict(key=k, label=self.ds_label(k), color=self.ds_color(k),
                        width=st.get("width", 1.6), dash=DASHES.get(st.get("dash", "실선")),
                        marker=st.get("marker", 3), shape=self.ds_shape(k),
                        emph=1 if (k in sel or (k == live and (self.scope.running or self.sweep))) else 0,
                        dim=bool(sel) and k not in sel)
            if base["emph"] and k == live and k not in sel:
                base["label"] += " (측정 중)"
            pae = [(r["pout"], r["pae"]) for r in rs if r.get("pae") is not None]
            gain = [(r["pout"], r["gain"]) for r in rs if r.get("gain") is not None]
            xs += [r["pout"] for r in rs]
            if pae:
                s1.append(dict(base, pts=pae))
            if gain:
                s2.append(dict(base, pts=gain))
        xr = (min(xs), max(xs)) if xs else None
        notes = ("" if s1 else ("Vdd 를 입력하면 PAE 가 표시됩니다" if self.rows else "기록된 데이터가 없습니다"),
                 "" if s2 else "기록된 데이터가 없습니다")
        return s1, s2, xr, notes

    # ------------------------------------------------ RF PA Analyzer 그래프 창 (실시간 연동)
    def analyzer_datasets(self):
        if not self.analyzer.running():
            return []
        return self.pa_datasets(self.rows)

    def pa_datasets(self, rows_in):
        """Bench 기록 → Analyzer Dataset (샘플 × 주파수). 조건 + 측정 표 (Analyzer 가 열 이름을 자동 인식).
        반환: [(key, 내부 이름, 표시 이름, 셀 표), ...]"""
        groups = collections.OrderedDict()
        for r in rows_in:
            if r.get("pout") is not None:
                groups.setdefault(self.ds_key(r), []).append(r)
        vdd = fnum(self.var_vdd.get())

        def v(x, nd):
            return "" if x is None else round(x, nd)
        out = []
        for k, rs in groups.items():
            rs = sorted(rs, key=lambda r: r["sg"] if r.get("sg") is not None else r["pout"])
            smp, fk = k
            cond = []
            if fk is not None:
                cond.append(["FREQ", "%.6g GHz" % fk])
            if vdd is not None:
                cond.append(["VDD", vdd])
            if smp:
                cond.append(["DUT", smp])
            if rs[0].get("inl") is not None:
                cond.append(["Input Loss", round(rs[0]["inl"], 3)])
            if rs[0].get("outl") is not None:
                cond.append(["Output Loss", round(rs[0]["outl"], 3)])
            rows = cond + [[], ["SG Pout (dBm)", "SA Pin (dBm)", "DUT_Pin (dBm)", "DUT_Pout (dBm)", "Gain",
                                "Id (mA)", "DC_Power(mW)", "DE(%)", "PAE(%)"]]
            for r in rs:
                rows.append([v(r.get("sg"), 3), v(r.get("sa"), 3), v(r.get("pin"), 3), v(r.get("pout"), 3),
                             v(r.get("gain"), 3), v(r.get("id"), 2),
                             "" if r.get("pdc") is None else round(r["pdc"] * 1e3, 2),
                             v(r.get("de"), 3), v(r.get("pae"), 3)])
            name = ("%s %sGHz" % (smp, "%.6g" % fk if fk is not None else "?")).strip()
            out.append((list(k), name, smp or "Bench", rows))   # Analyzer 가 이름 뒤에 FREQ 를 붙여 "S1 · 3.50 GHz"
        return out

    def open_analyzer(self):
        ok, msg = self.analyzer.open()
        if not ok:
            messagebox.showwarning(APP_NAME, msg)
            return
        self.status(msg, "#39ff88")
        self.analyzer_watch(time.time())
        self.refresh_plots(datasets=False)

    def analyzer_watch(self, t0):
        """창이 뜨는 동안 상태 확인 (연결되면 데이터 전체 전송, 실패하면 알림)."""
        a = self.analyzer
        if a.connected():
            a.sent = {}
            self.refresh_plots(datasets=False)
            self.status("PA Analyzer 그래프 창 연결됨 - 기록할 때마다 자동으로 갱신", "#39ff88")
            return
        if not a.running() or a.error:
            code = a.proc.poll() if a.proc is not None else None
            messagebox.showwarning(APP_NAME, (a.error or "PA Analyzer 그래프 창이 종료되었습니다 (코드 %s)." % code)
                                   + "\n\n로그: PA-Analyzer-graph.log (프로그램 폴더)")
            a.error = ""
            return
        if time.time() - t0 > 90:
            return
        self.root.after(300, lambda: self.analyzer_watch(t0))

    def plot_axes(self):
        out = []
        for vars_ in (self.var_pae_ax, self.var_gain_ax):
            lo, hi, st = (fnum(v.get()) for v in vars_)
            if lo is None or hi is None or hi <= lo:
                out.append(None)
                continue
            if st is None or st <= 0 or (hi - lo) / st > 100:
                st = (nice_ticks(lo, hi, 6)[1] - nice_ticks(lo, hi, 6)[0]) if len(nice_ticks(lo, hi, 6)) > 1 else (hi - lo)
            out.append((lo, hi, st))
        lo, hi, lab, mn = (fnum(v.get()) for v in self.var_x_ax)
        if lo is None or hi is None or hi <= lo:
            out.append(None)
        else:
            if lab is None or lab <= 0 or (hi - lo) / lab > 100:
                lab = 5.0
            out.append((lo, hi, lab, mn if (mn and mn > 0) else None))
        return tuple(out)

    # ------------------------------------------------ 케이블 손실 표 파일
    def loss_save(self):
        if not self.loss_table:
            messagebox.showinfo(APP_NAME, "저장할 손실 데이터가 없습니다.")
            return
        path = filedialog.asksaveasfilename(
            title="케이블 손실 표 내보내기 (txt)", defaultextension=".txt",
            initialdir=self.s.get("loss_dir") or None,
            initialfile="cable_loss_%s.txt" % datetime.datetime.now().strftime("%Y%m%d"),
            filetypes=[("텍스트 파일", "*.txt"), ("모든 파일", "*.*")])
        if not path:
            return
        # 탭 구분 텍스트 → 메모장으로 열기 / 엑셀에 그대로 붙여넣기 가능
        with open(path, "w", encoding="utf-8-sig", newline="\r\n") as f:
            f.write("Freq(GHz)\tIn loss(dB)\tOut loss(dB)\n")
            for fg, li, lo in sorted(self.loss_table):
                f.write("%.6g\t%.3f\t%.3f\n" % (fg, li, lo))
        self.s["loss_dir"] = os.path.dirname(path)
        self.status("케이블 손실 표 저장됨: " + path, "#39ff88")

    def loss_load(self):
        path = filedialog.askopenfilename(
            title="케이블 손실 표 불러오기 (txt)", initialdir=self.s.get("loss_dir") or None,
            filetypes=[("텍스트 파일", "*.txt"), ("CSV", "*.csv"), ("모든 파일", "*.*")])
        if not path:
            return
        rows = []
        try:
            try:
                with open(path, "r", encoding="utf-8-sig") as f:
                    lines = f.read().splitlines()
            except UnicodeDecodeError:  # 메모장 ANSI(cp949) 저장 파일
                with open(path, "r", encoding="cp949", errors="replace") as f:
                    lines = f.read().splitlines()
            for line in lines:
                # 탭 / 공백 / 쉼표 / 세미콜론 구분 모두 허용, 숫자 3개 있는 줄만 사용
                parts = line.replace(",", " ").replace(";", " ").split()
                vals = [fnum(x) for x in parts]
                if len(vals) >= 3 and None not in vals[:3]:
                    rows.append(vals[:3])
        except Exception as e:
            messagebox.showerror(APP_NAME, "파일을 읽지 못했습니다.\n%s" % e)
            return
        if not rows:
            messagebox.showwarning(APP_NAME, "읽을 수 있는 행이 없습니다.\n형식: 주파수(GHz), In loss(dB), Out loss(dB)")
            return
        self.loss_table = rows
        self.refresh_loss_tree()
        self.s["loss_dir"] = os.path.dirname(path)
        self.status("케이블 손실 표 불러옴: %d개 주파수 (%s)" % (len(rows), os.path.basename(path)), "#39ff88")

    def refresh_plots(self, datasets=True):
        if datasets:
            self.refresh_datasets()
        try:
            self.analyzer.sync(self.analyzer_datasets())
        except Exception:
            pass
        s1, s2, xr, notes = self.build_series()
        axes = self.plot_axes()
        for pnl in list(self.plots):
            try:
                pnl.show(s1, s2, xr, notes, axes)
            except tk.TclError:
                self.plots.remove(pnl)

    def build_scope_tab(self):
        f = ttk.Frame(self.nb)
        self.nb.add(f, text="  RTO2044 (전류)  ")
        self.scope = rto.App(self.root, container=f)
        orig = self.scope.show_value
        bench = self

        def hooked(raw, t):
            amps = raw * bench.scope.conv_factor() if math.isfinite(raw) else float("nan")
            # 새로 들어온 파형의 값만 평균·기록·기억에 사용 (트리거가 안 걸려 예전 파형이 반복되면 제외)
            if math.isfinite(amps) and getattr(bench.scope, "value_fresh", True) \
                    and not getattr(bench.scope, "stale", False):
                bench.cur_samples.append((t, amps))
                bench.cur_fresh_t = t
                p_now = bench.smw.get("p")
                if p_now is not None and math.isfinite(p_now) and t - bench.p_change_t > 0.3:
                    bench.cur_fresh_ref = (amps, p_now)   # 새 파형으로 읽힌 전류와 그때의 SG 파워
                bench.learn_current(amps, t)
            bench.cur_last = (t, amps)
            orig(raw, t)

        self.scope.show_value = hooked
        self.cur_last = (0, float("nan"))
        self.cur_fresh_t = 0.0
        self.cur_fresh_ref = None
        # 트리거 모드: Normal 권장 (이 버전에서 한 번만 바꿔 줌, 이후엔 사용자가 고른 값 유지)
        if not self.s.get("v106_normal"):
            self.scope.var_trk_mode.set(rto.TRIG_MODES[1])
            self.s["v106_normal"] = True

    # ------------------------------------------------ 동작
    def apply_worker_opts(self):
        self.smw_w.gtl = self.var_smw_gtl.get()
        self.fsw_w.gtl = self.var_fsw_gtl.get()
        self.smw_w.interval = max(100, fnum(self.var_smw_poll.get(), 300)) / 1000.0
        self.fsw_w.interval = max(100, fnum(self.var_fsw_poll.get(), 300)) / 1000.0

    def connect_all(self):
        if not self.smw["conn"]:
            self.smw_connect()
        if not self.fsw["conn"]:
            self.fsw_connect()
        if not self.scope.connected:
            self.scope.on_connect()

    def toggle_current(self):
        if not self.scope.connected:
            self.status("오실로스코프가 연결되지 않았습니다 - 'RTO2044 (전류)' 탭 확인", "#ff6b6b")
            return
        self.scope.on_run()

    def smw_connect(self):
        if self.smw["conn"]:
            self.smw_w.tasks.put(("disconnect",))
            return
        self.apply_worker_opts()
        self.smw_w.tasks.put(("connect", self.var_smw_host.get(), int(fnum(self.var_smw_port.get(), 5025))))

    def fsw_connect(self):
        if self.fsw["conn"]:
            self.fsw_w.tasks.put(("disconnect",))
            return
        self.apply_worker_opts()
        self.fsw_w.marker = int(self.var_fsw_mk.get())
        self.fsw_w.tasks.put(("connect", self.var_fsw_host.get(), int(fnum(self.var_fsw_port.get(), 5025))))

    def smw_set_level(self, lvl=None):
        if not self.smw["conn"]:
            messagebox.showinfo(APP_NAME, "SMW200A 가 연결되지 않았습니다.")
            return
        if lvl is None:
            lvl = fnum(self.var_smw_lvl.get())
            if lvl is None:
                messagebox.showwarning(APP_NAME, "레벨(dBm)에 숫자를 입력하세요.")
                return
        mx = fnum(self.var_smw_max.get(), 10.0)
        if lvl > mx + 1e-9:
            messagebox.showwarning(APP_NAME, "최대 허용 레벨(%.2f dBm)을 넘습니다." % mx)
            return
        self.var_smw_lvl.set("%.2f" % lvl)
        self.p_change_t = time.time()  # 읽어오기 전에 바로 기록 눌러도 안정화 대기
        self.smw_w.tasks.put(("call", lambda w: w.inst.write("SOUR1:POW %.2f" % lvl)))

    def plot_under_pointer(self):
        try:
            x, y = self.root.winfo_pointerxy()
            w = self.root.winfo_containing(x, y)
        except (tk.TclError, KeyError):
            return None, 0, 0
        if isinstance(w, XYPlot):
            return w, x - w.winfo_rootx(), y - w.winfo_rooty()
        return None, 0, 0

    def on_marker_key(self, event, kind):
        w = event.widget
        if isinstance(w, (tk.Entry, ttk.Entry, tk.Spinbox, ttk.Spinbox, ttk.Combobox, tk.Text)):
            return
        plot, px, py = self.plot_under_pointer()
        if plot is None:
            return
        if kind == "del":
            plot.delete_marker(px, py)
        elif kind == "delall":
            plot.delete_marker(everything=True)
        elif not plot.add_marker(kind, px, py):
            return
        return "break"

    def on_hotkey(self, event, fn):
        # 입력칸에 숫자를 치는 중이면 단축키로 쓰지 않음
        w = event.widget
        if isinstance(w, (tk.Entry, ttk.Entry, tk.Spinbox, ttk.Spinbox, ttk.Combobox, tk.Text)):
            return
        if self.sweep or self.ramp:
            return "break"
        now = time.time()
        k = event.keysym.replace("KP_", "")
        if now - self.last_key_t.get(k, 0) < 0.25:  # 같은 키를 누르고 있을 때 연속 입력 방지
            return "break"
        self.last_key_t[k] = now
        fn()
        return "break"

    def record_request(self):
        """기록: 방금 파워를 바꿨으면 안정화+평균 시간이 지난 뒤 기록."""
        settle = max(0.0, fnum(self.var_settle.get(), 1.0))
        avg = max(0.2, fnum(self.var_avg.get(), 1.0))
        ready_t = self.p_change_t + settle + avg
        now = time.time()
        if self.rec_wait is not None:
            self.root.after_cancel(self.rec_wait)
            self.rec_wait = None
        if now >= ready_t:
            self.record(manual=True)
            return
        self.lbl_rec.configure(text="기록 대기... %.1f초 (파워 안정화)" % (ready_t - now))

        def go():
            self.rec_wait = None
            self.lbl_rec.configure(text="")
            if time.time() < self.p_change_t + settle + avg - 0.05:
                self.record_request()  # 그 사이 파워가 또 바뀌었으면 다시 대기
                return
            self.record(manual=True, t1=self.p_change_t + settle, t2=time.time())

        self.rec_wait = self.root.after(int((ready_t - now) * 1000) + 50, go)

    def smw_step(self, sign):
        p = self.smw["p"]
        if p is None or not math.isfinite(p):
            messagebox.showinfo(APP_NAME, "SMW 현재 레벨을 아직 못 읽었습니다.")
            return
        st = fnum(self.var_smw_step.get(), 1.0)
        self.smw_set_level(round(p + sign * st, 2))

    def fsw_marker_changed(self):
        n = int(self.var_fsw_mk.get())
        self.fsw_w.tasks.put(("call", lambda w: (setattr(w, "marker", n), fsw_read_cfg(w))))
        self.fsw_samples.clear()

    def fsw_apply(self):
        if not self.fsw["conn"]:
            messagebox.showinfo(APP_NAME, "FSW 가 연결되지 않았습니다.")
            return
        n = int(self.var_fsw_mk.get())
        cent = fnum(self.var_fsw_cent.get())
        span = fnum(self.var_fsw_span.get())
        mx = fnum(self.var_fsw_mx.get())

        def job(w):
            w.marker = n
            if cent is not None:
                w.inst.write("SENS:FREQ:CENT %.6f" % (cent * 1e9))
            if span is not None:
                w.inst.write("SENS:FREQ:SPAN %.6f" % (span * 1e6))
            w.inst.write("CALC1:MARK%d:STAT ON" % n)
            if mx is not None:
                w.inst.write("CALC1:MARK%d:X %.6f" % (n, mx * 1e9))
            w.inst.query("*OPC?")
            errs = []
            for _ in range(10):
                e = w.inst.query("SYST:ERR?")
                if e.startswith("0") or e.startswith("+0"):
                    break
                errs.append(e)
            if errs:
                w.post("error", "FSW 오류: " + " / ".join(errs))
            fsw_read_cfg(w)
            w.post("filled")

        self.fsw_samples.clear()
        self.fsw_w.tasks.put(("call", job))

    def fsw_peak(self):
        if not self.fsw["conn"]:
            return
        n = int(self.var_fsw_mk.get())

        def job(w):
            w.marker = n
            w.inst.write("CALC1:MARK%d:STAT ON" % n)
            w.inst.write("CALC1:MARK%d:MAX" % n)
            w.inst.query("*OPC?")
            fsw_read_cfg(w)
            w.post("fill_fields")

        self.fsw_samples.clear()
        self.fsw_w.tasks.put(("call", job))

    def fsw_reload(self):
        if not self.fsw["conn"]:
            return
        self.fsw_w.tasks.put(("call", lambda w: (fsw_read_cfg(w), w.post("fill_fields"))))

    # ------------------------------------------------ 주파수 / 케이블 손실
    def apply_freq(self):
        g = fnum(self.var_freq.get())
        if g is None or g <= 0:
            messagebox.showwarning(APP_NAME, "주파수(GHz)를 입력하세요.")
            return
        hz = g * 1e9
        done = []
        if self.smw["conn"]:
            self.smw_w.tasks.put(("call", lambda w: w.inst.write("SOUR1:FREQ %.3f" % hz)))
            done.append("SG")
        if self.fsw["conn"]:
            n = int(self.var_fsw_mk.get())

            def job(w):
                w.marker = n
                w.inst.write("SENS:FREQ:CENT %.3f" % hz)
                w.inst.write("CALC1:MARK%d:STAT ON" % n)
                w.inst.write("CALC1:MARK%d:X %.3f" % (n, hz))
                w.inst.query("*OPC?")
                fsw_read_cfg(w)
                w.post("fill_fields")

            self.fsw_w.tasks.put(("call", job))
            done.append("SA")
        self.fsw_samples.clear()
        self.cur_samples.clear()
        self.cur_mem = {}
        self.mem_freq = round(g, 4)
        if done:
            self.status("%s 주파수 → %.6g GHz" % (" + ".join(done), g), "#39ff88")
        else:
            self.status("SG / SA 가 연결되지 않았습니다.", "#ff6b6b")

    def refresh_loss_tree(self):
        self.loss_hl = -1  # 다음 tick 에 하이라이트 다시 그림
        self.loss_table.sort(key=lambda r: r[0])
        self.loss_tree.delete(*self.loss_tree.get_children())
        for i, (fg, li, lo) in enumerate(self.loss_table):
            self.loss_tree.insert("", "end", iid=str(i), values=("%.6g" % fg, "%.2f" % li, "%.2f" % lo))

    def loss_selected(self, event=None):
        sel = self.loss_tree.selection()
        if sel:
            fg, li, lo = self.loss_table[int(sel[0])]
            self.var_lf.set("%.6g" % fg)
            self.var_li.set("%.2f" % li)
            self.var_lo.set("%.2f" % lo)

    def loss_add(self):
        fg, li, lo = fnum(self.var_lf.get()), fnum(self.var_li.get()), fnum(self.var_lo.get())
        if fg is None:
            f_now = self.smw.get("f")
            if f_now:
                fg = f_now / 1e9
                self.var_lf.set("%.6g" % fg)
        if fg is None or li is None or lo is None:
            messagebox.showwarning(APP_NAME, "주파수(GHz), In loss, Out loss 를 숫자로 입력하세요.")
            return
        self.loss_table = [r for r in self.loss_table if abs(r[0] - fg) > 1e-9]
        self.loss_table.append([fg, li, lo])
        self.refresh_loss_tree()

    def loss_del(self):
        sel = self.loss_tree.selection()
        if not sel:
            return
        idx = {int(i) for i in sel}
        self.loss_table = [r for i, r in enumerate(self.loss_table) if i not in idx]
        self.refresh_loss_tree()

    def loss_index(self, hz):
        """가장 가까운 주파수 행 번호 (표가 비었거나 주파수 없음 → None)."""
        if not self.loss_table or hz is None or not math.isfinite(hz):
            return None
        g = hz / 1e9
        return min(range(len(self.loss_table)), key=lambda i: abs(self.loss_table[i][0] - g))

    def losses_at(self, hz):
        """주파수(Hz)의 (In loss, Out loss): 표에서 가장 가까운 주파수 값. 표가 없으면 입력칸 값."""
        i = self.loss_index(hz)
        if i is None:
            return fnum(self.var_li.get(), 0.0), fnum(self.var_lo.get(), 0.0)
        return self.loss_table[i][1], self.loss_table[i][2]

    def update_loss_highlight(self):
        hz = self.smw.get("f") if self.smw.get("conn") else None
        if not hz:
            g = fnum(self.var_freq.get())
            hz = g * 1e9 if (g and g > 0) else None
        i = self.loss_index(hz)
        if i != self.loss_hl:
            for iid in self.loss_tree.get_children():
                self.loss_tree.item(iid, tags=("used",) if (i is not None and iid == str(i)) else ())
            if i is not None:
                self.loss_tree.see(str(i))
            self.loss_hl = i

    def dut_calc(self, sg, sa, amps, hz):
        """DUT Pin/Pout/Gain/Pdc/DE/PAE 계산. 값이 없으면 None."""
        li, lo = self.losses_at(hz)
        pin = sg - li if (sg is not None and math.isfinite(sg)) else None
        pout = sa + lo if (sa is not None and math.isfinite(sa)) else None
        gain = pout - pin if (pin is not None and pout is not None) else None
        vdd = fnum(self.var_vdd.get())
        pdc = vdd * amps if (vdd is not None and amps is not None and math.isfinite(amps)) else None
        de = pae = None
        min_a = fnum(self.var_minid.get(), 0.0) / 1e3 if hasattr(self, "var_minid") else 0.0
        low_id = amps is not None and math.isfinite(amps) and amps < min_a
        if pdc is not None and pdc > 0 and pout is not None and not low_id:
            de = dbm_to_w(pout) / pdc * 100.0
            if pin is not None:
                pae = (dbm_to_w(pout) - dbm_to_w(pin)) / pdc * 100.0
        ix = self.loss_index(hz)
        lossf = self.loss_table[ix][0] if ix is not None else None
        return dict(inl=li, outl=lo, lossf=lossf, pin=pin, pout=pout, gain=gain, pdc=pdc, de=de, pae=pae)

    # ------------------------------------------------ 기록
    def toggle_rec(self):
        """체크박스: 손으로 파워를 바꿀 때마다 자동 기록."""
        self.rec_on = self.var_autochg.get()
        if self.rec_on:
            self.last_pin = None
            self.change_t = time.time()
            self.pending = True
        else:
            self.pending = False
            self.lbl_rec.configure(text="")

    # ------------------------------------------------ 자동 측정 (SG 레벨 → 최대 허용)
    def toggle_sweep(self):
        if self.sweep:
            self.stop_sweep("사용자가 중지함")
            return
        if not self.smw["conn"] or not self.fsw["conn"]:
            messagebox.showwarning(APP_NAME, "SG(SMW200A)와 SA(FSW)를 먼저 연결하세요.")
            return
        if self.ramp:
            messagebox.showinfo(APP_NAME, "천천히 내리는 중입니다. 끝난 뒤 시작하세요.")
            return
        start = fnum(self.var_lvl2.get())
        end = fnum(self.var_smw_max.get())
        step = fnum(self.var_smw_step.get())
        if start is None or end is None or step is None or step <= 0 or start > end:
            messagebox.showwarning(APP_NAME, "SG 레벨(시작) ≤ 최대 허용(끝), 스텝 > 0 으로 입력하세요.")
            return
        levels = []
        v = start
        while v <= end + 1e-9 and len(levels) < 500:
            levels.append(round(v, 2))
            v += step
        settle = max(0.0, fnum(self.var_settle.get(), 1.0))
        avg = max(0.2, fnum(self.var_avg.get(), 1.0))
        warn = "" if self.scope.running else "\n\n⚠ 전류 측정이 꺼져 있습니다 (Id·PAE 빈칸으로 기록)"
        if self.var_rf_sweep_on.get():
            warn = ("\n\nRF OFF 상태 → SG %.2f dBm 으로 맞춘 뒤 RF ON 하고 시작" % levels[0]
                    if not self.smw["rf"] else "\n\nRF ON 확인됨") + warn
        if not messagebox.askyesno(APP_NAME, "SG %.2f → %.2f dBm, %.2g dB 간격, %d점을 자동 측정합니다.\n"
                                             "점당 약 %.1f초 (안정화 %.1f + 평균 %.1f)\n%s%s\n\n진행할까요?" % (
                                       levels[0], levels[-1], step, len(levels), settle + avg + 0.4, settle, avg,
                                       "끝나면 %.2f dBm 으로 복귀" % levels[0] if self.var_sw_ret.get() else "끝나도 마지막 레벨 유지",
                                       warn)):
            return
        self.sweep = {"levels": levels, "i": 0, "phase": "set", "t": 0.0, "confirm": None, "start": levels[0],
                      "need_rf": bool(self.var_rf_sweep_on.get())}
        if self.var_rf_sweep_on.get() and not self.smw["rf"]:
            # RF 꺼져 있음 → SG 시작 레벨로 먼저 맞춘 뒤 RF ON (높은 레벨에서 켜지지 않게)
            self.set_rf(True, level=levels[0], why="자동 측정 시작: ")
        self.btn_rec.configure(text="■ 자동 측정 중지 (Esc)", bg="#a52a2a")
        self.btn_sweep.configure(text="■ 자동 측정 중지 (Esc)")
        self.status("자동 측정 시작: %d점" % len(levels), "#39ff88")

    def stop_sweep(self, reason, ok=False, ramp=None):
        sw = self.sweep
        self.sweep = None
        dlg = getattr(self, "sweep_dialog", None)
        if dlg is not None:
            try:
                dlg.destroy()
            except tk.TclError:
                pass
            self.sweep_dialog = None
        self.btn_rec.configure(text="● 자동 측정 (SG 레벨 → 최대 허용)", bg="#7a1f1f")
        self.btn_sweep.configure(text="● 자동 측정 시작 (SG 레벨 → 최대 허용, 스텝 간격)")
        self.lbl_rec.configure(text="")
        self.status(("자동 측정 완료" if ok else "자동 측정 중지") + ": " + reason, "#39ff88" if ok else "#d4a017")
        if sw and (self.var_sw_ret.get() if ramp is None else ramp) and self.smw["conn"]:
            # 바로 내리지 않고 현재 파워에서 한 칸씩 천천히 내림
            cur = sw.get("cur", sw["start"])
            self.start_ramp(sw["start"], from_level=cur, why="자동 측정 %s (%s) → " % ("완료" if ok else "중지", reason))

    # ------------------------------------------------ 전류 기억 → 트리거 예상 위치
    def mem_key(self, hz=None):
        hz = self.smw.get("f") if hz is None else hz
        return round(hz / 1e9, 4) if hz else None

    def learn_current(self, amps, t):
        """안정된 상태(파워 바뀐 뒤 안정화 시간 지남)의 전류를 'SG 파워 → 전류'로 기억 (지금 샘플·주파수만)."""
        p = self.smw.get("p")
        if p is None or not math.isfinite(p) or not self.smw.get("rf"):
            return
        settle = max(0.0, fnum(self.var_settle.get(), 1.0))
        if t - self.p_change_t < settle:
            return
        key = self.mem_key()
        if key != self.mem_freq:
            self.reset_memory(quiet=True)
            self.mem_freq = key
        self.cur_mem[round(p, 2)] = amps

    def reset_memory(self, quiet=False):
        self.cur_mem = {}
        self.mem_freq = self.mem_key()
        if not quiet:
            self.status("전류 기억 초기화 (새 샘플 / 주파수)", "#39ff88")

    def predict_current(self, old, new):
        """SG 파워 new 에서의 전류 예상 (A). 기억한 값 → 보간 / 가까운 점들의 기울기 → 마지막 값 기준."""
        m = self.cur_mem if self.mem_freq == self.mem_key() else {}
        k = round(new, 2)
        if k in m:
            return m[k], "기억값"
        lower = sorted(x for x in m if x < k)
        upper = sorted(x for x in m if x > k)
        if lower and upper:
            a, b = lower[-1], upper[0]
            return m[a] + (m[b] - m[a]) * (k - a) / (b - a), "보간"
        side = lower[-2:] if lower else upper[:2]
        near = side[-1] if lower else (side[0] if side else None)
        if near is not None and abs(k - near) > 6.0:
            side = []   # 기억한 점에서 너무 멀면 기울기로 예상하지 않고 직전값 기준으로 대략 예상
        if len(side) == 2 and abs(side[1] - side[0]) > 1e-9:
            a, b = side
            slope = (m[b] - m[a]) / (b - a)
            ref = b if lower else a
            est = m[ref] + slope * (k - ref)
            return max(est, 0.0), "기울기"
        if len(side) == 1 and abs(k - side[0]) <= 6.0:
            ref = side[0]
            d = k - ref
            return m[ref] * 10 ** (d / (20.0 if d < 0 else 40.0)), "1점 기준"
        if self.cur_fresh_ref:
            a, p_ref = self.cur_fresh_ref
            d = max(-20.0, min(20.0, new - p_ref))
            # 내릴 때는 조금 낮게, 올릴 때도 보수적으로 예상 (레벨이 전류보다 높으면 트리거가 안 걸림)
            mult = 10 ** (d / (20.0 if d < 0 else 40.0))
            return a * min(mult, 1.5), "직전값 기준" if abs(d) <= 6 else "대략"   # 크게 올릴 때도 최대 1.5배까지만
        return None, ""

    def on_sg_change(self, old, new, hz):
        sc = self.scope
        if not (sc.running and sc.var_trk.get()):
            return
        if self.mem_key(hz) != self.mem_freq:
            self.reset_memory(quiet=True)
        pred, how = self.predict_current(old, new)
        if pred is None:
            return
        start_a = fnum(sc.var_trk_start.get(), 200.0) / 1e3
        if pred < start_a:
            pred, how = start_a, "시작 전류 대기"
        k = sc.conv_factor() or 1.0
        direction = 1 if new > old else -1
        why = "SG %+.2g dB → 예상 %.0f mA (%s)" % (new - old, pred * 1e3, how)
        sc.worker.tasks.put(("trk_hint", pred / k, direction, why))

    # ------------------------------------------------ 자동 측정: 튀는 값 판단
    def find_row(self, hz, sg):
        fk = round(hz / 1e9, 6) if hz else None
        smp = (self.var_sample.get() or "").strip()
        for r in self.rows:
            if r.get("sg") is not None and abs(r["sg"] - sg) < 0.006 and (r.get("freq") and fk) \
                    and abs(r["freq"] - fk) < 1e-6 and r.get("sample", "") == smp:
                return r
        return None

    def on_sample_change(self):
        """샘플이 바뀌면 전류 기억 새로 시작, 그래프의 '측정 중' 데이터셋도 바뀜."""
        self.cur_mem = {}
        self.cur_fresh_ref = None
        self.s["sample"] = self.var_sample.get()

    def check_anomaly(self, row, sw):
        """방금 기록한 점이 이상하면 이유 문자열, 정상이면 "" (직전 두 점 기준)."""
        if row is None:
            return "기록 실패"
        if row.get("id") is None:
            return "전류 못 읽음"
        i = sw["i"]
        if i == 0:
            return ""
        hz = self.smw["f"]
        p1 = self.find_row(hz, sw["levels"][i - 1])
        p2 = self.find_row(hz, sw["levels"][i - 2]) if i >= 2 else None
        tol_id = max(1.0, fnum(self.var_tol_id.get(), 15.0)) / 100.0
        tol_pae = max(0.5, fnum(self.var_tol_pae.get(), 5.0))
        if p1 is not None and p1.get("id") is not None:
            if row["id"] < p1["id"] * 0.95:
                return "전류 감소 (%.0f → %.0f mA)" % (p1["id"], row["id"])
            if p2 is not None and p2.get("id") is not None:
                exp = p1["id"] + (p1["id"] - p2["id"])
                if exp > 0 and abs(row["id"] - exp) > tol_id * exp:
                    return "전류 튐 (예상 %.0f, 측정 %.0f mA)" % (exp, row["id"])
        if row.get("pae") is not None and p1 is not None and p1.get("pae") is not None:
            if p2 is not None and p2.get("pae") is not None:
                exp = 2 * p1["pae"] - p2["pae"]
                if abs(row["pae"] - exp) > tol_pae:
                    return "PAE 튐 (예상 %.1f, 측정 %.1f %%)" % (exp, row["pae"])
            elif row["pae"] < p1["pae"] - tol_pae:
                return "PAE 감소 (%.1f → %.1f %%)" % (p1["pae"], row["pae"])
        return ""

    # ------------------------------------------------ 천천히 내리기
    # ------------------------------------------------ SG RF 출력
    def set_rf(self, on, level=None, why=""):
        """RF ON/OFF. level 을 주면 먼저 그 레벨로 맞춘 뒤 켬 (같은 작업 순서로 보내 순서 보장)."""
        if not self.smw["conn"]:
            self.status("SG 가 연결되지 않았습니다.", "#ff6b6b")
            return False

        def job(w, on=on, level=level):
            if on and level is not None:
                w.inst.write("SOUR1:POW %.2f" % level)
            w.inst.write("OUTP1:STAT %s" % ("ON" if on else "OFF"))
            smw_poll(w)                    # 바로 다시 읽어서 화면 갱신
        self.smw_w.tasks.put(("call", job))
        if on and level is not None:
            self.p_change_t = time.time()
        self.rf_cmd = (on, time.time())
        self.status(why + "SG RF %s%s" % ("ON" if on else "OFF",
                                          (" (SG %.2f dBm)" % level) if (on and level is not None) else ""),
                    "#39ff88" if on else "#d4a017")
        return True

    def toggle_rf(self):
        if not self.smw["conn"]:
            messagebox.showwarning(APP_NAME, "SG(SMW200A)를 먼저 연결하세요.")
            return
        if self.smw["rf"]:
            if self.sweep:
                if not messagebox.askyesno(APP_NAME, "자동 측정 중입니다. 측정을 중지하고 RF 를 끌까요?"):
                    return
                self.stop_sweep("RF OFF", ramp=False)
            if self.ramp:
                self.stop_ramp("RF OFF")
            self.set_rf(False)
            return
        p = self.smw.get("p")
        lvl = fnum(self.var_lvl2.get())
        msg = "SG RF 를 켭니다.\n\n현재 SG 레벨: %s dBm" % ("%.2f" % p if p is not None else "?")
        if lvl is not None and p is not None and p > lvl + 0.01:
            # 높은 레벨에서 갑자기 켜지지 않게: SG 레벨 칸 값으로 먼저 낮춰서 켜는 것을 기본으로
            ans = messagebox.askyesnocancel(
                APP_NAME, msg + "  (SG 레벨 칸 %.2f dBm 보다 높음)\n\n"
                                "[예] SG 레벨 %.2f dBm 으로 낮춘 뒤 켜기\n[아니요] 현재 레벨 그대로 켜기" % (lvl, lvl))
            if ans is None:
                return
            self.set_rf(True, level=lvl if ans else None)
            return
        self.set_rf(True)

    def update_rf_button(self):
        if not hasattr(self, "btn_rf"):
            return
        rf = bool(self.smw["rf"]) if self.smw["conn"] else None
        cmd = self.rf_cmd
        if cmd and (rf == cmd[0] or time.time() - cmd[1] > 5):
            self.rf_cmd = cmd = None
        if not self.smw["conn"]:
            self.btn_rf.configure(text="RF  (SG 연결 안 됨)", bg="#d9d9d9", fg="#777", activebackground="#d9d9d9")
            self.lbl_rf.configure(text="")
        elif cmd:
            self.btn_rf.configure(text="RF %s 보내는 중..." % ("ON" if cmd[0] else "OFF"), bg="#d4a017", fg="white",
                                  activebackground="#d4a017")
        elif rf:
            self.btn_rf.configure(text="● RF ON   (누르면 OFF)", bg="#2e7d46", fg="white", activebackground="#3a9a58")
            self.lbl_rf.configure(text="SG %.2f dBm 출력 중" % self.smw["p"] if self.smw.get("p") is not None else "")
        else:
            self.btn_rf.configure(text="○ RF OFF   (누르면 ON)", bg="#5a5a5a", fg="white", activebackground="#6a6a6a")
            self.lbl_rf.configure(text="")

    def toggle_ramp(self):
        if self.ramp:
            self.stop_ramp("사용자가 중지함 (현재 레벨 유지)")
            return
        if self.sweep:
            messagebox.showinfo(APP_NAME, "자동 측정 중입니다. 먼저 자동 측정을 중지하세요 (중지하면 자동으로 천천히 내려감).")
            return
        target = fnum(self.var_lvl2.get())
        if target is None:
            messagebox.showwarning(APP_NAME, "SG 레벨(dBm) 칸에 내려갈 목표 레벨을 입력하세요.")
            return
        self.start_ramp(target, rf_off=self.var_rf_ramp_off.get())

    def start_ramp(self, target, from_level=None, why="", rf_off=None):
        if rf_off is None:
            rf_off = self.var_rf_ramp_off.get()
        if not self.smw["conn"]:
            self.status("SG 가 연결되지 않아 내릴 수 없습니다.", "#ff6b6b")
            return
        cur = from_level if from_level is not None else self.smw.get("p")
        if cur is None or not math.isfinite(cur):
            self.status("SG 현재 레벨을 아직 못 읽었습니다.", "#ff6b6b")
            return
        if cur <= target + 1e-9:
            self.status(why + "이미 SG %.2f dBm (목표 %.2f dBm 이하)" % (cur, target), "#39ff88")
            if rf_off and self.smw["rf"]:
                self.set_rf(False, why=why + "SG %.2f dBm · " % cur)
            return
        self.ramp = {"target": target, "level": cur, "next": time.time() + 0.05, "why": why, "rf_off": rf_off}
        self.btn_ramp.configure(text="■ 천천히 내리기 중지")
        self.status(why + "천천히 내리는 중: %.2f → %.2f dBm" % (cur, target), "#d4a017")

    def stop_ramp(self, reason, ok=False):
        r = self.ramp
        self.ramp = None
        self.btn_ramp.configure(text="▼▼ 천천히 내리기 (현재 → SG 레벨)")
        self.lbl_rec.configure(text="")
        self.status((r["why"] if r else "") + ("천천히 내리기 완료: " if ok else "천천히 내리기 중지: ") + reason,
                    "#39ff88" if ok else "#d4a017")

    def ramp_step(self):
        r = self.ramp
        if not r:
            return
        if not self.smw["conn"]:
            self.stop_ramp("SG 연결 끊김")
            return
        now = time.time()
        if now < r["next"]:
            self.lbl_rec.configure(text="천천히 내리는 중  SG %.2f dBm → %.2f dBm  (%s %.1f초)" % (
                r["level"], r["target"], "RF OFF 까지" if r.get("phase") == "rf_off" else "다음", r["next"] - now))
            return
        if r.get("phase") == "rf_off":
            self.set_rf(False)
            self.stop_ramp("SG %.2f dBm, RF OFF" % r["level"], ok=True)
            return
        step = abs(fnum(self.var_smw_step.get(), 1.0)) or 1.0
        new = max(round(r["level"] - step, 2), r["target"])
        self.smw_w.tasks.put(("call", lambda w, l=new: w.inst.write("SOUR1:POW %.2f" % l)))
        self.p_change_t = now
        r["level"] = new
        dt = max(0.2, fnum(self.var_ramp_dt.get(), 1.0))
        r["next"] = now + dt
        if new <= r["target"] + 1e-9:
            if r.get("rf_off"):
                r["phase"] = "rf_off"            # 마지막 레벨이 적용된 뒤(한 간격 후) RF OFF
                return
            self.stop_ramp("SG %.2f dBm" % new, ok=True)

    # ------------------------------------------------ 접기 / 펼치기 그룹
    def fold_group(self, parent, title, key):
        """제목 왼쪽 ▼/▶ 를 눌러 접고 펼치는 그룹. (바깥 틀, 내용 넣을 프레임) 반환."""
        lf = ttk.LabelFrame(parent, padding=(6, 2, 6, 6))
        lab = ttk.Label(lf, text="", cursor="hand2", font=("맑은 고딕", 9, "bold"), foreground="#1f3f66")
        lf.configure(labelwidget=lab)
        inner = ttk.Frame(lf)
        stub = ttk.Frame(lf, height=1)   # 접었을 때 틀이 제목 높이로 줄어들도록 하는 빈 자리
        state = {"open": bool(self.s.get("fold_" + key, True))}

        def apply():
            if state["open"]:
                stub.pack_forget()
                inner.pack(fill="both", expand=True)
                lab.configure(text=" ▼ %s " % title)
            else:
                inner.pack_forget()
                stub.pack(fill="x")
                lab.configure(text=" ▶ %s  (펼치기) " % title)

        def toggle(event=None):
            state["open"] = not state["open"]
            self.s["fold_" + key] = state["open"]
            apply()
            self.root.after(20, self.fit_ctrl_height)

        lab.bind("<Button-1>", toggle)
        self.__dict__.setdefault("folds", {})[key] = toggle
        apply()
        return lf, inner

    def fit_ctrl_height(self):
        """설정 영역 높이를 내용에 맞춰 경계선 이동 → 접으면 그만큼 기록 표가 커짐.
        (그 뒤에 경계선을 끌어 줄이면 각 그룹에 스크롤바가 생김)"""
        try:
            self.root.update_idletasks()
            h1, h2 = self.sf_g1.natural_h(), self.sf_g2.natural_h()
            hr = self.sf_right.natural_h()
            total = max(h1 + h2 + 6, hr)
            self.leftcol.sashpos(0, total + 4)
            self.root.update_idletasks()
            self.lpan.sashpos(0, h1 + (total - h1 - h2 - 6) // 2 if total > h1 + h2 + 6 else h1)
        except (tk.TclError, AttributeError):
            pass

    def sweep_step(self):
        sw = self.sweep
        if not sw:
            return
        now = time.time()
        if not self.smw["conn"] or not self.fsw["conn"]:
            self.stop_sweep("장비 연결 끊김")
            return
        if sw.get("phase") in ("ask", "ask_sat"):
            self.lbl_rec.configure(text="자동 측정 일시 정지 - 팝업에서 다음 동작 선택")
            dlg = getattr(self, "sweep_dialog", None)
            alive = False
            try:
                alive = dlg is not None and bool(dlg.winfo_exists())
            except tk.TclError:
                pass
            if not alive and now - sw.get("ask_t", 0) > 1.0:
                # 팝업이 안 떴거나 닫혀 버림 → 다시 띄움 (멈춘 채로 남지 않게)
                sw["ask_t"] = now
                if sw["phase"] == "ask":
                    self.ask_sweep_end(sw.get("ask_reason"), sw.get("ask_more", True))
                else:
                    self.ask_saturation(sw.get("sat_info", ""))
            elif alive:
                try:
                    dlg.lift()
                except tk.TclError:
                    pass
            return
        lvl = sw["levels"][sw["i"]]
        mx = fnum(self.var_smw_max.get(), 10.0)
        if sw["phase"] == "set":
            if lvl > max(mx, sw.get("over_ok", -999)) + 1e-9:
                if sw["i"] == 0:
                    self.stop_sweep("최대 허용 레벨 초과")
                    return
                # 측정 중에 최대 허용을 낮춤 → 여기까지를 끝으로 보고 팝업
                sw["levels"] = sw["levels"][:sw["i"]]
                sw["i"] = len(sw["levels"])
                self.enter_ask(sw, "최대 허용 %.2f dBm 도달" % mx, True)
                return
            self.smw_w.tasks.put(("call", lambda w, l=lvl: w.inst.write("SOUR1:POW %.2f" % l)))
            self.p_change_t = now
            sw.update(phase="wait", t=now, confirm=None, cur=lvl)
            return
        settle = max(0.0, fnum(self.var_settle.get(), 1.0))
        avg = max(0.2, fnum(self.var_avg.get(), 1.0))
        p = self.smw["p"]
        if sw["confirm"] is None:
            rf_ok = self.smw["rf"] or not sw.get("need_rf")
            if p is not None and math.isfinite(p) and abs(p - lvl) < 0.011 and self.smw["t"] > sw["t"] and rf_ok:
                sw["confirm"] = max(self.smw["t"], sw["t"])
            elif now - sw["t"] > 6:
                self.stop_sweep(("SG RF 가 켜지지 않음 (RF ON 확인 실패)" if not rf_ok else
                                 "SG 레벨 %.2f dBm 설정 확인 실패" % lvl), ramp=False if not rf_ok else None)
                return
            else:
                self.lbl_rec.configure(text="자동 측정 %d/%d  SG %.2f dBm 설정 중..." % (sw["i"] + 1, len(sw["levels"]), lvl))
                return
        ready = sw["confirm"] + settle + avg
        if now < ready:
            self.lbl_rec.configure(text="자동 측정 %d/%d  SG %.2f dBm  %s %.1f초" % (
                sw["i"] + 1, len(sw["levels"]), lvl, "안정화" if now < sw["confirm"] + settle else "평균 중", ready - now))
            return
        self.record(manual=True, t1=sw["confirm"] + settle, t2=now)
        row = self.find_row(self.smw["f"], lvl)
        bad = self.check_anomaly(row, sw) if self.var_sw_retry.get() else ""
        if bad:
            tries = sw.setdefault("retries", {})
            n = tries.get(sw["i"], 0)
            if n < 2:
                tries[sw["i"]] = n + 1
                if sw["i"] > 0:
                    sw["i"] -= 1          # 한 단계 아래 레벨로 돌아가서 그 점부터 다시
                    back = sw["levels"][sw["i"]]
                    self.status("SG %.2f dBm: %s → %.2f dBm 부터 다시 측정 (%d/2)" % (lvl, bad, back, n + 1), "#d4a017")
                else:
                    self.status("SG %.2f dBm: %s → 다시 측정 (%d/2)" % (lvl, bad, n + 1), "#d4a017")
                sw["phase"] = "set"
                sw["redo"] = sw.get("redo", 0) + 1
                return
            if row is not None:   # 두 번 다시 재도 이상 → 표에 빨간색 표시하고 진행
                row["flag"] = bad
                self.tree.item(str(row["no"]), tags=("check",))
                self.status("SG %.2f dBm: 재측정 후에도 %s → 빨간색 표시, 다음 점 진행" % (lvl, bad), "#ff6b6b")
        idmax = fnum(self.var_sw_idmax.get())
        last = self.rows[-1] if self.rows else None
        for r in self.rows:
            if r.get("sg") is not None and abs(r["sg"] - lvl) < 0.006 and abs((r.get("freq") or 0) - (self.smw["f"] or 0) / 1e9) < 1e-6:
                last = r
        if idmax and last and last.get("id") is not None and last["id"] > idmax:
            sw["levels"] = sw["levels"][:sw["i"] + 1]
            sw["i"] = len(sw["levels"])
            self.enter_ask(sw, "Id %.0f mA > 상한 %.0f mA" % (last["id"], idmax), False)
            return
        # FSW(SA) 값이 직전 점보다 거의 안 오름 → 포화 가능, 계속할지 물어봄
        if self.var_sat_on.get() and not sw.get("sat_off") and sw["i"] > 0 and row is not None:
            prev = self.find_row(self.smw["f"], sw["levels"][sw["i"] - 1])
            thr = fnum(self.var_sat_db.get(), 0.1)
            if (prev is not None and prev.get("sa") is not None and row.get("sa") is not None
                    and thr is not None and lvl > prev["sg"] + 1e-6 and row["sa"] - prev["sa"] <= thr + 1e-6):
                sw["phase"] = "ask_sat"
                sw["ask_t"] = now
                sw["sat_info"] = ("SG %.2f → %.2f dBm 올렸는데\nSA(FSW) %.2f → %.2f dBm  (+%.2f dB, 기준 ≤ %.2g dB)\n"
                                  "DUT Pout %s dBm · Gain %s dB · Id %s mA · PAE %s %%" % (
                                      prev["sg"], lvl, prev["sa"], row["sa"], row["sa"] - prev["sa"], thr,
                                      self.fmt(row.get("pout"), 2), self.fmt(row.get("gain"), 2),
                                      self.fmt(row.get("id"), 0), self.fmt(row.get("pae"), 1)))
                self.ask_saturation(sw["sat_info"])
                return
        sw["i"] += 1
        if sw["i"] >= len(sw["levels"]):
            self.enter_ask(sw, None, True)
            return
        sw["phase"] = "set"

    def enter_ask(self, sw, reason, more):
        sw.update(phase="ask", ask_reason=reason, ask_more=more, ask_t=time.time())
        self.ask_sweep_end(reason, more)

    def popup(self, title, text, buttons, default_esc=None):
        """자동 측정용 선택 팝업 (항상 맨 위, 가운데). buttons: [(글자, 함수), ...]"""
        old = getattr(self, "sweep_dialog", None)
        if old is not None:
            try:
                old.destroy()
            except tk.TclError:
                pass
        win = tk.Toplevel(self.root)
        win.title(title)
        win.transient(self.root)
        win.resizable(False, False)
        fr = ttk.Frame(win, padding=16)
        fr.pack(fill="both", expand=True)
        ttk.Label(fr, text=text, font=("맑은 고딕", 10), justify="left").pack(anchor="w")
        bf = ttk.Frame(fr)
        bf.pack(fill="x", pady=(14, 0))
        done = {"v": False}

        def run(fn):
            if done["v"]:
                return
            done["v"] = True
            try:
                win.destroy()
            except tk.TclError:
                pass
            if self.sweep_dialog is win:
                self.sweep_dialog = None
            fn()
        first = None
        for lab, fn in buttons:
            b = ttk.Button(bf, text=lab, command=lambda fn=fn: run(fn))
            b.pack(side="left", padx=4)
            first = first or b
        last_fn = buttons[-1][1]
        win.protocol("WM_DELETE_WINDOW", lambda: run(last_fn))
        if default_esc is not None:
            win.bind("<Escape>", lambda e: run(default_esc))
        win.update_idletasks()
        x = self.root.winfo_rootx() + (self.root.winfo_width() - win.winfo_reqwidth()) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - win.winfo_reqheight()) // 3
        win.geometry("+%d+%d" % (max(0, x), max(0, y)))
        try:   # 다른 창(전류 큰 화면 '항상 위' 등)에 가려지지 않게
            win.attributes("-topmost", True)
            win.lift()
            win.focus_force()
        except tk.TclError:
            pass
        try:
            win.grab_set()
        except tk.TclError:
            win.after(200, lambda: win.winfo_exists() and win.grab_set())
        if first is not None:
            first.focus_set()
        try:
            self.root.bell()
        except tk.TclError:
            pass
        self.sweep_dialog = win
        return win

    def ask_saturation(self, info):
        """SA 가 거의 안 오름 → 계속 / 계속(다시 묻지 않음) / 천천히 내리기 / 그대로 멈춤"""
        sw = self.sweep
        if not sw:
            return
        lvl = sw["levels"][sw["i"]]

        def go(no_more=False):
            if self.sweep is not sw:
                return
            if no_more:
                sw["sat_off"] = True
            sw["i"] += 1
            if sw["i"] >= len(sw["levels"]):
                self.enter_ask(sw, None, True)
            else:
                sw["phase"] = "set"
                self.status("SA 포화 확인 → 계속 측정", "#d4a017")

        def down():
            if self.sweep is sw:
                self.stop_sweep("SA 포화 (SG %.2f dBm) → 천천히 내림" % lvl, ok=True, ramp=True)

        def keep():
            if self.sweep is sw:
                self.stop_sweep("SA 포화 (SG %.2f dBm) · 레벨 유지" % lvl, ok=True, ramp=False)

        self.popup("SA 증가 작음 (포화?)",
                   "※ FSW 값이 직전 점보다 거의 오르지 않았습니다.\n\n%s\n\n계속 올릴까요?" % info,
                   [("▲ 계속 진행", go), ("▲ 계속 (다시 묻지 않음)", lambda: go(True)),
                    ("▼▼ 천천히 내리기 (→ %.2f dBm)" % sw["start"], down), ("멈추고 그대로 두기", keep)],
                   default_esc=down)

    def finish_sweep_msg(self):
        sw = self.sweep
        if True:
            msg = "%d점 기록" % len(sw["levels"])
            if sw.get("redo"):
                msg += " (재측정 %d번)" % sw["redo"]
            nflag = sum(1 for r in self.rows if r.get("flag"))
            if nflag:
                msg += ", 확인 필요 %d점(빨간색)" % nflag
            return msg

    def ask_sweep_end(self, reason=None, more=True):
        """최대 허용 레벨까지 끝남(또는 Id 상한) → 한 칸 더 올리기 / 천천히 내리기 / 그대로 두기 선택."""
        sw = self.sweep
        if not sw:
            return
        last = sw["levels"][-1]
        step = fnum(self.var_smw_step.get(), 1.0) or 1.0
        nxt = round(last + step, 2)
        msg = self.finish_sweep_msg()
        r = self.find_row(self.smw["f"], last)
        info = ""
        if r is not None:
            info = "\n마지막 점: DUT Pout %s dBm · Gain %s dB · Id %s mA · PAE %s %%" % (
                self.fmt(r.get("pout"), 2), self.fmt(r.get("gain"), 2), self.fmt(r.get("id"), 0), self.fmt(r.get("pae"), 1))
        head = ("SG %.2f dBm 에서 멈춤: %s" % (last, reason)) if reason else ("SG %.2f dBm 까지 자동 측정 완료" % last)

        def up():
            if self.sweep is not sw:
                return
            sw["levels"].append(nxt)
            sw["over_ok"] = max(sw.get("over_ok", -999), nxt)   # 최대 허용을 넘는 한 칸 (사용자 선택)
            sw["phase"] = "set"
            self.status("한 칸 더: SG %.2f dBm" % nxt, "#d4a017")

        def down():
            if self.sweep is sw:
                self.stop_sweep(msg, ok=True, ramp=True)

        def keep():
            if self.sweep is sw:
                self.stop_sweep(msg + " · 레벨 유지", ok=True, ramp=False)

        buttons = ([("▲ 한 칸 더 올리기 (→ %.2f dBm)" % nxt, up)] if more else []) + [
            ("▼▼ 천천히 내리기 (→ %.2f dBm)" % sw["start"], down), ("그대로 두기", keep)]
        self.popup("자동 측정 완료", "%s (%s)%s\n\n다음 동작을 고르세요." % (head, msg, info), buttons, default_esc=down)

    def window_avg(self, samples, t1, t2, db=False):
        vals = [v for (t, v) in samples if t1 <= t <= t2 and math.isfinite(v)]
        if not vals:
            return None, 0
        if db:  # dBm → 선형 평균
            lin = sum(10 ** (v / 10.0) for v in vals) / len(vals)
            return 10 * math.log10(lin), len(vals)
        return sum(vals) / len(vals), len(vals)

    def record(self, manual=False, t1=None, t2=None):
        now = time.time()
        avg_s = max(0.0, fnum(self.var_avg.get(), 1.0))
        if t2 is None:
            t2 = now
        if t1 is None:
            t1 = t2 - max(avg_s, 0.3)
        pin_raw = self.smw["p"]
        freq = self.smw["f"]
        pout_raw, nf = self.window_avg(self.fsw_samples, t1, t2, db=True)
        if pout_raw is None and self.fsw["y"] is not None and math.isfinite(self.fsw["y"]):
            pout_raw = self.fsw["y"]
        cur, nc = self.window_avg(self.cur_samples, t1, t2)
        if cur is None:
            # 평균 구간에 새 파형이 없으면, 1초 안에 들어온 새 파형 값만 사용 (오래된 값은 쓰지 않음)
            t, a = self.cur_last
            if now - self.cur_fresh_t < 1.0 and abs(t - self.cur_fresh_t) < 1e-6 and math.isfinite(a) \
                    and self.cur_fresh_t >= self.p_change_t:
                cur = a
        if pout_raw is not None and math.isfinite(pout_raw) and self.var_saq.get():
            pout_raw = round_sa(pout_raw)
        c = self.dut_calc(pin_raw, pout_raw, cur, freq)
        row = {
            "no": len(self.rows) + 1,
            "time": datetime.datetime.now().strftime("%H:%M:%S"),
            "freq": freq / 1e9 if freq else None,
            "sg": pin_raw if (pin_raw is not None and math.isfinite(pin_raw)) else None,
            "sa": pout_raw,
            "id": cur * 1e3 if cur is not None else None,
            "sample": (self.var_sample.get() or "").strip(),
        }
        row.update(c)
        if nc > 0 and row["sg"] is not None and self.mem_key(freq) == self.mem_freq:
            self.cur_mem[round(row["sg"], 2)] = cur
        pin, pout = c["pin"], c["pout"]
        replaced = None
        if row["sg"] is not None:
            key = (row["sample"], round(row["freq"] or 0, 6), round(row["sg"], 2))
            for i, r in enumerate(self.rows):
                if r.get("sg") is not None and \
                        (r.get("sample", ""), round(r["freq"] or 0, 6), round(r["sg"], 2)) == key:
                    replaced = i
                    break
        if replaced is not None:
            row["no"] = self.rows[replaced]["no"]
            self.rows[replaced] = row
            self.tree.item(str(row["no"]), values=self.row_values(row), tags=())
        else:
            self.rows.append(row)
            self.tree.insert("", "end", iid=str(row["no"]), values=self.row_values(row))
        self.tree.see(str(row["no"]))
        self.tree.selection_set(str(row["no"]))
        self.refresh_plots()
        miss = []
        if pin is None:
            miss.append("SMW")
        if pout is None:
            miss.append("FSW")
        if cur is None:
            miss.append("전류(새 파형 없음 - 트리거 확인)")
        if fnum(self.var_vdd.get()) is None:
            miss.append("Vdd 미입력 → PAE")
        msg = "%s #%d  DUT Pin %s dBm" % ("덮어씀" if replaced is not None else "기록", row["no"], self.fmt(pin, 2))
        if cur is not None and row["pae"] is None and fnum(self.var_vdd.get()) is not None:
            msg += "  · Id < %s mA → PAE 제외" % self.var_minid.get()
        if miss:
            msg += "  (값 없음: %s)" % ", ".join(miss)
        self.status(msg, "#d4a017" if miss else "#39ff88")

    @staticmethod
    def fmt(v, d):
        return "" if v is None else ("%.*f" % (d, v))

    def row_values(self, r):
        f = self.fmt
        return (r["no"], r.get("sample", ""), r["time"], f(r["freq"], 4), f(r["sg"], 2), f(r["sa"], 1 if self.var_saq.get() else 2),
                f(r["inl"], 2), f(r["outl"], 2), f(r.get("lossf"), 4),
                f(r["pin"], 2), f(r["pout"], 2), f(r["gain"], 2), f(r["id"], 1), f(r["pdc"], 3),
                f(r["de"], 2), f(r["pae"], 2))

    def selected_rows(self):
        """기록 표에서 선택한 행 (Ctrl/Shift 다중 선택), 선택이 없으면 전체."""
        sel = set(self.tree.selection())
        rows = [r for r in self.rows if str(r["no"]) in sel]
        return (rows, True) if rows else (list(self.rows), False)

    def table_text(self, rows=None):
        lines = ["\t".join(c[1] for c in self.COLS)]
        for r in (self.rows if rows is None else rows):
            lines.append("\t".join(str(x) for x in self.row_values(r)))
        return "\n".join(lines)

    def pa_payload(self, rows):
        """RF PA Analyzer 의 Datasets 복사 형식 (Ctrl+V 하면 이름·FREQ 그대로 바로 그래프)"""
        return {"version": 1, "datasets": [
            {"name": name, "display": disp, "rows": cells, "freq_override_hz": None,
             "user_mapping": False, "header_row": None, "mapping": None, "style": {}}
            for _k, name, disp, cells in self.pa_datasets(rows)]}

    def copy_rows(self):
        """선택한 행(없으면 전체) 복사 → 엑셀에 Ctrl+V = 표, RF PA Analyzer 에 Ctrl+V = 바로 그래프."""
        rows, part = self.selected_rows()
        if not rows:
            self.status("기록된 행이 없습니다.", "#d4a017")
            return
        text = self.table_text(rows)
        payload = self.pa_payload(rows)
        ok = False
        if os.name == "nt" and payload["datasets"]:
            try:
                data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                ok = win_clipboard_set(text, {PA_MIME: data,
                                              'application/x-qt-windows-mime;value="%s"' % PA_MIME: data},
                                       hwnd=self.root.winfo_id())
            except Exception:
                ok = False
        if not ok:
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
        what = "%s%d행" % ("선택 " if part else "전체 ", len(rows))
        if ok:
            self.status("%s 복사됨 - 엑셀: 표 / PA Analyzer: Ctrl+V 하면 Dataset %d개 바로 그래프"
                        % (what, len(payload["datasets"])), "#39ff88")
        else:
            self.status("%s 복사됨 - 엑셀에서 Ctrl+V" % what, "#39ff88")

    def save_pam(self):
        """선택한 행(없으면 전체)을 RF PA Analyzer 프로젝트(.pam)로 저장 → Analyzer 에서 열면 바로 그래프."""
        rows, part = self.selected_rows()
        sets = self.pa_datasets(rows)
        if not sets:
            self.status("저장할 기록이 없습니다.", "#d4a017")
            return
        path = filedialog.asksaveasfilename(
            title="PA Analyzer 프로젝트로 저장 (.pam)", defaultextension=".pam",
            initialdir=self.s.get("pam_dir") or self.s.get("save_dir") or None,
            initialfile="PA_bench_%s.pam" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S"),
            filetypes=[("PA Analyzer 프로젝트", "*.pam"), ("모든 파일", "*.*")])
        if not path:
            return
        now = datetime.datetime.now().isoformat(timespec="seconds")
        used, sheets = set(), []
        for _k, name, disp, cells in sets:
            nm, i = name, 2
            while nm in used:                 # Analyzer 는 내부 이름이 겹치면 안 됨
                nm, i = "%s (%d)" % (name, i), i + 1
            used.add(nm)
            sheets.append({"name": nm, "display": disp, "rows": cells, "freq_override_hz": None,
                           "user_mapping": False, "header_row": None, "mapping": None,
                           "added_at": now, "added_how": "PA Bench Monitor %s" % VERSION, "modified_at": None})
        names = [sh["name"] for sh in sheets]
        doc = {"format": "PA-Measurement-Analyzer project", "version": 1, "saved": now, "source_file": "",
               "sheets": sheets, "settings": {"checked": names, "sheet": names[-1]}}
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(doc, f, ensure_ascii=False)
        except OSError as e:
            messagebox.showerror(APP_NAME, "저장 실패:\n%s" % e)
            return
        self.s["pam_dir"] = os.path.dirname(path)
        self.status("PA Analyzer 프로젝트 저장: %s (Dataset %d개, %s%d행)" % (
            os.path.basename(path), len(sheets), "선택 " if part else "", len(rows)), "#39ff88")

    def export_excel(self):
        if not self.rows:
            self.status("기록된 행이 없습니다.", "#d4a017")
            return
        try:
            import excel_export
        except ImportError:
            messagebox.showerror(APP_NAME, "엑셀 내보내기에 openpyxl 이 필요합니다.\n"
                                           "명령 프롬프트에서:  python -m pip install openpyxl\n"
                                           "(build_exe.bat 로 만든 exe 에는 포함되어 있음)")
            return
        name = "PA_bench_%s.xlsx" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = filedialog.asksaveasfilename(title="엑셀 내보내기", defaultextension=".xlsx", initialfile=name,
                                            initialdir=self.s.get("xlsx_dir") or None,
                                            filetypes=[("Excel", "*.xlsx")])
        if not path:
            return
        try:
            excel_export.export_xlsx(path, self.COLS, self.rows, self.row_values, self.ds_key, self.ds_label,
                                     self.ds_color, self.plot_axes(), vdd=fnum(self.var_vdd.get()),
                                     ds_shape=self.ds_shape)
        except PermissionError:
            messagebox.showerror(APP_NAME, "저장 실패: 같은 이름의 파일이 엑셀에서 열려 있으면 닫고 다시 시도하세요.")
            return
        except Exception as e:
            messagebox.showerror(APP_NAME, "엑셀 저장 실패\n%s" % e)
            return
        self.s["xlsx_dir"] = os.path.dirname(path)
        self.status("엑셀 저장됨: " + path, "#39ff88")

    def save_csv(self):
        if not self.rows:
            return
        name = "PA_bench_%s.csv" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=name,
                                            filetypes=[("CSV", "*.csv")])
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow([c[1] for c in self.COLS])
            for r in self.rows:
                w.writerow(self.row_values(r))
        self.status("저장됨: " + path, "#39ff88")

    def recalc_rows(self):
        """기록된 SG·SA·Id 원본값으로 DUT Pin/Pout/Gain/PAE 를 현재 Vdd·손실로 다시 계산."""
        for r in self.rows:
            amps = r["id"] / 1e3 if r.get("id") is not None else None
            hz = r["freq"] * 1e9 if r.get("freq") is not None else None
            r.update(self.dut_calc(r.get("sg"), r.get("sa"), amps, hz))
        self.renumber()
        self.status("%d행 다시 계산됨 (Vdd %s V)" % (len(self.rows), self.var_vdd.get() or "미입력"), "#39ff88")

    def delete_selected(self):
        sel = set(self.tree.selection())
        if not sel:
            return
        self.rows = [r for r in self.rows if str(r["no"]) not in sel]
        self.renumber()

    def clear_rows(self):
        if self.rows and messagebox.askyesno(APP_NAME, "기록을 모두 지울까요?"):
            self.rows = []
            self.fcolor_cache.clear()
            self.analyzer.reset()
            self.renumber()
            self.reset_memory()

    def renumber(self):
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(self.rows, 1):
            r["no"] = i
            self.tree.insert("", "end", iid=str(i), values=self.row_values(r),
                             tags=("check",) if r.get("flag") else ())
        self.refresh_plots()

    def status(self, text, color=FG_DIM):
        self.lbl_status.configure(text=text, fg=color)

    # ------------------------------------------------ 주기 처리
    def tick(self):
        # 어떤 단계에서 오류가 나도 다음 주기는 반드시 돌도록 (장비 읽기·자동 측정·천천히 내리기가 멈추지 않게)
        try:
            for step in (self.drain_queue, self.update_dashboard, self.auto_record_step,
                         self.sweep_step, self.ramp_step):
                try:
                    step()
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    self.status("내부 오류 (%s): %s" % (step.__name__, e), "#ff6b6b")
        finally:
            self.root.after(100, self.tick)

    def drain_queue(self):
        try:
            while True:
                msg = self.q.get_nowait()
                self.handle(msg)
        except queue.Empty:
            pass

    def handle(self, msg):
        name, kind = msg[0], msg[1]
        now = time.time()
        if name == "smw":
            if kind == "val":
                _, _, f, p, rf = msg
                old = self.smw.get("p")
                if old is None or not math.isfinite(old) or (math.isfinite(p) and abs(p - old) > 0.004):
                    self.p_change_t = now
                    if old is not None and math.isfinite(old) and math.isfinite(p):
                        self.on_sg_change(old, p, f)
                self.smw.update(f=f, p=p, rf=rf, t=now)
                self.lbl_smw_read.configure(text="현재: %s · %s dBm · RF %s" % (
                    fmt_freq(f), self.fmt(p, 2) if math.isfinite(p) else "---", "ON" if rf else "OFF"))
            elif kind == "connected":
                self.smw["conn"] = True
                self.btn_smw.configure(text="연결 해제")
                self.lbl_smw_idn.configure(text=msg[2], foreground="#1f4f8f")
                self.status("SMW200A 연결됨", "#39ff88")
            elif kind == "disconnected":
                self.smw.update(conn=False, p=None)
                self.btn_smw.configure(text="연결")
            elif kind == "error":
                self.status("SMW: " + msg[2], "#ff6b6b")
            elif kind == "status":
                self.status("SMW: " + msg[2])
        elif name == "fsw":
            if kind == "val":
                y = msg[2]
                self.fsw.update(y=y, t=now)
                if math.isfinite(y):
                    self.fsw_samples.append((now, y))
            elif kind == "cfg":
                _, _, cent, span, n, on, mx = msg
                self.fsw.update(mx=mx, cent=cent, span=span, mon=on)
                first = not self.fsw.get("filled_once")
                self.lbl_fsw_read.configure(text="장비 현재: Center %s · Span %s · M%d %s" % (
                    fmt_freq(cent), fmt_freq(span), n, fmt_freq(mx) if on else "꺼짐"))
                if first:
                    self.fill_fsw_fields()
                    self.fsw["filled_once"] = True
            elif kind == "fill_fields":
                self.fill_fsw_fields()
            elif kind == "filled":
                self.fill_fsw_fields()
                self.status("FSW 설정 적용됨", "#39ff88")
            elif kind == "connected":
                self.fsw["conn"] = True
                self.fsw["filled_once"] = False
                self.btn_fsw.configure(text="연결 해제")
                self.lbl_fsw_idn.configure(text=msg[2], foreground="#1f4f8f")
                self.status("FSW 연결됨 - 장비 설정값을 불러왔습니다", "#39ff88")
            elif kind == "disconnected":
                self.fsw.update(conn=False, y=None)
                self.btn_fsw.configure(text="연결")
            elif kind == "error":
                self.status("FSW: " + msg[2], "#ff6b6b")
            elif kind == "status":
                self.status("FSW: " + msg[2])

    def fill_fsw_fields(self):
        cent, span, mx = self.fsw.get("cent"), self.fsw.get("span"), self.fsw.get("mx")
        if cent is not None and math.isfinite(cent):
            self.var_fsw_cent.set("%.6g" % (cent / 1e9))
        if span is not None and math.isfinite(span):
            self.var_fsw_span.set("%.6g" % (span / 1e6))
        if mx is not None and math.isfinite(mx):
            self.var_fsw_mx.set("%.6g" % (mx / 1e9))

    def update_dashboard(self):
        now = time.time()
        # SMW
        v, sub = self.big["smw"]
        p = self.smw["p"]
        if self.smw["conn"] and p is not None and math.isfinite(p):
            v.configure(text="%.2f dBm" % p, fg=C_SMW if self.smw["rf"] else FG_DIM)
            sub.configure(text="%s · RF %s" % (fmt_freq(self.smw["f"]), "ON" if self.smw["rf"] else "OFF"))
        else:
            v.configure(text="---", fg=FG_DIM)
            sub.configure(text="연결 안 됨" if not self.smw["conn"] else "")
        self.update_rf_button()
        # FSW
        v, sub = self.big["fsw"]
        y = self.fsw["y"]
        if self.fsw["conn"] and y is not None and math.isfinite(y):
            v.configure(text="%.2f dBm" % y, fg=C_FSW)
            sub.configure(text="M%s @ %s" % (self.var_fsw_mk.get(), fmt_freq(self.fsw["mx"])))
        else:
            v.configure(text="---", fg=FG_DIM)
            sub.configure(text="연결 안 됨" if not self.fsw["conn"] else "마커 꺼짐 / 값 없음")
        # 전류
        v, sub = self.big["cur"]
        t, a = self.cur_last
        if self.scope.running and math.isfinite(a) and now - t < 3:
            v.configure(text=self.scope.format_value(a), fg=C_CUR if not getattr(self.scope, "stale", False) else FG_DIM)
            sub.configure(text=self.scope.lbl_info.cget("text")[:40])
        else:
            v.configure(text="---", fg=FG_DIM)
            sub.configure(text="측정 정지" if self.scope.connected else "연결 안 됨")
        # DUT Gain / PAE (실시간, 케이블 손실 포함)
        v, sub = self.big["gain"]
        amps = a if (math.isfinite(a) and now - t < 3 and self.scope.running) else None
        if (p is not None and y is not None and math.isfinite(p) and math.isfinite(y)
                and self.smw["conn"] and self.fsw["conn"]):
            c = self.dut_calc(p, y, amps, self.smw["f"])
            v.configure(text="%.2f dB" % c["gain"], fg=C_GAIN)
            txt = "Pin %.2f · Pout %.2f dBm" % (c["pin"], c["pout"])
            if c["pae"] is not None:
                txt += " · PAE %.1f%%" % c["pae"]
            sub.configure(text=txt)
        else:
            v.configure(text="---", fg=FG_DIM)
            sub.configure(text="")
        # 케이블 손실 / Vdd 안내
        li, lo = self.losses_at(self.smw["f"])
        ix = self.loss_index(self.smw["f"])
        self.lbl_loss.configure(text="적용 중: In %.2f / Out %.2f dB%s" % (
            li, lo, (" (표 %.6g GHz 값)" % self.loss_table[ix][0]) if ix is not None else ""))
        if ix is not None:
            lt = "케이블 손실 (표 %.4g GHz)  In %.1f · Out %.1f dB" % (self.loss_table[ix][0], li, lo)
        else:
            lt = "케이블 손실 (고정값)  In %.1f · Out %.1f dB" % (li, lo)
        if self.smw.get("f"):
            lt = "SG %.4g GHz → " % (self.smw["f"] / 1e9) + lt
        self.lbl_lossbar.configure(text=lt)
        run = self.scope.running
        want = ("■ 전류 측정 중 (정지)", "#2e7d46", "#3a9656") if run else ("▶ 전류 측정 시작", "#7d6a26", "#93802f")
        if self.btn_cur.cget("text") != want[0]:
            self.btn_cur.configure(text=want[0], bg=want[1], activebackground=want[2])
        self.lbl_mem.configure(text="기억 %d점" % len(self.cur_mem) if self.cur_mem else "")
        self.update_loss_highlight()
        lk = (self.ds_live(), bool(self.scope.running or self.sweep))
        if lk != self._live_key:
            self._live_key = lk
            self.refresh_plots()
        self.lbl_vdd.configure(text="" if fnum(self.var_vdd.get()) else "← Vdd 를 입력해야 Pdc · DE · PAE 가 계산됩니다")
        if p is not None and math.isfinite(p) and not self.var_lvl2.get():
            self.var_lvl2.set("%.2f" % p)

    def auto_record_step(self):
        if not self.rec_on:
            return
        p = self.smw["p"]
        now = time.time()
        if p is None or not math.isfinite(p):
            self.lbl_rec.configure(text="SMW 값 대기 중...")
            return
        if self.last_pin is None:
            self.last_pin = p
        elif abs(p - self.last_pin) > 0.004:
            self.last_pin = p
            self.change_t = now
            self.pending = True
        if self.pending:
            settle = max(0.0, fnum(self.var_settle.get(), 1.0))
            avg = max(0.2, fnum(self.var_avg.get(), 1.0))
            left = self.change_t + settle + avg - now
            if left > 0:
                stage = "안정화" if now < self.change_t + settle else "평균 중"
                self.lbl_rec.configure(text="Pin %.2f dBm  %s... %.1f초" % (p, stage, left))
            else:
                self.record(t1=self.change_t + settle, t2=now)
                self.pending = False
                self.lbl_rec.configure(text="다음 파워 변경 대기 중 (Pin %.2f dBm 기록됨)" % p)

    # ------------------------------------------------ 종료
    def on_close(self):
        s = self.s
        s.update(
            smw_host=self.var_smw_host.get(), smw_port=int(fnum(self.var_smw_port.get(), 5025)),
            smw_gtl=self.var_smw_gtl.get(), smw_poll=int(fnum(self.var_smw_poll.get(), 300)),
            smw_step=self.var_smw_step.get(), smw_max=self.var_smw_max.get(),
            fsw_host=self.var_fsw_host.get(), fsw_port=int(fnum(self.var_fsw_port.get(), 5025)),
            fsw_gtl=self.var_fsw_gtl.get(), fsw_poll=int(fnum(self.var_fsw_poll.get(), 300)),
            fsw_marker=int(self.var_fsw_mk.get()),
            settle=self.var_settle.get(), avg=self.var_avg.get(), vdd=self.var_vdd.get(),
            loss_table=self.loss_table, in_loss=self.var_li.get(), out_loss=self.var_lo.get(),
            freq_ghz=self.var_freq.get(), min_id=self.var_minid.get(), sa_q=self.var_saq.get(),
            pae_ax=[v.get() for v in self.var_pae_ax], gain_ax=[v.get() for v in self.var_gain_ax],
            x_ax=[v.get() for v in self.var_x_ax], sw_return=self.var_sw_ret.get(), sw_idmax=self.var_sw_idmax.get(),
            ramp_dt=self.var_ramp_dt.get(), sw_retry=self.var_sw_retry.get(), sample=self.var_sample.get(),
            sat_on=self.var_sat_on.get(), sat_db=self.var_sat_db.get(),
            tol_id=self.var_tol_id.get(), tol_pae=self.var_tol_pae.get(),
            rf_ramp_off=self.var_rf_ramp_off.get(), rf_sweep_on=self.var_rf_sweep_on.get(),
            geometry=self.root.geometry(), tab=self.nb.index("current"))
        save_settings(s)
        if self.rows:
            # 실수로 닫아도 기록이 남도록 자동 백업
            try:
                d = os.path.join(os.path.dirname(settings_path()), "backup")
                os.makedirs(d, exist_ok=True)
                path = os.path.join(d, "PA_bench_%s.csv" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
                with open(path, "w", newline="", encoding="utf-8-sig") as f:
                    w = csv.writer(f)
                    w.writerow([c[1] for c in self.COLS])
                    for r in self.rows:
                        w.writerow(self.row_values(r))
            except Exception:
                pass
        for w in (self.smw_w, self.fsw_w):
            w.alive = False
            w.close()
        self.scope.shutdown()
        try:
            self.analyzer.close()
        except Exception:
            pass
        self.root.destroy()


def main():
    import sys
    if HAS_ANALYZER and "--analyzer-child" in sys.argv:          # PA Analyzer 그래프 창 (별도 프로세스, 같은 exe)
        import analyzer_child
        port = int(sys.argv[sys.argv.index("--analyzer-child") + 1])
        sys.exit(analyzer_child.main(port))
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    BenchApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
