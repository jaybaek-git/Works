@echo off
cd /d %~dp0
set PYTHONUTF8=1
echo ============================================
echo  PA Bench Monitor v1.1.0.8 - EXE build
echo  (RF PA Analyzer graph window included: PySide6 + matplotlib)
echo ============================================
python --version
if errorlevel 1 (
  echo [ERROR] Python not found. Install Python 3.9+ ^(check "Add to PATH"^).
  pause
  exit /b 1
)
python -m pip install --upgrade pyinstaller openpyxl "PySide6>=6.5" "matplotlib>=3.7" numpy
if errorlevel 1 (
  echo [ERROR] package install failed. Check proxy / pip settings.
  pause
  exit /b 1
)
set NAME=PA-Bench-Monitor_v1.1.0.8
python -m PyInstaller --noconfirm --clean --onedir --windowed --name "%NAME%" ^
  --paths pa_analyzer\src ^
  --hidden-import analyzer_child ^
  --hidden-import matplotlib.backends.backend_qtagg ^
  --collect-submodules app --collect-submodules core --collect-submodules excel ^
  --collect-submodules measurement --collect-submodules plotting --collect-submodules simulation ^
  --collect-submodules ui --collect-submodules utils --collect-submodules sparam ^
  --add-data "pa_analyzer\data\example;data\example" ^
  --add-data "pa_analyzer\assets;assets" ^
  --exclude-module PyQt5 --exclude-module PyQt6 --exclude-module pandas ^
  pa_bench_monitor.py
if errorlevel 1 (
  echo [ERROR] Build failed.
  pause
  exit /b 1
)
powershell -NoProfile -Command "Compress-Archive -Force -Path 'dist\%NAME%' -DestinationPath 'dist\%NAME%-win64.zip'"
echo.
echo  DONE:  dist\%NAME%\%NAME%.exe
echo         dist\%NAME%-win64.zip  (give this zip to other PCs - unzip, run the exe inside)
echo.
pause
