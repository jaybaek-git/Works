@echo off
cd /d %~dp0
echo ============================================
echo  PA Bench Monitor v2.0 - EXE build (standalone)
echo ============================================
python --version
if errorlevel 1 (
  echo [ERROR] Python not found. Install Python 3.9+ ^(check "Add to PATH"^).
  pause
  exit /b 1
)
python -m pip install --upgrade pyinstaller openpyxl pyvisa
if errorlevel 1 (
  echo [ERROR] pyinstaller install failed. Check proxy / pip settings.
  pause
  exit /b 1
)
python -m PyInstaller --noconfirm --clean --onefile --windowed --name "PA-Bench-Monitor_v2.0" --collect-submodules pyvisa --copy-metadata pyvisa --exclude-module PySide6 --exclude-module matplotlib --exclude-module numpy pa_bench_monitor.py
if errorlevel 1 (
  echo [ERROR] Build failed.
  pause
  exit /b 1
)
echo.
echo  DONE:  dist\PA-Bench-Monitor_v2.0.exe
echo  (GPIB power supplies need Keysight IO Libraries Suite or NI-VISA on the PC)
echo.
pause
