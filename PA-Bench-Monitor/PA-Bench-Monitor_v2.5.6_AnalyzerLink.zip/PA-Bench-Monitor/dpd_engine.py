# -*- coding: utf-8 -*-
"""PA DPD Tester - 측정 · DPD 반복 (화면 없이 동작, 화면은 콜백으로 결과를 받음)

순서: 신호 만들기 → [DPD OFF 측정] → 반복 { 받은 IQ 로 postdistorter 학습 (ILA) → 예왜곡 신호 보내기 → 측정 }
"""
import math
import time

import numpy as np

import bench_link as BL
import dpd_core as C
import instruments as I


class Stop(Exception):
    pass


DEFAULTS = dict(
    smw_host="demo", fsw_host="demo", file_max_msps=0.0, auto_model=True,
    model="gmp", method="ila", dvr_seg=8, torch_dir="", aclr_src="fsw", iq_avg=2, nn_hidden=24, nn_epochs=30, ilc_iters=15, ilc_gain=0.8,
    freq_ghz=3.6, sg_dbm=-10.0, sg_max_dbm=0.0, in_loss_db=0.5, out_loss_db=40.0, cal_db=0.0,
    fsw_ref_dbm="auto", fsw_att_db="auto",
    os=4, n_sym=28, mod="256QAM", cfr_on=True, papr_db=8.0,
    sig_src="nr", wv_path="", ch_bw_mhz=98.28, adj_mhz=100.0,
    rec=None, auto_cal=False,
    K=7, M=4, L=1, odd_only=False, lam=1e-6, iters=4, mu=0.7, peak_lim_db=3.0, n_fit=40000, target_aclr=None,
)


MODEL_NAMES = {"gmp": "GMP", "sgmp": "구간 GMP", "dvr": "DVR", "nn": "신경망", "pnn": "위상정규 신경망", "tnn": "torch 신경망"}


def migrate_method(p):
    """예전 설정 (method = ila / dla / nn) → 모델 (model) + 학습 방식 (method = ila / dla)"""
    if p.get("method") == "nn":
        p["model"], p["method"] = "nn", "ila"
    p.setdefault("model", "gmp")
    if p.get("method") not in ("ila", "dla"):
        p["method"] = "ila"
    return p


def is_nn(p):
    return p.get("model") in ("nn", "pnn", "tnn")


def method_label(p):
    m = p.get("model", "gmp")
    if is_nn(p):
        return MODEL_NAMES[m]
    return "%s-%s" % (MODEL_NAMES.get(m, m), "DLA" if p.get("method") == "dla" else "ILA")


class Engine:
    def __init__(self, p, log=None, on_result=None, on_progress=None, dc_reader=None):
        self.p = dict(DEFAULTS)
        self.p.update(p or {})
        migrate_method(self.p)
        self.log = log or (lambda s: None)
        self.on_result = on_result or (lambda r: None)
        self.on_progress = on_progress or (lambda s: None)
        self.dc_reader = dc_reader or (lambda: None)      # () → (Vdd V, Id A, 측정 시각, 출처) 또는 None
        self._cal_done = False
        self.stop = False
        self.smw = self.fsw = None
        self.sig = None
        self.model = None
        self.G = None
        self.results = []
        self.tag = None            # 방식 비교 때 결과에 붙일 방식 이름
        self.compare = []

    # ------------------------------------------------------------ 준비
    def check(self):
        if self.stop:
            raise Stop()

    def connect(self):
        if self.smw is None:
            self.log("장비 연결: SMW %s · FSW %s" % (self.p["smw_host"], self.p["fsw_host"]))
            self.smw, self.fsw = I.open_pair(self.p["smw_host"], self.p["fsw_host"])
            self.smw.log = self.fsw.log = self.log
            self.log("  SMW: %s" % self.smw.idn)
            self.log("  FSW: %s" % self.fsw.idn)

    def make_signal(self):
        p = self.p
        t0 = time.time()
        if p.get("sig_src") == "file":
            self.sig = C.FileSignal(p["wv_path"], max_fs=float(p.get("file_max_msps") or 0) * 1e6 or None)
            if self.sig.fs != self.sig.fs_file:
                self.log("신호 파일 %.2f MSps → %.2f MSps 로 줄여서 사용 (FSW 캡처 · 계산용, 잘린 대역 밖 성분 %.1f dB)"
                         % (self.sig.fs_file / 1e6, self.sig.fs / 1e6, self.sig.drop_db))
            self.log("신호: %s · %.2f MSps · %d 샘플 (%.3f ms) · PAPR %.2f dB - EVM 은 파형 비교"
                     % (p["wv_path"], self.sig.fs / 1e6, len(self.sig.x), len(self.sig.x) / self.sig.fs * 1e3, C.papr(self.sig.x)))
            if len(self.sig.x) > 2000000:
                self.log("  ⚠ 샘플이 많아 (%d) 한 번 측정에 시간이 걸립니다" % len(self.sig.x))
        else:
            self.sig = C.NRSignal(os=p["os"], n_sym=p["n_sym"], mod=p["mod"])
            pk0 = C.papr(self.sig.x)
            if p["cfr_on"]:
                pk = self.sig.cfr(p["papr_db"])
            else:
                pk = pk0
            self.log("신호: NR 100 MHz 1C · %s · %d 심볼 · %.2f MSps · %d 샘플 · PAPR %.2f → %.2f dB (%.1f초)"
                     % (p["mod"], p["n_sym"], self.sig.fs / 1e6, len(self.sig.x), pk0, pk, time.time() - t0))
        self.model = self.make_model()
        self.G = None
        return self.sig

    def make_model(self, K=None, M=None, L=None):
        p = self.p
        K = p["K"] if K is None else K
        M = p["M"] if M is None else M
        L = p["L"] if L is None else L
        mdl = p.get("model", "gmp")
        if mdl == "tnn":
            import dpd_torch
            ok, msg = dpd_torch.load(p.get("torch_dir") or None)
            if ok:
                m = dpd_torch.TorchNNModel(M, int(p.get("nn_hidden", 24)), int(p.get("nn_epochs", 30)))
            else:
                # torch 가 없으면 멈추지 않고 numpy 위상정규 신경망으로 대신 (같은 구조 · 작고 느림)
                if not getattr(self, "_torch_warned", False):
                    self.log("  ⚠ torch 를 못 읽음 (%s) → numpy 위상정규 신경망으로 대신 돌림" % msg)
                    self._torch_warned = True
                m = C.NNModel(M, int(p.get("nn_hidden", 24)), int(p.get("nn_epochs", 30)), pn=True)
                m.fallback = True
        elif is_nn(p):
            m = C.NNModel(M, int(p.get("nn_hidden", 24)), int(p.get("nn_epochs", 30)), pn=(mdl == "pnn"))
        elif mdl == "dvr":
            m = C.DVRModel(int(p.get("dvr_seg", 8)), M, p["lam"])
        elif mdl == "sgmp":
            m = C.SegGMPModel(K, M, L, p["odd_only"], p["lam"])
        else:
            m = C.DPDModel(K, M, L, p["odd_only"], p["lam"])
        m.w = None
        return m

    # ------------------------------------------------------------ 한 번 측정
    def measure(self, pd, label, it=0, nmse=None, step="", kind=None):
        p, sig, x = self.p, self.sig, self.sig.x
        t_meas = time.time()
        self.cur = dict(label=label, step=step, t=t_meas)
        et = self.eta_text()
        self.on_progress("%s측정 중 · %s%s" % ((et + " · ") if et else "", label, (" · " + step) if step else ""))
        lvl = p["sg_dbm"] + 20 * math.log10(C.rms(pd) / C.rms(x))      # 원래 신호와 같은 크기 비율로 (SMW 는 RMS 를 레벨에 맞춤)
        clipped = False
        if lvl > p["sg_max_dbm"]:
            self.log("  ⚠ SG 레벨 %.2f dBm > 최대 %.2f dBm → 최대로 제한" % (lvl, p["sg_max_dbm"]))
            lvl, clipped = p["sg_max_dbm"], True
        self.check()
        wv = C.write_wv(None, pd, sig.fs, comment="PA DPD Tester %s" % label)
        self.log("  %s: SG %.2f dBm 로 신호 보내는 중 (%.1f MB)…" % (label, lvl, len(wv) / 1e6))
        self.smw.load_wave(wv, p["freq_ghz"] * 1e9, lvl, rf_on=True)
        self.check()
        att = None if str(p["fsw_att_db"]).strip().lower() in ("auto", "") else float(p["fsw_att_db"])
        ref_auto = str(p.get("fsw_ref_dbm", "auto")).strip().lower() in ("auto", "")
        ref = self._next_ref(pd, lvl) if ref_auto else float(p["fsw_ref_dbm"])
        bw = self.fsw.setup(p["freq_ghz"] * 1e9, sig.fs, ref if ref == ref else 10.0, att)
        if ref_auto and ref != ref:
            # 처음 (이 실행 · 이 레벨에서 아직 모름): FSW 자동 레벨로 Ref Level · 감쇠를 신호에 맞춤 → ADC 를 꽉 채워 잡음 바닥 ↓
            al_ = self.fsw.auto_level()
            if al_:
                ref = al_[0]
                self.log("  FSW 자동 레벨: Ref %.1f dBm · 감쇠 %.0f dB" % al_)
            else:
                ref = 10.0
                self.log("  ⚠ FSW 자동 레벨 안 됨 → Ref 10 dBm 로 한 번 받아 보고 맞춤")
        k_avg = max(1, int(p.get("iq_avg", 2)))
        L = len(pd)
        n = k_avg * L + 2000 if k_avg * L <= 2400000 else max(2, 2400000 // L) * L + 2000 if L <= 1200000 else L + 20000
        y = None
        for attempt in range(2):
            time.sleep(0.2)
            t_cap = time.time()
            self.log("  FSW I/Q 받는 중: %d 샘플 · %.2f MSps (%.2f ms, %.1f MB) · Ref %.1f dBm…"
                     % (n, sig.fs / 1e6, n / sig.fs * 1e3, n * 8 / 1e6, ref))
            y = self.fsw.capture(n, L + 20000)
            if len(y) < n:
                self.log("    FSW 한 번에 %d 샘플만 받음 (한 주기 + 여유로 계산)" % len(y))
            self.check()
            pk = 10 * np.log10(max(float(np.max(np.abs(y)) ** 2) / (2 * 50.0), 1e-30) * 1e3)   # FSW 입력 최고 전력 dBm
            self._ref_mem = (pk, C.papr(pd), lvl)
            if not ref_auto or attempt == 1:
                if pk > ref - 0.2:
                    self.log("  ⚠ FSW 입력 최고값 %.1f dBm 이 Ref %.1f dBm 에 닿음 - 찌그러짐 (Ref ↑ 또는 auto)" % (pk, ref))
                break
            if pk > ref - 0.3 or pk < ref - 6.0:
                new = pk + (3.0 if pk > ref - 0.3 else 1.5)
                self.log("  FSW 입력 최고 %.1f dBm · Ref %.1f → %.1f dBm 로 맞춰 다시 받음" % (pk, ref, new))
                ref = new
                self.fsw.set_ref(ref)
                continue
            break
        # Vdd 전원 전류: 이 신호를 보낸 뒤에 읽은 값 (최대 1.5초 기다림)
        dc = None
        t_end = time.time() + 1.5
        while True:
            try:
                dc = self.dc_reader()
            except Exception:
                dc = None
            if dc is None or dc[2] >= t_cap or time.time() > t_end or self.stop:
                break
            time.sleep(0.1)
        y_al, g, d = C.align(pd, y)
        n_per = 1
        acc = y_al.copy()
        while len(y) >= (n_per + 1) * L + 1000 and n_per < k_avg:
            # 여러 주기를 받았으면 주기마다 맞춰 평균 → 측정 잡음 10·log(주기 수) dB 줄어듦 (ILC · DLA 의 바닥이 낮아짐)
            try:
                y2, _, _ = C.align(pd, y[n_per * L:])
                acc += y2 * np.exp(1j * np.angle(np.vdot(y2, y_al)))
                n_per += 1
            except Exception:
                break
        y_al = acc / n_per
        if self.G is None:
            self.G = C.small_signal_gain(x, y_al)
        else:
            # 측정마다 SMW · FSW 사이 위상이 달라짐 → 작은 신호 구간 위상을 처음 측정 (DPD OFF) 에 맞춤
            c = C.small_signal_gain(pd, y_al)
            y_al = y_al * np.exp(1j * (np.angle(self.G) - np.angle(c)))
        pout = C.iq_power_dbm(y_al, p["out_loss_db"] + p["cal_db"])
        rec = p.get("rec")
        rec_p = BL.pout_at_sg(rec, lvl) if rec else float("nan")
        if rec and p.get("auto_cal") and it == 0 and not self._cal_done and math.isfinite(rec_p):
            self._cal_done = True
            # Bench 기록 (같은 SG 레벨의 DUT Pout) 에 맞춰 Pout 보정값을 정함 → 이후 측정도 같은 보정
            d = rec_p - pout
            p["cal_db"] = p["cal_db"] + d
            pout = rec_p
            self.log("  Pout 보정 = %.2f dB (Bench 기록: SG %.2f dBm → DUT Pout %.2f dBm 에 맞춤)" % (p["cal_db"], lvl, rec_p))
        bwc, adj = p.get("ch_bw_mhz", 98.28) * 1e6, p.get("adj_mhz", 100.0) * 1e6
        al, au, full = C.aclr(y_al, sig.fs, bwc, adj)
        if bw == bw and bw > 0 and bw / 2 < adj + bwc / 2:
            full = False                           # FSW 분석 대역폭이 인접 채널 끝 (±149.14 MHz) 보다 좁음
        ev = C.evm_any(sig, y_al)
        f, sdb = C.spectrum_db(y_al, sig.fs)
        f = f / 1e6
        al_iq, au_iq, src_used = float(al), float(au), "iq"
        if p.get("aclr_src", "fsw") == "fsw" and not getattr(self, "_mod_fail", False):
            # ACLR 은 FSW Mod. 화면 (사용자가 맞춘 스펙트럼 ACLR 측정, 설정 그대로) 에서 → I/Q 잡음 바닥에 안 막힘
            try:
                self.check()
                m = self.fsw.mod_aclr(p["freq_ghz"] * 1e9)
                al, au, full, src_used = m["aclr_l"], m["aclr_u"], True, "fsw"
                if m.get("f"):
                    f, sdb = np.asarray(m["f"]), np.asarray(m["db"])
            except Stop:
                raise
            except Exception as ex:
                self._mod_fail = True
                self.log("  ⚠ FSW Mod. 화면 ACLR 못 읽음 → 이번 실행은 I/Q 계산 ACLR 로 (%s)" % ex)
                self.fsw.select_iq(sig.fs)
        xin, gam, pm = C.am_curves(x, y_al, self.G)
        pin = lvl - p["in_loss_db"]
        vdd = idd = pdc = de = pae = float("nan")
        src = ""
        if dc is None and isinstance(self.smw, I.DemoSMW):
            # 데모: 가상 전원 (Vdd 48 V, Doherty 비슷한 효율 곡선)
            po_w = 10 ** ((pout - 30) / 10)
            eff = 0.18 + 0.40 * min(1.0, (po_w / 8.0) ** 0.45)
            dc = (48.0, po_w / eff / 48.0 + 0.25, time.time(), "demo")
        if dc is not None and dc[0] is not None and dc[1] is not None:
            vdd, idd, _t, src = dc
            pdc = vdd * idd
            if pdc > 0:
                po_w = 10 ** ((pout - 30) / 10)
                de = 100 * po_w / pdc
                pae = 100 * (po_w - 10 ** ((pin - 30) / 10)) / pdc
        r = dict(label=label, it=it, sg=lvl, pin=pin, pout=pout, gain=pout - pin, aclr_l=float(al), aclr_u=float(au),
                 aclr_full=bool(full), evm=ev, rec_pout=rec_p, cal_db=p["cal_db"], ch_bw=bwc / 1e6, adj=adj / 1e6,
                 evm_kind="OFDM" if getattr(sig, "X", None) is not None else "파형", papr=C.papr(pd), nmse=nmse, delay=d, fsw_bw=bw, clipped=clipped,
                 spec_f=np.asarray(f).tolist(), spec_db=np.asarray(sdb).tolist(), aclr_src=src_used,
                 aclr_iq_l=al_iq, aclr_iq_u=au_iq, n_avg=n_per, fsw_ref=ref, am_x=xin.tolist(), am_g=gam.tolist(), am_p=pm.tolist(),
                 t=time.strftime("%H:%M:%S"), kind=kind or ("off" if it == 0 else "dpd"), step=step, base_sg=p["sg_dbm"],
                 vdd=vdd, id=idd, pdc=pdc, de=de, pae=pae, dc_src=src, method=self.tag)
        self.results.append(r)
        self._eta_tick(t_meas)
        self.log("  %s: Pout %.2f dBm · ACLR %.1f / %.1f dBc%s · EVM %.2f %% · PAPR %.2f dB%s%s"
                 % (label, pout, al, au, (" (Mod. 화면 · I/Q 계산 %.1f / %.1f)" % (al_iq, au_iq)) if src_used == "fsw" else "", ev, r["papr"], (" · DE %.1f %% (Id %.3f A)" % (de, idd)) if de == de else "", "" if full else "  (⚠ 샘플레이트 · FSW 대역폭이 모자라 인접 채널 일부만 - ACLR 이 실제보다 좋게 나올 수 있음)"))
        self.on_result(r)
        return y_al, r

    # ------------------------------------------------------------ DPD
    def dpd_signal(self, w):
        x = self.sig.x
        pd = self.model.apply(x, w)
        lim = np.max(np.abs(x)) * 10 ** (self.p["peak_lim_db"] / 20)
        a = np.abs(pd)
        n_clip = int(np.sum(a > lim))
        pd = np.where(a > lim, pd * lim / np.maximum(a, 1e-12), pd)
        return pd, n_clip

    # ------------------------------------------------------------ 남은 시간 (측정 횟수 × 한 번 걸리는 시간)
    def _next_ref(self, pd, lvl):
        """다음 측정의 FSW Ref Level: 앞 측정 최고값 + 레벨 변화 + PAPR 변화 + 1.5 dB 여유 (모르면 nan → 자동 레벨)"""
        m = getattr(self, "_ref_mem", None)
        if not m:
            return float("nan")
        pk, papr0, lvl0 = m
        return pk + (lvl - lvl0) + (C.papr(pd) - papr0) + 1.5

    def eta_reset(self, total):
        self._ref_mem = None              # 실행마다 처음엔 FSW 자동 레벨
        self._mod_fail = False
        self.eta = dict(total=int(total), done=0, per=None, t_last=None, lvl=None)

    def eta_level(self, planned):
        """한 레벨 시작: 이 레벨에서 할 측정 수 (계획). 앞 레벨이 일찍 끝났으면 그만큼 전체에서 뺌"""
        e = getattr(self, "eta", None)
        if e is None:
            return
        self.eta_level_end()
        e["lvl"] = (planned, e["done"])

    def eta_level_end(self):
        e = getattr(self, "eta", None)
        if e is None or e.get("lvl") is None:
            return
        planned, d0 = e["lvl"]
        used = e["done"] - d0
        e["total"] += used - planned                       # 목표 ACLR 에 일찍 닿음 · 반복이 더 됨 → 바로잡기
        e["lvl"] = None

    def eta_left(self):
        """남은 초 (지금 측정에서 이미 지난 시간을 빼서 1초씩 줄어듦) · None = 모름"""
        e = getattr(self, "eta", None)
        if not e:
            return None
        left = max(e["total"] - e["done"], 0)
        per = e["per"] or (5.0 if is_nn(self.p) else 4.0)
        since = time.time() - (e["t_last"] or getattr(self, "cur", {}).get("t", time.time()))
        return max(left * per - min(since, per * 0.95), 0.0)

    def eta_text(self):
        e = getattr(self, "eta", None)
        if not e:
            return ""
        left = max(e["total"] - e["done"], 0)
        per = e["per"] or (5.0 if is_nn(self.p) else 4.0)
        sec = left * per
        if left == 0:
            return "곧 끝"
        t = ("%d분 %02d초" % (sec // 60, sec % 60)) if sec >= 60 else "%d초" % max(sec, 1)
        return "남은 약 %s (%d/%d)" % (t, e["done"], e["total"])

    def _eta_tick(self, t_start):
        e = getattr(self, "eta", None)
        if e is None:
            return
        now = time.time()
        dt = now - (e["t_last"] if e["t_last"] is not None else t_start)   # 학습 · 계산 시간도 포함
        e["per"] = dt if e["per"] is None else 0.6 * e["per"] + 0.4 * dt
        e["t_last"] = now
        e["done"] += 1

    def auto_model(self, y_off, label_pre, step):
        """DPD 모델 (K · M · L) 자동: ① 계산으로 36 조합의 검증 NMSE → 후보 3개 ② 후보마다 실제로 한 번 DPD 측정
        → ACLR 가장 좋은 것. 반환 (y_al, pd, last, w) - 이어서 그 모델로 반복"""
        p = self.p
        x = self.sig.x
        t0 = time.time()
        self.log("▶ %sDPD 모델 자동 찾기 ① 계산 (K · M · L 조합)…" % label_pre)
        self.on_progress(self.eta_text() + " · DPD 모델 찾는 중 (계산)")
        # 메모리 깊이 · 교차 지연은 "샘플 수" → 샘플레이트가 491.52 MSps 의 몇 배인지만큼 후보도 늘림 (같은 시간을 보게)
        ratio = max(1, int(round(self.sig.fs / 491.52e6)))
        Ms = tuple(sorted({max(1, int(round(m * ratio))) for m in (2, 3, 4, 6)}))
        Ls = tuple(sorted({int(round(l * ratio)) for l in (0, 1, 2)})) if ratio <= 2 else (0, ratio, 2 * ratio)
        if ratio > 1:
            self.log("  샘플레이트 %.2f MSps (491.52 의 %d배) → M 후보 %s · L 후보 %s" % (self.sig.fs / 1e6, ratio, Ms, Ls))
        res = C.model_search(y_off / self.G, x, p["odd_only"], p["lam"], n_fit=min(int(p["n_fit"]), 30000),
                             Ms=Ms, Ls=Ls, cancelled=lambda: self.stop)
        self.check()
        cands = C.pick_models(res, 3)
        self.log("  %d 조합 %.1f초 · 후보: %s" % (len(res), time.time() - t0, " · ".join(
            "K%d M%d L%d (%.1f dB, %d 계수)" % (K, M, L, nm, nc) for nm, nc, K, M, L in cands)))
        best = None
        for i, (nm, nc, K, M, L) in enumerate(cands):
            self.check()
            name = "K%d M%d L%d" % (K, M, L)
            self.log("▶ %sDPD 모델 자동 찾기 ② 실측 %d/%d: %s" % (label_pre, i + 1, len(cands), name))
            self.model = self.make_model(K, M, L)
            w, nmse = self.model.fit(y_off / self.G, x, n_fit=p["n_fit"])
            self.model.w = w
            pd, _ = self.dpd_signal(w)
            y_al, last = self.measure(pd, "%s후보 %s" % (label_pre, name), 1, nmse, step)
            sc = max(last["aclr_l"], last["aclr_u"])
            if best is None or sc < best[0]:
                best = (sc, (K, M, L), y_al, pd, last, w)
        sc, (K, M, L), y_al, pd, last, w = best
        self.model = self.make_model(K, M, L)
        self.model.w = w
        p["K"], p["M"], p["L"] = K, M, L
        self.chosen = (K, M, L)
        self.log("  ✔ 고른 모델: K%d M%d L%d (ACLR %.1f dBc) → 이 모델로 반복" % (K, M, L, sc))
        return y_al, pd, last, w

    def _dpd_level(self, y_al, w, label_pre, step, target=None, start=None):
        """한 SG 레벨에서 DPD 반복 (w = 시작 계수, 앞 레벨 것) → (마지막 결과, 계수)
        start = (pd, last): 이미 그 계수로 측정한 결과 (자동 모델 찾기 뒤) → 첫 반복을 이어서"""
        x = self.sig.x
        pd = x
        last = None
        n = int(self.p["iters"])
        if start is not None:
            pd, last = start
            n = max(n - 1, 1)
            if target is not None and max(last["aclr_l"], last["aclr_u"]) <= target:
                self.log("  목표 ACLR %.1f dBc 이내 → 반복 끝" % target)
                return last, w, pd
        for it in range(1, n + 1):
            self.check()
            self.log("▶ %sDPD 반복 %d / %d" % (label_pre, it, n))
            if w is not None and it == 1 and last is None:
                # 앞 레벨 계수로 먼저 한 번 보내 보고 (학습 없이) 그 결과로 이어서 학습 → 반복이 줄어듦
                pd, _ = self.dpd_signal(w)
                self.model.w = w
                y_al, last = self.measure(pd, "%sDPD 0 (이전 계수)" % label_pre, it, None, step)
                if target is not None and max(last["aclr_l"], last["aclr_u"]) <= target:
                    self.log("  목표 ACLR %.1f dBc 이내 → 다음 레벨" % target)
                    return last, w, pd
            meth = self.p.get("method", "ila")
            mu = float(self.p["mu"])
            if is_nn(self.p):
                # 신경망: 이전 가중치에서 이어서 학습 (ILA 방식, 섞지 않음)
                self.on_progress("%s · 신경망 학습 중 · %d 번째" % (self.eta_text(), it))
                t0 = time.time()
                w, nmse = self.model.fit(y_al / self.G, pd, n_fit=self.p["n_fit"], init=w, cancelled=lambda: self.stop)
                self.check()
                self.log("  신경망 학습 %.1f초 (가중치 %d 개)" % (time.time() - t0, self.model.n_coef()))
            elif meth == "dla" and w is not None:
                # 직접 학습: PA 출력 오차 (원래 신호 - 출력/G) 를 원래 신호 basis 로 맞춰 계수에 더함
                e = x - y_al / self.G
                dw, _ = self.model.fit(x, e, n_fit=self.p["n_fit"])
                w = w + mu * dw
                nmse = 10 * np.log10(np.mean(np.abs(e) ** 2) / np.mean(np.abs(x) ** 2))
            else:
                wn, nmse = self.model.fit(y_al / self.G, pd, n_fit=self.p["n_fit"])
                w = wn if w is None else (1 - mu) * w + mu * wn
            self.model.w = w
            pd, n_clip = self.dpd_signal(w)
            if n_clip:
                self.log("  최고값 제한 (+%.1f dB) 에 걸린 샘플 %d 개" % (self.p["peak_lim_db"], n_clip))
            y_al, last = self.measure(pd, "%sDPD %d" % (label_pre, it), it, nmse, step)
            if target is not None and max(last["aclr_l"], last["aclr_u"]) <= target:
                self.log("  목표 ACLR %.1f dBc 이내 → 반복 끝" % target)
                break
        return last, w, pd

    def run(self, do_dpd=True):
        """DPD OFF 측정 → (do_dpd) DPD 반복. 결과 목록 반환"""
        self.stop = False
        self.results = []
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        x = self.sig.x
        self.G = None
        auto = self.p.get("auto_model") and self.p.get("model", "gmp") == "gmp"
        n_it = int(self.p["iters"])
        self.eta_reset(1 if not do_dpd else 1 + (3 + max(n_it - 1, 1) if auto else n_it))
        self.eta_level(self.eta["total"])
        self.log("▶ DPD OFF 측정")
        y_al, r0 = self.measure(x, "DPD OFF", 0, step="SG %.2f dBm" % self.p["sg_dbm"])
        if not do_dpd:
            return self.results
        tgt = self.p.get("target_aclr")
        stp = "SG %.2f dBm" % self.p["sg_dbm"]
        if self.p.get("auto_model") and self.p.get("model", "gmp") == "gmp":
            y_al, pd, last, w = self.auto_model(y_al, "", stp)
            last, w, pd = self._dpd_level(y_al, w, "", stp, tgt, start=(pd, last))
        else:
            last, w, pd = self._dpd_level(y_al, None, "", stp, tgt)
        self.last_pd = pd
        return self.results

    def run_compare(self, methods, with_ilc=False):
        """방식 비교: 같은 SG 레벨 · 같은 DPD OFF 측정에서 출발해 방식마다 DPD 반복 → 방식별 최고 결과 요약
        methods = [(model, learn), ...]  예: [("gmp","ila"), ("gmp","dla"), ("dvr","ila"), ("nn","ila")]"""
        self.stop = False
        self.results = []
        self.compare = []
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        x = self.sig.x
        p = self.p
        keep = {k: p.get(k) for k in ("model", "method", "K", "M", "L")}
        n_it = int(p["iters"])
        tot = 1
        for mdl, lrn in methods:
            tot += (3 + max(n_it - 1, 1)) if (mdl == "gmp" and p.get("auto_model")) else n_it
        if with_ilc:
            tot += int(p.get("ilc_iters", 10))
        self.eta_reset(tot)
        self.eta_level(tot)
        stp = "SG %.2f dBm" % p["sg_dbm"]
        self.G = None
        self.tag = "OFF"
        self.log("━━ 방식 비교 · %d 가지%s · %s" % (len(methods), " + ILC 한계" if with_ilc else "", stp))
        y_off, r_off = self.measure(x, "DPD OFF", 0, step=stp)
        try:
            for i, (mdl, lrn) in enumerate(methods):
                self.check()
                p.update(keep)
                p["model"], p["method"] = mdl, lrn
                name = method_label(p)
                self.model = self.make_model()
                if getattr(self.model, "fallback", False):
                    name += " (numpy 대신)"
                self.tag = name
                self.log("━━ 방식 %d / %d: %s" % (i + 1, len(methods), name))
                t0 = time.time()
                n0 = len(self.results)
                try:
                    if mdl == "gmp" and p.get("auto_model"):
                        y_al, pd, last, w = self.auto_model(y_off, name + " · ", stp)
                        last, w, pd = self._dpd_level(y_al, w, name + " · ", stp, p.get("target_aclr"), start=(pd, last))
                    else:
                        last, w, pd = self._dpd_level(y_off, None, name + " · ", stp, p.get("target_aclr"))
                    err = ""
                except Stop:
                    raise
                except Exception as e:                     # 한 방식이 실패해도 다음 방식은 계속
                    self.log("  ⚠ %s 실패: %s" % (name, e))
                    err = str(e)
                rs = [r for r in self.results[n0:] if r.get("kind") == "dpd"]
                best = min(rs, key=lambda r: max(r["aclr_l"], r["aclr_u"])) if rs else None
                self.compare.append(dict(name=name, model=mdl, learn=lrn, best=best, t=time.time() - t0,
                                         n_coef=self.model.n_coef() if self.model is not None else 0,
                                         kml=("M%d H%d" % (p["M"], p.get("nn_hidden", 24)) if mdl in ("nn", "pnn", "tnn") else
                                              "구간 %d · M%d" % (p.get("dvr_seg", 8), p["M"]) if mdl == "dvr" else
                                              "K%d M%d L%d" % (p["K"], p["M"], p["L"])), err=err))
            if with_ilc:
                self.check()
                self.tag = "ILC 한계"
                t0 = time.time()
                b = self._ilc_level(y_off, "ILC · ", stp)
                self.compare.append(dict(name="ILC 한계", model="ilc", learn="", best=b, t=time.time() - t0, n_coef=0, kml="-", err=""))
        finally:
            p.update(keep)
            self.model = self.make_model()
            self.tag = None
        self.log("━━ 방식 비교 결과 (DPD OFF %.1f / %.1f dBc)" % (r_off["aclr_l"], r_off["aclr_u"]))
        for c in self.compare:
            b = c["best"]
            if b:
                self.log("  %-14s ACLR %.1f / %.1f dBc · EVM %.2f %% · Pout %.2f dBm · %.0f초 · 계수 %d"
                         % (c["name"], b["aclr_l"], b["aclr_u"], b["evm"], b["pout"], c["t"], c["n_coef"]))
            else:
                self.log("  %-14s 결과 없음 %s" % (c["name"], c["err"]))
        self.compare_off = r_off
        return self.results

    def _ilc_level(self, y_al, label_pre, step):
        """ILC: 모델 없이 측정을 되풀이하며 'PA 출력 = 원래 신호' 가 되는 입력을 샘플마다 직접 찾음 → 이 PA 의 한계 ACLR"""
        p, x = self.p, self.sig.x
        n = int(p.get("ilc_iters", 10))
        g = float(p.get("ilc_gain", 0.8))
        lim = np.max(np.abs(x)) * 10 ** (p["peak_lim_db"] / 20)
        u = x.copy()
        best = None            # (점수, 결과, 그때 입력 u, 그때 y_al)
        gk = g
        for k in range(1, n + 1):
            self.check()
            self.log("▶ %sILC %d / %d (한계 ACLR 찾기 · 이득 %.2f)" % (label_pre, k, n, gk))
            e = x - y_al / self.G
            u = u + gk * e
            a = np.abs(u)
            u = np.where(a > lim, u * lim / np.maximum(a, 1e-12), u)
            nm = 10 * np.log10(np.mean(np.abs(e) ** 2) / np.mean(np.abs(x) ** 2))
            y_al, r = self.measure(u, "%sILC %d" % (label_pre, k), k, nm, step, kind="ilc")
            sc = max(r["aclr_l"], r["aclr_u"])
            if best is None or sc < best[0]:
                best = (sc, r, u.copy(), y_al)
            elif sc > best[0] + 0.5:
                # 나빠지면 가장 좋았던 입력으로 돌아가서 이득을 반으로 (측정 잡음 · 과보정) → 천천히 더 내려감
                gk *= 0.5
                u, y_al = best[2].copy(), best[3]
                self.log("  ILC 나빠짐 (%.1f > 최고 %.1f dBc) → 최고 때로 돌아가 이득 %.2f" % (sc, best[0], gk))
                if gk < 0.05:
                    self.log("  ILC 이득이 너무 작아짐 → 멈춤 (잡음 · 최고값 제한 · SG 최대 한계)")
                    break
        best = (best[0], best[1])
        self.log("  ✔ 한계 ACLR (ILC 최고): %.1f / %.1f dBc · Pout %.2f dBm" % (best[1]["aclr_l"], best[1]["aclr_u"], best[1]["pout"]))
        return best[1]

    def run_ilc(self, levels=None):
        """ILC 로 한계 ACLR: levels 없으면 지금 SG 레벨 한 번, 있으면 레벨마다 (DPD OFF → ILC)"""
        self.stop = False
        self.results = []
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        x = self.sig.x
        base = self.p["sg_dbm"]
        levels = levels or [base]
        per_lv = 1 + int(self.p.get("ilc_iters", 10))
        self.eta_reset(per_lv * len([l for l in levels if l <= self.p["sg_max_dbm"] + 1e-9]))
        try:
            for i, lv in enumerate(levels):
                self.check()
                if lv > self.p["sg_max_dbm"] + 1e-9:
                    break
                self.eta_level(per_lv)
                self.p["sg_dbm"] = lv
                step = "레벨 %d/%d · SG %.2f dBm" % (i + 1, len(levels), lv) if len(levels) > 1 else "SG %.2f dBm" % lv
                self.G = None
                self.log("━━ %s · DPD OFF" % step)
                y_al, r_off = self.measure(x, "OFF", 0, step=step)
                self._ilc_level(y_al, "", step)
        finally:
            self.p["sg_dbm"] = base
        return self.results

    def run_sweep(self, levels, pout_stop=None):
        """파워 스윕: SG 레벨마다 DPD OFF 측정 → DPD 학습 (앞 레벨 계수로 시작) → DPD ON 측정"""
        self.stop = False
        self.results = []
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        x = self.sig.x
        w = None
        base = self.p["sg_dbm"]
        tgt = self.p.get("target_aclr")
        auto = self.p.get("auto_model") and self.p.get("model", "gmp") == "gmp"
        n_it = int(self.p["iters"])
        nl = len([l for l in levels if l <= self.p["sg_max_dbm"] + 1e-9])
        plan = lambda first: 1 + ((3 + max(n_it - 1, 1)) if (first and auto) else (n_it + (0 if first else 1)))
        self.eta_reset(sum(plan(i == 0) for i in range(nl)))
        try:
            for i, lv in enumerate(levels):
                self.check()
                if lv > self.p["sg_max_dbm"] + 1e-9:
                    self.log("SG %.2f dBm > SG 최대 → 스윕 끝" % lv)
                    break
                self.eta_level(plan(w is None))
                self.p["sg_dbm"] = lv
                step = "레벨 %d/%d · SG %.2f dBm" % (i + 1, len(levels), lv)
                self.log("━━ %s" % step)
                self.G = None
                y_al, r_off = self.measure(x, "OFF", 0, step=step)
                if self.p.get("auto_model") and self.p.get("model", "gmp") == "gmp" and w is None:          # 첫 레벨에서만 모델을 찾고 다음 레벨은 그 모델로
                    y_al, pd, last, w = self.auto_model(y_al, "", step)
                    last, w, pd = self._dpd_level(y_al, w, "", step, tgt, start=(pd, last))
                else:
                    last, w, pd = self._dpd_level(y_al, w, "", step, tgt)
                self.last_pd = pd
                if pout_stop is not None and r_off["pout"] >= pout_stop:
                    self.log("Pout %.2f dBm ≥ 멈춤 %.2f dBm → 스윕 끝" % (r_off["pout"], pout_stop))
                    break
                self.eta_level_end()
        finally:
            self.p["sg_dbm"] = base
        return self.results

    def abort(self, rf_off=True):
        """즉시 중지: 장비와 주고받던 것을 바로 끊고, 새로 연결해서 SG RF OFF · FSW 원래 모드로 (다른 스레드에서 부름)"""
        self.stop = True
        self.on_result = lambda r: None                  # 끊긴 실행의 결과는 화면에 안 올림
        self.on_progress = lambda s: None
        smw, fsw = self.smw, self.fsw
        self.smw = self.fsw = None
        for d in (smw, fsw):
            io = getattr(d, "io", None)
            if io is not None:
                io.abort()
        if smw is not None and rf_off:
            try:
                if getattr(smw, "io", None) is None:
                    smw.rf(False)                                  # 가상 장비
                else:
                    io = I.ScpiSocket(smw.io.host, smw.io.port, timeout=5.0, name="SMW")
                    io.write("OUTP1 OFF")
                    io.opc()
                    io.close()
                self.log("SG RF OFF")
            except Exception as e:
                self.log("⚠ SG RF OFF 실패: %s - SMW 에서 RF 를 직접 꺼 주세요" % e)
        if fsw is not None and getattr(fsw, "io", None) is not None and fsw.prev:
            try:
                fsw.io = I.ScpiSocket(fsw.io.host, fsw.io.port, timeout=10.0, name="FSW")
                fsw.restore()
                fsw.io.close()
            except Exception as e:
                self.log("⚠ FSW 원래 모드로 못 되돌림: %s" % e)

    def fsw_restore(self):
        f = self.fsw
        if f is not None and hasattr(f, "restore"):
            f.restore()

    def rf_off(self):
        try:
            if self.smw is not None:
                self.smw.rf(False)
                self.log("SG RF OFF")
        except Exception as e:
            self.log("RF OFF 실패: %s" % e)

    def close(self):
        try:
            self.fsw_restore()
        except Exception:
            pass
        for d in (self.smw, self.fsw):
            try:
                d.close()
            except Exception:
                pass
        self.smw = self.fsw = None
