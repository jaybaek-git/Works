"""
ext_psu  -  PA Bench Monitor (원래 Bench) 용: 키사이트 외부 전원 (GPIB) 2 가지

  1. 드라이버 앰프 전원: 별도 전원 1 대 (예: E3631A · E3632A · E36xx · N67xx 채널)
     · POWER SUPPLY ON: 게이트 ON → Vdd → 전류 맞추기가 다 끝난 뒤 맨 마지막에 ON (그 다음 측정 · RF)
     · POWER SUPPLY OFF · 전원 이상 처리: 맨 먼저 OFF → 그 다음 원래 끄는 순서
     · ON / OFF 만 (전압은 장비에 맞춰 둔 값 그대로)
  2. 외부 PK 게이트 (하나 더): N6705C 의 DRV · CA · PK 는 그대로 + 외부 전원에 피킹 게이트 하나 더
     · 샘플 종류마다 '외부 PK V' (빈칸 = 안 씀) - 값이 있는 샘플만 켬
     · POWER SUPPLY ON: 맨 앞 (게이트 · Vdd 보다 먼저) 그 값으로 ON → 읽어서 확인 (안 맞으면 순서 중지)
     · POWER SUPPLY OFF: Vdd 를 다 끈 뒤 (게이트와 같이) OFF · 전원 이상 처리 때는 그대로 둠 (게이트처럼)

  출력 칸: (단일) = 출력 1 개 장비 (E3632A · E36155A 등) · P6V / P25V / N25V = E3631A · 1 ~ 4 = 채널 장비 (N67xx · E3631xA)
  장비 없이: 주소 DEMO

psu_panel.py (바이어스 자동 순서) 는 고치지 않음: 이 화면의 post · run_seq · safe_down · read_job 만 바깥에서 감쌈.
Site2 판에서는 안 씀 (Site2 는 site2.py 가 함).
"""
import re
import time

OUTS = ["(단일)", "P6V", "P25V", "N25V", "1", "2", "3", "4"]


def _chs(cmd):
    m = re.search(r"\(@([^)]*)\)", cmd)
    if not m:
        return None
    out = []
    for part in m.group(1).split(","):
        part = part.strip()
        if ":" in part:
            a, b = part.split(":")
            out += list(range(int(a), int(b) + 1))
        elif part:
            out.append(int(part))
    return out


def norm_out(s):
    s = (s or "").strip().upper()
    if s in ("", "(단일)", "단일", "-"):
        return ""
    if s in ("+6V", "6V"):
        return "P6V"
    if s in ("+25V", "25V"):
        return "P25V"
    if s in ("-25V",):
        return "N25V"
    if s.startswith("CH"):
        s = s[2:]
    return s


class DemoExt:
    """가상 외부 전원 (출력 이름 · 채널 아무거나)"""

    def __init__(self):
        self.sel = ""
        self.v, self.i, self.on = {}, {}, {}

    def _k(self, cmd):
        ch = _chs(cmd)
        return str(ch[0]) if ch else self.sel

    def query(self, cmd):
        import random
        c = cmd.strip().upper()
        if c == "*IDN?":
            return "Keysight,EXT-PSU,0,DEMO"
        if c.startswith("SYST:ERR"):
            return '+0,"No error"'
        k = self._k(c)
        if c.startswith("MEAS") and " " in c and not _chs(c):
            k = c.split()[-1]
        on = self.on.get(k, self.on.get("", False)) if k not in self.on else self.on[k]
        if c.startswith("OUTP?"):
            return "1" if on else "0"
        if c.startswith("MEAS:VOLT"):
            return "%+.6E" % ((self.v.get(k, 0.0) + random.uniform(-5e-4, 5e-4)) if on else 0.0)
        if c.startswith("MEAS:CURR"):
            return "%+.6E" % (random.uniform(0.05, 0.06) if on else 0.0)
        if c.startswith("VOLT?"):
            return "%+.6E" % self.v.get(k, 0.0)
        if c.startswith("CURR?"):
            return "%+.6E" % self.i.get(k, 1.0)
        return "0"

    def write(self, cmd):
        c = cmd.strip().upper()
        val = c.split()[1].split(",")[0] if " " in c else ""
        k = self._k(c)
        if c.startswith("INST:SEL") or c.startswith("INST "):
            self.sel = val
        elif c.startswith("OUTP"):
            if _chs(c):
                self.on[k] = val in ("ON", "1")
            else:                                       # 출력 켜기가 장비 전체 (E3631A 등)
                for k_ in list(self.on) + [self.sel, ""]:
                    self.on[k_] = val in ("ON", "1")
        elif c.startswith("VOLT ") and not c.startswith("VOLT:"):
            self.v[k] = float(val)
        elif c.startswith("CURR ") and not c.startswith("CURR:"):
            self.i[k] = float(val)

    def close(self):
        pass


class Out:
    """외부 전원의 출력 하나: (단일) · P6V/P25V/N25V (E3631A, INST:SEL) · 채널 번호 (@n)"""

    def __init__(self, inst, out=""):
        self.inst = inst
        self.out = norm_out(out)
        self.ch = int(self.out) if self.out.isdigit() else None

    def name(self):
        return ("CH%d" % self.ch) if self.ch else (self.out or "단일")

    def _sel(self):
        if self.out and self.ch is None:
            self.inst.write("INST:SEL %s" % self.out)

    def q(self, head):
        head = head.strip()
        if self.ch:
            return self.inst.query("%s (@%d)" % (head, self.ch)).strip()
        if head.upper().startswith("MEAS:") and self.out:
            return self.inst.query("%s %s" % (head, self.out)).strip()
        if head.upper().startswith("OUTP"):
            return self.inst.query("OUTP?").strip()
        self._sel()
        return self.inst.query(head).strip()

    def w(self, head, val):
        head = head.strip().upper()
        if self.ch:
            self.inst.write("%s %s,(@%d)" % (head, val, self.ch))
        elif head == "OUTP":
            self.inst.write("OUTP %s" % val)
        else:
            self._sel()
            self.inst.write("%s %s" % (head, val))

    def is_on(self):
        try:
            return self.q("OUTP?") in ("1", "ON")
        except Exception:
            return False


class Ext:
    """설정 (app.s['ext_psu']) · 외부 장비 열기 · 드라이버 앰프 ON/OFF"""

    def __init__(self, app):
        self.app = app
        self.P = app.psu_panel
        self.dev = {}                                    # 주소 → 장비
        self.orig_open = self.P.visa.open

    def cfg(self):
        c = self.app.s.setdefault("ext_psu", {})
        if not c.get("_pk25"):                          # 1 번 사이트: 외부 PK 게이트는 E3631A +25V 출력 (기본값 · 한 번만 · 칸에서 바꿈)
            if not c.get("pk_out"):
                c["pk_out"] = "P25V"
            c["_pk25"] = True
        return c

    def log(self, msg, tag=""):
        try:
            self.P.q.put(("log", msg, tag))
        except Exception:
            pass

    def open_dev(self, addr):
        addr = (addr or "").strip()
        if not addr:
            raise RuntimeError("주소가 비어 있음")
        d = self.dev.get(addr.upper())
        if d is not None:
            return d
        if addr.upper().startswith("DEMO"):
            d = DemoExt()
        else:
            import psu_panel as PM
            if self.P.visa.rm is None:
                self.P.visa.open_rm()
            d = self.orig_open(PM.fix_addr(addr), 3000)
        try:
            idn = d.query("*IDN?").strip()
        except Exception as e:
            idn = "? (%s)" % e
        self.log("외부 전원 연결: %s → %s" % (addr, idn), "ok")
        self.dev[addr.upper()] = d
        return d

    def drop(self, addr):
        d = self.dev.pop((addr or "").strip().upper(), None)
        if d is not None:
            try:
                d.close()
            except Exception:
                pass

    def pk_out(self):
        c = self.cfg()
        return Out(self.open_dev(c.get("pk_addr", "")), c.get("pk_out", ""))

    def da_out(self):
        c = self.cfg()
        return Out(self.open_dev(c.get("da_addr", "")), c.get("da_out", ""))

    def pk_v(self):
        """지금 화면 '외부 PK' 칸 값 (빈칸 = 안 씀) → float / None"""
        v = getattr(self.app, "var_pk_ext", None)
        t = v.get().strip() if v is not None else ""
        try:
            return float(t) if t else None
        except ValueError:
            raise RuntimeError("외부 PK 칸이 숫자가 아님: %s" % t)

    def pk_on_for_seq(self):
        """POWER SUPPLY ON 맨 앞: 이 샘플에 외부 PK 값이 있으면 그 값으로 걸고 ON → 읽어서 확인 (안 맞으면 순서 중지)"""
        v = self.pk_v()
        if v is None:
            return
        c = self.cfg()
        if not (c.get("pk_addr") or "").strip():
            raise RuntimeError("외부 PK 값 %.3f V 가 있는데 외부 PK 전원 주소가 없음 (장비 설정 > 파워서플라이 연결)" % v)
        P = self.P
        try:
            gmin, gmax = float(P.lim["g_min"].get()), float(P.lim["g_max"].get())
        except Exception:
            gmin = gmax = None
        if gmin is not None and not (gmin <= v <= gmax):
            raise RuntimeError("외부 PK %.3f V 가 게이트 안전 한계 %g ~ %g V 밖" % (v, gmin, gmax))
        o = self.pk_out()
        o.w("VOLT", "%.3f" % v)
        try:
            o.w("CURR", "%.4f" % float(P.lim["g_imax"].get()))
        except Exception:
            pass
        if not o.is_on():
            o.w("OUTP", "ON")
        time.sleep(0.5)
        try:
            m = float(o.q("MEAS:VOLT?").split(",")[0])
        except Exception:
            m = float("nan")
        try:
            tol = abs(float(P.sq["gtol"].get()))
        except Exception:
            tol = 0.05
        if not o.is_on() or m != m or abs(m - v) > tol:
            raise RuntimeError("외부 PK 게이트 이상: 설정 %.3f V, 읽음 %s" % (v, ("%.3f V" % m) if m == m else "없음"))
        self.log("외부 PK 게이트 ON %.3f V (읽음 %.3f V) - 게이트 · Vdd 보다 먼저 (%s %s)"
                 % (v, m, c.get("pk_addr", ""), o.name()), "ok")

    def pk_set(self, on, why=""):
        """외부 PK 게이트 ON / OFF (연결돼 있을 때만)"""
        c = self.cfg()
        a_ = (c.get("pk_addr") or "").strip()
        if not a_ or a_.upper() not in self.dev:
            return
        try:
            o = self.pk_out()
            if o.is_on() == bool(on):
                return
            o.w("OUTP", "ON" if on else "OFF")
            self.log("외부 PK 게이트 %s%s" % ("ON" if on else "OFF", " - " + why if why else ""), "ok")
        except Exception as e:
            self.log("외부 PK 게이트 %s 실패: %s" % ("ON" if on else "OFF", e), "err")

    def da_set(self, on, why=""):
        """드라이버 앰프 전원 ON / OFF 만 (전압 · 전류는 장비에 맞춰 둔 값)"""
        c = self.cfg()
        if not c.get("da_use"):
            return
        try:
            o = self.da_out()                             # 전압 · 전류는 장비에 맞춰 둔 값 그대로 - ON / OFF 만
            if o.is_on() == bool(on):
                return
            o.w("OUTP", "ON" if on else "OFF")
            time.sleep(0.2)
            st = o.is_on()
            ok = st == bool(on)
            v = ""
            if on:
                try:
                    v = " · %.3f V" % float(o.q("MEAS:VOLT?").split(",")[0])
                except Exception:
                    pass
            self.log("드라이버 앰프 전원 %s (%s %s)%s%s%s" % ("ON" if on else "OFF", c.get("da_addr", ""), o.name(), v,
                                                       " - " + why if why else "", "" if ok else "  ✖ 상태가 안 바뀜"),
                     "ok" if ok else "err")
        except Exception as e:
            self.log("드라이버 앰프 전원 %s 실패: %s" % ("ON" if on else "OFF", e), "err")


def attach(app):
    """원래 Bench 에 붙임 (Site2 판에서는 부르지 않음)"""
    import psu_panel as PM
    if getattr(PM.Visa, "_site2", False):
        return
    P = getattr(app, "psu_panel", None)
    if P is None:
        return
    ext = Ext(app)
    app.ext_psu = ext

    # 2. 드라이버 앰프 전원 순서
    orig_post = P.post

    def post2(*msg):
        if msg and msg[0] == "bias_done" and getattr(P, "bias_state", "") == "on":
            ext.da_set(True, "바이어스 · 전류 맞추기 끝난 뒤 마지막")      # 순서 쓰레드에서 바로 → 측정 (RF) 보다 먼저
        orig_post(*msg)
    P.post = post2

    orig_run = P.run_seq

    def run2(fn, plan):
        nm = getattr(fn, "__name__", "")
        if nm == "job_power_off":
            ext.da_set(False, "끄기 맨 먼저")
            orig_run(fn, plan)
            try:                                           # 다 꺼졌을 때만 (중간에 멈추면 Vdd 가 남아 있을 수 있음)
                vdd_on = P.vdd_on()
            except Exception:
                vdd_on = True
            if P.bias_state == "off" and not vdd_on:
                ext.pk_set(False, "Vdd 다 끈 뒤 (게이트와 같이)")
            return
        if nm == "job_power_on":
            def fn2(p, fn=fn):
                ext.pk_on_for_seq()                        # 외부 PK 게이트: 게이트 · Vdd 보다 먼저 (빈칸이면 안 씀)
                fn(p)
            fn2.__name__ = nm
            orig_run(fn2, plan)
            return
        orig_run(fn, plan)
    P.run_seq = run2

    orig_safe = P.safe_down

    def safe2(why):
        ext.da_set(False, "이상 처리 맨 먼저")
        orig_safe(why)
    P.safe_down = safe2

    attach_soft_fault(app, lambda: ext.da_set(False, "Vdd 전류 이상 - 샘플 보호"))
    attach_cfg_ui(app, ext)
    attach_panel(app, ext)
    attach_pk_field(app, ext)


def gates_on(P):
    n = P.inst.get("n")
    if n is None:
        return False
    try:
        return any(x.strip() in ("1", "ON") for x in n.query("OUTP? (@1,2,3)").split(","))
    except Exception:
        return True


def pk_ext_val(app, name=None):
    """샘플 종류의 '외부 PK V' (빈칸 = 안 씀) → float 또는 None"""
    try:
        v = (app.stype_bias(name) or {}).get("pk_ext", "")
        return float(v) if str(v).strip() else None
    except (TypeError, ValueError):
        return None


def attach_pk_field(app, ext):
    """파워서플라이 화면 '게이트 기본값' 줄에 [외부 PK] 칸: 지금 샘플의 값 (빈칸 = 외부 PK 안 씀)"""
    import tkinter as tk
    from tkinter import ttk
    P = app.psu_panel
    try:
        tv = str(P.sq["g3"])
    except Exception:
        return
    row = None
    stack = [P.box_left]
    while stack and row is None:
        w_ = stack.pop()
        for c in w_.winfo_children():
            try:
                if c.winfo_class() in ("TEntry", "Entry") and str(c.cget("textvariable")) == tv:
                    row = c.master
                    break
            except Exception:
                pass
            stack.append(c)
    if row is None:
        return
    app.var_pk_ext = tk.StringVar(value="")
    kids = row.pack_slaves()
    after = kids[-1] if kids else None
    chip = tk.Label(row, text=" 외부 PK ", bg=EXT_COL, fg="white", font=("맑은 고딕", 8, "bold"))
    chip.pack(side="left", padx=(10, 1))
    ttk.Entry(row, textvariable=app.var_pk_ext, width=6).pack(side="left", padx=2)
    ttk.Label(row, text="V (빈칸 = 안 씀)", foreground="#666").pack(side="left", padx=(2, 0))
    if after is not None:                                   # 'V' 글 뒤에
        pass

    def load(*_):
        v = (app.stype_bias() or {}).get("pk_ext", "")
        app.var_pk_ext.set(str(v))
        refresh_panel(app, ext)
    app.ext_pk_load = load
    app.var_stype.trace_add("write", lambda *a: app.root.after(70, load))
    app.var_pk_ext.trace_add("write", lambda *a: app.root.after(50, lambda: refresh_panel(app, ext)))
    load()

    # [💾 샘플 종류 기본값으로 저장] 에 외부 PK 도 같이
    orig_save = app.save_stype_bias

    def save2():
        orig_save()
        t = app.cur_stype()
        for st in app.sample_types:
            if st["name"] == t:
                b = st.setdefault("bias", {})
                v = app.var_pk_ext.get().strip()
                if v:
                    b["pk_ext"] = v
                else:
                    b.pop("pk_ext", None)
        app.s["sample_types"] = [dict(x) for x in app.sample_types]
    app.save_stype_bias = save2


EXT_COL = "#00897b"     # 외부 PK 게이트 색 (청록)
DA_COL = "#8e24aa"      # 드라이버 앰프 전원 색 (보라)


def attach_panel(app, ext):
    """파워서플라이 화면 오른쪽: N6705C 아래에 외부 전원 앞면 (PK 게이트 · 드라이버 앰프) - 쓰는 것만 보임"""
    import tkinter as tk
    P = app.psu_panel
    try:
        mid = P.lbl_n_idn.master.master.master.master
        nw = P.lbl_n_idn.master.master.master
    except Exception:
        return
    BEZEL, LCD, DIM = "#41464d", "#0a0f14", "#5a6470"
    wrap = tk.Frame(mid)
    pnl = tk.Frame(wrap, bg=BEZEL, bd=3, relief="raised")
    pnl.pack(fill="both", expand=True, pady=(6, 0))
    hd = tk.Frame(pnl, bg=BEZEL)
    hd.pack(fill="x", padx=8, pady=(6, 2))
    lbl_model = tk.Label(hd, text="외부 전원", bg=BEZEL, fg="#e8e8e8", font=("Arial", 11, "bold"))
    lbl_model.pack(side="left")
    tk.Label(hd, text="  DC Power Supply (GPIB)", bg=BEZEL, fg="#c9cdd2", font=("Arial", 8)).pack(side="left")
    tk.Label(hd, text="외부 게이트 · 드라이버 앰프", bg=EXT_COL, fg="white", font=("맑은 고딕", 8, "bold")).pack(side="right")
    scr = tk.Frame(pnl, bg=LCD, bd=2, relief="sunken")
    scr.pack(fill="both", expand=True, padx=8, pady=(0, 4))
    keys = tk.Frame(pnl, bg=BEZEL)
    keys.pack(fill="x", padx=8, pady=(0, 8))
    cells = {}
    for i, (k, col, name) in enumerate((("pk", EXT_COL, "외부 PK 게이트"), ("da", DA_COL, "드라이버 앰프"))):
        scr.columnconfigure(i, weight=1, uniform="x")
        keys.columnconfigure(i, weight=1, uniform="x")
        cell = tk.Frame(scr, bg=LCD, highlightthickness=2, highlightbackground=col)
        top = tk.Frame(cell, bg=col)
        top.pack(fill="x")
        tk.Label(top, text=" %s " % name, bg=col, fg="white", font=("맑은 고딕", 10, "bold")).pack(side="left")
        r = {"addr": tk.Label(top, text="", bg=col, fg="white", font=("Arial", 8))}
        r["addr"].pack(side="left")
        r["o"] = tk.Label(top, text="Off", bg=col, fg="white", font=("Arial", 8, "bold"))
        r["o"].pack(side="right", padx=3)
        r["vm"] = tk.Label(cell, text="---", bg=LCD, fg=col if k == "pk" else "#ce93d8", font=("Consolas", 18, "bold"), anchor="e")
        r["vm"].pack(fill="x", padx=6, pady=(4, 0))
        r["im"] = tk.Label(cell, text="---", bg=LCD, fg="#e0e0e0", font=("Consolas", 12, "bold"), anchor="e")
        r["im"].pack(fill="x", padx=6)
        r["vs"] = tk.Label(cell, text="Set ---", bg=LCD, fg=DIM, font=("Consolas", 8), anchor="e")
        r["vs"].pack(fill="x", padx=6, pady=(0, 4))
        btn = tk.Button(keys, text="On/Off", bg="#555", fg="white", font=("Arial", 8, "bold"), bd=2, relief="raised",
                        highlightthickness=2, highlightbackground=col, activebackground="#777",
                        command=lambda k=k: toggle(k))
        r["cell"], r["btn"], r["i"] = cell, btn, i
        cells[k] = r

    def toggle(k):
        if not P.var_ctrl.get():
            P.post("log", "제어 잠금 상태 - 왼쪽 '🔓 제어 사용' 을 켜세요", "err")
            return

        def job():
            try:
                o = ext.pk_out() if k == "pk" else ext.da_out()
                on = not o.is_on()
                if k == "da":
                    ext.da_set(on, "손으로")
                else:
                    if on:
                        v = ext.pk_v()
                        if v is None:
                            P.post("log", "이 샘플 외부 PK 칸이 빈칸 - 값을 넣고 켜세요", "err")
                            return
                        o.w("VOLT", "%.3f" % v)
                    o.w("OUTP", "ON" if on else "OFF")
                    P.post("log", "외부 PK 게이트 %s" % ("ON" if on else "OFF"), "ok")
            except Exception as e:
                P.post("log", "외부 전원 On/Off 실패: %s" % e, "err")
            read()
        P.worker.tasks.put(job)

    def show(k, d):
        r = cells[k]
        if d is None:
            for x in ("vm", "im"):
                r[x].configure(text="---")
            r["vs"].configure(text="Set ---")
            r["o"].configure(text="연결 안 됨")
            r["btn"].configure(bg="#555")
            return
        on = d.get("on")
        r["vm"].configure(text="%.3f V" % d["vm"] if d.get("vm") == d.get("vm") else "---")
        r["im"].configure(text="%.4f A" % d["im"] if d.get("im") == d.get("im") else "---")
        r["vs"].configure(text="Set %.3f V · Lim %.3f A" % (d.get("vs", float("nan")), d.get("is", float("nan"))))
        r["o"].configure(text="ON" if on else "Off")
        r["btn"].configure(bg="#2e7d32" if on else "#555")

    def rd(o):
        f = lambda x: float(str(x).split(",")[0])
        d = {"on": o.is_on()}
        for k_, q in (("vm", "MEAS:VOLT?"), ("im", "MEAS:CURR?"), ("vs", "VOLT?"), ("is", "CURR?")):
            try:
                d[k_] = f(o.q(q))
            except Exception:
                d[k_] = float("nan")
        return d

    def read():
        c = ext.cfg()
        out = {}
        for k, use, addr in (("pk", bool((c.get("pk_addr") or "").strip()), c.get("pk_addr", "")),
                             ("da", bool(c.get("da_use")), c.get("da_addr", ""))):
            if not use or (addr or "").strip().upper() not in ext.dev:
                out[k] = None
                continue
            try:
                out[k] = rd(ext.pk_out() if k == "pk" else ext.da_out())
            except Exception:
                out[k] = None
        P.post("call", lambda: [show(k, d) for k, d in out.items()])

    orig_read = P.read_job

    def read2(full=True):
        orig_read(full)
        try:
            read()
        except Exception:
            pass
    P.read_job = read2

    def refresh():
        c = ext.cfg()
        use = {"pk": bool((c.get("pk_addr") or "").strip()), "da": bool(c.get("da_use"))}
        for k, r in cells.items():
            if use[k]:
                r["cell"].grid(row=0, column=r["i"], sticky="nsew", padx=3, pady=6)
                r["btn"].grid(row=0, column=r["i"], padx=6, sticky="we")
                a = c.get("pk_addr" if k == "pk" else "da_addr", "")
                o = Out(None, c.get("pk_out" if k == "pk" else "da_out", ""))
                extra = ""
                if k == "pk":
                    v = app.var_pk_ext.get().strip() if hasattr(app, "var_pk_ext") else ""
                    extra = " · 이 샘플 %s" % (("%s V" % v) if v else "안 씀")
                r["addr"].configure(text="%s %s%s" % (a, o.name(), extra))
            else:
                r["cell"].grid_forget()
                r["btn"].grid_forget()
        if use["pk"] or use["da"]:
            if not wrap.winfo_ismapped():
                wrap.pack(side="top", fill="x", after=nw)
        else:
            wrap.pack_forget()
    app.ext_panel_refresh = refresh
    app.ext_panel_cells = cells
    refresh()


def refresh_panel(app, ext):
    f = getattr(app, "ext_panel_refresh", None)
    if f:
        f()


def attach_cfg_ui(app, ext):
    """'파워서플라이 연결 · SCPI' 탭: 외부 전원 (드라이버 앰프 · PK 게이트) 주소 · 출력 · 전압"""
    import tkinter as tk
    from tkinter import ttk
    P = app.psu_panel
    box = P.box_extra
    first = None
    for w in box.winfo_children():
        if "Labelframe" in w.winfo_class():
            first = w
            break
    lf = ttk.LabelFrame(box, text=" 외부 전원 (GPIB) - 드라이버 앰프 전원 · PK 게이트 ", padding=8)
    if first is not None:
        lf.pack(fill="x", padx=8, pady=(4, 4), after=first)
    else:
        lf.pack(fill="x", padx=8, pady=(4, 4))
    c = ext.cfg()
    v = dict(da_use=tk.BooleanVar(value=bool(c.get("da_use"))),
             da_addr=tk.StringVar(value=c.get("da_addr", "")), da_out=tk.StringVar(value=c.get("da_out", "") or "(단일)"),
             pk_addr=tk.StringVar(value=c.get("pk_addr", "")), pk_out=tk.StringVar(value=c.get("pk_out", "") or "(단일)"))
    g = ttk.Frame(lf)
    g.pack(fill="x")
    ttk.Checkbutton(g, text="드라이버 앰프 전원 사용", variable=v["da_use"]).grid(row=0, column=0, sticky="w")
    ttk.Label(g, text="주소").grid(row=0, column=1, sticky="e", padx=(8, 2))
    ttk.Entry(g, textvariable=v["da_addr"], width=22).grid(row=0, column=2, sticky="we")
    ttk.Label(g, text="출력").grid(row=0, column=3, padx=(8, 2))
    ttk.Combobox(g, textvariable=v["da_out"], values=OUTS, width=7).grid(row=0, column=4)
    ttk.Label(g, text="PK 게이트 외부 전원").grid(row=1, column=0, sticky="w", pady=(4, 0))
    ttk.Label(g, text="주소").grid(row=1, column=1, sticky="e", padx=(8, 2), pady=(4, 0))
    ttk.Entry(g, textvariable=v["pk_addr"], width=22).grid(row=1, column=2, sticky="we", pady=(4, 0))
    ttk.Label(g, text="출력").grid(row=1, column=3, padx=(8, 2), pady=(4, 0))
    ttk.Combobox(g, textvariable=v["pk_out"], values=OUTS, width=7).grid(row=1, column=4, pady=(4, 0))
    g.columnconfigure(2, weight=1)
    ttk.Label(lf, text="드라이버 앰프: ON / OFF 만 (전압은 장비에 맞춰 둔 값) - POWER SUPPLY ON 때 바이어스 · 전류 맞추기 끝난 뒤 맨 마지막 ON · OFF 때 맨 먼저 OFF\n"
                       "외부 PK 게이트: 샘플 종류마다 '외부 PK V' 칸 (빈칸 = 안 씀) · 파워서플라이 화면 N6705C 아래에 앞면이 보임  ·  "
                       "출력: (단일) · E3631A = P6V/P25V/N25V · 채널 장비 = 1~4  ·  장비 없이: DEMO",
              foreground="#607d8b", justify="left").pack(anchor="w", pady=(4, 0))
    bf = ttk.Frame(lf)
    bf.pack(fill="x", pady=(6, 0))

    def apply(log=True):
        c = ext.cfg()
        import psu_panel as PM
        for k in ("da_addr", "pk_addr"):
            a = v[k].get().strip()
            a = PM.fix_addr(a) if a and not a.upper().startswith("DEMO") else a
            if a != c.get(k, ""):
                old = c.get(k, "")
                if old and old != c.get("pk_addr" if k == "da_addr" else "da_addr", ""):
                    P.worker.tasks.put(lambda o=old: ext.drop(o))
            v[k].set(a)
        c.update(da_use=bool(v["da_use"].get()), da_addr=v["da_addr"].get().strip(), da_out=norm_out(v["da_out"].get()),
                 pk_addr=v["pk_addr"].get().strip(), pk_out=norm_out(v["pk_out"].get()))
        refresh_panel(app, ext)
        if log:
            P.post("log", "외부 전원 적용: 드라이버 앰프 %s · PK 게이트 %s" % (
                ("%s %s" % (c["da_addr"], Out(None, c["da_out"]).name()))
                if c["da_use"] else "안 씀",
                ("%s %s" % (c["pk_addr"], Out(None, c["pk_out"]).name())) if c["pk_addr"] else "없음"), "ok")
        return True

    import psu_panel as PM_

    def da_btn(on):
        if not apply(log=False):
            return
        if not ext.cfg().get("da_use"):
            P.post("log", "드라이버 앰프 전원 사용에 체크하세요", "err")
            return
        if on and getattr(P, "bias_state", "") != "on":
            if not PM_.messagebox.askyesno("PA Bench Monitor", "바이어스가 다 켜져 있지 않습니다.\n그래도 드라이버 앰프 전원을 켤까요?"):
                return
        P.worker.tasks.put(lambda: ext.da_set(on, "손으로"))

    ttk.Button(bf, text="적용", command=apply).pack(side="left")
    ttk.Button(bf, text="드라이버 앰프 ON", command=lambda: da_btn(True)).pack(side="left", padx=(6, 0))
    ttk.Button(bf, text="드라이버 앰프 OFF", command=lambda: da_btn(False)).pack(side="left", padx=(4, 0))
    app.ext_cfg = dict(vars=v, apply=apply)


# ---------------------------------------------------------------- Vdd 전류 이상 → 먼저 샘플 보호 (SG RF OFF · 드라이버 앰프 OFF) → 그래도 이상하면 긴급 종료
def attach_soft_fault(app, da_off):
    """측정 중 Vdd 전류 급상승 · 최대 전류 넘음 (파워서플라이 '이상 판정 2)'):
    예전: 바로 바이어스 긴급 종료 (게이트 기본값 → Vdd 0 V)
    지금: ① SG RF OFF + 측정 중지 · 드라이버 앰프 OFF (샘플 보호)
          ② 약 1 초 뒤 Vdd 전류를 다시 읽어 바이어스 목표 Idq (목표 CA + 목표 DRV) 와 비슷하면
             → 바이어스는 그대로 · '설정값을 확인하세요' 안내
          ③ SG · 드라이버 앰프를 껐는데도 전류가 이상하면 → 예전처럼 바로 긴급 종료
    게이트 이상 (kind 'n') 은 예전 그대로. psu_panel.py 는 그대로 (이 화면의 check_faults 만 감쌈)"""
    import psu_panel as PM
    P = getattr(app, "psu_panel", None)
    if P is None or getattr(P, "_soft_fault", False):
        return
    P._soft_fault = True
    orig = P.check_faults

    def cf(kind, vals):
        if kind != "e":
            return orig(kind, vals)
        if P.bias_state != "on" or P.seq_running or getattr(P, "fault_busy", False):
            return
        i = vals.get("im")
        if i is None or i != i:
            return
        ref = getattr(P, "mon_ref", i)
        pre = P.lim_prefix()
        pct = P.sqf(pre + "spike_pct", P.sqf("spike_pct", 50)) / 100.0
        dma = P.sqf(pre + "spike_ma", P.sqf("spike_ma", 100)) / 1e3
        imax = P.sqf(pre + "imax", P.sqf("imax", 1.5))
        tag = {"": "", "mod_": " (Mod. 한계)", "dpd_": " (DPD 한계)"}.get(pre, "")
        why = None
        if i > imax:
            why = "Vdd 전류가 최대 %.2f A 를 넘음 (%.3f A)%s" % (imax, i, tag)
        elif i - ref >= dma and i >= ref * (1 + pct):
            why = "Vdd 전류 급상승: %.1f → %.1f mA%s" % (ref * 1e3, i * 1e3, tag)
        if why is None:
            P.mon_ref = i
            return
        P.mon_ref = ref
        P.fault_busy = True
        msg1 = "Vdd 전류가 지정값보다 많이 올라가 샘플 보호를 위해 SG RF OFF · Driver Amp 를 끕니다"
        try:
            if P.on_fault:
                P.on_fault(why)                            # (Bench) 측정 중지 + SG RF OFF - 먼저
        except Exception:
            pass
        try:
            app.status("⚠ " + msg1 + " (" + why + ")", "#ff6b6b")
        except Exception:
            pass
        P.post("log", "⚠ %s → %s" % (why, msg1), "err")
        idq = (P.sqf("t_green", 0) + P.sqf("t_yellow", 0)) / 1e3
        tol = 0.10                                         # Idq ±10 % 안이면 '비슷함' (바이어스 그대로)

        def job():
            safe = False
            try:
                time.sleep(0.1)                            # SG RF OFF 가 먼저 가게
                try:
                    da_off()
                except Exception as ex:
                    P.post("log", "드라이버 앰프 OFF 실패: %s" % ex, "err")
                time.sleep(0.7)                            # 전류가 가라앉을 시간 (SG · 드라이버 앰프 OFF 부터 약 1 초 안에 판단)
                e = P.inst.get("e")
                xs = []
                for _ in range(2):
                    try:
                        xs.append(PM.fnum(e.query("MEAS:CURR?")))
                    except Exception:
                        pass
                    time.sleep(0.1)
                xs = [x for x in xs if x == x]
                now = sum(xs) / len(xs) if xs else float("nan")
                band = idq * tol
                safe = idq > 0 and now == now and abs(now - idq) <= band
                if safe:
                    P.mon_ref = now
                    txt = ("%s\n\n%s.\n\n지금 Vdd 전류 %.1f mA 가 바이어스 목표 Idq %.1f mA (CA + DRV) 와 비슷합니다 (±10 %%, ±%.1f mA 안)\n"
                           "→ 바이어스는 문제가 없어 긴급 종료하지 않고 그대로 둡니다.\n\n"
                           "측정 중 전류 한계가 너무 낮을 수 있습니다. 파워서플라이 설정 '이상 판정 2)' 의\n"
                           "급상승 %% · mA · 최대 Id 값을 확인해서 바꿔 주세요. (SG RF · 드라이버 앰프는 꺼진 상태)"
                           % (why, msg1, now * 1e3, idq * 1e3, band * 1e3))
                    P.post("log", "Vdd 전류 %.1f mA ≈ Idq %.1f mA → 바이어스 그대로 (긴급 종료 안 함)" % (now * 1e3, idq * 1e3), "ok")
                    P.post("call", lambda: PM.messagebox.showwarning("샘플 보호 - 바이어스는 그대로", txt))
                else:
                    why2 = "%s\nSG RF OFF · 드라이버 앰프 OFF 뒤에도 Vdd 전류 %s (바이어스 Idq %.1f mA)" % (
                        why, ("%.1f mA" % (now * 1e3)) if now == now else "못 읽음", idq * 1e3)
                    P.red(why2 + "\n\n→ 게이트 기본값으로 올리고 Vdd 를 0 V 까지 빠르게 내립니다.")
                    P.safe_down(why2)
            finally:
                P.fault_busy = False
                try:
                    P.read_job(full=True)
                except Exception:
                    pass
        P.worker.tasks.put(job)
    P.check_faults = cf
