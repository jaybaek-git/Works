@echo off
cd /d %~dp0
set PYTHONUTF8=1
echo ============================================
echo  PA DPD Tester v0.1.1 - EXE build
echo ============================================
python --version
if errorlevel 1 (
  echo [ERROR] Python not found. Install Python 3.9+ ^(check "Add to PATH"^).
  pause
  exit /b 1
)
python -m pip install --upgrade pyinstaller numpy openpyxl
if errorlevel 1 (
  echo [ERROR] package install failed. Check proxy / pip settings.
  pause
  exit /b 1
)
set NAME=PA-DPD-Tester_v0.1.1
python -m PyInstaller --noconfirm --clean --onedir --windowed --name "%NAME%" ^
  --hidden-import dpd_engine --hidden-import dpd_core --hidden-import instruments --hidden-import demo_pa --hidden-import bench_link ^
  --exclude-module matplotlib --exclude-module PySide6 --exclude-module PyQt5 --exclude-module pandas --exclude-module scipy ^
  pa_dpd_tester.py
if errorlevel 1 (
  echo [ERROR] Build failed.
  pause
  exit /b 1
)
powershell -NoProfile -Command "Compress-Archive -Force -Path 'dist\%NAME%' -DestinationPath 'dist\%NAME%-win64.zip'"
echo.
echo  DONE:  dist\%NAME%\%NAME%.exe
echo         dist\%NAME%-win64.zip  (give this zip to other PCs - unzip, run the exe inside)
echo.
pause
