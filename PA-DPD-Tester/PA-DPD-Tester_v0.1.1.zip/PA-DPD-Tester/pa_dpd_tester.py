# -*- coding: utf-8 -*-
"""PA DPD Tester - SMW200A + FSW 로 PA 에 간단한 DPD (메모리 다항식 / GMP) 를 적용해 성능 확인

- 신호: 5G NR 100 MHz 1 캐리어 (SCS 30 kHz, 273 RB) OFDM, CFR, 오버샘플 ×2/×3/×4
- 순서: [DPD OFF 측정] → DPD 반복 (간접 학습 ILA) → 매번 Pout · ACLR · EVM · PAPR
- 장비에는 아무것도 설치하지 않음 (LAN, SCPI raw socket 5025). 주소에 demo = 가상 PA
"""
import json
import math
import os
import queue
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

VERSION = "v0.1.1"
APP = "PA DPD Tester"

import bench_link as BL

try:
    import dpd_engine as E
except Exception as _e:                     # numpy 가 없는 등
    E = None
    _IMPORT_ERR = _e

SET_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "PADPDTester")
SET_FILE = os.path.join(SET_DIR, "settings.json")

C_OFF = "#9e9e9e"
C_DPD = "#1f77b4"
C_ITER = ["#c6dbef", "#9ecae1", "#6baed6", "#4292c6", "#2171b5", "#08519c"]
FONT = ("맑은 고딕", 9)
FONT_B = ("맑은 고딕", 9, "bold")


def fnum(s, d=0.0):
    try:
        return float(str(s).strip())
    except (ValueError, TypeError):
        return d


# ---------------------------------------------------------------- 간단한 그래프 (Tk Canvas)
class Plot(tk.Canvas):
    def __init__(self, master, title="", xl="", yl="", **kw):
        super().__init__(master, bg="white", highlightthickness=1, highlightbackground="#cfd8dc", **kw)
        self.title, self.xl, self.yl = title, xl, yl
        self.series = []          # dict(x, y, color, width, dots, label)
        self.xr = self.yr = None  # 고정 범위
        self.vlines = []
        self.bind("<Configure>", lambda e: self.redraw())

    def set(self, series, xr=None, yr=None, vlines=()):
        self.series, self.xr, self.yr, self.vlines = series, xr, yr, list(vlines)
        self.redraw()

    @staticmethod
    def nice(lo, hi, n=5):
        if not (math.isfinite(lo) and math.isfinite(hi)) or hi <= lo:
            hi = lo + 1
        span = hi - lo
        raw = span / n
        mag = 10 ** math.floor(math.log10(raw))
        step = min((m * mag for m in (1, 2, 2.5, 5, 10) if m * mag >= raw), default=mag * 10)
        a = math.floor(lo / step) * step
        ticks = []
        v = a
        while v <= hi + step * 1e-6:
            if v >= lo - step * 1e-6:
                ticks.append(round(v, 10))
            v += step
        return ticks

    def redraw(self):
        self.delete("all")
        W, H = self.winfo_width(), self.winfo_height()
        if W < 50 or H < 50:
            return
        L, R, T, B = 52, 12, 24, 34
        self.create_text(L, 12, text=self.title, anchor="w", font=FONT_B, fill="#263238")
        xs = [v for s in self.series for v in s["x"]]
        ys = [v for s in self.series for v in s["y"]]
        if self.xr:
            x0, x1 = self.xr
        elif xs:
            x0, x1 = min(xs), max(xs)
        else:
            x0, x1 = 0, 1
        if self.yr:
            y0, y1 = self.yr
        elif ys:
            y0, y1 = min(ys), max(ys)
            pad = (y1 - y0) * 0.08 or 1
            y0, y1 = y0 - pad, y1 + pad
        else:
            y0, y1 = 0, 1
        if x1 <= x0:
            x1 = x0 + 1
        if y1 <= y0:
            y1 = y0 + 1
        px = lambda v: L + (v - x0) / (x1 - x0) * (W - L - R)
        py = lambda v: H - B - (v - y0) / (y1 - y0) * (H - T - B)
        for t in self.nice(x0, x1, 6):
            self.create_line(px(t), T, px(t), H - B, fill="#eceff1")
            self.create_text(px(t), H - B + 4, text=("%g" % t), anchor="n", font=("맑은 고딕", 8), fill="#607d8b")
        for t in self.nice(y0, y1, 5):
            self.create_line(L, py(t), W - R, py(t), fill="#eceff1")
            self.create_text(L - 4, py(t), text=("%g" % t), anchor="e", font=("맑은 고딕", 8), fill="#607d8b")
        self.create_rectangle(L, T, W - R, H - B, outline="#b0bec5")
        self.create_text((L + W - R) / 2, H - 4, text=self.xl, anchor="s", font=("맑은 고딕", 8), fill="#455a64")
        self.create_text(4, T - 2, text=self.yl, anchor="sw", font=("맑은 고딕", 8), fill="#455a64")
        for v, col in self.vlines:
            if x0 <= v <= x1:
                self.create_line(px(v), T, px(v), H - B, fill=col, dash=(3, 3))
        for s in self.series:
            pts = [(px(a), py(b)) for a, b in zip(s["x"], s["y"])
                   if math.isfinite(a) and math.isfinite(b) and x0 <= a <= x1 and y0 <= b <= y1]
            if not pts:
                continue
            if s.get("dots"):
                r = s.get("r", 1)
                for a, b in pts:
                    self.create_rectangle(a - r, b - r, a + r, b + r, outline="", fill=s["color"])
            elif len(pts) > 1:
                self.create_line(*[c for p in pts for c in p], fill=s["color"], width=s.get("width", 1))
        ly = T + 6
        for s in self.series:
            if s.get("label"):
                self.create_line(W - R - 118, ly, W - R - 100, ly, fill=s["color"], width=3)
                self.create_text(W - R - 96, ly, text=s["label"], anchor="w", font=("맑은 고딕", 8), fill="#263238")
                ly += 14


# ---------------------------------------------------------------- 화면
class App:
    FIELDS = [
        # (키, 이름, 기본값, 단위, 카드)
        ("smw_host", "SMW200A 주소", "demo", "", "dev"),
        ("fsw_host", "FSW 주소", "demo", "", "dev"),
        ("mod", "변조", "256QAM", "", "sig"),
        ("n_sym", "OFDM 심볼 수", "28", "개 (14개 = 0.5 ms)", "sig"),
        ("os", "샘플레이트", "4", "", "sig"),
        ("papr_db", "CFR 목표 PAPR", "8.0", "dB", "sig"),
        ("freq_ghz", "주파수", "3.6", "GHz", "rf"),
        ("sg_dbm", "SG 레벨 (RMS)", "-10", "dBm", "rf"),
        ("sg_max_dbm", "SG 최대", "0", "dBm (넘지 않음)", "rf"),
        ("in_loss_db", "입력 손실 (SG→PA)", "0.5", "dB", "rf"),
        ("out_loss_db", "출력 손실 (PA→FSW)", "40", "dB (감쇠기 포함)", "rf"),
        ("cal_db", "Pout 보정", "0", "dB (파워미터 기준)", "rf"),
        ("fsw_ref_dbm", "FSW Ref Level", "10", "dBm", "rf"),
        ("fsw_att_db", "FSW 감쇠", "auto", "dB 또는 auto", "rf"),
        ("K", "비선형 차수 K", "7", "", "dpd"),
        ("M", "메모리 깊이 M", "4", "탭", "dpd"),
        ("L", "GMP 교차 지연 L", "1", "(0 = 메모리 다항식)", "dpd"),
        ("iters", "반복 횟수", "4", "번", "dpd"),
        ("mu", "섞기 비율 μ", "0.7", "(1 = 새 계수만)", "dpd"),
        ("peak_lim_db", "최고값 제한", "3", "dB (원래 최고값 +)", "dpd"),
        ("lam", "정규화 λ", "1e-6", "", "dpd"),
        ("n_fit", "학습 샘플 수", "40000", "개", "dpd"),
    ]
    OS_TXT = {"2": "×2 = 245.76 MSps (인접 채널 일부만)", "3": "×3 = 368.64 MSps", "4": "×4 = 491.52 MSps (권장)"}

    def __init__(self, root):
        self.root = root
        self.s = self.load_settings()
        root.title("%s %s" % (APP, VERSION))
        root.geometry(self.s.get("geometry", "1420x880"))
        root.configure(bg="#eceff1")
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure(".", font=FONT)
        st.configure("Card.TLabelframe", background="white")
        st.configure("Card.TLabelframe.Label", background="white", font=FONT_B, foreground="#1565c0")
        st.configure("Card.TFrame", background="white")
        st.configure("Card.TLabel", background="white")
        st.configure("Unit.TLabel", background="white", foreground="#78909c", font=("맑은 고딕", 8))
        st.configure("Card.TCheckbutton", background="white")
        st.configure("Go.TButton", font=FONT_B, foreground="white", background="#1e88e5")
        st.map("Go.TButton", background=[("active", "#1565c0"), ("disabled", "#b0bec5")])
        st.configure("Stop.TButton", font=FONT_B, foreground="white", background="#e53935")
        st.map("Stop.TButton", background=[("active", "#c62828"), ("disabled", "#b0bec5")])
        st.configure("Treeview", rowheight=22, font=FONT)
        st.configure("Treeview.Heading", font=FONT_B)
        self.v = {}
        self.q = queue.Queue()
        self.engine = None
        self.worker = None
        self.results = []
        self.build()
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(100, self.pump)
        if E is None:
            messagebox.showerror(APP, "계산 모듈을 불러오지 못했습니다 (numpy 필요):\n%s" % _IMPORT_ERR)

    # ------------------------------------------------------------ 설정
    def load_settings(self):
        try:
            with open(SET_FILE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def save_settings(self):
        s = self.s
        for k, var in self.v.items():
            s[k] = var.get()
        try:
            s["geometry"] = self.root.geometry()
            os.makedirs(SET_DIR, exist_ok=True)
            with open(SET_FILE, "w", encoding="utf-8") as f:
                json.dump(s, f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    # ------------------------------------------------------------ 화면 만들기
    def build(self):
        main = tk.PanedWindow(self.root, orient="horizontal", sashwidth=6, bg="#cfd8dc", bd=0)
        main.pack(fill="both", expand=True)
        # 왼쪽: 설정 (스크롤)
        lf = tk.Frame(main, bg="#eceff1")
        cv = tk.Canvas(lf, bg="#eceff1", highlightthickness=0, width=400)
        sb = ttk.Scrollbar(lf, orient="vertical", command=cv.yview)
        inner = tk.Frame(cv, bg="#eceff1")
        inner.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))
        cv.create_window((0, 0), window=inner, anchor="nw", width=392)
        cv.configure(yscrollcommand=sb.set)
        cv.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        cv.bind_all("<MouseWheel>", lambda e: cv.yview_scroll(int(-e.delta / 120), "units") if str(e.widget).startswith(str(lf)) else None)
        main.add(lf, minsize=360)

        cards = {}
        for key, title in (("dev", "① 장비"), ("sig", "② 신호"), ("rf", "③ RF · 손실"), ("bench", "④ PA Bench 기록 → Pout"),
                           ("dpd", "⑤ DPD (메모리 다항식 / GMP)")):
            c = ttk.LabelFrame(inner, text=title, style="Card.TLabelframe", padding=(10, 6))
            c.pack(fill="x", padx=8, pady=(8, 0))
            c.columnconfigure(1, weight=1)
            cards[key] = c
        row = {k: 0 for k in cards}
        # 신호: 만든 NR 1C / 내 .wv
        c = cards["sig"]
        self.v["sig_src"] = tk.StringVar(value=self.s.get("sig_src", "nr"))
        self.v["wv_path"] = tk.StringVar(value=self.s.get("wv_path", ""))
        sf = ttk.Frame(c, style="Card.TFrame")
        sf.grid(row=0, column=0, columnspan=3, sticky="ew")
        ttk.Radiobutton(sf, text="NR 100 MHz 1C 만들기", variable=self.v["sig_src"], value="nr").pack(side="left")
        ttk.Radiobutton(sf, text="내 .wv 파일", variable=self.v["sig_src"], value="file").pack(side="left", padx=(10, 0))
        ff = ttk.Frame(c, style="Card.TFrame")
        ff.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(2, 4))
        ttk.Button(ff, text="불러오기…", command=self.pick_wv).pack(side="left")
        self.lbl_wv = ttk.Label(ff, text="", style="Unit.TLabel", wraplength=280)
        self.lbl_wv.pack(side="left", padx=(6, 0))
        af = ttk.Frame(c, style="Card.TFrame")
        af.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(0, 4))
        ttk.Label(af, text="ACLR: 채널 대역", style="Card.TLabel").pack(side="left")
        self.v["ch_bw_mhz"] = tk.StringVar(value=str(self.s.get("ch_bw_mhz", "98.28")))
        ttk.Entry(af, textvariable=self.v["ch_bw_mhz"], width=7, justify="right").pack(side="left", padx=3)
        ttk.Label(af, text="MHz · 인접 간격", style="Card.TLabel").pack(side="left")
        self.v["adj_mhz"] = tk.StringVar(value=str(self.s.get("adj_mhz", "100")))
        ttk.Entry(af, textvariable=self.v["adj_mhz"], width=6, justify="right").pack(side="left", padx=3)
        ttk.Label(af, text="MHz", style="Unit.TLabel").pack(side="left")
        self.v["sig_src"].trace_add("write", lambda *a: self.sig_src_changed())
        self.v["wv_path"].trace_add("write", lambda *a: self.sig_src_changed())
        ttk.Label(c, text="캐리어", style="Card.TLabel").grid(row=3, column=0, sticky="w", pady=2)
        self.v["carrier"] = tk.StringVar(value="1C (100 MHz 1개)")
        cb = ttk.Combobox(c, textvariable=self.v["carrier"], values=["1C (100 MHz 1개)", "2C (다음 버전)"], state="readonly", width=18)
        cb.grid(row=3, column=1, sticky="w")
        cb.bind("<<ComboboxSelected>>", lambda e: self.v["carrier"].set("1C (100 MHz 1개)"))
        row["sig"] = 4
        for key, name, dflt, unit, card in self.FIELDS:
            c = cards[card]
            r = row[card]
            ttk.Label(c, text=name, style="Card.TLabel").grid(row=r, column=0, sticky="w", pady=2, padx=(0, 6))
            var = tk.StringVar(value=str(self.s.get(key, dflt)))
            self.v[key] = var
            if key == "mod":
                w = ttk.Combobox(c, textvariable=var, values=["QPSK", "16QAM", "64QAM", "256QAM"], state="readonly", width=10)
            elif key == "os":
                w = ttk.Combobox(c, textvariable=var, values=["2", "3", "4"], state="readonly", width=4)
            else:
                w = ttk.Entry(c, textvariable=var, width=12 if card == "dev" else 8, justify="left" if card == "dev" else "right")
            w.grid(row=r, column=1, sticky="w")
            u = ttk.Label(c, text=self.OS_TXT.get(var.get(), "") if key == "os" else unit, style="Unit.TLabel")
            u.grid(row=r, column=2, sticky="w", padx=(4, 0))
            if key == "os":
                var.trace_add("write", lambda *a, u=u, var=var: u.configure(text=self.OS_TXT.get(var.get(), "")))
            row[card] = r + 1
        c = cards["sig"]
        self.v["cfr_on"] = tk.BooleanVar(value=bool(self.s.get("cfr_on", True)))
        ttk.Checkbutton(c, text="CFR 사용 (클리핑 + 필터로 PAPR 줄이기)", variable=self.v["cfr_on"], style="Card.TCheckbutton").grid(
            row=row["sig"], column=0, columnspan=3, sticky="w", pady=(2, 0))
        bf = ttk.Frame(c, style="Card.TFrame")
        bf.grid(row=row["sig"] + 1, column=0, columnspan=3, sticky="ew", pady=(6, 0))
        ttk.Button(bf, text="신호 만들기", command=self.make_signal).pack(side="left")
        ttk.Button(bf, text=".wv 저장…", command=self.save_wv_orig).pack(side="left", padx=4)
        self.lbl_sig = ttk.Label(c, text="", style="Unit.TLabel", wraplength=360)
        self.lbl_sig.grid(row=row["sig"] + 2, column=0, columnspan=3, sticky="w", pady=(4, 0))
        # 케이블 손실: Bench 표
        c = cards["rf"]
        self.v["bench_loss"] = tk.BooleanVar(value=bool(self.s.get("bench_loss", True)))
        ttk.Checkbutton(c, text="손실 = PA Bench Monitor 손실 표 사용", variable=self.v["bench_loss"],
                        style="Card.TCheckbutton", command=self.apply_bench_loss).grid(row=row["rf"], column=0, columnspan=3, sticky="w", pady=(4, 0))
        self.lbl_loss = ttk.Label(c, text="", style="Unit.TLabel", wraplength=360)
        self.lbl_loss.grid(row=row["rf"] + 1, column=0, columnspan=3, sticky="w")
        self.v["freq_ghz"].trace_add("write", lambda *a: self.apply_bench_loss())
        # Bench 기록 → Pout
        c = cards["bench"]
        ttk.Label(c, text="샘플 종류", style="Card.TLabel").grid(row=0, column=0, sticky="w", pady=2)
        self.v["b_stype"] = tk.StringVar(value=self.s.get("b_stype", ""))
        self.cb_stype = ttk.Combobox(c, textvariable=self.v["b_stype"], state="readonly", width=16)
        self.cb_stype.grid(row=0, column=1, sticky="w")
        self.cb_stype.bind("<<ComboboxSelected>>", lambda e: self.load_records())
        ttk.Button(c, text="새로 읽기", command=self.bench_refresh).grid(row=0, column=2, sticky="w", padx=(4, 0))
        ttk.Label(c, text="기록", style="Card.TLabel").grid(row=1, column=0, sticky="w", pady=2)
        self.v["b_rec"] = tk.StringVar(value="")
        self.cb_rec = ttk.Combobox(c, textvariable=self.v["b_rec"], state="readonly", width=30)
        self.cb_rec.grid(row=1, column=1, columnspan=2, sticky="w")
        self.cb_rec.bind("<<ComboboxSelected>>", lambda e: self.show_rec())
        self.lbl_rec = ttk.Label(c, text="", style="Unit.TLabel", wraplength=360)
        self.lbl_rec.grid(row=2, column=0, columnspan=3, sticky="w")
        tf_ = ttk.Frame(c, style="Card.TFrame")
        tf_.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(4, 0))
        ttk.Label(tf_, text="목표 Pout", style="Card.TLabel").pack(side="left")
        self.v["b_target"] = tk.StringVar(value=str(self.s.get("b_target", "")))
        ttk.Entry(tf_, textvariable=self.v["b_target"], width=7, justify="right").pack(side="left", padx=3)
        ttk.Label(tf_, text="dBm", style="Unit.TLabel").pack(side="left")
        ttk.Button(tf_, text="→ SG 레벨 정하기", command=self.sg_from_target).pack(side="left", padx=(6, 0))
        self.v["auto_cal"] = tk.BooleanVar(value=bool(self.s.get("auto_cal", True)))
        ttk.Checkbutton(c, text="DPD OFF 측정 때 Pout 보정을 이 기록에 맞춤", variable=self.v["auto_cal"],
                        style="Card.TCheckbutton").grid(row=4, column=0, columnspan=3, sticky="w", pady=(4, 0))
        self.recs = []
        self.bench = None
        c = cards["dpd"]
        self.v["odd_only"] = tk.BooleanVar(value=bool(self.s.get("odd_only", False)))
        ttk.Checkbutton(c, text="홀수 차수만 (K = 1, 3, 5, …)", variable=self.v["odd_only"], style="Card.TCheckbutton").grid(
            row=row["dpd"], column=0, columnspan=3, sticky="w", pady=(2, 0))
        # 실행
        run = ttk.LabelFrame(inner, text="⑥ 실행", style="Card.TLabelframe", padding=(10, 8))
        run.pack(fill="x", padx=8, pady=(8, 8))
        self.btn_off = ttk.Button(run, text="DPD OFF 측정만", command=lambda: self.start(False))
        self.btn_off.grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self.btn_go = ttk.Button(run, text="▶ DPD 실행 (OFF → 반복)", style="Go.TButton", command=lambda: self.start(True))
        self.btn_go.grid(row=0, column=1, sticky="ew")
        self.btn_stop = ttk.Button(run, text="■ 중지", style="Stop.TButton", command=self.stop, state="disabled")
        self.btn_stop.grid(row=1, column=0, sticky="ew", padx=(0, 4), pady=(4, 0))
        ttk.Button(run, text="SG RF OFF", command=self.rf_off).grid(row=1, column=1, sticky="ew", pady=(4, 0))
        sv = ttk.Frame(run, style="Card.TFrame")
        sv.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        ttk.Button(sv, text="결과 엑셀 저장…", command=self.save_xlsx).pack(side="left")
        ttk.Button(sv, text="DPD 신호 .wv…", command=self.save_wv_dpd).pack(side="left", padx=4)
        ttk.Button(sv, text="계수 CSV…", command=self.save_coef).pack(side="left")
        self.v["rf_off_end"] = tk.BooleanVar(value=bool(self.s.get("rf_off_end", True)))
        ttk.Checkbutton(run, text="끝나면 SG RF OFF", variable=self.v["rf_off_end"], style="Card.TCheckbutton").grid(
            row=3, column=0, columnspan=2, sticky="w", pady=(6, 0))
        run.columnconfigure(0, weight=1)
        run.columnconfigure(1, weight=1)

        # 오른쪽: 결과 표 + 그래프 + 로그
        rf = tk.Frame(main, bg="#eceff1")
        main.add(rf, minsize=600)
        top = tk.Frame(rf, bg="#eceff1")
        top.pack(fill="x", padx=8, pady=(8, 4))
        self.big = {}
        for k, name in (("aclr", "ACLR (L / U)"), ("evm", "EVM"), ("pout", "Pout"), ("papr", "PAPR")):
            f = tk.Frame(top, bg="white", highlightthickness=1, highlightbackground="#cfd8dc")
            f.pack(side="left", fill="x", expand=True, padx=(0, 6))
            tk.Label(f, text=name, bg="white", fg="#607d8b", font=("맑은 고딕", 9)).pack(anchor="w", padx=8, pady=(4, 0))
            a = tk.Label(f, text="-", bg="white", fg="#9e9e9e", font=("맑은 고딕", 15, "bold"))
            a.pack(anchor="w", padx=8)
            b = tk.Label(f, text="", bg="white", fg="#1565c0", font=("맑은 고딕", 9))
            b.pack(anchor="w", padx=8, pady=(0, 4))
            self.big[k] = (a, b)
        cols = ("label", "sg", "pin", "pout", "gain", "aclr_l", "aclr_u", "evm", "papr", "nmse", "t")
        heads = ("단계", "SG dBm", "Pin dBm", "Pout dBm", "Gain dB", "ACLR L dBc", "ACLR U dBc", "EVM %", "PAPR dB", "학습 NMSE dB", "시각")
        tf = tk.Frame(rf, bg="#eceff1")
        tf.pack(fill="x", padx=8)
        self.tree = ttk.Treeview(tf, columns=cols, show="headings", height=6)
        for c_, h in zip(cols, heads):
            self.tree.heading(c_, text=h)
            self.tree.column(c_, width=78 if c_ != "label" else 84, anchor="center")
        self.tree.pack(fill="x")
        lg = tk.Frame(rf, bg="#eceff1")
        lg.pack(side="bottom", fill="x", padx=8, pady=(0, 8))
        self.txt = tk.Text(lg, height=7, font=("Consolas", 9), bg="#263238", fg="#eceff1", relief="flat", wrap="none")
        self.txt.pack(fill="x")
        gp = tk.Frame(rf, bg="#eceff1")
        gp.pack(fill="both", expand=True, padx=8, pady=6)
        gp.columnconfigure(0, weight=3)
        gp.columnconfigure(1, weight=2)
        gp.rowconfigure(0, weight=1)
        gp.rowconfigure(1, weight=1)
        self.p_spec = Plot(gp, "스펙트럼 (채널 최고 = 0 dB)", "주파수 오프셋 MHz", "dB")
        self.p_spec.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=(0, 6))
        self.p_trend = Plot(gp, "반복별 ACLR (0 = DPD OFF)", "반복", "dBc")
        self.p_trend.grid(row=0, column=1, sticky="nsew", pady=(0, 6))
        self.p_amam = Plot(gp, "AM-AM (원래 신호 → PA 출력, 작은 신호 이득 = 0)", "입력 dB (최고값 기준)", "dB")
        self.p_amam.grid(row=1, column=0, sticky="nsew", padx=(0, 6))
        self.p_ampm = Plot(gp, "AM-PM", "입력 dB (최고값 기준)", "°")
        self.p_ampm.grid(row=1, column=1, sticky="nsew")
        self.log("%s %s - 주소에 demo 를 넣으면 장비 없이 가상 PA 로 확인합니다." % (APP, VERSION))
        self.sig_src_changed()
        self.bench_refresh()

    # ------------------------------------------------------------ 신호 파일
    def pick_wv(self):
        p = filedialog.askopenfilename(title=".wv 불러오기 (암호화 안 된 R&S 파형)", filetypes=[("R&S waveform", "*.wv")],
                                       initialdir=self.s.get("wv_dir") or None)
        if not p:
            return
        try:
            x, fs = E.C.read_wv(p)
        except Exception as e:
            messagebox.showerror(APP, str(e))
            return
        self.s["wv_dir"] = os.path.dirname(p)
        self.v["wv_path"].set(p)
        self.v["sig_src"].set("file")
        self.log("불러옴: %s (%d 샘플 · %.2f MSps)" % (p, len(x), fs / 1e6))

    def sig_src_changed(self):
        f = self.v["sig_src"].get() == "file"
        p = self.v["wv_path"].get()
        self.lbl_wv.configure(text=(os.path.basename(p) if p else "(파일 없음)") if f else "")
        if f and p and os.path.isfile(p):
            try:
                raw = open(p, "rb").read(4096).decode("latin-1")
                i = raw.find("{CLOCK:")
                fs = float(raw[i + 7:raw.find("}", i)]) if i >= 0 else float("nan")
                self.lbl_wv.configure(text="%s · %.2f MSps" % (os.path.basename(p), fs / 1e6))
            except Exception:
                pass
        if self.engine is not None:
            self.engine.sig = None

    # ------------------------------------------------------------ PA Bench 연동
    def bench_refresh(self):
        self.bench = BL.load_settings()
        if not self.bench:
            self.cb_stype.configure(values=[])
            self.lbl_rec.configure(text="PA Bench Monitor 설정을 찾지 못했습니다 (%s)" % BL.BENCH_SET)
            self.lbl_loss.configure(text="")
            return
        names = BL.sample_types(self.bench)
        self.cb_stype.configure(values=names)
        if self.v["b_stype"].get() not in names:
            self.v["b_stype"].set(self.bench.get("stype") if self.bench.get("stype") in names else (names[0] if names else ""))
        self.apply_bench_loss()
        self.load_records()

    def apply_bench_loss(self):
        if not hasattr(self, "lbl_loss"):
            return
        on = bool(self.v["bench_loss"].get())
        if not on:
            self.lbl_loss.configure(text="손실은 위 칸 값 사용")
            return
        r = BL.losses_at(self.bench, fnum(self.v["freq_ghz"].get(), float("nan"))) if self.bench else None
        if r is None:
            self.lbl_loss.configure(text="PA Bench Monitor 손실 표 없음 → 위 칸 값 사용")
            return
        li, lo, how = r
        self.v["in_loss_db"].set("%.2f" % li)
        self.v["out_loss_db"].set("%.2f" % lo)
        self.lbl_loss.configure(text="In %.2f dB · Out %.2f dB  (%s)" % (li, lo, how))

    def load_records(self):
        self.recs = []
        st = self.v["b_stype"].get()
        pam = BL.latest_pam(self.bench, st) if (self.bench and st) else None
        if not pam:
            self.cb_rec.configure(values=[])
            self.v["b_rec"].set("")
            self.lbl_rec.configure(text="이 샘플 종류의 .pam 기록이 없습니다" if st else "")
            return
        try:
            recs = BL.read_records(pam)
        except Exception as e:
            self.lbl_rec.configure(text=".pam 읽기 실패: %s" % e)
            return
        g = fnum(self.v["freq_ghz"].get(), float("nan"))
        # 지금 주파수에 가까운 것 · Mod. · 최근 순서
        recs.sort(key=lambda r: r["when"], reverse=True)
        recs.sort(key=lambda r: (abs(r["freq_ghz"] - g) if (g == g and r["freq_ghz"] == r["freq_ghz"]) else 99, 0 if r["mod"] else 1))
        self.recs = recs
        labels = ["%s · %.6g GHz%s" % (r["display"], r["freq_ghz"], "" if r["mod"] else " (Pulse)") for r in recs]
        self.cb_rec.configure(values=labels)
        self.v["b_rec"].set(labels[0] if labels else "")
        self.pam_path = pam
        self.show_rec()

    def cur_rec(self):
        labels = list(self.cb_rec.cget("values") or [])
        cur = self.v["b_rec"].get()
        if cur in labels and labels.index(cur) < len(self.recs):
            return self.recs[labels.index(cur)]
        return None

    def show_rec(self):
        r = self.cur_rec()
        if r is None:
            self.lbl_rec.configure(text="")
            return
        self.lbl_rec.configure(text="%s · SG %.1f ~ %.1f dBm → Pout %.1f ~ %.1f dBm (%d점)%s"
                               % (os.path.basename(getattr(self, "pam_path", "")), min(r["sg"]), max(r["sg"]),
                                  min(r["pout"]), max(r["pout"]), len(r["sg"]),
                                  "" if r["mod"] else " · ⚠ Pulse 기록 (모듈레이션 기록이 더 맞음)"))

    def sg_from_target(self):
        r = self.cur_rec()
        t = fnum(self.v["b_target"].get(), float("nan"))
        if r is None or t != t:
            messagebox.showinfo(APP, "기록을 고르고 목표 Pout 을 넣으세요.")
            return
        sg = BL.sg_for_pout(r, t)
        if sg != sg:
            return
        out = t > max(r["pout"]) or t < min(r["pout"])
        mx = fnum(self.v["sg_max_dbm"].get(), 0.0)
        if sg > mx:
            messagebox.showwarning(APP, "필요한 SG %.2f dBm 이 SG 최대 %.2f dBm 보다 큽니다." % (sg, mx))
            return
        self.v["sg_dbm"].set("%.2f" % sg)
        self.log("목표 Pout %.2f dBm → SG %.2f dBm (Bench 기록 보간%s)" % (t, sg, ", 기록 범위 밖 - 연장" if out else ""))

    # ------------------------------------------------------------ 값 모으기
    def params(self):
        p = {}
        for key, name, dflt, unit, card in self.FIELDS:
            val = self.v[key].get().strip()
            if key in ("smw_host", "fsw_host", "mod", "fsw_att_db"):
                p[key] = val
            elif key in ("n_sym", "os", "K", "M", "L", "iters", "n_fit"):
                p[key] = int(fnum(val, float(dflt)))
            else:
                p[key] = fnum(val, float(dflt))
        p["cfr_on"] = bool(self.v["cfr_on"].get())
        p["odd_only"] = bool(self.v["odd_only"].get())
        p["sig_src"] = self.v["sig_src"].get()
        p["wv_path"] = self.v["wv_path"].get()
        if p["sig_src"] == "file" and not os.path.isfile(p["wv_path"]):
            raise ValueError("불러올 .wv 파일을 고르세요")
        p["ch_bw_mhz"] = fnum(self.v["ch_bw_mhz"].get(), 98.28)
        p["adj_mhz"] = fnum(self.v["adj_mhz"].get(), 100.0)
        if p["sig_src"] == "nr":
            p["ch_bw_mhz"], p["adj_mhz"] = 98.28, 100.0
        p["rec"] = self.cur_rec()
        p["auto_cal"] = bool(self.v["auto_cal"].get()) and p["rec"] is not None
        if p["K"] < 1 or p["M"] < 1 or p["n_sym"] < 2:
            raise ValueError("K, M 은 1 이상 · 심볼 수는 2 이상")
        return p

    def log(self, s):
        self.txt.insert("end", time.strftime("%H:%M:%S  ") + s + "\n")
        self.txt.see("end")

    # ------------------------------------------------------------ 실행
    def busy(self, on):
        self.btn_go.configure(state="disabled" if on else "normal")
        self.btn_off.configure(state="disabled" if on else "normal")
        self.btn_stop.configure(state="normal" if on else "disabled")

    def get_engine(self, p):
        if self.engine is None or self.engine.p.get("smw_host") != p["smw_host"] or self.engine.p.get("fsw_host") != p["fsw_host"]:
            if self.engine is not None:
                self.engine.close()
            self.engine = E.Engine(p, log=lambda s: self.q.put(("log", s)), on_result=lambda r: self.q.put(("res", r)))
        else:
            sig_keys = ("os", "n_sym", "mod", "cfr_on", "papr_db", "K", "M", "L", "odd_only", "lam", "sig_src", "wv_path")
            if any(self.engine.p.get(k) != p[k] for k in sig_keys):
                self.engine.sig = None            # 신호 · 모델이 바뀌면 다시 만들기
            self.engine.p.update(p)
        return self.engine

    def make_signal(self):
        if E is None or self.worker:
            return
        try:
            p = self.params()
        except ValueError as e:
            messagebox.showwarning(APP, str(e))
            return
        eng = self.get_engine(p)
        self.busy(True)

        def job():
            try:
                sig = eng.make_signal()
                self.q.put(("sig", "%d 샘플 · %.2f MSps · 길이 %.3f ms · PAPR %.2f dB"
                            % (len(sig.x), sig.fs / 1e6, len(sig.x) / sig.fs * 1e3, E.C.papr(sig.x))))
            except Exception as e:
                self.q.put(("err", "신호 만들기 실패: %s" % e))
            self.q.put(("done", None))
        self.worker = threading.Thread(target=job, daemon=True)
        self.worker.start()

    def start(self, do_dpd):
        if E is None or self.worker:
            return
        try:
            p = self.params()
        except ValueError as e:
            messagebox.showwarning(APP, str(e))
            return
        if p["sg_dbm"] > p["sg_max_dbm"]:
            messagebox.showwarning(APP, "SG 레벨 (%.2f) 이 SG 최대 (%.2f) 보다 큽니다." % (p["sg_dbm"], p["sg_max_dbm"]))
            return
        self.save_settings()
        eng = self.get_engine(p)
        self.results = []
        for i in self.tree.get_children():
            self.tree.delete(i)
        self.busy(True)
        rf_end = bool(self.v["rf_off_end"].get())

        def job():
            try:
                if eng.sig is None:
                    sig = eng.make_signal()
                    self.q.put(("sig", "%d 샘플 · %.2f MSps · PAPR %.2f dB" % (len(sig.x), sig.fs / 1e6, E.C.papr(sig.x))))
                eng.run(do_dpd)
                self.q.put(("log", "✔ 끝"))
            except E.Stop:
                self.q.put(("log", "■ 중지됨"))
            except Exception as e:
                self.q.put(("err", "측정 실패: %s" % e))
            finally:
                if rf_end:
                    eng.rf_off()
                self.q.put(("done", None))
        self.worker = threading.Thread(target=job, daemon=True)
        self.worker.start()

    def stop(self):
        if self.engine:
            self.engine.stop = True
            self.log("중지 요청 - 지금 단계가 끝나면 멈춥니다")

    def rf_off(self):
        if self.engine and not self.worker:
            self.engine.rf_off()
        elif self.engine:
            self.stop()

    def pump(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "log":
                    self.log(val)
                elif kind == "err":
                    self.log("✖ " + val)
                    messagebox.showerror(APP, val)
                elif kind == "sig":
                    self.lbl_sig.configure(text=val)
                elif kind == "res":
                    self.add_result(val)
                elif kind == "done":
                    self.worker = None
                    self.busy(False)
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    # ------------------------------------------------------------ 결과 표시
    def add_result(self, r):
        self.results.append(r)
        f = lambda v, n=2: ("%.*f" % (n, v)) if isinstance(v, (int, float)) and v is not None and math.isfinite(v) else "-"
        self.tree.insert("", "end", values=(r["label"], f(r["sg"]), f(r["pin"]), f(r["pout"]), f(r["gain"]),
                                             f(r["aclr_l"], 1), f(r["aclr_u"], 1), f(r["evm"]), f(r["papr"]),
                                             f(r["nmse"], 1) if r.get("nmse") is not None else "-", r["t"]))
        off = self.results[0]
        last = r
        a, b = self.big["aclr"]
        a.configure(text="%.1f / %.1f dBc" % (last["aclr_l"], last["aclr_u"]), fg="#1565c0" if last is not off else "#455a64")
        b.configure(text=("DPD OFF %.1f / %.1f → 개선 %.1f dB" % (off["aclr_l"], off["aclr_u"],
                          max(off["aclr_l"], off["aclr_u"]) - max(last["aclr_l"], last["aclr_u"]))) if last is not off else "DPD OFF")
        a, b = self.big["evm"]
        a.configure(text="%.2f %%%s" % (last["evm"], "" if last.get("evm_kind", "OFDM") == "OFDM" else " (파형)"),
                    fg="#1565c0" if last is not off else "#455a64")
        b.configure(text=("DPD OFF %.2f %%" % off["evm"]) if last is not off else "")
        a, b = self.big["pout"]
        a.configure(text="%.2f dBm" % last["pout"], fg="#263238")
        rp = last.get("rec_pout")
        b.configure(text="Gain %.2f dB · Pin %.2f dBm%s" % (last["gain"], last["pin"],
                    (" · 기록 %.2f" % rp) if isinstance(rp, float) and math.isfinite(rp) else ""))
        if isinstance(last.get("cal_db"), float):
            self.v["cal_db"].set("%.2f" % last["cal_db"])
        a, b = self.big["papr"]
        a.configure(text="%.2f dB" % last["papr"], fg="#263238")
        b.configure(text=("DPD OFF %.2f dB" % off["papr"]) if last is not off else "")
        self.draw()

    def draw(self):
        rs = self.results
        if not rs:
            return
        off, last = rs[0], rs[-1]
        ser = []
        for i, r in enumerate(rs[1:-1]):
            ser.append(dict(x=r["spec_f"], y=r["spec_db"], color=C_ITER[min(i, len(C_ITER) - 1)]))
        ser.append(dict(x=off["spec_f"], y=off["spec_db"], color=C_OFF, width=2, label="DPD OFF"))
        if last is not off:
            ser.append(dict(x=last["spec_f"], y=last["spec_db"], color=C_DPD, width=2, label=last["label"]))
        fmax = max(abs(off["spec_f"][0]), abs(off["spec_f"][-1]))
        cb_, ad_ = off.get("ch_bw", 98.28) / 2, off.get("adj", 100.0)
        self.p_spec.set(ser, xr=(-fmax, fmax), yr=(-90, 5), vlines=[(-ad_ - cb_, "#ef9a9a"), (-cb_, "#90caf9"), (cb_, "#90caf9"),
                                                                    (ad_ + cb_, "#ef9a9a")])
        its = [r["it"] for r in rs]
        self.p_trend.set([dict(x=its, y=[r["aclr_l"] for r in rs], color="#e53935", width=2, label="ACLR L"),
                          dict(x=its, y=[r["aclr_u"] for r in rs], color="#fb8c00", width=2, label="ACLR U"),
                          dict(x=its, y=[r["aclr_l"] for r in rs], color="#e53935", dots=True, r=3),
                          dict(x=its, y=[r["aclr_u"] for r in rs], color="#fb8c00", dots=True, r=3)],
                         xr=(-0.2, max(its) + 0.2 if max(its) > 0 else 1))
        ser = [dict(x=off["am_x"], y=off["am_g"], color=C_OFF, dots=True, label="DPD OFF")]
        if last is not off:
            ser.append(dict(x=last["am_x"], y=last["am_g"], color=C_DPD, dots=True, label=last["label"]))
        g0 = sorted(off["am_g"])[len(off["am_g"]) // 2] if off["am_g"] else 0
        self.p_amam.set(ser, xr=(-30, 1), yr=(g0 - 4, g0 + 3))
        ser = [dict(x=off["am_x"], y=off["am_p"], color=C_OFF, dots=True, label="DPD OFF")]
        if last is not off:
            ser.append(dict(x=last["am_x"], y=last["am_p"], color=C_DPD, dots=True, label=last["label"]))
        self.p_ampm.set(ser, xr=(-30, 1), yr=(-20, 20))

    # ------------------------------------------------------------ 저장
    def ask(self, title, ext, ft, name):
        return filedialog.asksaveasfilename(title=title, defaultextension=ext, filetypes=ft, initialfile=name,
                                            initialdir=self.s.get("save_dir") or None)

    def remember_dir(self, path):
        if path:
            self.s["save_dir"] = os.path.dirname(path)

    def stamp(self):
        return time.strftime("%Y%m%d_%H%M")

    def save_wv_orig(self):
        if not self.engine or self.engine.sig is None:
            messagebox.showinfo(APP, "먼저 [신호 만들기] 를 누르세요.")
            return
        p = self.ask(".wv 저장", ".wv", [("R&S waveform", "*.wv")], "NR100M_1C_%s.wv" % self.stamp())
        if p:
            E.C.write_wv(p, self.engine.sig.x, self.engine.sig.fs, "NR 100 MHz 1C (PA DPD Tester)")
            self.remember_dir(p)
            self.log("저장: %s" % p)

    def save_wv_dpd(self):
        pd = getattr(self.engine, "last_pd", None) if self.engine else None
        if pd is None:
            messagebox.showinfo(APP, "DPD 를 실행한 뒤에 저장할 수 있습니다.")
            return
        p = self.ask("DPD 신호 .wv 저장", ".wv", [("R&S waveform", "*.wv")], "NR100M_1C_DPD_%s.wv" % self.stamp())
        if p:
            E.C.write_wv(p, pd, self.engine.sig.fs, "NR 100 MHz 1C + DPD (PA DPD Tester)")
            self.remember_dir(p)
            self.log("저장: %s  (SG 레벨은 표의 마지막 SG 값으로)" % p)

    def save_coef(self):
        m = self.engine.model if self.engine else None
        if m is None or m.w is None:
            messagebox.showinfo(APP, "DPD 를 실행한 뒤에 저장할 수 있습니다.")
            return
        p = self.ask("DPD 계수 저장", ".csv", [("CSV", "*.csv")], "DPD_coef_%s.csv" % self.stamp())
        if p:
            names = m.term_names()
            with open(p, "w", encoding="utf-8-sig") as f:
                f.write("# K=%d M=%d L=%d odd=%s lambda=%g\nterm,re,im\n" % (m.K, m.M, m.L, m.odd, m.lam))
                for nm, c in zip(names, m.w):
                    f.write("%s,%.9e,%.9e\n" % (nm, c.real, c.imag))
            self.remember_dir(p)
            self.log("저장: %s" % p)

    def save_xlsx(self):
        if not self.results:
            messagebox.showinfo(APP, "저장할 결과가 없습니다.")
            return
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
        except ImportError:
            messagebox.showerror(APP, "openpyxl 이 없습니다.")
            return
        path = self.ask("결과 엑셀 저장", ".xlsx", [("Excel", "*.xlsx")], "DPD_%s.xlsx" % self.stamp())
        if not path:
            return
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "결과"
        p = self.params()
        ws.append(["PA DPD Tester %s" % VERSION, time.strftime("%Y-%m-%d %H:%M")])
        ws.append(["신호", "NR 100 MHz 1C · %s · %d 심볼 · ×%d · CFR %s %.1f dB" % (p["mod"], p["n_sym"], p["os"], "ON" if p["cfr_on"] else "OFF", p["papr_db"])])
        ws.append(["DPD", "K=%d M=%d L=%d %s λ=%g μ=%g 반복 %d" % (p["K"], p["M"], p["L"], "홀수만" if p["odd_only"] else "", p["lam"], p["mu"], p["iters"])])
        ws.append(["RF", "%.4f GHz · 입력 손실 %.2f dB · 출력 손실 %.2f dB · 보정 %.2f dB" % (p["freq_ghz"], p["in_loss_db"], p["out_loss_db"], p["cal_db"])])
        ws.append([])
        hd = ["단계", "SG dBm", "Pin dBm", "Pout dBm", "Gain dB", "ACLR L dBc", "ACLR U dBc", "EVM %", "PAPR dB", "학습 NMSE dB", "시각"]
        ws.append(hd)
        for c in ws[ws.max_row]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="1565C0")
            c.alignment = Alignment(horizontal="center")
        for r in self.results:
            ws.append([r["label"], round(r["sg"], 2), round(r["pin"], 2), round(r["pout"], 2), round(r["gain"], 2),
                       round(r["aclr_l"], 2), round(r["aclr_u"], 2), round(r["evm"], 3), round(r["papr"], 2),
                       round(r["nmse"], 2) if r.get("nmse") is not None else None, r["t"]])
        for col, w in zip("ABCDEFGHIJK", (10, 9, 9, 10, 9, 11, 11, 8, 9, 12, 9)):
            ws.column_dimensions[col].width = w
        ws2 = wb.create_sheet("스펙트럼")
        ws2.append(["MHz"] + [r["label"] + " dB" for r in self.results])
        for i, fval in enumerate(self.results[0]["spec_f"]):
            ws2.append([round(fval, 3)] + [round(r["spec_db"][i], 2) if i < len(r["spec_db"]) else None for r in self.results])
        ws3 = wb.create_sheet("AM-AM AM-PM")
        off, last = self.results[0], self.results[-1]
        ws3.append(["OFF 입력 dB", "OFF 이득 dB", "OFF 위상 °", "", last["label"] + " 입력 dB", "이득 dB", "위상 °"])
        for i in range(max(len(off["am_x"]), len(last["am_x"]))):
            a = [off["am_x"][i], off["am_g"][i], off["am_p"][i]] if i < len(off["am_x"]) else [None] * 3
            b = [last["am_x"][i], last["am_g"][i], last["am_p"][i]] if i < len(last["am_x"]) else [None] * 3
            ws3.append([round(v, 3) if v is not None else None for v in a] + [None] + [round(v, 3) if v is not None else None for v in b])
        try:
            wb.save(path)
        except PermissionError:
            messagebox.showerror(APP, "파일이 열려 있어 저장하지 못했습니다:\n%s" % path)
            return
        self.remember_dir(path)
        self.log("저장: %s" % path)

    def on_close(self):
        if self.worker and self.engine:
            if not messagebox.askyesno(APP, "측정 중입니다. 멈추고 닫을까요?"):
                return
            self.engine.stop = True
        self.save_settings()
        if self.engine:
            self.engine.close()
        self.root.destroy()


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
