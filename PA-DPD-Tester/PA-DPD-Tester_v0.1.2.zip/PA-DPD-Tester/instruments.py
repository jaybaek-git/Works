# -*- coding: utf-8 -*-
"""PA DPD Tester - 장비 제어 (SCPI raw socket 5025, VISA 설치 필요 없음)

SMW200A : .wv 파일을 장비로 보내 ARB 로 재생 (MMEM:DATA → BB:ARB:WAV:SEL → BB:ARB:STAT ON)
FSW     : I/Q Analyzer 로 IQ 받기 (TRAC:IQ:SRAT / RLEN → INIT → TRAC:IQ:DATA:MEM?)
주소에 demo 를 넣으면 가상 장비 + 가상 PA 로 동작
"""
import socket
import time

import numpy as np

import dpd_core as C


class ScpiSocket:
    def __init__(self, host, port=5025, timeout=20.0):
        self.sock = socket.create_connection((host, int(port)), timeout=timeout)
        self.sock.settimeout(timeout)
        self.timeout = timeout
        self.buf = b""

    def write(self, cmd):
        self.sock.sendall((cmd + "\n").encode("ascii"))

    def write_block(self, head, data):
        """head 뒤에 IEEE488.2 binary block (#<n><len><data>) 을 붙여 보냄 (예: MMEM:DATA 'path',)"""
        ln = str(len(data))
        self.sock.sendall(head.encode("ascii") + ("#%d%s" % (len(ln), ln)).encode("ascii") + data + b"\n")

    def query(self, cmd):
        self.write(cmd)
        while b"\n" not in self.buf:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise ConnectionError("장비와의 연결이 끊어졌습니다.")
            self.buf += chunk
        line, self.buf = self.buf.split(b"\n", 1)
        return line.decode("ascii", "replace").strip()

    def _read_exact(self, n):
        parts, have = [self.buf], len(self.buf)
        while have < n:
            chunk = self.sock.recv(1 << 20)
            if not chunk:
                raise ConnectionError("장비와의 연결이 끊어졌습니다.")
            parts.append(chunk)
            have += len(chunk)
        b = b"".join(parts)
        out, self.buf = b[:n], b[n:]
        return out

    def query_block(self, cmd):
        self.write(cmd)
        while self._read_exact(1) != b"#":
            pass
        nd = int(self._read_exact(1))
        ln = int(self._read_exact(nd))
        data = self._read_exact(ln)
        if self.buf[:1] == b"\n":
            self.buf = self.buf[1:]
        return data

    def opc(self):
        return self.query("*OPC?")

    def err(self):
        try:
            return self.query("SYST:ERR?")
        except Exception as e:
            return str(e)

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass


# ---------------------------------------------------------------- SMW200A
class SMW:
    PATH = "/var/user/pa_dpd_tx_%d.wv"

    def __init__(self, host, port=5025):
        self.io = ScpiSocket(host, port, timeout=60.0)
        self.idn = self.io.query("*IDN?")
        self.n = 0

    def load_wave(self, wv_bytes, freq, level, rf_on=True):
        io = self.io
        self.n += 1
        path = self.PATH % (self.n % 2)                  # 파일 이름을 번갈아 써서 ARB 가 꼭 새로 읽게
        io.write("*CLS")
        io.write_block("MMEM:DATA '%s'," % path, wv_bytes)
        io.opc()
        io.write("SOUR1:FREQ %.0f" % freq)
        io.write("SOUR1:POW %.2f" % level)
        io.write("SOUR1:BB:ARB:WAV:SEL '%s'" % path)
        io.write("SOUR1:BB:ARB:STAT ON")
        if rf_on:
            io.write("OUTP1 ON")
        io.opc()
        e = io.err()
        if not e.startswith("0"):
            raise RuntimeError("SMW 오류: %s" % e)

    def set_level(self, level):
        self.io.write("SOUR1:POW %.2f" % level)
        self.io.opc()

    def rf(self, on):
        self.io.write("OUTP1 %s" % ("ON" if on else "OFF"))
        self.io.opc()

    def close(self):
        self.io.close()


# ---------------------------------------------------------------- FSW
class FSW:
    CH = "DPD IQ"

    def __init__(self, host, port=5025):
        self.io = ScpiSocket(host, port, timeout=30.0)
        self.idn = self.io.query("*IDN?")
        self.made = False

    def setup(self, freq, fs, ref_dbm, att_db=None):
        io = self.io
        io.write("*CLS")
        if not self.made:
            io.write("INST:SEL '%s'" % self.CH)
            if not io.err().startswith("0"):
                io.write("INST:CRE IQ, '%s'" % self.CH)      # I/Q Analyzer 채널을 새로 만듦
                io.opc()
            self.made = True
        io.write("FREQ:CENT %.0f" % freq)
        io.write("DISP:TRAC:Y:SCAL:RLEV %.2f" % ref_dbm)
        if att_db is None:
            io.write("INP:ATT:AUTO ON")
        else:
            io.write("INP:ATT %.0f" % att_db)
        io.write("TRAC:IQ:SRAT %.6f" % fs)
        io.write("TRIG:SOUR IMM")
        io.write("INIT:CONT OFF")
        io.opc()
        try:
            return float(io.query("TRAC:IQ:BWID?"))
        except Exception:
            return float("nan")

    def capture(self, n):
        io = self.io
        io.write("TRAC:IQ:RLEN %d" % n)
        io.write("INIT:IMM")
        io.opc()
        io.write("FORM REAL,32")
        io.write("TRAC:IQ:DATA:FORM IQP")
        raw = io.query_block("TRAC:IQ:DATA:MEM? 0,%d" % n)
        v = np.frombuffer(raw, "<f4").astype(float)
        return v[0::2] + 1j * v[1::2]

    def close(self):
        self.io.close()


# ---------------------------------------------------------------- 가상 장비 (demo)
class DemoBench:
    """SMW → (입력 손실) → 가상 PA → (출력 손실) → FSW"""

    def __init__(self):
        from demo_pa import DemoPA
        self.pa = DemoPA()
        self.wave = None
        self.level = -30.0
        self.rf_on = False
        self.freq = 3.6e9
        self.in_loss = 0.5
        self.out_loss = 40.0
        self.rng = np.random.default_rng(7)


class DemoSMW:
    def __init__(self, bench):
        self.b = bench
        self.idn = "Rohde&Schwarz,SMW200A,DEMO,5.30"

    def load_wave(self, wv_bytes, freq, level, rf_on=True):
        import tempfile, os
        fd, p = tempfile.mkstemp(suffix=".wv")
        os.write(fd, wv_bytes)
        os.close(fd)
        x, fs = C.read_wv(p)
        os.remove(p)
        self.b.wave = x
        self.b.freq = freq
        self.b.level = level
        self.b.rf_on = bool(rf_on)
        time.sleep(0.3)

    def set_level(self, level):
        self.b.level = level

    def rf(self, on):
        self.b.rf_on = bool(on)

    def close(self):
        pass


class DemoFSW:
    def __init__(self, bench):
        self.b = bench
        self.idn = "Rohde&Schwarz,FSW-43,DEMO,5.00"
        self.fs = 491.52e6

    def setup(self, freq, fs, ref_dbm, att_db=None):
        self.fs = fs
        return 0.8 * fs

    def capture(self, n):
        b = self.b
        if b.wave is None or not b.rf_on:
            return 1e-6 * (b.rng.standard_normal(n) + 1j * b.rng.standard_normal(n))
        x = b.wave / C.rms(b.wave)
        vin = x * np.sqrt(2 * 50 * 10 ** ((b.level - b.in_loss - 30) / 10))     # SMW RMS = 설정 레벨
        reps = int(np.ceil((n + len(x)) / len(x))) + 1
        y = b.pa(np.tile(vin, reps))[len(x):]                                   # 앞 한 주기는 버림 (메모리 안정)
        s0 = int(b.rng.integers(0, len(x)))
        y = y[s0:s0 + n] * 10 ** (-b.out_loss / 20) * np.exp(1j * b.rng.uniform(0, 2 * np.pi))
        time.sleep(0.2)
        return y

    def close(self):
        pass


def open_pair(smw_host, fsw_host):
    """(smw, fsw) 연결. 둘 중 하나라도 demo 면 둘 다 가상"""
    if str(smw_host).strip().lower() == "demo" or str(fsw_host).strip().lower() == "demo":
        b = DemoBench()
        return DemoSMW(b), DemoFSW(b)
    return SMW(smw_host), FSW(fsw_host)
