# -*- coding: utf-8 -*-
"""PA DPD Tester - 측정 · DPD 반복 (화면 없이 동작, 화면은 콜백으로 결과를 받음)

순서: 신호 만들기 → [DPD OFF 측정] → 반복 { 받은 IQ 로 postdistorter 학습 (ILA) → 예왜곡 신호 보내기 → 측정 }
"""
import math
import time

import numpy as np

import dpd_core as C
import instruments as I


class Stop(Exception):
    pass


DEFAULTS = dict(
    smw_host="demo", fsw_host="demo",
    freq_ghz=3.6, sg_dbm=-10.0, sg_max_dbm=0.0, in_loss_db=0.5, out_loss_db=40.0, cal_db=0.0,
    fsw_ref_dbm=10.0, fsw_att_db="auto",
    os=4, n_sym=28, mod="256QAM", cfr_on=True, papr_db=8.0,
    K=7, M=4, L=1, odd_only=False, lam=1e-6, iters=4, mu=0.7, peak_lim_db=3.0, n_fit=40000,
)


class Engine:
    def __init__(self, p, log=None, on_result=None):
        self.p = dict(DEFAULTS)
        self.p.update(p or {})
        self.log = log or (lambda s: None)
        self.on_result = on_result or (lambda r: None)
        self.stop = False
        self.smw = self.fsw = None
        self.sig = None
        self.model = None
        self.G = None
        self.results = []

    # ------------------------------------------------------------ 준비
    def check(self):
        if self.stop:
            raise Stop()

    def connect(self):
        if self.smw is None:
            self.log("장비 연결: SMW %s · FSW %s" % (self.p["smw_host"], self.p["fsw_host"]))
            self.smw, self.fsw = I.open_pair(self.p["smw_host"], self.p["fsw_host"])
            self.log("  SMW: %s" % self.smw.idn)
            self.log("  FSW: %s" % self.fsw.idn)

    def make_signal(self):
        p = self.p
        t0 = time.time()
        self.sig = C.NRSignal(os=p["os"], n_sym=p["n_sym"], mod=p["mod"])
        pk0 = C.papr(self.sig.x)
        if p["cfr_on"]:
            pk = self.sig.cfr(p["papr_db"])
        else:
            pk = pk0
        self.log("신호: NR 100 MHz 1C · %s · %d 심볼 · %.2f MSps · %d 샘플 · PAPR %.2f → %.2f dB (%.1f초)"
                 % (p["mod"], p["n_sym"], self.sig.fs / 1e6, len(self.sig.x), pk0, pk, time.time() - t0))
        self.model = C.DPDModel(p["K"], p["M"], p["L"], p["odd_only"], p["lam"])
        self.model.w = None
        self.G = None
        return self.sig

    # ------------------------------------------------------------ 한 번 측정
    def measure(self, pd, label, it=0, nmse=None):
        p, sig, x = self.p, self.sig, self.sig.x
        lvl = p["sg_dbm"] + 20 * math.log10(C.rms(pd) / C.rms(x))      # 원래 신호와 같은 크기 비율로 (SMW 는 RMS 를 레벨에 맞춤)
        clipped = False
        if lvl > p["sg_max_dbm"]:
            self.log("  ⚠ SG 레벨 %.2f dBm > 최대 %.2f dBm → 최대로 제한" % (lvl, p["sg_max_dbm"]))
            lvl, clipped = p["sg_max_dbm"], True
        self.check()
        wv = C.write_wv(None, pd, sig.fs, comment="PA DPD Tester %s" % label)
        self.log("  %s: SG %.2f dBm 로 신호 보내는 중 (%.1f MB)…" % (label, lvl, len(wv) / 1e6))
        self.smw.load_wave(wv, p["freq_ghz"] * 1e9, lvl, rf_on=True)
        self.check()
        att = None if str(p["fsw_att_db"]).strip().lower() in ("auto", "") else float(p["fsw_att_db"])
        bw = self.fsw.setup(p["freq_ghz"] * 1e9, sig.fs, p["fsw_ref_dbm"], att)
        n = 2 * len(pd) + 2000
        time.sleep(0.2)
        y = self.fsw.capture(n)
        self.check()
        y_al, g, d = C.align(pd, y)
        if self.G is None:
            self.G = C.small_signal_gain(x, y_al)
        else:
            # 측정마다 SMW · FSW 사이 위상이 달라짐 → 작은 신호 구간 위상을 처음 측정 (DPD OFF) 에 맞춤
            c = C.small_signal_gain(pd, y_al)
            y_al = y_al * np.exp(1j * (np.angle(self.G) - np.angle(c)))
        pout = C.iq_power_dbm(y_al, p["out_loss_db"] + p["cal_db"])
        al, au, full = C.aclr(y_al, sig.fs)
        if bw == bw and bw > 0 and bw / 2 < 149.2e6:
            full = False                           # FSW 분석 대역폭이 인접 채널 끝 (±149.14 MHz) 보다 좁음
        ev = C.evm(sig, y_al)
        f, sdb = C.spectrum_db(y_al, sig.fs)
        xin, gam, pm = C.am_curves(x, y_al, self.G)
        pin = lvl - p["in_loss_db"]
        r = dict(label=label, it=it, sg=lvl, pin=pin, pout=pout, gain=pout - pin, aclr_l=float(al), aclr_u=float(au),
                 aclr_full=bool(full), evm=ev, papr=C.papr(pd), nmse=nmse, delay=d, fsw_bw=bw, clipped=clipped,
                 spec_f=(f / 1e6).tolist(), spec_db=sdb.tolist(), am_x=xin.tolist(), am_g=gam.tolist(), am_p=pm.tolist(),
                 t=time.strftime("%H:%M:%S"))
        self.results.append(r)
        self.log("  %s: Pout %.2f dBm · ACLR %.1f / %.1f dBc · EVM %.2f %% · PAPR %.2f dB%s"
                 % (label, pout, al, au, ev, r["papr"], "" if full else "  (⚠ 샘플레이트 · FSW 대역폭이 모자라 인접 채널 일부만 - ACLR 이 실제보다 좋게 나올 수 있음)"))
        self.on_result(r)
        return y_al, r

    # ------------------------------------------------------------ DPD
    def dpd_signal(self, w):
        x = self.sig.x
        pd = self.model.apply(x, w)
        lim = np.max(np.abs(x)) * 10 ** (self.p["peak_lim_db"] / 20)
        a = np.abs(pd)
        n_clip = int(np.sum(a > lim))
        pd = np.where(a > lim, pd * lim / np.maximum(a, 1e-12), pd)
        return pd, n_clip

    def run(self, do_dpd=True):
        """DPD OFF 측정 → (do_dpd) DPD 반복. 결과 목록 반환"""
        self.stop = False
        self.results = []
        self.connect()
        if self.sig is None:
            self.make_signal()
        x = self.sig.x
        self.log("▶ DPD OFF 측정")
        y_al, r0 = self.measure(x, "DPD OFF", 0)
        if not do_dpd:
            return self.results
        pd, w = x, None
        for it in range(1, int(self.p["iters"]) + 1):
            self.check()
            self.log("▶ DPD 반복 %d / %d" % (it, self.p["iters"]))
            wn, nmse = self.model.fit(y_al / self.G, pd, n_fit=self.p["n_fit"])
            mu = 1.0 if w is None else float(self.p["mu"])
            w = wn if w is None else (1 - mu) * w + mu * wn
            self.model.w = w
            pd, n_clip = self.dpd_signal(w)
            if n_clip:
                self.log("  최고값 제한 (+%.1f dB) 에 걸린 샘플 %d 개" % (self.p["peak_lim_db"], n_clip))
            y_al, r = self.measure(pd, "DPD %d" % it, it, nmse)
        self.last_pd = pd
        return self.results

    def rf_off(self):
        try:
            if self.smw is not None:
                self.smw.rf(False)
                self.log("SG RF OFF")
        except Exception as e:
            self.log("RF OFF 실패: %s" % e)

    def close(self):
        for d in (self.smw, self.fsw):
            try:
                d.close()
            except Exception:
                pass
        self.smw = self.fsw = None
