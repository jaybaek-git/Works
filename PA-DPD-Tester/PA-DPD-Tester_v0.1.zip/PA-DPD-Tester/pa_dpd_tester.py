# -*- coding: utf-8 -*-
"""PA DPD Tester - SMW200A + FSW 로 PA 에 간단한 DPD (메모리 다항식 / GMP) 를 적용해 성능 확인

- 신호: 5G NR 100 MHz 1 캐리어 (SCS 30 kHz, 273 RB) OFDM, CFR, 오버샘플 ×2/×3/×4
- 순서: [DPD OFF 측정] → DPD 반복 (간접 학습 ILA) → 매번 Pout · ACLR · EVM · PAPR
- 장비에는 아무것도 설치하지 않음 (LAN, SCPI raw socket 5025). 주소에 demo = 가상 PA
"""
import json
import math
import os
import queue
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

VERSION = "v0.1"
APP = "PA DPD Tester"

try:
    import dpd_engine as E
except Exception as _e:                     # numpy 가 없는 등
    E = None
    _IMPORT_ERR = _e

SET_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "PADPDTester")
SET_FILE = os.path.join(SET_DIR, "settings.json")

C_OFF = "#9e9e9e"
C_DPD = "#1f77b4"
C_ITER = ["#c6dbef", "#9ecae1", "#6baed6", "#4292c6", "#2171b5", "#08519c"]
FONT = ("맑은 고딕", 9)
FONT_B = ("맑은 고딕", 9, "bold")


def fnum(s, d=0.0):
    try:
        return float(str(s).strip())
    except (ValueError, TypeError):
        return d


# ---------------------------------------------------------------- 간단한 그래프 (Tk Canvas)
class Plot(tk.Canvas):
    def __init__(self, master, title="", xl="", yl="", **kw):
        super().__init__(master, bg="white", highlightthickness=1, highlightbackground="#cfd8dc", **kw)
        self.title, self.xl, self.yl = title, xl, yl
        self.series = []          # dict(x, y, color, width, dots, label)
        self.xr = self.yr = None  # 고정 범위
        self.vlines = []
        self.bind("<Configure>", lambda e: self.redraw())

    def set(self, series, xr=None, yr=None, vlines=()):
        self.series, self.xr, self.yr, self.vlines = series, xr, yr, list(vlines)
        self.redraw()

    @staticmethod
    def nice(lo, hi, n=5):
        if not (math.isfinite(lo) and math.isfinite(hi)) or hi <= lo:
            hi = lo + 1
        span = hi - lo
        raw = span / n
        mag = 10 ** math.floor(math.log10(raw))
        step = min((m * mag for m in (1, 2, 2.5, 5, 10) if m * mag >= raw), default=mag * 10)
        a = math.floor(lo / step) * step
        ticks = []
        v = a
        while v <= hi + step * 1e-6:
            if v >= lo - step * 1e-6:
                ticks.append(round(v, 10))
            v += step
        return ticks

    def redraw(self):
        self.delete("all")
        W, H = self.winfo_width(), self.winfo_height()
        if W < 50 or H < 50:
            return
        L, R, T, B = 52, 12, 24, 34
        self.create_text(L, 12, text=self.title, anchor="w", font=FONT_B, fill="#263238")
        xs = [v for s in self.series for v in s["x"]]
        ys = [v for s in self.series for v in s["y"]]
        if self.xr:
            x0, x1 = self.xr
        elif xs:
            x0, x1 = min(xs), max(xs)
        else:
            x0, x1 = 0, 1
        if self.yr:
            y0, y1 = self.yr
        elif ys:
            y0, y1 = min(ys), max(ys)
            pad = (y1 - y0) * 0.08 or 1
            y0, y1 = y0 - pad, y1 + pad
        else:
            y0, y1 = 0, 1
        if x1 <= x0:
            x1 = x0 + 1
        if y1 <= y0:
            y1 = y0 + 1
        px = lambda v: L + (v - x0) / (x1 - x0) * (W - L - R)
        py = lambda v: H - B - (v - y0) / (y1 - y0) * (H - T - B)
        for t in self.nice(x0, x1, 6):
            self.create_line(px(t), T, px(t), H - B, fill="#eceff1")
            self.create_text(px(t), H - B + 4, text=("%g" % t), anchor="n", font=("맑은 고딕", 8), fill="#607d8b")
        for t in self.nice(y0, y1, 5):
            self.create_line(L, py(t), W - R, py(t), fill="#eceff1")
            self.create_text(L - 4, py(t), text=("%g" % t), anchor="e", font=("맑은 고딕", 8), fill="#607d8b")
        self.create_rectangle(L, T, W - R, H - B, outline="#b0bec5")
        self.create_text((L + W - R) / 2, H - 4, text=self.xl, anchor="s", font=("맑은 고딕", 8), fill="#455a64")
        self.create_text(4, T - 2, text=self.yl, anchor="sw", font=("맑은 고딕", 8), fill="#455a64")
        for v, col in self.vlines:
            if x0 <= v <= x1:
                self.create_line(px(v), T, px(v), H - B, fill=col, dash=(3, 3))
        for s in self.series:
            pts = [(px(a), py(b)) for a, b in zip(s["x"], s["y"])
                   if math.isfinite(a) and math.isfinite(b) and x0 <= a <= x1 and y0 <= b <= y1]
            if not pts:
                continue
            if s.get("dots"):
                r = s.get("r", 1)
                for a, b in pts:
                    self.create_rectangle(a - r, b - r, a + r, b + r, outline="", fill=s["color"])
            elif len(pts) > 1:
                self.create_line(*[c for p in pts for c in p], fill=s["color"], width=s.get("width", 1))
        ly = T + 6
        for s in self.series:
            if s.get("label"):
                self.create_line(W - R - 118, ly, W - R - 100, ly, fill=s["color"], width=3)
                self.create_text(W - R - 96, ly, text=s["label"], anchor="w", font=("맑은 고딕", 8), fill="#263238")
                ly += 14


# ---------------------------------------------------------------- 화면
class App:
    FIELDS = [
        # (키, 이름, 기본값, 단위, 카드)
        ("smw_host", "SMW200A 주소", "demo", "", "dev"),
        ("fsw_host", "FSW 주소", "demo", "", "dev"),
        ("mod", "변조", "256QAM", "", "sig"),
        ("n_sym", "OFDM 심볼 수", "28", "개 (14개 = 0.5 ms)", "sig"),
        ("os", "샘플레이트", "4", "", "sig"),
        ("papr_db", "CFR 목표 PAPR", "8.0", "dB", "sig"),
        ("freq_ghz", "주파수", "3.6", "GHz", "rf"),
        ("sg_dbm", "SG 레벨 (RMS)", "-10", "dBm", "rf"),
        ("sg_max_dbm", "SG 최대", "0", "dBm (넘지 않음)", "rf"),
        ("in_loss_db", "입력 손실 (SG→PA)", "0.5", "dB", "rf"),
        ("out_loss_db", "출력 손실 (PA→FSW)", "40", "dB (감쇠기 포함)", "rf"),
        ("cal_db", "Pout 보정", "0", "dB (파워미터 기준)", "rf"),
        ("fsw_ref_dbm", "FSW Ref Level", "10", "dBm", "rf"),
        ("fsw_att_db", "FSW 감쇠", "auto", "dB 또는 auto", "rf"),
        ("K", "비선형 차수 K", "7", "", "dpd"),
        ("M", "메모리 깊이 M", "4", "탭", "dpd"),
        ("L", "GMP 교차 지연 L", "1", "(0 = 메모리 다항식)", "dpd"),
        ("iters", "반복 횟수", "4", "번", "dpd"),
        ("mu", "섞기 비율 μ", "0.7", "(1 = 새 계수만)", "dpd"),
        ("peak_lim_db", "최고값 제한", "3", "dB (원래 최고값 +)", "dpd"),
        ("lam", "정규화 λ", "1e-6", "", "dpd"),
        ("n_fit", "학습 샘플 수", "40000", "개", "dpd"),
    ]
    OS_TXT = {"2": "×2 = 245.76 MSps (인접 채널 일부만)", "3": "×3 = 368.64 MSps", "4": "×4 = 491.52 MSps (권장)"}

    def __init__(self, root):
        self.root = root
        self.s = self.load_settings()
        root.title("%s %s" % (APP, VERSION))
        root.geometry(self.s.get("geometry", "1420x880"))
        root.configure(bg="#eceff1")
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure(".", font=FONT)
        st.configure("Card.TLabelframe", background="white")
        st.configure("Card.TLabelframe.Label", background="white", font=FONT_B, foreground="#1565c0")
        st.configure("Card.TFrame", background="white")
        st.configure("Card.TLabel", background="white")
        st.configure("Unit.TLabel", background="white", foreground="#78909c", font=("맑은 고딕", 8))
        st.configure("Card.TCheckbutton", background="white")
        st.configure("Go.TButton", font=FONT_B, foreground="white", background="#1e88e5")
        st.map("Go.TButton", background=[("active", "#1565c0"), ("disabled", "#b0bec5")])
        st.configure("Stop.TButton", font=FONT_B, foreground="white", background="#e53935")
        st.map("Stop.TButton", background=[("active", "#c62828"), ("disabled", "#b0bec5")])
        st.configure("Treeview", rowheight=22, font=FONT)
        st.configure("Treeview.Heading", font=FONT_B)
        self.v = {}
        self.q = queue.Queue()
        self.engine = None
        self.worker = None
        self.results = []
        self.build()
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(100, self.pump)
        if E is None:
            messagebox.showerror(APP, "계산 모듈을 불러오지 못했습니다 (numpy 필요):\n%s" % _IMPORT_ERR)

    # ------------------------------------------------------------ 설정
    def load_settings(self):
        try:
            with open(SET_FILE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def save_settings(self):
        s = self.s
        for k, var in self.v.items():
            s[k] = var.get()
        try:
            s["geometry"] = self.root.geometry()
            os.makedirs(SET_DIR, exist_ok=True)
            with open(SET_FILE, "w", encoding="utf-8") as f:
                json.dump(s, f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    # ------------------------------------------------------------ 화면 만들기
    def build(self):
        main = tk.PanedWindow(self.root, orient="horizontal", sashwidth=6, bg="#cfd8dc", bd=0)
        main.pack(fill="both", expand=True)
        # 왼쪽: 설정 (스크롤)
        lf = tk.Frame(main, bg="#eceff1")
        cv = tk.Canvas(lf, bg="#eceff1", highlightthickness=0, width=400)
        sb = ttk.Scrollbar(lf, orient="vertical", command=cv.yview)
        inner = tk.Frame(cv, bg="#eceff1")
        inner.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))
        cv.create_window((0, 0), window=inner, anchor="nw", width=392)
        cv.configure(yscrollcommand=sb.set)
        cv.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        cv.bind_all("<MouseWheel>", lambda e: cv.yview_scroll(int(-e.delta / 120), "units") if str(e.widget).startswith(str(lf)) else None)
        main.add(lf, minsize=360)

        cards = {}
        for key, title in (("dev", "① 장비"), ("sig", "② 신호 - 5G NR 100 MHz"), ("rf", "③ RF · 손실"), ("dpd", "④ DPD (메모리 다항식 / GMP)")):
            c = ttk.LabelFrame(inner, text=title, style="Card.TLabelframe", padding=(10, 6))
            c.pack(fill="x", padx=8, pady=(8, 0))
            c.columnconfigure(1, weight=1)
            cards[key] = c
        row = {k: 0 for k in cards}
        # 신호 대역 (1C 만 지금)
        c = cards["sig"]
        ttk.Label(c, text="캐리어", style="Card.TLabel").grid(row=0, column=0, sticky="w", pady=2)
        self.v["carrier"] = tk.StringVar(value="1C (100 MHz 1개)")
        cb = ttk.Combobox(c, textvariable=self.v["carrier"], values=["1C (100 MHz 1개)", "2C (다음 버전)"], state="readonly", width=18)
        cb.grid(row=0, column=1, sticky="w")
        cb.bind("<<ComboboxSelected>>", lambda e: self.v["carrier"].set("1C (100 MHz 1개)"))
        row["sig"] = 1
        for key, name, dflt, unit, card in self.FIELDS:
            c = cards[card]
            r = row[card]
            ttk.Label(c, text=name, style="Card.TLabel").grid(row=r, column=0, sticky="w", pady=2, padx=(0, 6))
            var = tk.StringVar(value=str(self.s.get(key, dflt)))
            self.v[key] = var
            if key == "mod":
                w = ttk.Combobox(c, textvariable=var, values=["QPSK", "16QAM", "64QAM", "256QAM"], state="readonly", width=10)
            elif key == "os":
                w = ttk.Combobox(c, textvariable=var, values=["2", "3", "4"], state="readonly", width=4)
            else:
                w = ttk.Entry(c, textvariable=var, width=12 if card == "dev" else 8, justify="left" if card == "dev" else "right")
            w.grid(row=r, column=1, sticky="w")
            u = ttk.Label(c, text=self.OS_TXT.get(var.get(), "") if key == "os" else unit, style="Unit.TLabel")
            u.grid(row=r, column=2, sticky="w", padx=(4, 0))
            if key == "os":
                var.trace_add("write", lambda *a, u=u, var=var: u.configure(text=self.OS_TXT.get(var.get(), "")))
            row[card] = r + 1
        c = cards["sig"]
        self.v["cfr_on"] = tk.BooleanVar(value=bool(self.s.get("cfr_on", True)))
        ttk.Checkbutton(c, text="CFR 사용 (클리핑 + 필터로 PAPR 줄이기)", variable=self.v["cfr_on"], style="Card.TCheckbutton").grid(
            row=row["sig"], column=0, columnspan=3, sticky="w", pady=(2, 0))
        bf = ttk.Frame(c, style="Card.TFrame")
        bf.grid(row=row["sig"] + 1, column=0, columnspan=3, sticky="ew", pady=(6, 0))
        ttk.Button(bf, text="신호 만들기", command=self.make_signal).pack(side="left")
        ttk.Button(bf, text=".wv 저장…", command=self.save_wv_orig).pack(side="left", padx=4)
        self.lbl_sig = ttk.Label(c, text="", style="Unit.TLabel", wraplength=360)
        self.lbl_sig.grid(row=row["sig"] + 2, column=0, columnspan=3, sticky="w", pady=(4, 0))
        c = cards["dpd"]
        self.v["odd_only"] = tk.BooleanVar(value=bool(self.s.get("odd_only", False)))
        ttk.Checkbutton(c, text="홀수 차수만 (K = 1, 3, 5, …)", variable=self.v["odd_only"], style="Card.TCheckbutton").grid(
            row=row["dpd"], column=0, columnspan=3, sticky="w", pady=(2, 0))
        # 실행
        run = ttk.LabelFrame(inner, text="⑤ 실행", style="Card.TLabelframe", padding=(10, 8))
        run.pack(fill="x", padx=8, pady=(8, 8))
        self.btn_off = ttk.Button(run, text="DPD OFF 측정만", command=lambda: self.start(False))
        self.btn_off.grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self.btn_go = ttk.Button(run, text="▶ DPD 실행 (OFF → 반복)", style="Go.TButton", command=lambda: self.start(True))
        self.btn_go.grid(row=0, column=1, sticky="ew")
        self.btn_stop = ttk.Button(run, text="■ 중지", style="Stop.TButton", command=self.stop, state="disabled")
        self.btn_stop.grid(row=1, column=0, sticky="ew", padx=(0, 4), pady=(4, 0))
        ttk.Button(run, text="SG RF OFF", command=self.rf_off).grid(row=1, column=1, sticky="ew", pady=(4, 0))
        sv = ttk.Frame(run, style="Card.TFrame")
        sv.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        ttk.Button(sv, text="결과 엑셀 저장…", command=self.save_xlsx).pack(side="left")
        ttk.Button(sv, text="DPD 신호 .wv…", command=self.save_wv_dpd).pack(side="left", padx=4)
        ttk.Button(sv, text="계수 CSV…", command=self.save_coef).pack(side="left")
        self.v["rf_off_end"] = tk.BooleanVar(value=bool(self.s.get("rf_off_end", True)))
        ttk.Checkbutton(run, text="끝나면 SG RF OFF", variable=self.v["rf_off_end"], style="Card.TCheckbutton").grid(
            row=3, column=0, columnspan=2, sticky="w", pady=(6, 0))
        run.columnconfigure(0, weight=1)
        run.columnconfigure(1, weight=1)

        # 오른쪽: 결과 표 + 그래프 + 로그
        rf = tk.Frame(main, bg="#eceff1")
        main.add(rf, minsize=600)
        top = tk.Frame(rf, bg="#eceff1")
        top.pack(fill="x", padx=8, pady=(8, 4))
        self.big = {}
        for k, name in (("aclr", "ACLR (L / U)"), ("evm", "EVM"), ("pout", "Pout"), ("papr", "PAPR")):
            f = tk.Frame(top, bg="white", highlightthickness=1, highlightbackground="#cfd8dc")
            f.pack(side="left", fill="x", expand=True, padx=(0, 6))
            tk.Label(f, text=name, bg="white", fg="#607d8b", font=("맑은 고딕", 9)).pack(anchor="w", padx=8, pady=(4, 0))
            a = tk.Label(f, text="-", bg="white", fg="#9e9e9e", font=("맑은 고딕", 15, "bold"))
            a.pack(anchor="w", padx=8)
            b = tk.Label(f, text="", bg="white", fg="#1565c0", font=("맑은 고딕", 9))
            b.pack(anchor="w", padx=8, pady=(0, 4))
            self.big[k] = (a, b)
        cols = ("label", "sg", "pin", "pout", "gain", "aclr_l", "aclr_u", "evm", "papr", "nmse", "t")
        heads = ("단계", "SG dBm", "Pin dBm", "Pout dBm", "Gain dB", "ACLR L dBc", "ACLR U dBc", "EVM %", "PAPR dB", "학습 NMSE dB", "시각")
        tf = tk.Frame(rf, bg="#eceff1")
        tf.pack(fill="x", padx=8)
        self.tree = ttk.Treeview(tf, columns=cols, show="headings", height=6)
        for c_, h in zip(cols, heads):
            self.tree.heading(c_, text=h)
            self.tree.column(c_, width=78 if c_ != "label" else 84, anchor="center")
        self.tree.pack(fill="x")
        lg = tk.Frame(rf, bg="#eceff1")
        lg.pack(side="bottom", fill="x", padx=8, pady=(0, 8))
        self.txt = tk.Text(lg, height=7, font=("Consolas", 9), bg="#263238", fg="#eceff1", relief="flat", wrap="none")
        self.txt.pack(fill="x")
        gp = tk.Frame(rf, bg="#eceff1")
        gp.pack(fill="both", expand=True, padx=8, pady=6)
        gp.columnconfigure(0, weight=3)
        gp.columnconfigure(1, weight=2)
        gp.rowconfigure(0, weight=1)
        gp.rowconfigure(1, weight=1)
        self.p_spec = Plot(gp, "스펙트럼 (채널 최고 = 0 dB)", "주파수 오프셋 MHz", "dB")
        self.p_spec.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=(0, 6))
        self.p_trend = Plot(gp, "반복별 ACLR (0 = DPD OFF)", "반복", "dBc")
        self.p_trend.grid(row=0, column=1, sticky="nsew", pady=(0, 6))
        self.p_amam = Plot(gp, "AM-AM (원래 신호 → PA 출력, 작은 신호 이득 = 0)", "입력 dB (최고값 기준)", "dB")
        self.p_amam.grid(row=1, column=0, sticky="nsew", padx=(0, 6))
        self.p_ampm = Plot(gp, "AM-PM", "입력 dB (최고값 기준)", "°")
        self.p_ampm.grid(row=1, column=1, sticky="nsew")
        self.log("%s %s - 주소에 demo 를 넣으면 장비 없이 가상 PA 로 확인합니다." % (APP, VERSION))

    # ------------------------------------------------------------ 값 모으기
    def params(self):
        p = {}
        for key, name, dflt, unit, card in self.FIELDS:
            val = self.v[key].get().strip()
            if key in ("smw_host", "fsw_host", "mod", "fsw_att_db"):
                p[key] = val
            elif key in ("n_sym", "os", "K", "M", "L", "iters", "n_fit"):
                p[key] = int(fnum(val, float(dflt)))
            else:
                p[key] = fnum(val, float(dflt))
        p["cfr_on"] = bool(self.v["cfr_on"].get())
        p["odd_only"] = bool(self.v["odd_only"].get())
        if p["K"] < 1 or p["M"] < 1 or p["n_sym"] < 2:
            raise ValueError("K, M 은 1 이상 · 심볼 수는 2 이상")
        return p

    def log(self, s):
        self.txt.insert("end", time.strftime("%H:%M:%S  ") + s + "\n")
        self.txt.see("end")

    # ------------------------------------------------------------ 실행
    def busy(self, on):
        self.btn_go.configure(state="disabled" if on else "normal")
        self.btn_off.configure(state="disabled" if on else "normal")
        self.btn_stop.configure(state="normal" if on else "disabled")

    def get_engine(self, p):
        if self.engine is None or self.engine.p.get("smw_host") != p["smw_host"] or self.engine.p.get("fsw_host") != p["fsw_host"]:
            if self.engine is not None:
                self.engine.close()
            self.engine = E.Engine(p, log=lambda s: self.q.put(("log", s)), on_result=lambda r: self.q.put(("res", r)))
        else:
            sig_keys = ("os", "n_sym", "mod", "cfr_on", "papr_db", "K", "M", "L", "odd_only", "lam")
            if any(self.engine.p.get(k) != p[k] for k in sig_keys):
                self.engine.sig = None            # 신호 · 모델이 바뀌면 다시 만들기
            self.engine.p.update(p)
        return self.engine

    def make_signal(self):
        if E is None or self.worker:
            return
        try:
            p = self.params()
        except ValueError as e:
            messagebox.showwarning(APP, str(e))
            return
        eng = self.get_engine(p)
        self.busy(True)

        def job():
            try:
                sig = eng.make_signal()
                self.q.put(("sig", "%d 샘플 · %.2f MSps · 길이 %.3f ms · PAPR %.2f dB"
                            % (len(sig.x), sig.fs / 1e6, len(sig.x) / sig.fs * 1e3, E.C.papr(sig.x))))
            except Exception as e:
                self.q.put(("err", "신호 만들기 실패: %s" % e))
            self.q.put(("done", None))
        self.worker = threading.Thread(target=job, daemon=True)
        self.worker.start()

    def start(self, do_dpd):
        if E is None or self.worker:
            return
        try:
            p = self.params()
        except ValueError as e:
            messagebox.showwarning(APP, str(e))
            return
        if p["sg_dbm"] > p["sg_max_dbm"]:
            messagebox.showwarning(APP, "SG 레벨 (%.2f) 이 SG 최대 (%.2f) 보다 큽니다." % (p["sg_dbm"], p["sg_max_dbm"]))
            return
        self.save_settings()
        eng = self.get_engine(p)
        self.results = []
        for i in self.tree.get_children():
            self.tree.delete(i)
        self.busy(True)
        rf_end = bool(self.v["rf_off_end"].get())

        def job():
            try:
                if eng.sig is None:
                    sig = eng.make_signal()
                    self.q.put(("sig", "%d 샘플 · %.2f MSps · PAPR %.2f dB" % (len(sig.x), sig.fs / 1e6, E.C.papr(sig.x))))
                eng.run(do_dpd)
                self.q.put(("log", "✔ 끝"))
            except E.Stop:
                self.q.put(("log", "■ 중지됨"))
            except Exception as e:
                self.q.put(("err", "측정 실패: %s" % e))
            finally:
                if rf_end:
                    eng.rf_off()
                self.q.put(("done", None))
        self.worker = threading.Thread(target=job, daemon=True)
        self.worker.start()

    def stop(self):
        if self.engine:
            self.engine.stop = True
            self.log("중지 요청 - 지금 단계가 끝나면 멈춥니다")

    def rf_off(self):
        if self.engine and not self.worker:
            self.engine.rf_off()
        elif self.engine:
            self.stop()

    def pump(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "log":
                    self.log(val)
                elif kind == "err":
                    self.log("✖ " + val)
                    messagebox.showerror(APP, val)
                elif kind == "sig":
                    self.lbl_sig.configure(text=val)
                elif kind == "res":
                    self.add_result(val)
                elif kind == "done":
                    self.worker = None
                    self.busy(False)
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    # ------------------------------------------------------------ 결과 표시
    def add_result(self, r):
        self.results.append(r)
        f = lambda v, n=2: ("%.*f" % (n, v)) if isinstance(v, (int, float)) and v is not None and math.isfinite(v) else "-"
        self.tree.insert("", "end", values=(r["label"], f(r["sg"]), f(r["pin"]), f(r["pout"]), f(r["gain"]),
                                             f(r["aclr_l"], 1), f(r["aclr_u"], 1), f(r["evm"]), f(r["papr"]),
                                             f(r["nmse"], 1) if r.get("nmse") is not None else "-", r["t"]))
        off = self.results[0]
        last = r
        a, b = self.big["aclr"]
        a.configure(text="%.1f / %.1f dBc" % (last["aclr_l"], last["aclr_u"]), fg="#1565c0" if last is not off else "#455a64")
        b.configure(text=("DPD OFF %.1f / %.1f → 개선 %.1f dB" % (off["aclr_l"], off["aclr_u"],
                          max(off["aclr_l"], off["aclr_u"]) - max(last["aclr_l"], last["aclr_u"]))) if last is not off else "DPD OFF")
        a, b = self.big["evm"]
        a.configure(text="%.2f %%" % last["evm"], fg="#1565c0" if last is not off else "#455a64")
        b.configure(text=("DPD OFF %.2f %%" % off["evm"]) if last is not off else "")
        a, b = self.big["pout"]
        a.configure(text="%.2f dBm" % last["pout"], fg="#263238")
        b.configure(text="Gain %.2f dB · Pin %.2f dBm" % (last["gain"], last["pin"]))
        a, b = self.big["papr"]
        a.configure(text="%.2f dB" % last["papr"], fg="#263238")
        b.configure(text=("DPD OFF %.2f dB" % off["papr"]) if last is not off else "")
        self.draw()

    def draw(self):
        rs = self.results
        if not rs:
            return
        off, last = rs[0], rs[-1]
        ser = []
        for i, r in enumerate(rs[1:-1]):
            ser.append(dict(x=r["spec_f"], y=r["spec_db"], color=C_ITER[min(i, len(C_ITER) - 1)]))
        ser.append(dict(x=off["spec_f"], y=off["spec_db"], color=C_OFF, width=2, label="DPD OFF"))
        if last is not off:
            ser.append(dict(x=last["spec_f"], y=last["spec_db"], color=C_DPD, width=2, label=last["label"]))
        fmax = max(abs(off["spec_f"][0]), abs(off["spec_f"][-1]))
        self.p_spec.set(ser, xr=(-fmax, fmax), yr=(-90, 5), vlines=[(-150, "#ef9a9a"), (-50, "#90caf9"), (50, "#90caf9"), (150, "#ef9a9a")])
        its = [r["it"] for r in rs]
        self.p_trend.set([dict(x=its, y=[r["aclr_l"] for r in rs], color="#e53935", width=2, label="ACLR L"),
                          dict(x=its, y=[r["aclr_u"] for r in rs], color="#fb8c00", width=2, label="ACLR U"),
                          dict(x=its, y=[r["aclr_l"] for r in rs], color="#e53935", dots=True, r=3),
                          dict(x=its, y=[r["aclr_u"] for r in rs], color="#fb8c00", dots=True, r=3)],
                         xr=(-0.2, max(its) + 0.2 if max(its) > 0 else 1))
        ser = [dict(x=off["am_x"], y=off["am_g"], color=C_OFF, dots=True, label="DPD OFF")]
        if last is not off:
            ser.append(dict(x=last["am_x"], y=last["am_g"], color=C_DPD, dots=True, label=last["label"]))
        g0 = sorted(off["am_g"])[len(off["am_g"]) // 2] if off["am_g"] else 0
        self.p_amam.set(ser, xr=(-30, 1), yr=(g0 - 4, g0 + 3))
        ser = [dict(x=off["am_x"], y=off["am_p"], color=C_OFF, dots=True, label="DPD OFF")]
        if last is not off:
            ser.append(dict(x=last["am_x"], y=last["am_p"], color=C_DPD, dots=True, label=last["label"]))
        self.p_ampm.set(ser, xr=(-30, 1), yr=(-20, 20))

    # ------------------------------------------------------------ 저장
    def ask(self, title, ext, ft, name):
        return filedialog.asksaveasfilename(title=title, defaultextension=ext, filetypes=ft, initialfile=name,
                                            initialdir=self.s.get("save_dir") or None)

    def remember_dir(self, path):
        if path:
            self.s["save_dir"] = os.path.dirname(path)

    def stamp(self):
        return time.strftime("%Y%m%d_%H%M")

    def save_wv_orig(self):
        if not self.engine or self.engine.sig is None:
            messagebox.showinfo(APP, "먼저 [신호 만들기] 를 누르세요.")
            return
        p = self.ask(".wv 저장", ".wv", [("R&S waveform", "*.wv")], "NR100M_1C_%s.wv" % self.stamp())
        if p:
            E.C.write_wv(p, self.engine.sig.x, self.engine.sig.fs, "NR 100 MHz 1C (PA DPD Tester)")
            self.remember_dir(p)
            self.log("저장: %s" % p)

    def save_wv_dpd(self):
        pd = getattr(self.engine, "last_pd", None) if self.engine else None
        if pd is None:
            messagebox.showinfo(APP, "DPD 를 실행한 뒤에 저장할 수 있습니다.")
            return
        p = self.ask("DPD 신호 .wv 저장", ".wv", [("R&S waveform", "*.wv")], "NR100M_1C_DPD_%s.wv" % self.stamp())
        if p:
            E.C.write_wv(p, pd, self.engine.sig.fs, "NR 100 MHz 1C + DPD (PA DPD Tester)")
            self.remember_dir(p)
            self.log("저장: %s  (SG 레벨은 표의 마지막 SG 값으로)" % p)

    def save_coef(self):
        m = self.engine.model if self.engine else None
        if m is None or m.w is None:
            messagebox.showinfo(APP, "DPD 를 실행한 뒤에 저장할 수 있습니다.")
            return
        p = self.ask("DPD 계수 저장", ".csv", [("CSV", "*.csv")], "DPD_coef_%s.csv" % self.stamp())
        if p:
            names = m.term_names()
            with open(p, "w", encoding="utf-8-sig") as f:
                f.write("# K=%d M=%d L=%d odd=%s lambda=%g\nterm,re,im\n" % (m.K, m.M, m.L, m.odd, m.lam))
                for nm, c in zip(names, m.w):
                    f.write("%s,%.9e,%.9e\n" % (nm, c.real, c.imag))
            self.remember_dir(p)
            self.log("저장: %s" % p)

    def save_xlsx(self):
        if not self.results:
            messagebox.showinfo(APP, "저장할 결과가 없습니다.")
            return
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
        except ImportError:
            messagebox.showerror(APP, "openpyxl 이 없습니다.")
            return
        path = self.ask("결과 엑셀 저장", ".xlsx", [("Excel", "*.xlsx")], "DPD_%s.xlsx" % self.stamp())
        if not path:
            return
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "결과"
        p = self.params()
        ws.append(["PA DPD Tester %s" % VERSION, time.strftime("%Y-%m-%d %H:%M")])
        ws.append(["신호", "NR 100 MHz 1C · %s · %d 심볼 · ×%d · CFR %s %.1f dB" % (p["mod"], p["n_sym"], p["os"], "ON" if p["cfr_on"] else "OFF", p["papr_db"])])
        ws.append(["DPD", "K=%d M=%d L=%d %s λ=%g μ=%g 반복 %d" % (p["K"], p["M"], p["L"], "홀수만" if p["odd_only"] else "", p["lam"], p["mu"], p["iters"])])
        ws.append(["RF", "%.4f GHz · 입력 손실 %.2f dB · 출력 손실 %.2f dB · 보정 %.2f dB" % (p["freq_ghz"], p["in_loss_db"], p["out_loss_db"], p["cal_db"])])
        ws.append([])
        hd = ["단계", "SG dBm", "Pin dBm", "Pout dBm", "Gain dB", "ACLR L dBc", "ACLR U dBc", "EVM %", "PAPR dB", "학습 NMSE dB", "시각"]
        ws.append(hd)
        for c in ws[ws.max_row]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="1565C0")
            c.alignment = Alignment(horizontal="center")
        for r in self.results:
            ws.append([r["label"], round(r["sg"], 2), round(r["pin"], 2), round(r["pout"], 2), round(r["gain"], 2),
                       round(r["aclr_l"], 2), round(r["aclr_u"], 2), round(r["evm"], 3), round(r["papr"], 2),
                       round(r["nmse"], 2) if r.get("nmse") is not None else None, r["t"]])
        for col, w in zip("ABCDEFGHIJK", (10, 9, 9, 10, 9, 11, 11, 8, 9, 12, 9)):
            ws.column_dimensions[col].width = w
        ws2 = wb.create_sheet("스펙트럼")
        ws2.append(["MHz"] + [r["label"] + " dB" for r in self.results])
        for i, fval in enumerate(self.results[0]["spec_f"]):
            ws2.append([round(fval, 3)] + [round(r["spec_db"][i], 2) if i < len(r["spec_db"]) else None for r in self.results])
        ws3 = wb.create_sheet("AM-AM AM-PM")
        off, last = self.results[0], self.results[-1]
        ws3.append(["OFF 입력 dB", "OFF 이득 dB", "OFF 위상 °", "", last["label"] + " 입력 dB", "이득 dB", "위상 °"])
        for i in range(max(len(off["am_x"]), len(last["am_x"]))):
            a = [off["am_x"][i], off["am_g"][i], off["am_p"][i]] if i < len(off["am_x"]) else [None] * 3
            b = [last["am_x"][i], last["am_g"][i], last["am_p"][i]] if i < len(last["am_x"]) else [None] * 3
            ws3.append([round(v, 3) if v is not None else None for v in a] + [None] + [round(v, 3) if v is not None else None for v in b])
        try:
            wb.save(path)
        except PermissionError:
            messagebox.showerror(APP, "파일이 열려 있어 저장하지 못했습니다:\n%s" % path)
            return
        self.remember_dir(path)
        self.log("저장: %s" % path)

    def on_close(self):
        if self.worker and self.engine:
            if not messagebox.askyesno(APP, "측정 중입니다. 멈추고 닫을까요?"):
                return
            self.engine.stop = True
        self.save_settings()
        if self.engine:
            self.engine.close()
        self.root.destroy()


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
