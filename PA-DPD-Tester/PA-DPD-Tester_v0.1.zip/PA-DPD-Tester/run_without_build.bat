@echo off
cd /d %~dp0
REM First time only:  python -m pip install numpy openpyxl
python pa_dpd_tester.py
if errorlevel 1 pause
