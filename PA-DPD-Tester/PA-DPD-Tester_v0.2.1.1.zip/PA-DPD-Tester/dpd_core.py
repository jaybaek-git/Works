# -*- coding: utf-8 -*-
"""PA DPD Tester - 신호 · DPD 계산 (numpy 만 사용)

- 5G NR 100 MHz (SCS 30 kHz, 273 RB) 1 캐리어 OFDM 신호 만들기 + CFR (PAPR 줄이기)
- R&S .wv 파일 쓰기 (SMW200A ARB 용, 암호화 없음)
- 받은 IQ 정렬 (지연 · 위상 · 크기)
- DPD: 메모리 다항식 (MP) / GMP, 간접 학습 (ILA), 정규화 최소제곱
- 성능: ACLR (±100 MHz, 98.28 MHz 측정 대역), EVM (서브캐리어별 등화), AM-AM / AM-PM
"""
import math
import time

import numpy as np

# ---------------------------------------------------------------- NR 100 MHz 1C
NR = dict(scs=30e3, nrb=273, nfft=4096, fs=122.88e6, cp=288, bw=100e6, meas_bw=98.28e6)
QAM_BITS = {"QPSK": 2, "16QAM": 4, "64QAM": 6, "256QAM": 8}


def qam_symbols(n, mod, rng):
    b = QAM_BITS[mod]
    m = int(round(math.sqrt(2 ** b)))
    lv = np.arange(m) * 2 - (m - 1)
    i = rng.choice(lv, n)
    q = rng.choice(lv, n)
    s = (i + 1j * q).astype(np.complex128)
    return s / math.sqrt(np.mean(np.abs(s) ** 2))


class NRSignal:
    """NR 100 MHz 1 캐리어 OFDM. os = 오버샘플링 (샘플레이트 = 122.88 MHz × os)"""

    def __init__(self, os=4, n_sym=28, mod="256QAM", seed=1, carriers=1):
        self.os = int(os)
        self.n_sym = int(n_sym)
        self.mod = mod
        self.seed = seed
        self.carriers = carriers                  # 지금은 1 캐리어만 (2 캐리어는 다음 버전)
        self.nfft = NR["nfft"] * self.os
        self.cp = NR["cp"] * self.os
        self.fs = NR["fs"] * self.os
        self.nsc = NR["nrb"] * 12                 # 3276 서브캐리어
        k = np.arange(self.nsc) - self.nsc // 2   # DC 포함 가운데 정렬 (DC 도 사용 - 테스트용)
        self.bins = np.mod(k, self.nfft)
        rng = np.random.default_rng(seed)
        self.X = qam_symbols(self.n_sym * self.nsc, mod, rng).reshape(self.n_sym, self.nsc)
        self.x = self._modulate(self.X)
        self.x_orig = self.x.copy()

    def _modulate(self, X):
        F = np.zeros((X.shape[0], self.nfft), complex)
        F[:, self.bins] = X
        t = np.fft.ifft(F, axis=1) * math.sqrt(self.nfft)
        t = np.concatenate([t[:, -self.cp:], t], axis=1)
        x = self.chan_filter(t.reshape(-1))
        return x / rms(x)

    def chan_filter(self, x):
        """채널 필터: 전체 주기 신호를 FFT 로 걸러 ±49.2 MHz 밖을 없앰 (49.2~50.4 MHz 코사인 전이).
        필터가 없으면 OFDM 심볼 경계 때문에 기준 신호 자체 ACLR 이 -43 dBc 정도라서 DPD 효과를 못 봄"""
        n = len(x)
        f = np.abs(np.fft.fftfreq(n, 1 / self.fs))
        f1, f2 = 49.2e6, 50.4e6
        h = np.where(f <= f1, 1.0, np.where(f >= f2, 0.0, 0.5 * (1 + np.cos(np.pi * (f - f1) / (f2 - f1)))))
        return np.fft.ifft(np.fft.fft(x) * h)

    @property
    def sym_len(self):
        return self.nfft + self.cp

    def cfr(self, papr_db=8.0, iters=4):
        """클리핑 + 대역 밖 제거를 반복해서 PAPR 을 papr_db 근처로 (EVM 이 조금 나빠짐)"""
        x = self.x_orig.copy()
        for _ in range(iters):
            r = rms(x)
            lim = r * 10 ** (papr_db / 20)
            a = np.abs(x)
            g = np.where(a > lim, lim / np.maximum(a, 1e-12), 1.0)
            x = self.chan_filter(x * g)              # 클리핑으로 생긴 대역 밖 성분 제거
        self.x = x / rms(x)
        return papr(self.x)


class FileSignal:
    """불러온 .wv 신호 (QAM 심볼을 모름 → EVM 은 파형 비교)"""

    def __init__(self, path):
        x, fs = read_wv(path)
        if not fs or fs <= 0:
            raise ValueError(".wv 에 샘플레이트 (CLOCK) 가 없습니다")
        if len(x) < 1000:
            raise ValueError(".wv 샘플이 너무 적습니다 (%d)" % len(x))
        self.path = path
        self.fs = float(fs)
        self.x = x / rms(x)
        self.x_orig = self.x
        self.X = None
        self.n_sym = None

    def cfr(self, papr_db=8.0, iters=4):
        return papr(self.x)               # 불러온 신호는 그대로 씀


def evm_any(sig, y_al):
    """EVM (%): 만든 NR 신호는 서브캐리어 등화 EVM, 불러온 신호는 파형 EVM (복소 이득만 맞춘 오차 / 신호)"""
    if getattr(sig, "X", None) is not None:
        return evm(sig, y_al)
    x = sig.x
    g = np.vdot(x, y_al) / np.vdot(x, x)
    e = y_al / g - x
    return float(100 * math.sqrt(np.mean(np.abs(e) ** 2) / np.mean(np.abs(x) ** 2)))


def rms(x):
    return float(np.sqrt(np.mean(np.abs(x) ** 2)))


def papr(x):
    return float(20 * np.log10(np.max(np.abs(x)) / rms(x)))


# ---------------------------------------------------------------- .wv (R&S ARB)
def write_wv(path, x, fs, comment="PA DPD Tester"):
    """R&S SMU-WV 파일 (int16 I/Q). 최고값 = 풀스케일, LEVEL OFFS = (RMS 오프셋, 0) → SMW 는 RMS 를 설정 레벨에 맞춤"""
    x = np.asarray(x, complex)
    pk = float(np.max(np.abs(x))) or 1.0
    s = x / pk * 32767.0
    iq = np.empty(2 * len(s), np.int16)
    iq[0::2] = np.clip(np.round(s.real), -32767, 32767).astype(np.int16)
    iq[1::2] = np.clip(np.round(s.imag), -32767, 32767).astype(np.int16)
    rms_off = -20 * math.log10(rms(x) / pk)
    comment = "".join(ch if 32 <= ord(ch) < 127 and ch not in "{}" else "_" for ch in str(comment))   # 헤더는 ASCII 만
    hdr = ("{TYPE: SMU-WV,0}{COMMENT: %s}{DATE: %s}{CLOCK: %.0f}{LEVEL OFFS: %.6f,0.000000}{SAMPLES: %d}"
           % (comment, time.strftime("%Y-%m-%d;%H:%M:%S"), fs, rms_off, len(s)))
    body = iq.astype("<i2").tobytes()
    data = hdr.encode("ascii") + ("{WAVEFORM-%d:#" % (len(body) + 1)).encode("ascii") + body + b"}"
    if path:
        with open(path, "wb") as f:
            f.write(data)
    return data


def read_wv(path):
    """암호화 안 된 .wv 읽기 → (x, fs). 암호화된 파일이면 ValueError"""
    raw = open(path, "rb").read()
    i = raw.find(b"{WAVEFORM-")
    head = raw[:4096].upper()
    if i < 0 or b"ENCRYPT" in head or b"SMU-WV" not in head:
        raise ValueError("암호화된 .wv 이거나 R&S 파형 파일이 아닙니다 (IQ 값을 읽을 수 없음).\n"
                         "SMW · WinIQSIM 표준 옵션으로 만든 파일은 암호화돼 있을 수 있어요.")
    hdr = raw[:i].decode("latin-1")
    j = raw.find(b"#", i) + 1
    n = int(raw[i + 10:raw.find(b":", i)]) - 1
    iq = np.frombuffer(raw[j:j + n], "<i2").astype(float)
    fs = 0.0
    k = hdr.find("{CLOCK:")
    if k >= 0:
        fs = float(hdr[k + 7:hdr.find("}", k)].strip())
    return (iq[0::2] + 1j * iq[1::2]) / 32767.0, fs


# ---------------------------------------------------------------- 정렬
def frac_delay(x, d):
    """주기 신호 x 를 d 샘플 (실수) 만큼 늦춤 (FFT 위상)"""
    n = len(x)
    f = np.fft.fftfreq(n)
    return np.fft.ifft(np.fft.fft(x) * np.exp(-2j * np.pi * f * d))


def align(x, y):
    """y (받은 신호, 길이 ≥ len(x)) 를 x (보낸 주기 신호) 에 맞춤.
    → (y_al: x 와 같은 길이 · 같은 시간, gain: 복소 이득 y ≈ gain·x, delay 샘플)"""
    n = len(x)
    if len(y) < n:
        raise ValueError("받은 IQ 가 보낸 신호보다 짧음 (%d < %d)" % (len(y), n))
    seg = y[:n]
    # 지연은 크기(envelope)끼리 상관으로 찾음 → 위상 · 작은 주파수 차이에 영향 안 받음
    ex = np.abs(x) - np.mean(np.abs(x))
    ey = np.abs(seg) - np.mean(np.abs(seg))
    a = np.real(np.fft.ifft(np.fft.fft(ey) * np.conj(np.fft.fft(ex))))
    k = int(np.argmax(a))
    ym1, y0, yp1 = a[(k - 1) % n], a[k], a[(k + 1) % n]
    den = ym1 - 2 * y0 + yp1
    frac = 0.5 * (ym1 - yp1) / den if den != 0 else 0.0
    d = k + frac                                    # seg[n] ≈ x[n - d]
    # 정수 지연만큼 잘라냄 (받은 IQ 가 충분히 길면 이어진 구간을 그대로 → 주파수 차이가 있어도 끊김 없음)
    z = y[k:k + n] if len(y) >= k + n else np.roll(seg, -k)
    # 작은 주파수 차이 (SMW · FSW 기준 클럭이 따로일 때) → 구간별 위상 기울기를 빼 줌
    nb = 64
    L = n // nb
    if L > 64:
        ph = np.unwrap(np.angle([np.vdot(x[i * L:(i + 1) * L], z[i * L:(i + 1) * L]) for i in range(nb)]))
        slope = np.polyfit((np.arange(nb) + 0.5) * L, ph, 1)[0]
        if abs(slope) * n > 0.02:                   # 한 주기 동안 1도 이상 돌 때만
            z = z * np.exp(-1j * slope * np.arange(n))
    y_al = frac_delay(z, -frac)                     # 남은 소수 지연 (주기 신호로 보고 FFT 위상)
    g = np.vdot(x, y_al) / np.vdot(x, x)
    return y_al, g, d


def small_signal_gain(x, y_al, frac=0.3):
    """크기가 작은 샘플 (하위 frac) 로 구한 선형 이득 - DPD 가 맞춰야 할 목표 이득"""
    a = np.abs(x)
    m = a <= np.quantile(a, frac)
    return np.vdot(x[m], y_al[m]) / np.vdot(x[m], x[m])


# ---------------------------------------------------------------- DPD (MP / GMP)
class DPDModel:
    """메모리 다항식 (GMP 는 앞뒤 envelope 교차항 추가).
    K = 비선형 차수 (홀수만 쓰기 옵션), M = 메모리 깊이, L = GMP 교차 지연 (0 = MP)"""

    def __init__(self, K=7, M=4, L=0, odd_only=False, lam=1e-6):
        self.K, self.M, self.L, self.odd, self.lam = int(K), int(M), int(L), bool(odd_only), float(lam)
        self.w = None

    def orders(self):
        return [k for k in range(1, self.K + 1) if (not self.odd or k % 2 == 1)]

    def basis(self, u):
        n = len(u)
        cols = []
        a = np.abs(u)
        for m in range(self.M):
            um = np.roll(u, m)
            am = np.roll(a, m)
            for k in self.orders():
                cols.append(um * am ** (k - 1))
        if self.L > 0:                                  # GMP: x(n-m)|x(n-m-l)|^(k-1), l = ±1..L
            for m in range(self.M):
                um = np.roll(u, m)
                for l in list(range(1, self.L + 1)) + list(range(-self.L, 0)):
                    al = np.roll(a, m + l)
                    for k in self.orders():
                        if k > 1:
                            cols.append(um * al ** (k - 1))
        return np.stack(cols, axis=1)

    def term_names(self):
        """계수 이름 (basis 순서와 같음)"""
        out = []
        for m in range(self.M):
            for k in self.orders():
                out.append("x(n-%d)|x(n-%d)|^%d" % (m, m, k - 1))
        if self.L > 0:
            for m in range(self.M):
                for l in list(range(1, self.L + 1)) + list(range(-self.L, 0)):
                    for k in self.orders():
                        if k > 1:
                            out.append("x(n-%d)|x(n-%d)|^%d" % (m, m + l, k - 1))
        return out

    def n_coef(self):
        return self.basis(np.zeros(4, complex)).shape[1]

    def identity(self):
        w = np.zeros(self.n_coef(), complex)
        w[0] = 1.0                                     # k=1, m=0
        self.w = w
        return w

    def fit(self, u, d, n_fit=40000, rng=None):
        """postdistorter 학습: basis(u) · w ≈ d (정규화 최소제곱). n_fit 샘플만 사용"""
        n = len(u)
        n_fit = min(int(n_fit or n), n)
        rng = rng or np.random.default_rng(0)
        s0 = int(rng.integers(0, n - n_fit + 1))
        Phi = self._basis_seg(u, s0, n_fit)              # 필요한 구간만 (메모리 절약)
        d = d[s0:s0 + n_fit]
        idx = np.arange(n_fit)
        sc = np.sqrt(np.mean(np.abs(Phi) ** 2, axis=0))      # 열마다 크기를 맞춤 (|u|^k 차수별 크기 차이로 계산이 불안정해지지 않게)
        sc[sc == 0] = 1.0
        P = Phi / sc
        A = P.conj().T @ P
        b = P.conj().T @ d[idx]
        lam = self.lam * np.trace(A).real / A.shape[0]
        w = np.linalg.solve(A + lam * np.eye(A.shape[0]), b) / sc
        resid = d[idx] - Phi @ w
        nmse = 10 * np.log10(np.mean(np.abs(resid) ** 2) / np.mean(np.abs(d[idx]) ** 2))
        return w, float(nmse)

    def pad(self):
        return self.M + self.L + 1

    def _basis_seg(self, u, s0, n):
        """주기 신호 u 의 [s0, s0+n) 구간 basis (앞쪽 지연 샘플은 주기로 이어 붙임)"""
        p = self.pad()
        idx = np.arange(s0 - p, s0 + n + p) % len(u)
        B = self.basis(u[idx])
        return B[p:p + n]

    def apply(self, x, w=None, chunk=65536):
        """DPD 적용 (구간을 나눠 계산 - 49만 샘플도 메모리 적게)"""
        w = self.w if w is None else w
        if w is None:
            return x.copy()
        out = np.empty(len(x), complex)
        for s0 in range(0, len(x), chunk):
            n = min(chunk, len(x) - s0)
            out[s0:s0 + n] = self._basis_seg(x, s0, n) @ w
        return out


# ---------------------------------------------------------------- 성능
def welch_psd(x, fs, nfft=8192):
    """Welch PSD (Hann, 50% 겹침) → (f [Hz, -fs/2..fs/2], psd 선형)"""
    x = np.asarray(x)
    nfft = min(nfft, len(x))
    win = np.hanning(nfft)
    step = nfft // 2
    acc = np.zeros(nfft)
    cnt = 0
    for s in range(0, len(x) - nfft + 1, step):
        seg = x[s:s + nfft] * win
        acc += np.abs(np.fft.fft(seg)) ** 2
        cnt += 1
    psd = np.fft.fftshift(acc / max(cnt, 1) / (fs * np.sum(win ** 2)))
    f = np.fft.fftshift(np.fft.fftfreq(nfft, 1 / fs))
    return f, psd


def band_power(f, psd, fc, bw):
    m = (f >= fc - bw / 2) & (f <= fc + bw / 2)
    return float(np.sum(psd[m])) if np.any(m) else float("nan"), bool(np.any(m)) and (fc - bw / 2 >= f[0]) and (fc + bw / 2 <= f[-1])


def aclr(y, fs, bw=NR["meas_bw"], spacing=NR["bw"]):
    """ACLR (dBc): 아래 / 위 인접 채널 (±spacing, 측정 대역 bw). 샘플레이트가 모자라면 full=False"""
    f, p = welch_psd(y, fs)
    pc, _ = band_power(f, p, 0.0, bw)
    pl, okl = band_power(f, p, -spacing, bw)
    pu, oku = band_power(f, p, spacing, bw)
    return (10 * np.log10(pl / pc), 10 * np.log10(pu / pc), okl and oku)


def evm(sig, y_al):
    """EVM (%) : 정렬된 받은 신호를 심볼별 FFT → 서브캐리어별 채널 추정으로 등화 → 보낸 QAM 과 비교"""
    n_sym, L = sig.n_sym, sig.sym_len
    Y = y_al[:n_sym * L].reshape(n_sym, L)[:, sig.cp:]
    F = np.fft.fft(Y, axis=1) / math.sqrt(sig.nfft)
    Yd = F[:, sig.bins]
    X = sig.X
    H = np.sum(Yd * np.conj(X), axis=0) / np.sum(np.abs(X) ** 2, axis=0)
    E = Yd / H - X
    return float(100 * math.sqrt(np.sum(np.abs(E) ** 2) / np.sum(np.abs(X) ** 2)))


def am_curves(x, y_al, g, n_pts=3000, rng=None):
    """AM-AM (dB 이득) · AM-PM (도) 산점도용 - 입력 크기 (최고값 기준 dB)"""
    rng = rng or np.random.default_rng(1)
    idx = rng.choice(len(x), min(n_pts, len(x)), replace=False)
    xi, yi = x[idx], y_al[idx] / g
    pk = np.max(np.abs(x))
    a = np.abs(xi)
    m = a > pk * 1e-3
    xin = 20 * np.log10(a[m] / pk)
    gain = 20 * np.log10(np.abs(yi[m]) / a[m])
    ph = np.degrees(np.angle(yi[m] / xi[m]))
    return xin, gain, ph


def iq_power_dbm(y, offset_db=0.0):
    """FSW I/Q (V) → 평균 전력 dBm (50 Ω, |iq| = 첨두 전압 기준) + 보정값"""
    p = np.mean(np.abs(y) ** 2) / (2 * 50.0)
    return float(10 * np.log10(max(p, 1e-30) * 1e3) + offset_db)


def spectrum_db(y, fs, n_pts=1200):
    """그래프용 스펙트럼 (dB, 채널 최고 0 dB 기준) - 점 수를 줄여서"""
    f, p = welch_psd(y, fs)
    pdb = 10 * np.log10(np.maximum(p, 1e-30))
    pdb -= np.max(pdb)
    if len(f) > n_pts:
        k = len(f) // n_pts
        f = f[:k * n_pts].reshape(n_pts, k).mean(1)
        pdb = pdb[:k * n_pts].reshape(n_pts, k).max(1)
    return f, pdb
