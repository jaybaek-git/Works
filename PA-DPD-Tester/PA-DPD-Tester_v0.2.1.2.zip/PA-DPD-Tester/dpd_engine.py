# -*- coding: utf-8 -*-
"""PA DPD Tester - 측정 · DPD 반복 (화면 없이 동작, 화면은 콜백으로 결과를 받음)

순서: 신호 만들기 → [DPD OFF 측정] → 반복 { 받은 IQ 로 postdistorter 학습 (ILA) → 예왜곡 신호 보내기 → 측정 }
"""
import math
import time

import numpy as np

import bench_link as BL
import dpd_core as C
import instruments as I


class Stop(Exception):
    pass


DEFAULTS = dict(
    smw_host="demo", fsw_host="demo",
    freq_ghz=3.6, sg_dbm=-10.0, sg_max_dbm=0.0, in_loss_db=0.5, out_loss_db=40.0, cal_db=0.0,
    fsw_ref_dbm=10.0, fsw_att_db="auto",
    os=4, n_sym=28, mod="256QAM", cfr_on=True, papr_db=8.0,
    sig_src="nr", wv_path="", ch_bw_mhz=98.28, adj_mhz=100.0,
    rec=None, auto_cal=False,
    K=7, M=4, L=1, odd_only=False, lam=1e-6, iters=4, mu=0.7, peak_lim_db=3.0, n_fit=40000, target_aclr=None,
)


class Engine:
    def __init__(self, p, log=None, on_result=None, on_progress=None, dc_reader=None):
        self.p = dict(DEFAULTS)
        self.p.update(p or {})
        self.log = log or (lambda s: None)
        self.on_result = on_result or (lambda r: None)
        self.on_progress = on_progress or (lambda s: None)
        self.dc_reader = dc_reader or (lambda: None)      # () → (Vdd V, Id A, 측정 시각, 출처) 또는 None
        self._cal_done = False
        self.stop = False
        self.smw = self.fsw = None
        self.sig = None
        self.model = None
        self.G = None
        self.results = []

    # ------------------------------------------------------------ 준비
    def check(self):
        if self.stop:
            raise Stop()

    def connect(self):
        if self.smw is None:
            self.log("장비 연결: SMW %s · FSW %s" % (self.p["smw_host"], self.p["fsw_host"]))
            self.smw, self.fsw = I.open_pair(self.p["smw_host"], self.p["fsw_host"])
            self.smw.log = self.fsw.log = self.log
            self.log("  SMW: %s" % self.smw.idn)
            self.log("  FSW: %s" % self.fsw.idn)

    def make_signal(self):
        p = self.p
        t0 = time.time()
        if p.get("sig_src") == "file":
            self.sig = C.FileSignal(p["wv_path"])
            self.log("신호: %s · %.2f MSps · %d 샘플 (%.3f ms) · PAPR %.2f dB - EVM 은 파형 비교"
                     % (p["wv_path"], self.sig.fs / 1e6, len(self.sig.x), len(self.sig.x) / self.sig.fs * 1e3, C.papr(self.sig.x)))
            if len(self.sig.x) > 2000000:
                self.log("  ⚠ 샘플이 많아 (%d) 한 번 측정에 시간이 걸립니다" % len(self.sig.x))
        else:
            self.sig = C.NRSignal(os=p["os"], n_sym=p["n_sym"], mod=p["mod"])
            pk0 = C.papr(self.sig.x)
            if p["cfr_on"]:
                pk = self.sig.cfr(p["papr_db"])
            else:
                pk = pk0
            self.log("신호: NR 100 MHz 1C · %s · %d 심볼 · %.2f MSps · %d 샘플 · PAPR %.2f → %.2f dB (%.1f초)"
                     % (p["mod"], p["n_sym"], self.sig.fs / 1e6, len(self.sig.x), pk0, pk, time.time() - t0))
        self.model = C.DPDModel(p["K"], p["M"], p["L"], p["odd_only"], p["lam"])
        self.model.w = None
        self.G = None
        return self.sig

    # ------------------------------------------------------------ 한 번 측정
    def measure(self, pd, label, it=0, nmse=None, step=""):
        p, sig, x = self.p, self.sig, self.sig.x
        self.on_progress("측정 중 · %s%s" % (label, (" · " + step) if step else ""))
        lvl = p["sg_dbm"] + 20 * math.log10(C.rms(pd) / C.rms(x))      # 원래 신호와 같은 크기 비율로 (SMW 는 RMS 를 레벨에 맞춤)
        clipped = False
        if lvl > p["sg_max_dbm"]:
            self.log("  ⚠ SG 레벨 %.2f dBm > 최대 %.2f dBm → 최대로 제한" % (lvl, p["sg_max_dbm"]))
            lvl, clipped = p["sg_max_dbm"], True
        self.check()
        wv = C.write_wv(None, pd, sig.fs, comment="PA DPD Tester %s" % label)
        self.log("  %s: SG %.2f dBm 로 신호 보내는 중 (%.1f MB)…" % (label, lvl, len(wv) / 1e6))
        self.smw.load_wave(wv, p["freq_ghz"] * 1e9, lvl, rf_on=True)
        self.check()
        att = None if str(p["fsw_att_db"]).strip().lower() in ("auto", "") else float(p["fsw_att_db"])
        bw = self.fsw.setup(p["freq_ghz"] * 1e9, sig.fs, p["fsw_ref_dbm"], att)
        n = 2 * len(pd) + 2000 if len(pd) <= 600000 else len(pd) + 20000     # 긴 신호는 한 주기 + 여유만
        time.sleep(0.2)
        t_cap = time.time()
        self.log("  FSW I/Q 받는 중: %d 샘플 · %.2f MSps (%.2f ms, %.1f MB)…" % (n, sig.fs / 1e6, n / sig.fs * 1e3, n * 8 / 1e6))
        y = self.fsw.capture(n)
        self.check()
        # Vdd 전원 전류: 이 신호를 보낸 뒤에 읽은 값 (최대 1.5초 기다림)
        dc = None
        t_end = time.time() + 1.5
        while True:
            try:
                dc = self.dc_reader()
            except Exception:
                dc = None
            if dc is None or dc[2] >= t_cap or time.time() > t_end:
                break
            time.sleep(0.1)
        y_al, g, d = C.align(pd, y)
        if self.G is None:
            self.G = C.small_signal_gain(x, y_al)
        else:
            # 측정마다 SMW · FSW 사이 위상이 달라짐 → 작은 신호 구간 위상을 처음 측정 (DPD OFF) 에 맞춤
            c = C.small_signal_gain(pd, y_al)
            y_al = y_al * np.exp(1j * (np.angle(self.G) - np.angle(c)))
        pout = C.iq_power_dbm(y_al, p["out_loss_db"] + p["cal_db"])
        rec = p.get("rec")
        rec_p = BL.pout_at_sg(rec, lvl) if rec else float("nan")
        if rec and p.get("auto_cal") and it == 0 and not self._cal_done and math.isfinite(rec_p):
            self._cal_done = True
            # Bench 기록 (같은 SG 레벨의 DUT Pout) 에 맞춰 Pout 보정값을 정함 → 이후 측정도 같은 보정
            d = rec_p - pout
            p["cal_db"] = p["cal_db"] + d
            pout = rec_p
            self.log("  Pout 보정 = %.2f dB (Bench 기록: SG %.2f dBm → DUT Pout %.2f dBm 에 맞춤)" % (p["cal_db"], lvl, rec_p))
        bwc, adj = p.get("ch_bw_mhz", 98.28) * 1e6, p.get("adj_mhz", 100.0) * 1e6
        al, au, full = C.aclr(y_al, sig.fs, bwc, adj)
        if bw == bw and bw > 0 and bw / 2 < adj + bwc / 2:
            full = False                           # FSW 분석 대역폭이 인접 채널 끝 (±149.14 MHz) 보다 좁음
        ev = C.evm_any(sig, y_al)
        f, sdb = C.spectrum_db(y_al, sig.fs)
        xin, gam, pm = C.am_curves(x, y_al, self.G)
        pin = lvl - p["in_loss_db"]
        vdd = idd = pdc = de = pae = float("nan")
        src = ""
        if dc is None and isinstance(self.smw, I.DemoSMW):
            # 데모: 가상 전원 (Vdd 48 V, Doherty 비슷한 효율 곡선)
            po_w = 10 ** ((pout - 30) / 10)
            eff = 0.18 + 0.40 * min(1.0, (po_w / 8.0) ** 0.45)
            dc = (48.0, po_w / eff / 48.0 + 0.25, time.time(), "demo")
        if dc is not None and dc[0] is not None and dc[1] is not None:
            vdd, idd, _t, src = dc
            pdc = vdd * idd
            if pdc > 0:
                po_w = 10 ** ((pout - 30) / 10)
                de = 100 * po_w / pdc
                pae = 100 * (po_w - 10 ** ((pin - 30) / 10)) / pdc
        r = dict(label=label, it=it, sg=lvl, pin=pin, pout=pout, gain=pout - pin, aclr_l=float(al), aclr_u=float(au),
                 aclr_full=bool(full), evm=ev, rec_pout=rec_p, cal_db=p["cal_db"], ch_bw=bwc / 1e6, adj=adj / 1e6,
                 evm_kind="OFDM" if getattr(sig, "X", None) is not None else "파형", papr=C.papr(pd), nmse=nmse, delay=d, fsw_bw=bw, clipped=clipped,
                 spec_f=(f / 1e6).tolist(), spec_db=sdb.tolist(), am_x=xin.tolist(), am_g=gam.tolist(), am_p=pm.tolist(),
                 t=time.strftime("%H:%M:%S"), kind="off" if it == 0 else "dpd", step=step, base_sg=p["sg_dbm"],
                 vdd=vdd, id=idd, pdc=pdc, de=de, pae=pae, dc_src=src)
        self.results.append(r)
        self.log("  %s: Pout %.2f dBm · ACLR %.1f / %.1f dBc · EVM %.2f %% · PAPR %.2f dB%s%s"
                 % (label, pout, al, au, ev, r["papr"], (" · DE %.1f %% (Id %.3f A)" % (de, idd)) if de == de else "", "" if full else "  (⚠ 샘플레이트 · FSW 대역폭이 모자라 인접 채널 일부만 - ACLR 이 실제보다 좋게 나올 수 있음)"))
        self.on_result(r)
        return y_al, r

    # ------------------------------------------------------------ DPD
    def dpd_signal(self, w):
        x = self.sig.x
        pd = self.model.apply(x, w)
        lim = np.max(np.abs(x)) * 10 ** (self.p["peak_lim_db"] / 20)
        a = np.abs(pd)
        n_clip = int(np.sum(a > lim))
        pd = np.where(a > lim, pd * lim / np.maximum(a, 1e-12), pd)
        return pd, n_clip

    def _dpd_level(self, y_al, w, label_pre, step, target=None):
        """한 SG 레벨에서 DPD 반복 (w = 시작 계수, 앞 레벨 것) → (마지막 결과, 계수)"""
        x = self.sig.x
        pd = x
        last = None
        n = int(self.p["iters"])
        for it in range(1, n + 1):
            self.check()
            self.log("▶ %sDPD 반복 %d / %d" % (label_pre, it, n))
            if w is not None and it == 1 and last is None:
                # 앞 레벨 계수로 먼저 한 번 보내 보고 (학습 없이) 그 결과로 이어서 학습 → 반복이 줄어듦
                pd, _ = self.dpd_signal(w)
                self.model.w = w
                y_al, last = self.measure(pd, "%sDPD 0 (이전 계수)" % label_pre, it, None, step)
                if target is not None and max(last["aclr_l"], last["aclr_u"]) <= target:
                    self.log("  목표 ACLR %.1f dBc 이내 → 다음 레벨" % target)
                    return last, w, pd
            wn, nmse = self.model.fit(y_al / self.G, pd, n_fit=self.p["n_fit"])
            mu = 1.0 if w is None else float(self.p["mu"])
            w = wn if w is None else (1 - mu) * w + mu * wn
            self.model.w = w
            pd, n_clip = self.dpd_signal(w)
            if n_clip:
                self.log("  최고값 제한 (+%.1f dB) 에 걸린 샘플 %d 개" % (self.p["peak_lim_db"], n_clip))
            y_al, last = self.measure(pd, "%sDPD %d" % (label_pre, it), it, nmse, step)
            if target is not None and max(last["aclr_l"], last["aclr_u"]) <= target:
                self.log("  목표 ACLR %.1f dBc 이내 → 반복 끝" % target)
                break
        return last, w, pd

    def run(self, do_dpd=True):
        """DPD OFF 측정 → (do_dpd) DPD 반복. 결과 목록 반환"""
        self.stop = False
        self.results = []
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        x = self.sig.x
        self.G = None
        self.log("▶ DPD OFF 측정")
        y_al, r0 = self.measure(x, "DPD OFF", 0, step="SG %.2f dBm" % self.p["sg_dbm"])
        if not do_dpd:
            return self.results
        tgt = self.p.get("target_aclr")
        last, w, pd = self._dpd_level(y_al, None, "", "SG %.2f dBm" % self.p["sg_dbm"], tgt)
        self.last_pd = pd
        return self.results

    def run_sweep(self, levels, pout_stop=None):
        """파워 스윕: SG 레벨마다 DPD OFF 측정 → DPD 학습 (앞 레벨 계수로 시작) → DPD ON 측정"""
        self.stop = False
        self.results = []
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        x = self.sig.x
        w = None
        base = self.p["sg_dbm"]
        tgt = self.p.get("target_aclr")
        try:
            for i, lv in enumerate(levels):
                self.check()
                if lv > self.p["sg_max_dbm"] + 1e-9:
                    self.log("SG %.2f dBm > SG 최대 → 스윕 끝" % lv)
                    break
                self.p["sg_dbm"] = lv
                step = "레벨 %d/%d · SG %.2f dBm" % (i + 1, len(levels), lv)
                self.log("━━ %s" % step)
                self.G = None
                y_al, r_off = self.measure(x, "OFF", 0, step=step)
                last, w, pd = self._dpd_level(y_al, w, "", step, tgt)
                self.last_pd = pd
                if pout_stop is not None and r_off["pout"] >= pout_stop:
                    self.log("Pout %.2f dBm ≥ 멈춤 %.2f dBm → 스윕 끝" % (r_off["pout"], pout_stop))
                    break
        finally:
            self.p["sg_dbm"] = base
        return self.results

    def rf_off(self):
        try:
            if self.smw is not None:
                self.smw.rf(False)
                self.log("SG RF OFF")
        except Exception as e:
            self.log("RF OFF 실패: %s" % e)

    def close(self):
        for d in (self.smw, self.fsw):
            try:
                d.close()
            except Exception:
                pass
        self.smw = self.fsw = None
