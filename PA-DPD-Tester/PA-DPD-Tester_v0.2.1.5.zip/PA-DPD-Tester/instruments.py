# -*- coding: utf-8 -*-
"""PA DPD Tester - 장비 제어 (SCPI raw socket 5025, VISA 설치 필요 없음)

SMW200A : .wv 파일을 장비로 보내 ARB 로 재생 (MMEM:DATA → BB:ARB:WAV:SEL → BB:ARB:STAT ON)
FSW     : I/Q Analyzer 로 IQ 받기 (TRAC:IQ:SRAT / RLEN → INIT → TRAC:IQ:DATA:MEM?)
주소에 demo 를 넣으면 가상 장비 + 가상 PA 로 동작
"""
import socket
import time

import numpy as np

import dpd_core as C


class ScpiSocket:
    def __init__(self, host, port=5025, timeout=20.0, name="장비"):
        self.name = name
        self.last = ""
        self.sock = socket.create_connection((host, int(port)), timeout=timeout)
        self.sock.settimeout(timeout)
        self.timeout = timeout
        self.buf = b""

    def set_timeout(self, t):
        self.timeout = t
        self.sock.settimeout(t)

    def _recv(self, n):
        try:
            chunk = self.sock.recv(n)
        except socket.timeout:
            raise TimeoutError("%s 응답 없음 (%.0f 초) - 마지막 명령: %s" % (self.name, self.timeout, self.last))
        if not chunk:
            raise ConnectionError("%s 와의 연결이 끊어졌습니다 (마지막 명령: %s)" % (self.name, self.last))
        return chunk

    def write(self, cmd):
        self.last = cmd
        self.sock.sendall((cmd + "\n").encode("ascii"))

    def write_block(self, head, data):
        """head 뒤에 IEEE488.2 binary block (#<n><len><data>) 을 붙여 보냄 (예: MMEM:DATA 'path',)"""
        ln = str(len(data))
        self.last = head + "#<%d bytes>" % len(data)
        self.sock.sendall(head.encode("ascii") + ("#%d%s" % (len(ln), ln)).encode("ascii") + data + b"\n")

    def query(self, cmd):
        self.write(cmd)
        while b"\n" not in self.buf:
            self.buf += self._recv(65536)
        line, self.buf = self.buf.split(b"\n", 1)
        return line.decode("ascii", "replace").strip()

    def _read_exact(self, n):
        parts, have = [self.buf], len(self.buf)
        while have < n:
            chunk = self._recv(1 << 20)
            parts.append(chunk)
            have += len(chunk)
        b = b"".join(parts)
        out, self.buf = b[:n], b[n:]
        return out

    def query_block(self, cmd):
        self.write(cmd)
        while self._read_exact(1) != b"#":
            pass
        nd = int(self._read_exact(1))
        ln = int(self._read_exact(nd))
        data = self._read_exact(ln)
        if self.buf[:1] == b"\n":
            self.buf = self.buf[1:]
        return data

    def opc(self):
        return self.query("*OPC?")

    def err(self):
        try:
            return self.query("SYST:ERR?")
        except Exception as e:
            return str(e)

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass


# ---------------------------------------------------------------- SMW200A
class SMW:
    PATH = "/var/user/pa_dpd_tx_%d.wv"

    def __init__(self, host, port=5025):
        self.io = ScpiSocket(host, port, timeout=60.0, name="SMW")
        self.idn = self.io.query("*IDN?")
        self.n = 0
        self.log = lambda s: None

    def load_wave(self, wv_bytes, freq, level, rf_on=True):
        io = self.io
        self.n += 1
        path = self.PATH % (self.n % 2)                  # 파일 이름을 번갈아 써서 ARB 가 꼭 새로 읽게
        io.write("*CLS")
        io.set_timeout(60.0 + len(wv_bytes) / 2e6)            # 큰 파일은 더 기다림
        io.write_block("MMEM:DATA '%s'," % path, wv_bytes)
        io.opc()
        e = io.err()
        if not e.startswith("0"):
            raise RuntimeError("SMW 파일 저장 오류: %s" % e)
        io.write("SOUR1:FREQ %.0f" % freq)
        io.write("SOUR1:POW %.2f" % level)
        io.write("SOUR1:BB:ARB:WAV:SEL '%s'" % path)
        io.write("SOUR1:BB:ARB:STAT ON")
        if rf_on:
            io.write("OUTP1 ON")
        io.opc()
        e = io.err()
        io.set_timeout(60.0)
        if not e.startswith("0"):
            raise RuntimeError("SMW 오류: %s" % e)
        try:
            clk = float(io.query("SOUR1:BB:ARB:CLOC?"))
            self.log("    SMW ARB 클럭 %.2f MHz" % (clk / 1e6))
        except Exception:
            pass

    def set_level(self, level):
        self.io.write("SOUR1:POW %.2f" % level)
        self.io.opc()

    def rf(self, on):
        self.io.write("OUTP1 %s" % ("ON" if on else "OFF"))
        self.io.opc()

    def close(self):
        self.io.close()


# ---------------------------------------------------------------- FSW
class FSW:
    CH = "DPD IQ"
    CHUNK = 131072                     # 한 번에 받는 샘플 수 (1 MB)

    def __init__(self, host, port=5025):
        self.host, self.port = host, port
        self.io = ScpiSocket(host, port, timeout=30.0, name="FSW")
        self.idn = self.io.query("*IDN?")
        self.made = False
        self.fs = None
        self.log = lambda s: None

    def setup(self, freq, fs, ref_dbm, att_db=None):
        io = self.io
        io.write("*CLS")
        self.select_iq()
        io.write("FREQ:CENT %.0f" % freq)
        io.write("DISP:TRAC:Y:SCAL:RLEV %.2f" % ref_dbm)
        if att_db is None:
            io.write("INP:ATT:AUTO ON")
        else:
            io.write("INP:ATT %.0f" % att_db)
        io.write("TRAC:IQ:SRAT %.6f" % fs)
        io.write("TRIG:SOUR IMM")
        io.write("INIT:CONT OFF")
        io.opc()
        e = self.errors()
        if e:
            self.log("    ⚠ FSW 설정 오류: %s" % " / ".join(e))
        try:
            got = float(io.query("TRAC:IQ:SRAT?"))
            self.fs = got
            if abs(got - fs) > 1e3:
                raise RuntimeError("FSW 샘플레이트가 %.2f MHz 로 바뀜 (요청 %.2f MHz) - FSW 대역 옵션 한계일 수 있음. "
                                   "1 신호의 샘플레이트를 ×2 로 낮춰 보세요." % (got / 1e6, fs / 1e6))
        except (ValueError, TimeoutError):
            pass
        try:
            return float(io.query("TRAC:IQ:BWID?"))
        except Exception:
            return float("nan")

    def errors(self):
        """FSW 오류 줄을 모두 꺼냄 (예전 명령의 오류가 남아 있으면 다음 판단을 헷갈리게 하므로)"""
        out = []
        for _ in range(20):
            e = self.io.err()
            if e.startswith("0") or e.startswith("+0"):
                break
            out.append(e)
        return out

    def _is_iq(self):
        try:
            return "IQ" in self.io.query("INST?").upper()
        except Exception:
            return False

    def select_iq(self):
        """I/Q Analyzer 채널로. 펌웨어에 따라 이름 선택 (INST:SEL 'name') 이 안 되므로 (-141) 종류로 선택 (INST:SEL IQ)"""
        io = self.io
        self.errors()
        if self._is_iq():
            return
        tries = [("INST:SEL IQ", lambda: io.write("INST:SEL IQ")),
                 ("INST:SEL '%s'" % self.CH, lambda: io.write("INST:SEL '%s'" % self.CH)),
                 ("INST:CRE IQ", lambda: io.write("INST:CRE IQ, '%s'" % self.CH))]
        why = []
        for name, f in tries:
            f()
            io.opc()
            e = self.errors()
            if self._is_iq():
                self.log("    FSW I/Q Analyzer 선택 (%s)" % name)
                return
            why.append("%s: %s" % (name, " / ".join(e) or "선택 안 됨"))
        raise RuntimeError("FSW 를 I/Q Analyzer 로 바꾸지 못했습니다 (%s) - FSW 에서 MODE → I/Q Analyzer 를 직접 열어 주세요."
                           % " · ".join(why))

    def reopen(self):
        self.io = ScpiSocket(self.host, self.port, timeout=30.0, name="FSW")

    def _rlen(self):
        try:
            return int(float(self.io.query("TRAC:IQ:RLEN?")))
        except (ValueError, TimeoutError):
            return 0

    def _set_len(self, want):
        """캡처 길이 정하기: 펌웨어 · 옵션마다 받는 명령이 달라서 차례로 시도 → (실제 길이, 오류 설명)"""
        io, fs = self.io, self.fs
        tries = [("RLEN", lambda: io.write("TRAC:IQ:RLEN %d" % want))]
        tries.append(("채널 다시 선택 + RLEN", lambda: (io.write("INST:SEL '%s'" % self.CH), io.opc(),
                                                       io.write("TRAC:IQ:RLEN %d" % want))))
        if fs:
            tries.append(("TRAC:IQ:SET", lambda: io.write("TRAC:IQ:SET NORM,0,%.0f,IMM,POS,0,%d" % (fs, want))))
            tries.append(("측정 시간", lambda: io.write("SENS:SWE:TIME %.9f" % (want / fs))))
        why = []
        for name, f in tries:
            f()
            errs = self.errors()
            got = self._rlen()
            if got >= want and not errs:
                if name != "RLEN":
                    self.log("    FSW 캡처 길이: %s 방식으로 설정됨 (%d 샘플)" % (name, got))
                return got, ""
            why.append("%s: %s" % (name, " / ".join(errs) or "%d 샘플로 바뀜" % got))
            if got >= want and name == "측정 시간":
                return got, ""
        return 0, " · ".join(why)

    def capture(self, n, n_min=None):
        """I/Q n 샘플 받기. FSW 가 n 을 못 받으면 n_min (한 주기 + 여유) 까지 줄여서 받음"""
        io = self.io
        old = self.errors()
        if old:
            self.log("    (FSW 에 남아 있던 오류: %s)" % " / ".join(old))
        tried = [n] + ([n_min] if n_min and n_min < n else [])
        got, why = 0, ""
        for want in tried:
            got, why = self._set_len(want)
            if got >= want:
                break
            self.log("    ⚠ FSW 캡처 길이 %d 샘플 안 됨 (%s)%s" % (want, why, " → 줄여서 다시" if want != tried[-1] else ""))
            got = 0
        if got <= 0:
            raise RuntimeError("FSW 캡처 길이 설정 오류 (%d 샘플 · %.2f MSps): %s" % (tried[-1], (self.fs or 0) / 1e6, why))
        n = got
        io.set_timeout(30.0 + n / 491.52e6 * 20)
        try:
            io.write("INIT:IMM")
            io.opc()
            io.write("FORM REAL,32")
            io.write("TRAC:IQ:DATA:FORM IQP")
            e = self.errors()
            if e:
                self.log("    ⚠ FSW 캡처 후 오류: %s" % " / ".join(e))
            io.set_timeout(30.0)
            parts, k, t0 = [], 0, time.time()
            while k < n:                                       # 큰 블록 한 번 대신 나눠서 받음 (FSW 전송 한계 · 느린 LAN)
                m = min(self.CHUNK, n - k)
                try:
                    parts.append(io.query_block("TRAC:IQ:DATA:MEM? %d,%d" % (k, m)))
                except TimeoutError as ex:
                    try:
                        io.close()
                    except Exception:
                        pass
                    self.reopen()                              # 늦게 오는 데이터가 다음 명령 응답과 섞이지 않게 새로 연결
                    io = self.io
                    e = self.errors()
                    if m > 16384:                              # 더 작게 나눠서 한 번 더
                        self.log("    ⚠ FSW I/Q %d 샘플 받기 응답 없음%s → 16384 샘플씩 다시"
                                 % (m, (" (" + " / ".join(e) + ")") if e else ""))
                        self.CHUNK = 16384
                        io.write("FORM REAL,32")
                        io.write("TRAC:IQ:DATA:FORM IQP")
                        continue
                    raise TimeoutError("%s (%d / %d 샘플째, 한 번에 %d 샘플)%s"
                                       % (ex, k, n, m, (" · FSW 오류: " + " / ".join(e)) if e else ""))
                k += m
            raw = b"".join(parts)
            if n > self.CHUNK:
                self.log("    FSW I/Q %d 샘플을 %d 번에 나눠 받음 (%.1f 초)" % (n, len(parts), time.time() - t0))
        finally:
            io = self.io
            io.set_timeout(30.0)
        v = np.frombuffer(raw, "<f4").astype(float)
        return v[0::2] + 1j * v[1::2]

    def close(self):
        self.io.close()


# ---------------------------------------------------------------- 가상 장비 (demo)
class DemoBench:
    """SMW → (입력 손실) → 가상 PA → (출력 손실) → FSW"""

    def __init__(self):
        from demo_pa import DemoPA
        self.pa = DemoPA()
        self.wave = None
        self.level = -30.0
        self.rf_on = False
        self.freq = 3.6e9
        self.in_loss = 0.5
        self.out_loss = 40.0
        self.rng = np.random.default_rng(7)


class DemoSMW:
    def __init__(self, bench):
        self.b = bench
        self.idn = "Rohde&Schwarz,SMW200A,DEMO,5.30"

    def load_wave(self, wv_bytes, freq, level, rf_on=True):
        import tempfile, os
        fd, p = tempfile.mkstemp(suffix=".wv")
        os.write(fd, wv_bytes)
        os.close(fd)
        x, fs = C.read_wv(p)
        os.remove(p)
        self.b.wave = x
        self.b.freq = freq
        self.b.level = level
        self.b.rf_on = bool(rf_on)
        time.sleep(0.3)

    def set_level(self, level):
        self.b.level = level

    def rf(self, on):
        self.b.rf_on = bool(on)

    def close(self):
        pass


class DemoFSW:
    def __init__(self, bench):
        self.b = bench
        self.idn = "Rohde&Schwarz,FSW-43,DEMO,5.00"
        self.fs = 491.52e6

    def setup(self, freq, fs, ref_dbm, att_db=None):
        self.fs = fs
        return 0.8 * fs

    def capture(self, n, n_min=None):
        b = self.b
        if b.wave is None or not b.rf_on:
            return 1e-6 * (b.rng.standard_normal(n) + 1j * b.rng.standard_normal(n))
        x = b.wave / C.rms(b.wave)
        vin = x * np.sqrt(2 * 50 * 10 ** ((b.level - b.in_loss - 30) / 10))     # SMW RMS = 설정 레벨
        reps = int(np.ceil((n + len(x)) / len(x))) + 1
        y = b.pa(np.tile(vin, reps))[len(x):]                                   # 앞 한 주기는 버림 (메모리 안정)
        s0 = int(b.rng.integers(0, len(x)))
        y = y[s0:s0 + n] * 10 ** (-b.out_loss / 20) * np.exp(1j * b.rng.uniform(0, 2 * np.pi))
        time.sleep(0.2)
        return y

    def close(self):
        pass


def open_pair(smw_host, fsw_host):
    """(smw, fsw) 연결. 둘 중 하나라도 demo 면 둘 다 가상"""
    if str(smw_host).strip().lower() == "demo" or str(fsw_host).strip().lower() == "demo":
        b = DemoBench()
        return DemoSMW(b), DemoFSW(b)
    return SMW(smw_host), FSW(fsw_host)
