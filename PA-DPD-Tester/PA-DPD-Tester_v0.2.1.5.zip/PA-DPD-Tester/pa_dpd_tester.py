# -*- coding: utf-8 -*-
"""PA DPD Tester - SMW200A + FSW 로 PA 에 간단한 DPD (메모리 다항식 / GMP) 를 적용해 성능 확인

- 신호: 5G NR 100 MHz 1 캐리어 (SCS 30 kHz, 273 RB) OFDM 만들기 또는 내 .wv (암호화 없는 것)
- 순서: [DPD OFF 측정] → DPD 반복 (간접 학습 ILA) → 매번 Pout · ACLR · EVM · PAPR
- 화면은 PA Bench Monitor 와 같은 모양 (위쪽 줄 · 큰 숫자 · 번호 카드 · 화이트/블랙) → 나중에 합칠 때 그대로
- 장비에는 아무것도 설치하지 않음 (LAN, SCPI raw socket 5025). 주소에 demo = 가상 PA
"""
import json
import math
import os
import queue
import sys
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
from tkinter import filedialog, messagebox, ttk

import bench_link as BL

try:
    import dpd_engine as E
except Exception as _e:                     # numpy 가 없는 등
    E = None
    _IMPORT_ERR = _e

VERSION = "v0.2.1.5"
APP = "PA DPD Tester"

SET_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "PADPDTester")
SET_FILE = os.path.join(SET_DIR, "settings.json")

# PA Bench Monitor 와 같은 색 · 테마
BG = "#0b0f14"
DASH = "#141b22"
TOPBAR = "#1c2530"
C_ACLR = "#ffb74d"       # 주황 (Bench SG 색)
C_EVM = "#4fc3f7"        # 하늘 (Bench SA 색)
C_POUT = "#39ff88"       # 초록 (Bench 전류 색)
C_PAPR = "#e0e0e0"
C_EFF = "#ce93d8"        # 보라 (효율)
THEMES = {
    "light": dict(bg="#e9edf1", panel="#ffffff", border="#cfd8dc", fg="#1f2933", dim="#546e7a", unit="#78909c",
                  entry="#ffffff", entry_bd="#b0bec5", accent="#1e88e5", line="#eceff1", sel="#e3f2fd",
                  head="#eceff1", plot_bg="#ffffff", grid="#e6e6e6", plot_fg="#333333", plot_dim="#a0a0a0",
                  btn="#ffffff", btn_act="#eef2f5", warn="#c0504d", ok="#2e7d32", info="#1f4f8f",
                  log_bg="#263238", log_fg="#eceff1"),
    "dark": dict(bg="#0f141a", panel="#18212a", border="#2b3743", fg="#dfe6ec", dim="#9fb0bd", unit="#7d8f9c",
                 entry="#0f151b", entry_bd="#3a4855", accent="#1e88e5", line="#26313c", sel="#173451",
                 head="#1f2a35", plot_bg="#11181f", grid="#22303b", plot_fg="#cfd8dc", plot_dim="#6c7a86",
                 btn="#22303c", btn_act="#2c3b48", warn="#ef9a9a", ok="#81c784", info="#90caf9",
                 log_bg="#0b0f14", log_fg="#cfd8dc"),
}
THEME = dict(THEMES["light"])
C_OFF = "#9e9e9e"
C_DPD = "#1e88e5"
C_ITER = ["#c6dbef", "#9ecae1", "#6baed6", "#4292c6", "#2171b5", "#08519c"]
F = ("맑은 고딕", 9)
FB = ("맑은 고딕", 9, "bold")


def fnum(s, d=0.0):
    try:
        return float(str(s).strip())
    except (ValueError, TypeError):
        return d


def mix(c1, c2, k):
    a = [int(c1.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4)]
    b = [int(c2.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4)]
    return "#%02x%02x%02x" % tuple(int(round(x + (y - x) * k)) for x, y in zip(a, b))


# ---------------------------------------------------------------- 그래프 (Tk Canvas, 테마 색)
class Plot(tk.Canvas):
    def __init__(self, master, title="", xl="", yl="", **kw):
        super().__init__(master, highlightthickness=1, bd=0, **kw)
        self.title, self.xl, self.yl = title, xl, yl
        self.series = []
        self.xr = self.yr = None
        self.vlines = []
        self.bind("<Configure>", lambda e: self.redraw())

    def set(self, series, xr=None, yr=None, vlines=(), bubbles=()):
        self.series, self.xr, self.yr, self.vlines = series, xr, yr, list(vlines)
        self.bubbles = list(bubbles)
        self.redraw()

    @staticmethod
    def nice(lo, hi, n=5):
        if not (math.isfinite(lo) and math.isfinite(hi)) or hi <= lo:
            hi = lo + 1
        raw = (hi - lo) / n
        mag = 10 ** math.floor(math.log10(raw))
        step = min((m * mag for m in (1, 2, 2.5, 5, 10) if m * mag >= raw), default=mag * 10)
        v = math.floor(lo / step) * step
        out = []
        while v <= hi + step * 1e-6:
            if v >= lo - step * 1e-6:
                out.append(round(v, 10))
            v += step
        return out

    def redraw(self):
        T = THEME
        self.configure(bg=T["plot_bg"], highlightbackground=T["border"])
        self.delete("all")
        W, H = self.winfo_width(), self.winfo_height()
        if W < 50 or H < 50:
            return
        L, R, Tp, B = 52, 12, 26, 34
        self.create_text(L, 13, text=self.title, anchor="w", font=FB, fill=T["plot_fg"])
        xs = [v for s in self.series for v in s["x"]]
        ys = [v for s in self.series for v in s["y"]]
        x0, x1 = self.xr if self.xr else ((min(xs), max(xs)) if xs else (0, 1))
        if self.yr:
            y0, y1 = self.yr
        elif ys:
            y0, y1 = min(ys), max(ys)
            pad = (y1 - y0) * 0.08 or 1
            y0, y1 = y0 - pad, y1 + pad
        else:
            y0, y1 = 0, 1
        x1 = x1 if x1 > x0 else x0 + 1
        y1 = y1 if y1 > y0 else y0 + 1
        px = lambda v: L + (v - x0) / (x1 - x0) * (W - L - R)
        py = lambda v: H - B - (v - y0) / (y1 - y0) * (H - Tp - B)
        for t in self.nice(x0, x1, 6):
            self.create_line(px(t), Tp, px(t), H - B, fill=T["grid"])
            self.create_text(px(t), H - B + 4, text="%g" % t, anchor="n", font=("맑은 고딕", 8), fill=T["plot_dim"])
        for t in self.nice(y0, y1, 5):
            self.create_line(L, py(t), W - R, py(t), fill=T["grid"])
            self.create_text(L - 4, py(t), text="%g" % t, anchor="e", font=("맑은 고딕", 8), fill=T["plot_dim"])
        self.create_rectangle(L, Tp, W - R, H - B, outline=T["border"])
        self.create_text((L + W - R) / 2, H - 3, text=self.xl, anchor="s", font=("맑은 고딕", 8), fill=T["plot_dim"])
        self.create_text(6, Tp - 3, text=self.yl, anchor="sw", font=("맑은 고딕", 8), fill=T["plot_dim"])
        for v, col in self.vlines:
            if x0 <= v <= x1:
                self.create_line(px(v), Tp, px(v), H - B, fill=col, dash=(3, 3))
        for s in self.series:
            pts = [(px(a), py(b)) for a, b in zip(s["x"], s["y"])
                   if math.isfinite(a) and math.isfinite(b) and x0 <= a <= x1 and y0 <= b <= y1]
            if not pts:
                continue
            if s.get("dots"):
                r = s.get("r", 1)
                for a, b in pts:
                    self.create_rectangle(a - r, b - r, a + r, b + r, outline="", fill=s["color"])
            elif len(pts) > 1:
                self.create_line(*[c for p in pts for c in p], fill=s["color"], width=s.get("width", 1),
                                 dash=s.get("dash") or "")
            if s.get("marks"):
                r = s.get("r", 3)
                for a, b in pts:
                    if s.get("hollow"):
                        self.create_oval(a - r, b - r, a + r, b + r, outline=s["color"], width=2, fill=T["plot_bg"])
                    else:
                        self.create_oval(a - r, b - r, a + r, b + r, outline="", fill=s["color"])
        for bx, by, txt, col in getattr(self, "bubbles", []):
            if not (math.isfinite(bx) and math.isfinite(by)) or not (x0 <= bx <= x1 and y0 <= by <= y1):
                continue
            a, b = px(bx), py(by)
            self.create_oval(a - 8, b - 8, a + 8, b + 8, outline=col, width=3)
            t = self.create_text(0, 0, text=txt, fill="white", font=FB)
            bb = self.bbox(t)
            tw, th = bb[2] - bb[0] + 14, bb[3] - bb[1] + 6
            bx0 = min(max(a + 12, L + 2), W - R - tw - 2)
            by0 = max(b - th - 10, Tp + 2)
            self.create_rectangle(bx0, by0, bx0 + tw, by0 + th, fill=col, outline="")
            self.coords(t, bx0 + tw / 2, by0 + th / 2)
            self.tag_raise(t)
        ly = Tp + 8
        for s in self.series:
            if s.get("label"):
                self.create_line(W - R - 150, ly, W - R - 128, ly, fill=s["color"], width=3, dash=s.get("dash") or "")
                self.create_text(W - R - 124, ly, text=s["label"], anchor="w", font=("맑은 고딕", 8), fill=T["plot_fg"])
                ly += 14


class ScrollFrame(ttk.Frame):
    """세로 스크롤 틀 (내용은 .body)"""

    def __init__(self, parent, **kw):
        super().__init__(parent, **kw)
        self.cv = tk.Canvas(self, highlightthickness=0, bd=0)
        self.vsb = ttk.Scrollbar(self, orient="vertical", command=self.cv.yview)
        self.cv.configure(yscrollcommand=self.vsb.set)
        self.cv.pack(side="left", fill="both", expand=True)
        self.vsb.pack(side="right", fill="y")
        self.body = ttk.Frame(self.cv)
        self.win = self.cv.create_window(0, 0, window=self.body, anchor="nw")
        self.body.bind("<Configure>", lambda e: self.cv.configure(scrollregion=(0, 0, self.body.winfo_reqwidth(),
                                                                                 self.body.winfo_reqheight())))
        self.cv.bind("<Configure>", lambda e: self.cv.itemconfigure(self.win, width=e.width))
        self.bind_all("<MouseWheel>", self._wheel, add="+")

    def _wheel(self, e):
        try:
            w = self.winfo_containing(e.x_root, e.y_root)
        except (tk.TclError, KeyError):
            return
        while w is not None:
            if w is self:
                self.cv.yview_scroll(int(-e.delta / 120), "units")
                return
            w = w.master


# ---------------------------------------------------------------- 화면
class App:
    FIELDS = [
        # (키, 이름, 기본값, 단위, 카드)
        ("smw_host", "SMW200A 주소", "demo", "", "dev"),
        ("fsw_host", "FSW 주소", "demo", "", "dev"),
        ("mod", "변조", "256QAM", "", "sig"),
        ("n_sym", "OFDM 심볼 수", "28", "개 (14 = 0.5 ms)", "sig"),
        ("papr_db", "CFR 목표 PAPR", "8.0", "dB", "sig"),
        ("freq_ghz", "주파수", "3.6", "GHz", "rf"),
        ("sg_dbm", "SG 레벨 (RMS)", "-10", "dBm", "rf"),
        ("sg_max_dbm", "SG 최대", "0", "dBm (넘지 않음)", "rf"),
        ("in_loss_db", "입력 손실 (SG→PA)", "0.5", "dB", "rf"),
        ("out_loss_db", "출력 손실 (PA→FSW)", "40", "dB (감쇠기 포함)", "rf"),
        ("cal_db", "Pout 보정", "0", "dB", "rf"),
        ("fsw_ref_dbm", "FSW Ref Level", "10", "dBm", "rf"),
        ("fsw_att_db", "FSW 감쇠", "auto", "dB 또는 auto", "rf"),
        ("K", "비선형 차수 K", "7", "", "dpd"),
        ("M", "메모리 깊이 M", "4", "탭", "dpd"),
        ("L", "GMP 교차 지연 L", "1", "0 = 메모리 다항식", "dpd"),
        ("iters", "반복 횟수", "4", "번", "dpd"),
        ("mu", "섞기 비율 μ", "0.7", "1 = 새 계수만", "dpd"),
        ("peak_lim_db", "최고값 제한", "3", "dB (원래 최고값 +)", "dpd"),
        ("lam", "정규화 λ", "1e-6", "", "dpd"),
        ("n_fit", "학습 샘플 수", "40000", "개", "dpd"),
    ]
    OS_TXT = {"2": "245.76 MSps · 인접 채널 일부만", "3": "368.64 MSps", "4": "491.52 MSps (권장)"}

    def __init__(self, root):
        self.root = root
        self.s = self.load_settings()
        root.title("%s %s" % (APP, VERSION))
        try:
            base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
            ico = os.path.join(base, "assets", "dpd.png")
            if os.path.isfile(ico):
                self._icon = tk.PhotoImage(file=ico)
                root.iconphoto(True, self._icon)
        except Exception:
            pass
        root.geometry(self.s.get("geometry", "1500x920"))
        self.v = {}
        self.q = queue.Queue()
        self.engine = None
        self.worker = None
        self.results = []
        self.recs = []
        self.bench = None
        self._themed = []
        self.apply_theme(self.s.get("theme", "light"), redraw=False)
        self.build()
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.bind_all("<Escape>", lambda e: self.stop())
        root.after(100, self.pump)
        if E is None:
            messagebox.showerror(APP, "계산 모듈을 불러오지 못했습니다 (numpy 필요):\n%s" % _IMPORT_ERR)

    # ------------------------------------------------------------ 설정
    def load_settings(self):
        try:
            with open(SET_FILE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def save_settings(self):
        s = self.s

        for k, var in self.v.items():
            s[k] = var.get()
        try:
            s["geometry"] = self.root.geometry()
            os.makedirs(SET_DIR, exist_ok=True)
            with open(SET_FILE, "w", encoding="utf-8") as f:
                json.dump(s, f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    # ------------------------------------------------------------ 테마 (PA Bench Monitor 와 같음)
    @staticmethod
    def draw_switch(img, bg, track, knob, on, W=30, H=16):
        def hx(c):
            c = c.lstrip("#")
            return [int(c[i:i + 2], 16) for i in (0, 2, 4)]
        Bc, TR, KN = hx(bg), hx(track), hx(knob)
        r = H / 2.0
        kr = r - 2.0
        kx = (W - r) if on else r
        rows = []
        SS = 3
        for y in range(H):
            line = []
            for x in range(W):
                ct = ck = 0
                for sy in range(SS):
                    for sx in range(SS):
                        px_, py_ = x + (sx + 0.5) / SS, y + (sy + 0.5) / SS
                        cx = min(max(px_, r), W - r)
                        if (px_ - cx) ** 2 + (py_ - r) ** 2 <= r * r:
                            ct += 1
                            if (px_ - kx) ** 2 + (py_ - r) ** 2 <= kr * kr:
                                ck += 1
                a, k = ct / 9.0, ck / 9.0
                col = [Bc[i] + (TR[i] - Bc[i]) * a for i in range(3)]
                col = [col[i] + (KN[i] - col[i]) * k for i in range(3)]
                line.append("#%02x%02x%02x" % tuple(int(round(v)) for v in col))
            rows.append("{" + " ".join(line) + "}")
        img.put(" ".join(rows))

    def apply_switch_style(self, st):
        T = THEME
        off_t = "#455a64" if self.s.get("theme") == "dark" else "#b0bec5"
        if not hasattr(self, "_sw_imgs"):
            self._sw_imgs = {k: tk.PhotoImage(width=30, height=16) for k in ("on", "off", "don", "doff")}
            im = self._sw_imgs
            try:
                st.element_create("Switchp.indicator", "image", im["off"], ("disabled", "selected", im["don"]),
                                  ("disabled", im["doff"]), ("selected", im["on"]), border=0, padding=(0, 0, 6, 0), sticky="w")
            except tk.TclError:
                pass
        im = self._sw_imgs
        bg = T["panel"]
        self.draw_switch(im["on"], bg, T["accent"], "#ffffff", True)
        self.draw_switch(im["off"], bg, off_t, "#ffffff", False)
        self.draw_switch(im["don"], bg, mix(T["accent"], bg, 0.55), mix("#ffffff", bg, 0.3), True)
        self.draw_switch(im["doff"], bg, mix(off_t, bg, 0.55), mix("#ffffff", bg, 0.3), False)
        try:
            st.layout("Card.TCheckbutton", [("Checkbutton.padding", {"sticky": "nswe", "children": [
                ("Switchp.indicator", {"side": "left", "sticky": ""}),
                ("Checkbutton.focus", {"side": "left", "sticky": "w", "children": [("Checkbutton.label", {"sticky": "nswe"})]})]})])
            st.configure("Card.TCheckbutton", padding=(1, 2, 4, 2))
        except tk.TclError:
            pass

    def apply_theme(self, name="light", redraw=True):
        name = name if name in THEMES else "light"
        self.s["theme"] = name
        THEME.clear()
        THEME.update(THEMES[name])
        T = THEME
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure(".", background=T["bg"], foreground=T["fg"], fieldbackground=T["entry"], font=F,
                     bordercolor=T["border"], lightcolor=T["panel"], darkcolor=T["border"], troughcolor=T["bg"],
                     selectbackground=T["accent"], selectforeground="white", insertcolor=T["fg"])
        st.map(".", foreground=[("disabled", T["unit"])])
        for sty in ("TFrame", "TLabel", "TCheckbutton", "TRadiobutton"):
            st.configure(sty, background=T["bg"], foreground=T["fg"])
        st.configure("Card.TFrame", background=T["panel"])
        st.configure("Card.TLabel", background=T["panel"], foreground=T["fg"])
        st.configure("Lab.TLabel", background=T["panel"], foreground=T["dim"])
        st.configure("Unit.TLabel", background=T["panel"], foreground=T["unit"])
        st.configure("Hint.TLabel", background=T["panel"], foreground=T["unit"], font=("맑은 고딕", 8))
        st.configure("Info.TLabel", background=T["panel"], foreground=T["info"])
        st.configure("Head.TLabel", background=T["panel"], foreground=T["fg"], font=("맑은 고딕", 10, "bold"))
        st.configure("Num.TLabel", background=T["accent"], foreground="white", font=("맑은 고딕", 8, "bold"), anchor="center", width=2)
        st.configure("Card.TCheckbutton", background=T["panel"], foreground=T["fg"])
        st.map("Card.TCheckbutton", background=[("active", T["panel"])])
        self.apply_switch_style(st)
        st.configure("TEntry", fieldbackground=T["entry"], foreground=T["fg"], bordercolor=T["entry_bd"],
                     lightcolor=T["entry"], darkcolor=T["entry"], padding=(4, 2))
        st.map("TEntry", bordercolor=[("focus", T["accent"])], lightcolor=[("focus", T["accent"])])
        st.configure("TCombobox", fieldbackground=T["entry"], foreground=T["fg"], background=T["btn"],
                     arrowcolor=T["fg"], bordercolor=T["entry_bd"])
        st.map("TCombobox", fieldbackground=[("readonly", T["entry"])], foreground=[("readonly", T["fg"])],
               selectbackground=[("readonly", T["entry"])], selectforeground=[("readonly", T["fg"])])
        self.root.option_add("*TCombobox*Listbox.background", T["entry"])
        self.root.option_add("*TCombobox*Listbox.foreground", T["fg"])
        st.configure("TButton", background=T["btn"], foreground=T["fg"], bordercolor=T["entry_bd"],
                     lightcolor=T["btn"], darkcolor=T["btn"], padding=(8, 3), focuscolor=T["btn"])
        st.map("TButton", background=[("pressed", T["btn_act"]), ("active", T["btn_act"])])
        st.configure("Pri.TButton", background=T["accent"], foreground="white", bordercolor="#1565c0",
                     lightcolor=T["accent"], darkcolor=T["accent"], font=FB)
        st.map("Pri.TButton", background=[("pressed", "#1565c0"), ("active", "#1976d2"), ("disabled", T["border"])])
        st.configure("Seg.Toolbutton", background=T["panel"], foreground=T["accent"], padding=(10, 3), borderwidth=1,
                     relief="solid", bordercolor=T["accent"], lightcolor=T["panel"], darkcolor=T["panel"], font=F, anchor="center")
        st.map("Seg.Toolbutton", background=[("selected", T["accent"]), ("active", T["sel"])], foreground=[("selected", "white")],
               lightcolor=[("selected", T["accent"])], darkcolor=[("selected", T["accent"])], relief=[("selected", "solid")])
        st.configure("Tab.Toolbutton", background=T["head"], foreground=T["dim"], padding=(16, 6), font=("맑은 고딕", 10),
                     borderwidth=0, relief="flat", lightcolor=T["head"], darkcolor=T["head"])
        st.map("Tab.Toolbutton", background=[("selected", T["accent"]), ("active", T["sel"])], foreground=[("selected", "white")],
               lightcolor=[("selected", T["accent"])], darkcolor=[("selected", T["accent"])], relief=[("selected", "flat")])
        st.configure("Treeview", background=T["panel"], fieldbackground=T["panel"], foreground=T["fg"], bordercolor=T["border"], rowheight=22)
        st.map("Treeview", background=[("selected", T["sel"])], foreground=[("selected", T["fg"])])
        st.configure("Treeview.Heading", background=T["head"], foreground=T["dim"], bordercolor=T["border"], font=FB, relief="flat")
        for sb_ in ("TScrollbar", "Vertical.TScrollbar", "Horizontal.TScrollbar"):
            st.configure(sb_, background=T["border"], troughcolor=T["bg"], bordercolor=T["bg"], arrowcolor=T["dim"],
                         lightcolor=T["border"], darkcolor=T["border"], gripcount=0)
        st.configure("TPanedwindow", background=T["bg"])
        self.root.configure(bg=T["bg"])
        for w, opts in list(self._themed):
            try:
                w.configure(**{k: THEME[v] for k, v in opts.items()})
            except tk.TclError:
                pass
        if hasattr(self, "theme_btns"):
            for k, b in self.theme_btns.items():
                b.configure(bg="#1e88e5" if k == name else "#263340")
        if redraw and hasattr(self, "p_spec"):
            for p in (self.p_spec, self.p_trend, self.p_amam, self.p_ampm, self.p_hist):
                p.redraw()

    def reg(self, w, **opts):
        self._themed.append((w, opts))
        try:
            w.configure(**{k: THEME[v] for k, v in opts.items()})
        except tk.TclError:
            pass
        return w

    def card(self, parent, title, num=None, right_text=None):
        """PA Bench Monitor 와 같은 카드: 번호 · 제목 · 구분선 · 내용"""
        outer = tk.Frame(parent, highlightthickness=1, bd=0)
        self.reg(outer, bg="panel", highlightbackground="border", highlightcolor="border")
        hd = ttk.Frame(outer, style="Card.TFrame")
        hd.pack(fill="x", padx=10, pady=(7, 5))
        if num is not None:
            ttk.Label(hd, text=str(num), style="Num.TLabel").pack(side="left", padx=(0, 7))
        ttk.Label(hd, text=title, style="Head.TLabel").pack(side="left")
        rt = ttk.Label(hd, text=right_text or "", style="Hint.TLabel")
        rt.pack(side="right")
        sep = tk.Frame(outer, height=1)
        self.reg(sep, bg="line")
        sep.pack(fill="x")
        body = ttk.Frame(outer, style="Card.TFrame", padding=(10, 6, 10, 8))
        body.pack(fill="both", expand=True)
        outer.body, outer.right = body, rt
        return outer

    def seg(self, parent, var, items):
        f = ttk.Frame(parent, style="Card.TFrame")
        for val, txt in items:
            ttk.Radiobutton(f, text=txt, value=val, variable=var, style="Seg.Toolbutton").pack(side="left")
        return f

    def set_theme(self, name):
        self.apply_theme(name)
        self.save_settings()

    # ------------------------------------------------------------ 화면 만들기
    def build(self):
        self.build_topbar()
        self.build_dashboard()
        main = ttk.PanedWindow(self.root, orient="horizontal")
        main.pack(fill="both", expand=True, padx=6, pady=(6, 6))
        left = ScrollFrame(main)
        self.reg(left.cv, bg="bg")
        main.add(left, weight=0)
        inner = left.body
        right = ttk.Frame(main)
        main.add(right, weight=1)
        self.build_left(inner)
        self.build_right(right)
        self.log("%s %s - 주소에 demo 를 넣으면 장비 없이 가상 PA 로 확인합니다." % (APP, VERSION))
        self.sig_src_changed()
        self.bench_refresh()
        self.update_chips()
        self.refresh_hist_list()
        self.draw_hist()

    def build_topbar(self):
        bar = tk.Frame(self.root, bg=TOPBAR)
        bar.pack(side="top", fill="x")
        tk.Label(bar, text=APP, bg=TOPBAR, fg="white", font=("맑은 고딕", 12, "bold")).pack(side="left", padx=(12, 4), pady=6)
        tk.Label(bar, text=VERSION + "  (NR 100 MHz · 메모리 다항식 / GMP)", bg=TOPBAR, fg="#90a4ae",
                 font=("맑은 고딕", 8)).pack(side="left", padx=(0, 14))
        self.chips = {}
        for key, name in (("smw", "SMW200A"), ("fsw", "FSW"), ("psu", "Vdd 전원"), ("bench", "PA Bench 기록")):
            c = tk.Label(bar, text="● " + name, bg="#263340", fg="#78909c", font=("맑은 고딕", 8), padx=8, pady=2)
            c.pack(side="left", padx=2)
            self.chips[key] = c
        mk = dict(relief="flat", padx=10, pady=2, activeforeground="#ffffff", font=F, bd=0)
        tk.Button(bar, text="⚙ 장비 설정", command=lambda: self.show_tab("equip"), bg="#2f3d4a", fg="#e0e0e0",
                  activebackground="#3c4d5c", **mk).pack(side="left", padx=(12, 3))
        tk.Button(bar, text="SG RF OFF", command=self.rf_off, bg="#2f3d4a", fg="#e0e0e0",
                  activebackground="#3c4d5c", **mk).pack(side="left", padx=3)
        tf = tk.Frame(bar, bg="#455a64")
        tf.pack(side="left", padx=(10, 3))
        self.theme_btns = {}
        for key, txt in (("light", "☀ 화이트"), ("dark", "🌙 블랙")):
            b = tk.Button(tf, text=txt, command=lambda k=key: self.set_theme(k), relief="flat", bd=0, padx=10, pady=1,
                          font=F, bg="#1e88e5" if self.s.get("theme", "light") == key else "#263340", fg="white",
                          activebackground="#1976d2", activeforeground="white")
            b.pack(side="left", padx=1, pady=1)
            self.theme_btns[key] = b
        self.btn_stop = tk.Button(bar, text="■ 중지 (Esc)", command=self.stop, bg="#c62828", fg="white",
                                  activebackground="#e53935", activeforeground="white", relief="flat", bd=0, padx=16, pady=3,
                                  font=("맑은 고딕", 10, "bold"))
        self.btn_stop.pack(side="right", padx=10, pady=5)

    def build_dashboard(self):
        d = tk.Frame(self.root, bg=DASH)
        d.pack(side="top", fill="x")
        cols = tk.Frame(d, bg=DASH)
        cols.pack(fill="x", padx=8, pady=6)
        self.big = {}
        for i, (key, title, color) in enumerate((("aclr", "ACLR  L / U", C_ACLR), ("evm", "EVM", C_EVM),
                                                 ("pout", "Pout · DUT", C_POUT), ("eff", "DE (효율)", C_EFF),
                                                 ("papr", "PAPR · DPD 신호", C_PAPR))):
            cols.columnconfigure(i, weight={"aclr": 13, "papr": 8}.get(key, 10), uniform="c")
            box = tk.Frame(cols, bg=BG, highlightthickness=1, highlightbackground="#2b3540")
            box.grid(row=0, column=i, sticky="nsew", padx=4)
            tk.Label(box, text=title, bg=BG, fg="#b0bec5", font=("맑은 고딕", 12, "bold")).pack(anchor="w", padx=12, pady=(5, 0))
            v = tk.Label(box, text="---", bg=BG, fg=color, font=("Consolas", 34, "bold"), anchor="w", width=1)
            v.pack(fill="x", padx=10)
            sub = tk.Label(box, text="", bg=BG, fg="#90a4ae", font=("Consolas", 11), anchor="w")
            sub.pack(fill="x", padx=12, pady=(0, 6))
            self.big[key] = (v, sub, color)
        d.bind("<Configure>", lambda e: self.root.after_idle(self.fit_big))

    def fit_big(self):
        fonts = self.__dict__.setdefault("_bigf", {})
        w = max(self.root.winfo_width(), 600)
        base = int(max(18, min(40, w / 46)))
        for key, (v, sub, col) in self.big.items():
            avail = v.winfo_width() - 6
            if avail < 40:
                continue
            size = base
            while size > 12:
                f = fonts.get(size) or fonts.setdefault(size, tkfont.Font(family="Consolas", size=size, weight="bold"))
                if f.measure(v.cget("text")) <= avail:
                    break
                size -= 1
            v.configure(font=("Consolas", size, "bold"))

    def field(self, body, r, key, name, dflt, unit, width=8):
        ttk.Label(body, text=name, style="Lab.TLabel").grid(row=r, column=0, sticky="w", pady=2, padx=(0, 8))
        var = tk.StringVar(value=str(self.s.get(key, dflt)))
        self.v[key] = var
        if key == "mod":
            w = ttk.Combobox(body, textvariable=var, values=["QPSK", "16QAM", "64QAM", "256QAM"], state="readonly", width=9)
        else:
            w = ttk.Entry(body, textvariable=var, width=width, justify="right" if width < 12 else "left")
        w.grid(row=r, column=1, sticky="w")
        ttk.Label(body, text=unit, style="Unit.TLabel").grid(row=r, column=2, sticky="w", padx=(5, 0))
        return w

    def build_left(self, inner):
        W = 400
        fields = {}
        for key, name, dflt, unit, card in self.FIELDS:
            fields.setdefault(card, []).append((key, name, dflt, unit))
        # 1 신호
        c = self.card(inner, "신호", 1)
        c.pack(fill="x", padx=(2, 6), pady=(0, 6))
        b = c.body
        self.v["sig_src"] = tk.StringVar(value=self.s.get("sig_src", "nr"))
        self.v["wv_path"] = tk.StringVar(value=self.s.get("wv_path", ""))
        ttk.Label(b, text="신호", style="Lab.TLabel").grid(row=0, column=0, sticky="w", pady=2)
        self.seg(b, self.v["sig_src"], (("nr", "NR 100 MHz 1C 만들기"), ("file", "내 .wv"))).grid(row=0, column=1, columnspan=2, sticky="w")
        self.f_file = ttk.Frame(b, style="Card.TFrame")
        self.f_file.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(4, 0))
        ttk.Button(self.f_file, text="불러오기…", command=self.pick_wv).pack(side="left")
        self.lbl_wv = ttk.Label(self.f_file, text="", style="Info.TLabel", wraplength=300)
        self.lbl_wv.pack(side="left", padx=(6, 0))
        self.f_nr = ttk.Frame(b, style="Card.TFrame")
        self.f_nr.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(4, 0))
        nb = self.f_nr
        ttk.Label(nb, text="캐리어", style="Lab.TLabel").grid(row=0, column=0, sticky="w", pady=2, padx=(0, 8))
        self.v["carrier"] = tk.StringVar(value="1C")
        self.seg(nb, self.v["carrier"], (("1C", "1C (100 MHz)"), ("2C", "2C · 다음 버전"))).grid(row=0, column=1, columnspan=2, sticky="w")
        self.v["carrier"].trace_add("write", lambda *a: self.v["carrier"].get() != "1C" and self.v["carrier"].set("1C"))
        r = 1
        for key, name, dflt, unit in fields["sig"]:
            self.field(nb, r, key, name, dflt, unit)
            r += 1
        ttk.Label(nb, text="샘플레이트", style="Lab.TLabel").grid(row=r, column=0, sticky="w", pady=2)
        self.v["os"] = tk.StringVar(value=str(self.s.get("os", "4")))
        self.seg(nb, self.v["os"], (("2", "×2"), ("3", "×3"), ("4", "×4"))).grid(row=r, column=1, sticky="w")
        self.lbl_os = ttk.Label(nb, text="", style="Unit.TLabel")
        self.lbl_os.grid(row=r, column=2, sticky="w", padx=(5, 0))
        self.v["os"].trace_add("write", lambda *a: self.lbl_os.configure(text=self.OS_TXT.get(self.v["os"].get(), "")))
        self.lbl_os.configure(text=self.OS_TXT.get(self.v["os"].get(), ""))
        self.v["cfr_on"] = tk.BooleanVar(value=bool(self.s.get("cfr_on", True)))
        ttk.Checkbutton(nb, text="CFR 사용 (클리핑 + 필터로 PAPR 줄이기)", variable=self.v["cfr_on"],
                        style="Card.TCheckbutton").grid(row=r + 1, column=0, columnspan=3, sticky="w", pady=(4, 0))
        af = ttk.Frame(b, style="Card.TFrame")
        af.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(6, 0))
        ttk.Label(af, text="ACLR 채널", style="Lab.TLabel").pack(side="left")
        self.v["ch_bw_mhz"] = tk.StringVar(value=str(self.s.get("ch_bw_mhz", "98.28")))
        self.e_chbw = ttk.Entry(af, textvariable=self.v["ch_bw_mhz"], width=6, justify="right")
        self.e_chbw.pack(side="left", padx=3)
        ttk.Label(af, text="MHz · 인접 간격", style="Lab.TLabel").pack(side="left")
        self.v["adj_mhz"] = tk.StringVar(value=str(self.s.get("adj_mhz", "100")))
        self.e_adj = ttk.Entry(af, textvariable=self.v["adj_mhz"], width=5, justify="right")
        self.e_adj.pack(side="left", padx=3)
        ttk.Label(af, text="MHz", style="Unit.TLabel").pack(side="left")
        bf = ttk.Frame(b, style="Card.TFrame")
        bf.grid(row=4, column=0, columnspan=3, sticky="ew", pady=(8, 0))
        ttk.Button(bf, text="신호 만들기", command=self.make_signal).pack(side="left")
        ttk.Button(bf, text=".wv 저장…", command=self.save_wv_orig).pack(side="left", padx=4)
        self.lbl_sig = ttk.Label(b, text="", style="Hint.TLabel", wraplength=W - 40)
        self.lbl_sig.grid(row=5, column=0, columnspan=3, sticky="w", pady=(4, 0))
        self.v["sig_src"].trace_add("write", lambda *a: self.sig_src_changed())
        self.v["wv_path"].trace_add("write", lambda *a: self.sig_src_changed())

        # 2 RF · 손실
        c = self.card(inner, "RF · 케이블 손실", 2)
        c.pack(fill="x", padx=(2, 6), pady=(0, 6))
        b = c.body
        r = 0
        for key, name, dflt, unit in fields["rf"]:
            self.field(b, r, key, name, dflt, unit)
            r += 1
        self.v["bench_loss"] = tk.BooleanVar(value=bool(self.s.get("bench_loss", True)))
        ttk.Checkbutton(b, text="손실 = PA Bench Monitor 손실 표 사용", variable=self.v["bench_loss"],
                        style="Card.TCheckbutton", command=self.apply_bench_loss).grid(row=r, column=0, columnspan=3, sticky="w", pady=(4, 0))
        self.lbl_loss = ttk.Label(b, text="", style="Info.TLabel", wraplength=W - 40)
        self.lbl_loss.grid(row=r + 1, column=0, columnspan=3, sticky="w")
        self.v["freq_ghz"].trace_add("write", lambda *a: self.apply_bench_loss())

        # 3 Bench 기록 → Pout
        c = self.card(inner, "PA Bench 기록 → Pout", 3, "읽기만 함")
        c.pack(fill="x", padx=(2, 6), pady=(0, 6))
        b = c.body
        ttk.Label(b, text="샘플 종류", style="Lab.TLabel").grid(row=0, column=0, sticky="w", pady=2, padx=(0, 8))
        self.v["b_stype"] = tk.StringVar(value=self.s.get("b_stype", ""))
        self.cb_stype = ttk.Combobox(b, textvariable=self.v["b_stype"], state="readonly", width=14)
        self.cb_stype.grid(row=0, column=1, sticky="w")
        self.cb_stype.bind("<<ComboboxSelected>>", lambda e: self.load_records())
        ttk.Button(b, text="새로 읽기", command=self.bench_refresh).grid(row=0, column=2, sticky="w", padx=(4, 0))
        ttk.Label(b, text="기록", style="Lab.TLabel").grid(row=1, column=0, sticky="w", pady=2)
        self.v["b_rec"] = tk.StringVar(value="")
        self.cb_rec = ttk.Combobox(b, textvariable=self.v["b_rec"], state="readonly", width=28)
        self.cb_rec.grid(row=1, column=1, columnspan=2, sticky="w")
        self.cb_rec.bind("<<ComboboxSelected>>", lambda e: self.show_rec())
        self.lbl_rec = ttk.Label(b, text="", style="Hint.TLabel", wraplength=W - 40)
        self.lbl_rec.grid(row=2, column=0, columnspan=3, sticky="w")
        ttk.Label(b, text="목표 Pout", style="Lab.TLabel").grid(row=3, column=0, sticky="w", pady=(4, 2))
        tf_ = ttk.Frame(b, style="Card.TFrame")
        tf_.grid(row=3, column=1, columnspan=2, sticky="w", pady=(4, 2))
        self.v["b_target"] = tk.StringVar(value=str(self.s.get("b_target", "")))
        ttk.Entry(tf_, textvariable=self.v["b_target"], width=7, justify="right").pack(side="left")
        ttk.Label(tf_, text="dBm", style="Unit.TLabel").pack(side="left", padx=(4, 6))
        ttk.Button(tf_, text="→ SG 레벨 정하기", command=self.sg_from_target).pack(side="left")
        self.v["auto_cal"] = tk.BooleanVar(value=bool(self.s.get("auto_cal", True)))
        ttk.Checkbutton(b, text="DPD OFF 측정 때 Pout 보정을 이 기록에 맞춤", variable=self.v["auto_cal"],
                        style="Card.TCheckbutton").grid(row=4, column=0, columnspan=3, sticky="w", pady=(4, 0))

        # 4 DPD
        c = self.card(inner, "DPD (메모리 다항식 / GMP)", 4, "간접 학습 ILA")
        c.pack(fill="x", padx=(2, 6), pady=(0, 6))
        b = c.body
        r = 0
        for key, name, dflt, unit in fields["dpd"]:
            self.field(b, r, key, name, dflt, unit)
            r += 1
        self.v["odd_only"] = tk.BooleanVar(value=bool(self.s.get("odd_only", False)))
        ttk.Checkbutton(b, text="홀수 차수만 (K = 1, 3, 5, …)", variable=self.v["odd_only"],
                        style="Card.TCheckbutton").grid(row=r, column=0, columnspan=3, sticky="w", pady=(4, 0))

        # 5 실행
        c = self.card(inner, "실행", 5)
        c.pack(fill="x", padx=(2, 6), pady=(0, 6))
        b = c.body
        b.columnconfigure(0, weight=1)
        b.columnconfigure(1, weight=1)
        self.v["run_mode"] = tk.StringVar(value=self.s.get("run_mode", "sweep"))
        ttk.Label(b, text="방식", style="Lab.TLabel").grid(row=0, column=0, sticky="w")
        self.seg(b, self.v["run_mode"], (("one", "한 레벨 (위 SG 레벨)"), ("sweep", "파워 스윕"))).grid(row=0, column=1, sticky="w")
        sw = ttk.Frame(b, style="Card.TFrame")
        sw.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        self.f_sweep = sw
        for i, (key, name, dflt, unit) in enumerate((("sw_start", "SG 시작", "-15", "dBm"), ("sw_stop", "SG 끝", "0", "dBm"),
                                                      ("sw_step", "간격", "1", "dB"),
                                                      ("sw_pout_stop", "Pout 멈춤", "", "dBm (빈칸 = 끝까지)"))):
            self.field(sw, i, key, name, dflt, unit, width=7)
        of = ttk.Frame(b, style="Card.TFrame")
        of.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(4, 0))
        for i, (key, name, dflt, unit) in enumerate((("target_aclr", "목표 ACLR", "-50", "dBc (닿으면 반복 끝 · 빈칸 = 끝까지)"),
                                                      ("run_name", "기록 이름", "", "(빈칸 = 샘플 종류 · 시각)"))):
            self.field(of, i, key, name, dflt, unit, width=7 if key == "target_aclr" else 16)
        self.v["run_mode"].trace_add("write", lambda *a: self.run_mode_changed())
        self.btn_off = ttk.Button(b, text="DPD OFF 측정만", command=lambda: self.start(False))
        self.btn_off.grid(row=3, column=0, sticky="ew", padx=(0, 4), pady=(8, 0))
        self.btn_go = ttk.Button(b, text="▶ DPD 실행", style="Pri.TButton", command=lambda: self.start(True))
        self.btn_go.grid(row=3, column=1, sticky="ew", pady=(8, 0))
        self.v["rf_off_end"] = tk.BooleanVar(value=bool(self.s.get("rf_off_end", True)))
        ttk.Checkbutton(b, text="끝나면 SG RF OFF", variable=self.v["rf_off_end"], style="Card.TCheckbutton").grid(
            row=4, column=0, columnspan=2, sticky="w", pady=(6, 0))
        self.run_mode_changed()

    def build_right(self, right):
        T = THEME
        # 탭 (Bench 와 같은 모양)
        tb = ttk.Frame(right)
        tb.pack(fill="x")
        self.v_tab = tk.StringVar(value="aclr")
        for key, txt in (("aclr", "ACLR vs Pout"), ("graph", "스펙트럼 · AM-AM · AM-PM"),
                         ("equip", "장비 (SMW · FSW)"), ("log", "로그")):
            ttk.Radiobutton(tb, text=txt, value=key, variable=self.v_tab, style="Tab.Toolbutton",
                            command=lambda: self.show_tab(self.v_tab.get())).pack(side="left")
        self.tabs = {}
        holder = ttk.Frame(right)
        holder.pack(fill="both", expand=True)
        # 그래프
        g = ttk.Frame(holder)
        g.columnconfigure(0, weight=3)
        g.columnconfigure(1, weight=2)
        g.rowconfigure(0, weight=1)
        g.rowconfigure(1, weight=1)
        self.p_spec = Plot(g, "스펙트럼 (채널 최고 = 0 dB)", "주파수 오프셋 MHz", "dB")
        self.p_spec.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=(6, 6))
        self.p_trend = Plot(g, "측정 순서별 ACLR (빨강 L · 주황 U)", "측정 순서", "dBc")
        self.p_trend.grid(row=0, column=1, sticky="nsew", pady=(6, 6))
        self.p_amam = Plot(g, "AM-AM (원래 신호 → PA 출력, 작은 신호 이득 = 0)", "입력 dB (최고값 기준)", "dB")
        self.p_amam.grid(row=1, column=0, sticky="nsew", padx=(0, 6))
        self.p_ampm = Plot(g, "AM-PM", "입력 dB (최고값 기준)", "°")
        self.p_ampm.grid(row=1, column=1, sticky="nsew")
        self.tabs["graph"] = g
        # ACLR vs Pout (PA Analyzer 처럼: 과거 기록과 겹쳐 보기)
        a = ttk.Frame(holder)
        a.columnconfigure(0, weight=1)
        a.rowconfigure(1, weight=1)
        bar = ttk.Frame(a)
        bar.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(6, 4))
        self.v["y_q"] = tk.StringVar(value=self.s.get("y_q", "aclr"))
        ttk.Label(bar, text="세로축").pack(side="left", padx=(0, 6))
        for val, txt in (("aclr", "ACLR (나쁜 쪽)"), ("aclr_l", "ACLR L"), ("aclr_u", "ACLR U"), ("evm", "EVM"),
                         ("de", "DE"), ("pae", "PAE")):
            ttk.Radiobutton(bar, text=txt, value=val, variable=self.v["y_q"], style="Seg.Toolbutton",
                            command=self.draw_hist).pack(side="left")
        ttk.Label(bar, text="   점선 = DPD OFF · 실선 = DPD ON · 색 = 주파수 (같은 주파수는 같은 색)", foreground=T["unit"]).pack(side="left")
        self.p_hist = Plot(a, "ACLR vs Pout", "DUT Pout (dBm)", "dBc")
        self.p_hist.grid(row=1, column=0, sticky="nsew", padx=(0, 6))
        side = self.card(a, "기록", None, "")
        side.grid(row=1, column=1, sticky="ns")
        self.hist_card = side
        hb = side.body
        self.htree = ttk.Treeview(hb, columns=("on", "name", "ghz", "n", "when"), show="headings", height=8, selectmode="extended")
        for c_, h, w_ in (("on", "표시", 36), ("name", "이름", 130), ("ghz", "GHz", 50), ("n", "점", 34), ("when", "날짜", 92)):
            self.htree.heading(c_, text=h)
            self.htree.column(c_, width=w_, anchor="center" if c_ != "name" else "w", stretch=c_ == "name")
        self.htree.pack(fill="both", expand=True)
        hb.pack_propagate(True)
        self.htree.bind("<Button-1>", self.hist_click)
        self.htree.bind("<Double-1>", lambda e: self.hist_rename())
        hb2 = ttk.Frame(hb, style="Card.TFrame")
        hb2.pack(fill="x", pady=(6, 0))
        for txt, cmd in (("전체 표시", lambda: self.hist_show(True)), ("숨김", lambda: self.hist_show(False)),
                         ("이름", self.hist_rename), ("삭제", self.hist_delete)):
            ttk.Button(hb2, text=txt, command=cmd).pack(side="left", padx=(0, 3))
        ttk.Button(hb, text="PA Analyzer 용 엑셀 내보내기…", command=self.hist_export).pack(fill="x", pady=(6, 0))
        ttk.Label(hb, text="표시 칸 클릭 = 켜기/끄기 · 이름 더블클릭 = 바꾸기", style="Hint.TLabel").pack(anchor="w", pady=(4, 0))
        self.tabs["aclr"] = a
        self.root.after(1000, self.live_dc)
        # 장비
        e = ttk.Frame(holder)
        c = self.card(e, "장비 연결", None, "LAN · SCPI 5025 · demo = 가상 PA")
        c.pack(fill="x", padx=0, pady=6)
        r = 0
        for key, name, dflt, unit, card in self.FIELDS:
            if card == "dev":
                self.field(c.body, r, key, name, dflt, unit, width=20)
                r += 1
        ttk.Label(c.body, text="SMW 는 /var/user/pa_dpd_tx_0.wv · _1.wv 에 번갈아 저장, FSW 는 'DPD IQ' I/Q Analyzer 채널을 만들어 씀.\n"
                               "10 MHz 기준 클럭을 연결하면 가장 안정적입니다.", style="Hint.TLabel").grid(row=r, column=0, columnspan=3, sticky="w", pady=(6, 0))
        self.lbl_idn = ttk.Label(c.body, text="", style="Info.TLabel")
        self.lbl_idn.grid(row=r + 1, column=0, columnspan=3, sticky="w", pady=(4, 0))
        for k in ("smw_host", "fsw_host"):
            self.v[k].trace_add("write", lambda *a: self.update_chips())
        self.tabs["equip"] = e
        # 로그
        lg = ttk.Frame(holder)
        self.txt = tk.Text(lg, font=("Consolas", 9), relief="flat", wrap="none", bd=0)
        self.reg(self.txt, bg="log_bg", fg="log_fg", insertbackground="log_fg")
        self.txt.pack(fill="both", expand=True, pady=6)
        self.tabs["log"] = lg
        self.show_tab("aclr")
        # 아래: 측정 기록 (Bench 의 측정 기록과 같은 자리)
        rec = self.card(right, "측정 기록", None, "")
        rec.pack(side="bottom", fill="x", pady=(6, 0), before=holder)
        self.rec_card = rec
        top = ttk.Frame(rec.body, style="Card.TFrame")
        top.pack(fill="x", pady=(0, 4))
        self.lbl_last = ttk.Label(top, text="", style="Info.TLabel")
        self.lbl_last.pack(side="left")
        for txt, cmd in (("계수 CSV…", self.save_coef), ("DPD 신호 .wv…", self.save_wv_dpd), ("엑셀 저장…", self.save_xlsx)):
            ttk.Button(top, text=txt, command=cmd).pack(side="right", padx=(4, 0))
        cols = ("label", "sg", "pin", "pout", "rec", "gain", "aclr_l", "aclr_u", "evm", "id", "de", "pae", "papr", "nmse", "t")
        heads = ("단계", "SG(dBm)", "Pin(dBm)", "Pout(dBm)", "기록 Pout", "Gain(dB)", "ACLR L(dBc)", "ACLR U(dBc)",
                 "EVM(%)", "Id(mA)", "DE(%)", "PAE(%)", "PAPR(dB)", "학습 NMSE", "시각")
        self.tree = ttk.Treeview(rec.body, columns=cols, show="headings", height=5)
        for c_, h in zip(cols, heads):
            self.tree.heading(c_, text=h)
            self.tree.column(c_, width=72 if c_ != "label" else 80, anchor="center")
        self.tree.pack(fill="x")
        # 한 줄 로그 (로그 탭이 아닐 때도 마지막 줄은 보이게)
        self.lbl_status = ttk.Label(right, text="", foreground=T["dim"])
        self.lbl_status.pack(side="bottom", fill="x", pady=(4, 0), before=rec)

    def read_dc(self):
        """Vdd 전원 (Vdd V, Id A, 측정 시각, 출처) - PA Bench Monitor 가 공유하는 값만 읽음 (전원에는 연결 안 함)"""
        d = BL.read_live()
        if d and d.get("vdd") is not None and d.get("id") is not None:
            return (float(d["vdd"]), float(d["id"]), float(d["t"]), "PA Bench")
        return None

    def live_dc(self):
        """측정하지 않을 때 DE 칸 아래에 지금 Vdd · Id 표시 (출처 포함) · 연결 표시"""
        try:
            dc = self.read_dc()
            ch = self.chips.get("psu")
            if ch is not None:
                ch.configure(fg="#39ff88" if dc else "#78909c", text="● Vdd 전원%s" % ((" (" + dc[3] + ")") if dc else ""))
            if not self.worker and not self.results:
                v_, sb_, col_ = self.big["eff"]
                sb_.configure(text=("지금 Id %.3f A · Vdd %.2f V (%s)" % (dc[1], dc[0], dc[3])) if dc else
                              "Vdd 전류 없음 - PA Bench Monitor 에서 파워서플라이 연결")
        except Exception:
            pass
        self.root.after(1000, self.live_dc)

    def show_tab(self, key):
        self.v_tab.set(key)
        for k, f in self.tabs.items():
            if k == key:
                f.pack(fill="both", expand=True)
            else:
                f.pack_forget()

    def update_chips(self):
        def chip(k, on, warn=False):
            c = self.chips.get(k)
            if c:
                c.configure(fg="#39ff88" if on else ("#ffd54f" if warn else "#78909c"))
        conn = self.engine is not None and getattr(self.engine, "smw", None) is not None
        demo = self.v.get("smw_host") and self.v["smw_host"].get().strip().lower() == "demo"
        chip("smw", conn, demo)
        chip("fsw", conn, demo)
        chip("bench", bool(self.recs))
        if conn:
            self.lbl_idn.configure(text="SMW: %s\nFSW: %s" % (self.engine.smw.idn, self.engine.fsw.idn))

    # ------------------------------------------------------------ 신호 파일
    def pick_wv(self):
        p = filedialog.askopenfilename(title=".wv 불러오기 (암호화 안 된 R&S 파형)", filetypes=[("R&S waveform", "*.wv")],
                                       initialdir=self.s.get("wv_dir") or None)
        if not p:
            return
        try:
            x, fs = E.C.read_wv(p)
        except Exception as e:
            messagebox.showerror(APP, str(e))
            return
        self.s["wv_dir"] = os.path.dirname(p)
        self.v["wv_path"].set(p)
        self.v["sig_src"].set("file")
        self.log("불러옴: %s (%d 샘플 · %.2f MSps)" % (p, len(x), fs / 1e6))

    def sig_src_changed(self):
        f = self.v["sig_src"].get() == "file"
        p = self.v["wv_path"].get()
        if hasattr(self, "f_nr"):
            if f:
                self.f_nr.grid_remove()
                self.f_file.grid()
            else:
                self.f_file.grid_remove()
                self.f_nr.grid()
            for e_ in (self.e_chbw, self.e_adj):
                e_.configure(state="normal" if f else "disabled")
            if not f:
                self.v["ch_bw_mhz"].set("98.28")
                self.v["adj_mhz"].set("100")
        txt = "(파일을 고르세요)"
        if p and os.path.isfile(p):
            txt = os.path.basename(p)
            try:
                raw = open(p, "rb").read(4096).decode("latin-1")
                i = raw.find("{CLOCK:")
                if i >= 0:
                    txt += " · %.2f MSps" % (float(raw[i + 7:raw.find("}", i)]) / 1e6)
            except Exception:
                pass
        self.lbl_wv.configure(text=txt)
        if self.engine is not None:
            self.engine.sig = None

    # ------------------------------------------------------------ PA Bench 연동
    def bench_refresh(self):
        self.bench = BL.load_settings()
        if not self.bench:
            self.cb_stype.configure(values=[])
            self.lbl_rec.configure(text="PA Bench Monitor 설정을 찾지 못했습니다 (%s)" % BL.BENCH_SET)
            self.lbl_loss.configure(text="")
            return
        names = BL.sample_types(self.bench)
        self.cb_stype.configure(values=names)
        if self.v["b_stype"].get() not in names:
            self.v["b_stype"].set(self.bench.get("stype") if self.bench.get("stype") in names else (names[0] if names else ""))
        self.apply_bench_loss()
        self.load_records()

    def apply_bench_loss(self):
        if not hasattr(self, "lbl_loss"):
            return
        on = bool(self.v["bench_loss"].get())
        if not on:
            self.lbl_loss.configure(text="손실은 위 칸 값 사용")
            return
        r = BL.losses_at(self.bench, fnum(self.v["freq_ghz"].get(), float("nan"))) if self.bench else None
        if r is None:
            self.lbl_loss.configure(text="PA Bench Monitor 손실 표 없음 → 위 칸 값 사용")
            return
        li, lo, how = r
        self.v["in_loss_db"].set("%.2f" % li)
        self.v["out_loss_db"].set("%.2f" % lo)
        self.lbl_loss.configure(text="In %.2f dB · Out %.2f dB  (%s)" % (li, lo, how))

    def load_records(self):
        self.recs = []
        st = self.v["b_stype"].get()
        pam = BL.latest_pam(self.bench, st) if (self.bench and st) else None
        if not pam:
            self.cb_rec.configure(values=[])
            self.v["b_rec"].set("")
            self.lbl_rec.configure(text="이 샘플 종류의 .pam 기록이 없습니다" if st else "")
            return
        try:
            recs = BL.read_records(pam)
        except Exception as e:
            self.lbl_rec.configure(text=".pam 읽기 실패: %s" % e)
            return
        g = fnum(self.v["freq_ghz"].get(), float("nan"))
        # 지금 주파수에 가까운 것 · Mod. · 최근 순서
        recs.sort(key=lambda r: r["when"], reverse=True)
        recs.sort(key=lambda r: (abs(r["freq_ghz"] - g) if (g == g and r["freq_ghz"] == r["freq_ghz"]) else 99, 0 if r["mod"] else 1))
        self.recs = recs
        labels = ["%s · %.6g GHz%s" % (r["display"], r["freq_ghz"], "" if r["mod"] else " (Pulse)") for r in recs]
        self.cb_rec.configure(values=labels)
        self.v["b_rec"].set(labels[0] if labels else "")
        self.pam_path = pam
        self.show_rec()
        self.update_chips()

    def cur_rec(self):
        labels = list(self.cb_rec.cget("values") or [])
        cur = self.v["b_rec"].get()
        if cur in labels and labels.index(cur) < len(self.recs):
            return self.recs[labels.index(cur)]
        return None

    def show_rec(self):
        r = self.cur_rec()
        if r is None:
            self.lbl_rec.configure(text="")
            return
        self.lbl_rec.configure(text="%s · SG %.1f ~ %.1f dBm → Pout %.1f ~ %.1f dBm (%d점)%s"
                               % (os.path.basename(getattr(self, "pam_path", "")), min(r["sg"]), max(r["sg"]),
                                  min(r["pout"]), max(r["pout"]), len(r["sg"]),
                                  "" if r["mod"] else " · ⚠ Pulse 기록 (모듈레이션 기록이 더 맞음)"))

    def sg_from_target(self):
        r = self.cur_rec()
        t = fnum(self.v["b_target"].get(), float("nan"))
        if r is None or t != t:
            messagebox.showinfo(APP, "기록을 고르고 목표 Pout 을 넣으세요.")
            return
        sg = BL.sg_for_pout(r, t)
        if sg != sg:
            return
        out = t > max(r["pout"]) or t < min(r["pout"])
        mx = fnum(self.v["sg_max_dbm"].get(), 0.0)
        if sg > mx:
            messagebox.showwarning(APP, "필요한 SG %.2f dBm 이 SG 최대 %.2f dBm 보다 큽니다." % (sg, mx))
            return
        self.v["sg_dbm"].set("%.2f" % sg)
        self.log("목표 Pout %.2f dBm → SG %.2f dBm (Bench 기록 보간%s)" % (t, sg, ", 기록 범위 밖 - 연장" if out else ""))

    # ------------------------------------------------------------ 값 모으기
    def params(self):
        p = {}
        for key, name, dflt, unit, card in self.FIELDS:
            val = self.v[key].get().strip()
            if key in ("smw_host", "fsw_host", "mod", "fsw_att_db"):
                p[key] = val
            elif key in ("n_sym", "K", "M", "L", "iters", "n_fit"):
                p[key] = int(fnum(val, float(dflt)))
            else:
                p[key] = fnum(val, float(dflt))
        p["os"] = int(fnum(self.v["os"].get(), 4))
        p["cfr_on"] = bool(self.v["cfr_on"].get())
        p["odd_only"] = bool(self.v["odd_only"].get())
        p["sig_src"] = self.v["sig_src"].get()
        p["wv_path"] = self.v["wv_path"].get()
        if p["sig_src"] == "file" and not os.path.isfile(p["wv_path"]):
            raise ValueError("불러올 .wv 파일을 고르세요")
        p["ch_bw_mhz"] = fnum(self.v["ch_bw_mhz"].get(), 98.28)
        p["adj_mhz"] = fnum(self.v["adj_mhz"].get(), 100.0)
        if p["sig_src"] == "nr":
            p["ch_bw_mhz"], p["adj_mhz"] = 98.28, 100.0
        p["rec"] = self.cur_rec()
        p["auto_cal"] = bool(self.v["auto_cal"].get()) and p["rec"] is not None
        if p["K"] < 1 or p["M"] < 1 or p["n_sym"] < 2:
            raise ValueError("K, M 은 1 이상 · 심볼 수는 2 이상")
        return p

    def log(self, s):
        self.txt.insert("end", time.strftime("%H:%M:%S  ") + s + "\n")
        self.txt.see("end")
        if hasattr(self, "lbl_status"):
            self.lbl_status.configure(text=s.strip())

    # ------------------------------------------------------------ 실행
    def busy(self, on):
        self.btn_go.configure(state="disabled" if on else "normal")
        self.btn_off.configure(state="disabled" if on else "normal")
        self.btn_stop.configure(state="normal" if on else "disabled")

    def get_engine(self, p):
        if self.engine is None or self.engine.p.get("smw_host") != p["smw_host"] or self.engine.p.get("fsw_host") != p["fsw_host"]:
            if self.engine is not None:
                self.engine.close()
            self.engine = E.Engine(p, log=lambda s: self.q.put(("log", s)), on_result=lambda r: self.q.put(("res", r)),
                                   on_progress=lambda s: self.q.put(("prog", s)), dc_reader=self.read_dc)
        else:
            sig_keys = ("os", "n_sym", "mod", "cfr_on", "papr_db", "K", "M", "L", "odd_only", "lam", "sig_src", "wv_path")
            if any(self.engine.p.get(k) != p[k] for k in sig_keys):
                self.engine.sig = None            # 신호 · 모델이 바뀌면 다시 만들기
            self.engine.p.update(p)
        return self.engine

    def make_signal(self):
        if E is None or self.worker:
            return
        try:
            p = self.params()
        except ValueError as e:
            messagebox.showwarning(APP, str(e))
            return
        eng = self.get_engine(p)
        self.busy(True)

        def job():
            try:
                sig = eng.make_signal()
                self.q.put(("sig", "%d 샘플 · %.2f MSps · 길이 %.3f ms · PAPR %.2f dB"
                            % (len(sig.x), sig.fs / 1e6, len(sig.x) / sig.fs * 1e3, E.C.papr(sig.x))))
            except Exception as e:
                self.q.put(("err", "신호 만들기 실패: %s" % e))
            self.q.put(("done", None))
        self.worker = threading.Thread(target=job, daemon=True)
        self.worker.start()

    def run_mode_changed(self):
        if self.v["run_mode"].get() == "sweep":
            self.f_sweep.grid()
            self.btn_go.configure(text="▶ 파워 스윕 + DPD")
        else:
            self.f_sweep.grid_remove()
            self.btn_go.configure(text="▶ DPD 실행 (OFF → 반복)")

    def sweep_levels(self):
        a, b, st = (fnum(self.v[k].get(), float("nan")) for k in ("sw_start", "sw_stop", "sw_step"))
        if not (a == a and b == b and st == st) or st <= 0:
            raise ValueError("파워 스윕: SG 시작 · 끝 · 간격을 확인하세요")
        n = int(math.floor(abs(b - a) / st + 1e-6)) + 1
        if n > 60:
            raise ValueError("파워 스윕 레벨이 너무 많습니다 (%d개, 60개까지)" % n)
        sgn = 1 if b >= a else -1
        return [round(a + sgn * st * k, 3) for k in range(n)]

    def start(self, do_dpd):
        if E is None or self.worker:
            return
        sweep = do_dpd and self.v["run_mode"].get() == "sweep"
        try:
            p = self.params()
            levels = self.sweep_levels() if sweep else None
        except ValueError as e:
            messagebox.showwarning(APP, str(e))
            return
        if sweep and max(levels) > p["sg_max_dbm"]:
            if not messagebox.askyesno(APP, "스윕 끝 (%.2f dBm) 이 SG 최대 (%.2f dBm) 보다 큽니다.\nSG 최대까지만 측정할까요?"
                                       % (max(levels), p["sg_max_dbm"])):
                return
            levels = [l for l in levels if l <= p["sg_max_dbm"] + 1e-9]
        if not sweep and p["sg_dbm"] > p["sg_max_dbm"]:
            messagebox.showwarning(APP, "SG 레벨 (%.2f) 이 SG 최대 (%.2f) 보다 큽니다." % (p["sg_dbm"], p["sg_max_dbm"]))
            return
        t = fnum(self.v["target_aclr"].get(), float("nan"))
        p["target_aclr"] = t if t == t else None
        pstop = fnum(self.v["sw_pout_stop"].get(), float("nan"))
        self.save_settings()
        eng = self.get_engine(p)
        self.results = []
        for i in self.tree.get_children():
            self.tree.delete(i)
        self.new_run(p, sweep)
        self.busy(True)
        rf_end = bool(self.v["rf_off_end"].get())

        def job():
            try:
                if eng.sig is None:
                    sig = eng.make_signal()
                    self.q.put(("sig", "%d 샘플 · %.2f MSps · PAPR %.2f dB" % (len(sig.x), sig.fs / 1e6, E.C.papr(sig.x))))
                if sweep:
                    eng.run_sweep(levels, pstop if pstop == pstop else None)
                else:
                    eng.run(do_dpd)
                self.q.put(("log", "✔ 끝"))
            except E.Stop:
                self.q.put(("log", "■ 중지됨"))
            except Exception as e:
                self.q.put(("err", "측정 실패: %s" % e))
            finally:
                if rf_end:
                    eng.rf_off()
                self.q.put(("done", None))
        self.worker = threading.Thread(target=job, daemon=True)
        self.worker.start()

    # ------------------------------------------------------------ 기록 (ACLR vs Pout, 과거와 비교)
    HIST_FILE = os.path.join(SET_DIR, "history.json")

    def load_hist(self):
        if not hasattr(self, "hist"):
            try:
                with open(self.HIST_FILE, encoding="utf-8") as f:
                    self.hist = json.load(f)
            except Exception:
                self.hist = []
        return self.hist

    def save_hist(self):
        try:
            os.makedirs(SET_DIR, exist_ok=True)
            tmp = self.HIST_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.hist[-300:], f, ensure_ascii=False)
            os.replace(tmp, self.HIST_FILE)
        except Exception as e:
            self.log("기록 저장 실패: %s" % e)

    def new_run(self, p, sweep):
        self.load_hist()
        st = self.v["b_stype"].get().strip()
        name = self.v["run_name"].get().strip() or ("%s %s" % (st or "DPD", time.strftime("%m-%d %H:%M"))).strip()
        sig = ("내 .wv %s" % os.path.basename(p["wv_path"])) if p["sig_src"] == "file" else \
              "NR100 1C %s ×%d CFR %s" % (p["mod"], p["os"], ("%.1f" % p["papr_db"]) if p["cfr_on"] else "OFF")
        run = dict(id="%d" % (time.time() * 1000), name=name, when=time.strftime("%Y-%m-%d %H:%M"), freq=p["freq_ghz"],
                   stype=st, sig=sig, dpd="K%d M%d L%d" % (p["K"], p["M"], p["L"]), sweep=bool(sweep), on=True, pts=[])
        self.hist.append(run)
        self.cur_run = run
        self.refresh_hist_list()

    def add_hist_point(self, r):
        run = getattr(self, "cur_run", None)
        if run is None:
            return
        run["pts"].append(dict(kind=r.get("kind", "dpd"), base=r.get("base_sg"), sg=r["sg"], pout=r["pout"],
                               aclr_l=r["aclr_l"], aclr_u=r["aclr_u"], evm=r["evm"], label=r["label"],
                               de=r.get("de"), pae=r.get("pae"), id=r.get("id"), pdc=r.get("pdc")))
        self.refresh_hist_list()
        self.draw_hist()

    @staticmethod
    def run_curves(run):
        """기록 → (OFF 점들, ON 점들): 레벨(base SG)마다 OFF 1개 · DPD 는 그 레벨의 마지막 결과"""
        off, on = {}, {}
        for q in run.get("pts", []):
            k = round(q.get("base") if q.get("base") is not None else q["sg"], 3)
            (off if q["kind"] == "off" else on)[k] = q
        return [off[k] for k in sorted(off)], [on[k] for k in sorted(on)]

    def yval(self, q):
        y = self.v["y_q"].get()
        if y == "aclr":
            return max(q["aclr_l"], q["aclr_u"])
        v = q.get(y)
        return v if isinstance(v, (int, float)) and v is not None else float("nan")

    def hist_colors(self):
        """주파수 → 고정 색 (낮은 주파수부터 파랑 · 초록 · 빨강 …, PA Bench Monitor 와 같은 순서)"""
        pal = ["#1f77b4", "#2ca02c", "#d62728", "#ff7f0e", "#9467bd", "#8c564b", "#e377c2", "#17becf", "#bcbd22", "#7f7f7f"]
        fs = sorted({round(fnum(r.get("freq"), 0), 6) for r in self.load_hist()})
        return {f: pal[i % len(pal)] for i, f in enumerate(fs)}

    def draw_hist(self):
        if not hasattr(self, "p_hist"):
            return
        fc = self.hist_colors()
        shown = [r for r in self.load_hist() if r.get("on") and r.get("pts")]
        same = {}
        ser = []
        for r in shown:
            f = round(fnum(r.get("freq"), 0), 6)
            n = same.get(f, 0)
            same[f] = n + 1
        seen = {}
        for r in shown:
            f = round(fnum(r.get("freq"), 0), 6)
            k = seen.get(f, 0)
            seen[f] = k + 1
            col = fc.get(f, "#1f77b4")
            if same[f] > 1:                              # 같은 주파수 여러 기록 → 예전 것일수록 옅게
                col = mix(col, THEME["plot_bg"], 0.55 * (same[f] - 1 - k) / max(same[f] - 1, 1))
            off, on = self.run_curves(r)
            nm = "%s %.4g GHz" % (r["name"], fnum(r.get("freq"), 0))
            if off:
                ser.append(dict(x=[q["pout"] for q in off], y=[self.yval(q) for q in off], color=col, width=2, dash=(5, 4),
                                marks=True, hollow=True, r=3, label=nm + " OFF"))
            if on:
                ser.append(dict(x=[q["pout"] for q in on], y=[self.yval(q) for q in on], color=col, width=2,
                                marks=True, r=3, label=nm + " DPD"))
        bub = []
        if self.worker and getattr(self, "cur_run", None) and self.cur_run.get("pts"):
            q = self.cur_run["pts"][-1]
            y = self.yval(q)
            unit = "%" if self.v["y_q"].get() in ("evm", "de", "pae") else "dBc"
            bub.append((q["pout"], y, "● 측정 중 %.1f %s" % (y, unit) if unit == "dBc" else "● 측정 중 %.1f %%" % y,
                        "#e53935" if q["kind"] == "off" else "#1e88e5"))
        ylab = {"aclr": "ACLR 나쁜 쪽 (dBc)", "aclr_l": "ACLR L (dBc)", "aclr_u": "ACLR U (dBc)", "evm": "EVM (%)",
                "de": "DE (%)", "pae": "PAE (%)"}[self.v["y_q"].get()]
        self.p_hist.title = ylab.split(" (")[0] + " vs Pout"
        self.p_hist.yl = "%" if self.v["y_q"].get() in ("evm", "de", "pae") else "dBc"
        self.p_hist.set(ser[-24:], bubbles=bub)

    def refresh_hist_list(self):
        if not hasattr(self, "htree"):
            return
        sel = set(self.htree.selection())
        self.htree.delete(*self.htree.get_children())
        for r in reversed(self.load_hist()):
            off, on = self.run_curves(r)
            self.htree.insert("", "end", iid=r["id"], values=("☑" if r.get("on") else "☐", r["name"], "%.4g" % fnum(r.get("freq"), 0),
                                                              len(off) + len(on), r.get("when", "")[2:]))
        for i in sel:
            if self.htree.exists(i):
                self.htree.selection_add(i)

    def hist_run(self, iid):
        return next((r for r in self.load_hist() if r["id"] == iid), None)

    def hist_click(self, e):
        if self.htree.identify_column(e.x) != "#1":
            return
        iid = self.htree.identify_row(e.y)
        r = self.hist_run(iid) if iid else None
        if r is not None:
            r["on"] = not r.get("on")
            self.save_hist()
            self.refresh_hist_list()
            self.draw_hist()
            return "break"

    def hist_show(self, on):
        sel = self.htree.selection()
        for r in self.load_hist():
            if not sel or r["id"] in sel:
                r["on"] = on
        self.save_hist()
        self.refresh_hist_list()
        self.draw_hist()

    def hist_rename(self):
        sel = self.htree.selection()
        r = self.hist_run(sel[0]) if sel else None
        if r is None:
            return
        from tkinter import simpledialog
        nm = simpledialog.askstring(APP, "기록 이름", initialvalue=r["name"], parent=self.root)
        if nm:
            r["name"] = nm.strip()
            self.save_hist()
            self.refresh_hist_list()
            self.draw_hist()

    def hist_delete(self):
        sel = self.htree.selection()
        if not sel:
            return
        if not messagebox.askyesno(APP, "고른 기록 %d개를 지울까요?" % len(sel)):
            return
        self.hist = [r for r in self.load_hist() if r["id"] not in sel]
        self.save_hist()
        self.refresh_hist_list()
        self.draw_hist()

    def hist_export(self):
        """PA Analyzer 가 읽는 엑셀: 기록 × (DPD OFF / DPD ON) 마다 시트 하나 (조건 + 표, ACLR · EVM 열)"""
        sel = self.htree.selection()
        runs = [r for r in self.load_hist() if (r["id"] in sel if sel else r.get("on")) and r.get("pts")]
        if not runs:
            messagebox.showinfo(APP, "내보낼 기록을 고르세요 (고른 게 없으면 표시 중인 기록).")
            return
        try:
            import openpyxl
        except ImportError:
            messagebox.showerror(APP, "openpyxl 이 없습니다.")
            return
        path = self.ask("PA Analyzer 용 엑셀", ".xlsx", [("Excel", "*.xlsx")], "DPD_ACLR_%s.xlsx" % self.stamp())
        if not path:
            return
        wb = openpyxl.Workbook()
        wb.remove(wb.active)
        used = set()
        for r in runs:
            for kind, pts in zip(("OFF", "DPD"), self.run_curves(r)):
                if not pts:
                    continue
                nm = ("%s %s" % (r["name"], kind))[:28]
                for ch in '[]:*?/\\':
                    nm = nm.replace(ch, "_")
                base, k = nm, 2
                while nm in used:
                    nm = "%s(%d)" % (base[:25], k)
                    k += 1
                used.add(nm)
                ws = wb.create_sheet(nm)
                ws.append(["FREQ", "%.6g GHz" % fnum(r.get("freq"), 0)])
                ws.append(["DUT", "%s %s" % (r["name"], "DPD OFF" if kind == "OFF" else "DPD ON")])
                ws.append(["Signal", r.get("sig", "")])
                ws.append(["DPD", r.get("dpd", "") if kind == "DPD" else "OFF"])
                ws.append([])
                ws.append(["SG Pout (dBm)", "DUT_Pout (dBm)", "ACLR (dBc)", "EVM (%)", "Id (mA)", "DC_Power(mW)", "DE(%)", "PAE(%)",
                           "Lower (dBc)", "Upper (dBc)"])

                def rr(v, n):
                    return round(v, n) if isinstance(v, (int, float)) and v is not None and math.isfinite(v) else None
                for q in pts:
                    ws.append([rr(q["sg"], 3), rr(q["pout"], 3), rr(max(q["aclr_l"], q["aclr_u"]), 3), rr(q["evm"], 3),
                               rr((q.get("id") or float("nan")) * 1e3, 2), rr((q.get("pdc") or float("nan")) * 1e3, 1),
                               rr(q.get("de"), 3), rr(q.get("pae"), 3), rr(q["aclr_l"], 3), rr(q["aclr_u"], 3)])
        try:
            wb.save(path)
        except PermissionError:
            messagebox.showerror(APP, "파일이 열려 있어 저장하지 못했습니다:\n%s" % path)
            return
        self.remember_dir(path)
        self.log("PA Analyzer 용 엑셀 저장: %s (시트 %d개) - PA Analyzer 에서 엑셀 불러오기로 열면 됩니다" % (path, len(used)))

    def stop(self):
        if self.engine:
            self.engine.stop = True
            self.log("중지 요청 - 지금 단계가 끝나면 멈춥니다")

    def rf_off(self):
        if self.engine and not self.worker:
            self.engine.rf_off()
        elif self.engine:
            self.stop()

    def pump(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "log":
                    self.log(val)
                elif kind == "err":
                    self.log("✖ " + val)
                    messagebox.showerror(APP, val)
                elif kind == "sig":
                    self.lbl_sig.configure(text=val)
                elif kind == "res":
                    self.add_result(val)
                    self.add_hist_point(val)
                elif kind == "prog":
                    v_, sb_, col_ = self.big["aclr"]
                    sb_.configure(text="● " + val, fg="#ffd54f")
                elif kind == "done":
                    self.worker = None
                    self.busy(False)
                    self.update_chips()
                    if getattr(self, "cur_run", None) is not None:
                        if not self.cur_run.get("pts"):
                            self.hist = [r for r in self.load_hist() if r is not self.cur_run]
                        self.save_hist()
                        self.refresh_hist_list()
                        self.cur_run = None
                    self.draw_hist()
                    if self.results:
                        last = self.results[-1]
                        offs = [q for q in self.results if q.get("kind") == "off" and q.get("base_sg") == last.get("base_sg")]
                        off = offs[-1] if offs else self.results[0]
                        txt = "✔ 끝 · %s" % last["label"] if last is off else "✔ 끝 · 같은 SG 의 OFF %.1f / %.1f → %.1f dB 개선" % (
                            off["aclr_l"], off["aclr_u"], max(off["aclr_l"], off["aclr_u"]) - max(last["aclr_l"], last["aclr_u"]))
                        self.big["aclr"][1].configure(text=txt, fg="#90a4ae")
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    # ------------------------------------------------------------ 결과 표시
    def add_result(self, r):
        self.results.append(r)
        f = lambda v, n=2: ("%.*f" % (n, v)) if isinstance(v, (int, float)) and v is not None and math.isfinite(v) else "-"
        idm = r.get("id")
        self.tree.insert("", "end", values=(r["label"], f(r["sg"]), f(r["pin"]), f(r["pout"]), f(r.get("rec_pout")), f(r["gain"]),
                                             f(r["aclr_l"], 1), f(r["aclr_u"], 1), f(r["evm"]),
                                             f(idm * 1e3 if isinstance(idm, float) else None, 1), f(r.get("de"), 1), f(r.get("pae"), 1),
                                             f(r["papr"]),
                                             f(r["nmse"], 1) if r.get("nmse") is not None else "-", r["t"]))
        self.tree.see(self.tree.get_children()[-1])
        last = r
        offs = [q for q in self.results if q.get("kind", "off") == "off" and q.get("base_sg") == r.get("base_sg")]
        off = offs[-1] if offs else self.results[0]          # 같은 SG 레벨의 DPD OFF 와 비교
        is_off = last is off

        def tile(k, big, sub):
            v, sb, col = self.big[k]
            v.configure(text=big)
            if not (k == "aclr" and self.worker):
                sb.configure(text=sub, fg="#90a4ae")
        tile("aclr", "%.1f / %.1f" % (last["aclr_l"], last["aclr_u"]),
             ("DPD OFF (dBc)" if is_off else "%s · OFF %.1f / %.1f → %.1f dB 개선" % (
                 last["label"], off["aclr_l"], off["aclr_u"], max(off["aclr_l"], off["aclr_u"]) - max(last["aclr_l"], last["aclr_u"])))
             + ("" if last.get("aclr_full", True) else "  ⚠ 일부 대역"))
        tile("evm", "%.2f %%" % last["evm"], ("%s EVM" % ("파형" if last.get("evm_kind") == "파형" else "OFDM"))
             + ("" if is_off else " · OFF %.2f %%" % off["evm"]))
        rp = last.get("rec_pout")
        tile("pout", "%.2f dBm" % last["pout"], "Gain %.2f dB · Pin %.2f dBm%s" % (
            last["gain"], last["pin"], (" · 기록 %.2f" % rp) if isinstance(rp, float) and math.isfinite(rp) else ""))
        de, pae = last.get("de"), last.get("pae")
        ok_ = isinstance(de, float) and math.isfinite(de)
        tile("eff", ("%.1f %%" % de) if ok_ else "---",
             ("PAE %.1f %%%s · Id %.3f A" % (pae, "" if is_off or not isinstance(off.get("de"), float) or not math.isfinite(off["de"])
                                             else " · OFF %.1f %%" % off["de"], last["id"])) if ok_ else
             "Vdd 전류 없음 - PA Bench Monitor 에서 파워서플라이 연결")
        tile("papr", "%.2f dB" % last["papr"], "SG %.2f dBm%s" % (last["sg"], "" if is_off else " · OFF %.2f dB" % off["papr"]))
        self.root.after_idle(self.fit_big)
        self.lbl_last.configure(text="%s · %s" % (last["label"], last["t"]))
        if isinstance(last.get("cal_db"), float):
            self.v["cal_db"].set("%.2f" % last["cal_db"])
        self.draw()

    def draw(self):
        rs = self.results
        if not rs:
            return
        off, last = rs[0], rs[-1]
        ser = []
        for i, r in enumerate(rs[1:-1]):
            ser.append(dict(x=r["spec_f"], y=r["spec_db"], color=C_ITER[min(i, len(C_ITER) - 1)]))
        ser.append(dict(x=off["spec_f"], y=off["spec_db"], color=C_OFF, width=2, label="DPD OFF"))
        if last is not off:
            ser.append(dict(x=last["spec_f"], y=last["spec_db"], color=C_DPD, width=2, label=last["label"]))
        fmax = max(abs(off["spec_f"][0]), abs(off["spec_f"][-1]))
        cb_, ad_ = off.get("ch_bw", 98.28) / 2, off.get("adj", 100.0)
        self.p_spec.set(ser, xr=(-fmax, fmax), yr=(-90, 5), vlines=[(-ad_ - cb_, "#ef9a9a"), (-cb_, "#90caf9"), (cb_, "#90caf9"),
                                                                    (ad_ + cb_, "#ef9a9a")])
        its = list(range(len(rs)))
        self.p_trend.set([dict(x=its, y=[r["aclr_l"] for r in rs], color="#e53935", width=2, label="ACLR L"),
                          dict(x=its, y=[r["aclr_u"] for r in rs], color="#fb8c00", width=2, label="ACLR U"),
                          dict(x=its, y=[r["aclr_l"] for r in rs], color="#e53935", dots=True, r=3),
                          dict(x=its, y=[r["aclr_u"] for r in rs], color="#fb8c00", dots=True, r=3)],
                         xr=(-0.2, max(its) + 0.2 if max(its) > 0 else 1))
        ser = [dict(x=off["am_x"], y=off["am_g"], color=C_OFF, dots=True, label="DPD OFF")]
        if last is not off:
            ser.append(dict(x=last["am_x"], y=last["am_g"], color=C_DPD, dots=True, label=last["label"]))
        g0 = sorted(off["am_g"])[len(off["am_g"]) // 2] if off["am_g"] else 0
        self.p_amam.set(ser, xr=(-30, 1), yr=(g0 - 4, g0 + 3))
        ser = [dict(x=off["am_x"], y=off["am_p"], color=C_OFF, dots=True, label="DPD OFF")]
        if last is not off:
            ser.append(dict(x=last["am_x"], y=last["am_p"], color=C_DPD, dots=True, label=last["label"]))
        self.p_ampm.set(ser, xr=(-30, 1), yr=(-20, 20))

    # ------------------------------------------------------------ 저장
    def ask(self, title, ext, ft, name):
        return filedialog.asksaveasfilename(title=title, defaultextension=ext, filetypes=ft, initialfile=name,
                                            initialdir=self.s.get("save_dir") or None)

    def remember_dir(self, path):
        if path:
            self.s["save_dir"] = os.path.dirname(path)

    def stamp(self):
        return time.strftime("%Y%m%d_%H%M")

    def save_wv_orig(self):
        if not self.engine or self.engine.sig is None:
            messagebox.showinfo(APP, "먼저 [신호 만들기] 를 누르세요.")
            return
        p = self.ask(".wv 저장", ".wv", [("R&S waveform", "*.wv")], "NR100M_1C_%s.wv" % self.stamp())
        if p:
            E.C.write_wv(p, self.engine.sig.x, self.engine.sig.fs, "NR 100 MHz 1C (PA DPD Tester)")
            self.remember_dir(p)
            self.log("저장: %s" % p)

    def save_wv_dpd(self):
        pd = getattr(self.engine, "last_pd", None) if self.engine else None
        if pd is None:
            messagebox.showinfo(APP, "DPD 를 실행한 뒤에 저장할 수 있습니다.")
            return
        p = self.ask("DPD 신호 .wv 저장", ".wv", [("R&S waveform", "*.wv")], "NR100M_1C_DPD_%s.wv" % self.stamp())
        if p:
            E.C.write_wv(p, pd, self.engine.sig.fs, "NR 100 MHz 1C + DPD (PA DPD Tester)")
            self.remember_dir(p)
            self.log("저장: %s  (SG 레벨은 표의 마지막 SG 값으로)" % p)

    def save_coef(self):
        m = self.engine.model if self.engine else None
        if m is None or m.w is None:
            messagebox.showinfo(APP, "DPD 를 실행한 뒤에 저장할 수 있습니다.")
            return
        p = self.ask("DPD 계수 저장", ".csv", [("CSV", "*.csv")], "DPD_coef_%s.csv" % self.stamp())
        if p:
            names = m.term_names()
            with open(p, "w", encoding="utf-8-sig") as f:
                f.write("# K=%d M=%d L=%d odd=%s lambda=%g\nterm,re,im\n" % (m.K, m.M, m.L, m.odd, m.lam))
                for nm, c in zip(names, m.w):
                    f.write("%s,%.9e,%.9e\n" % (nm, c.real, c.imag))
            self.remember_dir(p)
            self.log("저장: %s" % p)

    def save_xlsx(self):
        if not self.results:
            messagebox.showinfo(APP, "저장할 결과가 없습니다.")
            return
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
        except ImportError:
            messagebox.showerror(APP, "openpyxl 이 없습니다.")
            return
        path = self.ask("결과 엑셀 저장", ".xlsx", [("Excel", "*.xlsx")], "DPD_%s.xlsx" % self.stamp())
        if not path:
            return
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "결과"
        p = self.params()
        ws.append(["PA DPD Tester %s" % VERSION, time.strftime("%Y-%m-%d %H:%M")])
        ws.append(["신호", "NR 100 MHz 1C · %s · %d 심볼 · ×%d · CFR %s %.1f dB" % (p["mod"], p["n_sym"], p["os"], "ON" if p["cfr_on"] else "OFF", p["papr_db"])])
        ws.append(["DPD", "K=%d M=%d L=%d %s λ=%g μ=%g 반복 %d" % (p["K"], p["M"], p["L"], "홀수만" if p["odd_only"] else "", p["lam"], p["mu"], p["iters"])])
        ws.append(["RF", "%.4f GHz · 입력 손실 %.2f dB · 출력 손실 %.2f dB · 보정 %.2f dB" % (p["freq_ghz"], p["in_loss_db"], p["out_loss_db"], p["cal_db"])])
        ws.append([])
        hd = ["단계", "SG dBm", "Pin dBm", "Pout dBm", "Gain dB", "ACLR L dBc", "ACLR U dBc", "EVM %", "PAPR dB", "학습 NMSE dB", "시각"]
        ws.append(hd)
        for c in ws[ws.max_row]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="1565C0")
            c.alignment = Alignment(horizontal="center")
        for r in self.results:
            ws.append([r["label"], round(r["sg"], 2), round(r["pin"], 2), round(r["pout"], 2), round(r["gain"], 2),
                       round(r["aclr_l"], 2), round(r["aclr_u"], 2), round(r["evm"], 3), round(r["papr"], 2),
                       round(r["nmse"], 2) if r.get("nmse") is not None else None, r["t"]])
        for col, w in zip("ABCDEFGHIJK", (10, 9, 9, 10, 9, 11, 11, 8, 9, 12, 9)):
            ws.column_dimensions[col].width = w
        ws2 = wb.create_sheet("스펙트럼")
        ws2.append(["MHz"] + [r["label"] + " dB" for r in self.results])
        for i, fval in enumerate(self.results[0]["spec_f"]):
            ws2.append([round(fval, 3)] + [round(r["spec_db"][i], 2) if i < len(r["spec_db"]) else None for r in self.results])
        ws3 = wb.create_sheet("AM-AM AM-PM")
        off, last = self.results[0], self.results[-1]
        ws3.append(["OFF 입력 dB", "OFF 이득 dB", "OFF 위상 °", "", last["label"] + " 입력 dB", "이득 dB", "위상 °"])
        for i in range(max(len(off["am_x"]), len(last["am_x"]))):
            a = [off["am_x"][i], off["am_g"][i], off["am_p"][i]] if i < len(off["am_x"]) else [None] * 3
            b = [last["am_x"][i], last["am_g"][i], last["am_p"][i]] if i < len(last["am_x"]) else [None] * 3
            ws3.append([round(v, 3) if v is not None else None for v in a] + [None] + [round(v, 3) if v is not None else None for v in b])
        try:
            wb.save(path)
        except PermissionError:
            messagebox.showerror(APP, "파일이 열려 있어 저장하지 못했습니다:\n%s" % path)
            return
        self.remember_dir(path)
        self.log("저장: %s" % path)

    def on_close(self):
        if self.worker and self.engine:
            if not messagebox.askyesno(APP, "측정 중입니다. 멈추고 닫을까요?"):
                return
            self.engine.stop = True
        self.save_settings()
        if self.engine:
            self.engine.close()
        self.root.destroy()


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
