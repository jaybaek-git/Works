@echo off
cd /d %~dp0
REM First time only:  python -m pip install numpy openpyxl pyvisa
set PY=
python -c "import sys" >nul 2>&1
if not errorlevel 1 set PY=python
if not defined PY (
  py -3 -c "import sys" >nul 2>&1
  if not errorlevel 1 set PY=py -3
)
if not defined PY (
  echo [ERROR] Python not found. Install Python 3.9+ from python.org ^(check "Add python.exe to PATH"^).
  pause
  exit /b 1
)
%PY% pa_dpd_tester.py
if errorlevel 1 pause
