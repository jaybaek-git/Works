# -*- coding: utf-8 -*-
"""PA DPD Tester - 측정 · DPD 반복 (화면 없이 동작, 화면은 콜백으로 결과를 받음)

순서: 신호 만들기 → [DPD OFF 측정] → 반복 { 받은 IQ 로 postdistorter 학습 (ILA) → 예왜곡 신호 보내기 → 측정 }
"""
import math
import time

import numpy as np

import bench_link as BL
import dpd_core as C
import instruments as I


class Stop(Exception):
    pass


DEFAULTS = dict(
    smw_host="demo", fsw_host="demo", file_max_msps=500.0, auto_model=True,
    method="ila", nn_hidden=24, nn_epochs=30, ilc_iters=10, ilc_gain=0.8,
    freq_ghz=3.6, sg_dbm=-10.0, sg_max_dbm=0.0, in_loss_db=0.5, out_loss_db=40.0, cal_db=0.0,
    fsw_ref_dbm=10.0, fsw_att_db="auto",
    os=4, n_sym=28, mod="256QAM", cfr_on=True, papr_db=8.0,
    sig_src="nr", wv_path="", ch_bw_mhz=98.28, adj_mhz=100.0,
    rec=None, auto_cal=False,
    K=7, M=4, L=1, odd_only=False, lam=1e-6, iters=4, mu=0.7, peak_lim_db=3.0, n_fit=40000, target_aclr=None,
)


class Engine:
    def __init__(self, p, log=None, on_result=None, on_progress=None, dc_reader=None):
        self.p = dict(DEFAULTS)
        self.p.update(p or {})
        self.log = log or (lambda s: None)
        self.on_result = on_result or (lambda r: None)
        self.on_progress = on_progress or (lambda s: None)
        self.dc_reader = dc_reader or (lambda: None)      # () → (Vdd V, Id A, 측정 시각, 출처) 또는 None
        self._cal_done = False
        self.stop = False
        self.smw = self.fsw = None
        self.sig = None
        self.model = None
        self.G = None
        self.results = []

    # ------------------------------------------------------------ 준비
    def check(self):
        if self.stop:
            raise Stop()

    def connect(self):
        if self.smw is None:
            self.log("장비 연결: SMW %s · FSW %s" % (self.p["smw_host"], self.p["fsw_host"]))
            self.smw, self.fsw = I.open_pair(self.p["smw_host"], self.p["fsw_host"])
            self.smw.log = self.fsw.log = self.log
            self.log("  SMW: %s" % self.smw.idn)
            self.log("  FSW: %s" % self.fsw.idn)

    def make_signal(self):
        p = self.p
        t0 = time.time()
        if p.get("sig_src") == "file":
            self.sig = C.FileSignal(p["wv_path"], max_fs=float(p.get("file_max_msps") or 0) * 1e6 or None)
            if self.sig.fs != self.sig.fs_file:
                self.log("신호 파일 %.2f MSps → %.2f MSps 로 줄여서 사용 (FSW 캡처 · 계산용, 잘린 대역 밖 성분 %.1f dB)"
                         % (self.sig.fs_file / 1e6, self.sig.fs / 1e6, self.sig.drop_db))
            self.log("신호: %s · %.2f MSps · %d 샘플 (%.3f ms) · PAPR %.2f dB - EVM 은 파형 비교"
                     % (p["wv_path"], self.sig.fs / 1e6, len(self.sig.x), len(self.sig.x) / self.sig.fs * 1e3, C.papr(self.sig.x)))
            if len(self.sig.x) > 2000000:
                self.log("  ⚠ 샘플이 많아 (%d) 한 번 측정에 시간이 걸립니다" % len(self.sig.x))
        else:
            self.sig = C.NRSignal(os=p["os"], n_sym=p["n_sym"], mod=p["mod"])
            pk0 = C.papr(self.sig.x)
            if p["cfr_on"]:
                pk = self.sig.cfr(p["papr_db"])
            else:
                pk = pk0
            self.log("신호: NR 100 MHz 1C · %s · %d 심볼 · %.2f MSps · %d 샘플 · PAPR %.2f → %.2f dB (%.1f초)"
                     % (p["mod"], p["n_sym"], self.sig.fs / 1e6, len(self.sig.x), pk0, pk, time.time() - t0))
        self.model = self.make_model()
        self.G = None
        return self.sig

    def make_model(self, K=None, M=None, L=None):
        p = self.p
        if p.get("method") == "nn":
            m = C.NNModel(p["M"] if M is None else M, int(p.get("nn_hidden", 24)), int(p.get("nn_epochs", 30)))
        else:
            m = C.DPDModel(p["K"] if K is None else K, p["M"] if M is None else M, p["L"] if L is None else L,
                           p["odd_only"], p["lam"])
        m.w = None
        return m

    # ------------------------------------------------------------ 한 번 측정
    def measure(self, pd, label, it=0, nmse=None, step="", kind=None):
        p, sig, x = self.p, self.sig, self.sig.x
        t_meas = time.time()
        self.cur = dict(label=label, step=step, t=t_meas)
        et = self.eta_text()
        self.on_progress("%s측정 중 · %s%s" % ((et + " · ") if et else "", label, (" · " + step) if step else ""))
        lvl = p["sg_dbm"] + 20 * math.log10(C.rms(pd) / C.rms(x))      # 원래 신호와 같은 크기 비율로 (SMW 는 RMS 를 레벨에 맞춤)
        clipped = False
        if lvl > p["sg_max_dbm"]:
            self.log("  ⚠ SG 레벨 %.2f dBm > 최대 %.2f dBm → 최대로 제한" % (lvl, p["sg_max_dbm"]))
            lvl, clipped = p["sg_max_dbm"], True
        self.check()
        wv = C.write_wv(None, pd, sig.fs, comment="PA DPD Tester %s" % label)
        self.log("  %s: SG %.2f dBm 로 신호 보내는 중 (%.1f MB)…" % (label, lvl, len(wv) / 1e6))
        self.smw.load_wave(wv, p["freq_ghz"] * 1e9, lvl, rf_on=True)
        self.check()
        att = None if str(p["fsw_att_db"]).strip().lower() in ("auto", "") else float(p["fsw_att_db"])
        bw = self.fsw.setup(p["freq_ghz"] * 1e9, sig.fs, p["fsw_ref_dbm"], att)
        n = 2 * len(pd) + 2000 if len(pd) <= 600000 else len(pd) + 20000     # 긴 신호는 한 주기 + 여유만
        time.sleep(0.2)
        t_cap = time.time()
        self.log("  FSW I/Q 받는 중: %d 샘플 · %.2f MSps (%.2f ms, %.1f MB)…" % (n, sig.fs / 1e6, n / sig.fs * 1e3, n * 8 / 1e6))
        y = self.fsw.capture(n, len(pd) + 20000)
        if len(y) < n:
            self.log("    FSW 한 번에 %d 샘플만 받음 (한 주기 + 여유로 계산)" % len(y))
        self.check()
        # Vdd 전원 전류: 이 신호를 보낸 뒤에 읽은 값 (최대 1.5초 기다림)
        dc = None
        t_end = time.time() + 1.5
        while True:
            try:
                dc = self.dc_reader()
            except Exception:
                dc = None
            if dc is None or dc[2] >= t_cap or time.time() > t_end or self.stop:
                break
            time.sleep(0.1)
        y_al, g, d = C.align(pd, y)
        if len(y) >= 2 * len(pd) + 1000:
            # 두 주기를 받았으면 둘째 주기도 맞춰 평균 → 측정 잡음 3 dB 줄어듦 (ILC · DLA 의 바닥이 낮아짐)
            try:
                y2, _, _ = C.align(pd, y[len(pd):])
                y2 = y2 * np.exp(1j * np.angle(np.vdot(y2, y_al)))
                y_al = 0.5 * (y_al + y2)
            except Exception:
                pass
        if self.G is None:
            self.G = C.small_signal_gain(x, y_al)
        else:
            # 측정마다 SMW · FSW 사이 위상이 달라짐 → 작은 신호 구간 위상을 처음 측정 (DPD OFF) 에 맞춤
            c = C.small_signal_gain(pd, y_al)
            y_al = y_al * np.exp(1j * (np.angle(self.G) - np.angle(c)))
        pout = C.iq_power_dbm(y_al, p["out_loss_db"] + p["cal_db"])
        rec = p.get("rec")
        rec_p = BL.pout_at_sg(rec, lvl) if rec else float("nan")
        if rec and p.get("auto_cal") and it == 0 and not self._cal_done and math.isfinite(rec_p):
            self._cal_done = True
            # Bench 기록 (같은 SG 레벨의 DUT Pout) 에 맞춰 Pout 보정값을 정함 → 이후 측정도 같은 보정
            d = rec_p - pout
            p["cal_db"] = p["cal_db"] + d
            pout = rec_p
            self.log("  Pout 보정 = %.2f dB (Bench 기록: SG %.2f dBm → DUT Pout %.2f dBm 에 맞춤)" % (p["cal_db"], lvl, rec_p))
        bwc, adj = p.get("ch_bw_mhz", 98.28) * 1e6, p.get("adj_mhz", 100.0) * 1e6
        al, au, full = C.aclr(y_al, sig.fs, bwc, adj)
        if bw == bw and bw > 0 and bw / 2 < adj + bwc / 2:
            full = False                           # FSW 분석 대역폭이 인접 채널 끝 (±149.14 MHz) 보다 좁음
        ev = C.evm_any(sig, y_al)
        f, sdb = C.spectrum_db(y_al, sig.fs)
        xin, gam, pm = C.am_curves(x, y_al, self.G)
        pin = lvl - p["in_loss_db"]
        vdd = idd = pdc = de = pae = float("nan")
        src = ""
        if dc is None and isinstance(self.smw, I.DemoSMW):
            # 데모: 가상 전원 (Vdd 48 V, Doherty 비슷한 효율 곡선)
            po_w = 10 ** ((pout - 30) / 10)
            eff = 0.18 + 0.40 * min(1.0, (po_w / 8.0) ** 0.45)
            dc = (48.0, po_w / eff / 48.0 + 0.25, time.time(), "demo")
        if dc is not None and dc[0] is not None and dc[1] is not None:
            vdd, idd, _t, src = dc
            pdc = vdd * idd
            if pdc > 0:
                po_w = 10 ** ((pout - 30) / 10)
                de = 100 * po_w / pdc
                pae = 100 * (po_w - 10 ** ((pin - 30) / 10)) / pdc
        r = dict(label=label, it=it, sg=lvl, pin=pin, pout=pout, gain=pout - pin, aclr_l=float(al), aclr_u=float(au),
                 aclr_full=bool(full), evm=ev, rec_pout=rec_p, cal_db=p["cal_db"], ch_bw=bwc / 1e6, adj=adj / 1e6,
                 evm_kind="OFDM" if getattr(sig, "X", None) is not None else "파형", papr=C.papr(pd), nmse=nmse, delay=d, fsw_bw=bw, clipped=clipped,
                 spec_f=(f / 1e6).tolist(), spec_db=sdb.tolist(), am_x=xin.tolist(), am_g=gam.tolist(), am_p=pm.tolist(),
                 t=time.strftime("%H:%M:%S"), kind=kind or ("off" if it == 0 else "dpd"), step=step, base_sg=p["sg_dbm"],
                 vdd=vdd, id=idd, pdc=pdc, de=de, pae=pae, dc_src=src)
        self.results.append(r)
        self._eta_tick(t_meas)
        self.log("  %s: Pout %.2f dBm · ACLR %.1f / %.1f dBc · EVM %.2f %% · PAPR %.2f dB%s%s"
                 % (label, pout, al, au, ev, r["papr"], (" · DE %.1f %% (Id %.3f A)" % (de, idd)) if de == de else "", "" if full else "  (⚠ 샘플레이트 · FSW 대역폭이 모자라 인접 채널 일부만 - ACLR 이 실제보다 좋게 나올 수 있음)"))
        self.on_result(r)
        return y_al, r

    # ------------------------------------------------------------ DPD
    def dpd_signal(self, w):
        x = self.sig.x
        pd = self.model.apply(x, w)
        lim = np.max(np.abs(x)) * 10 ** (self.p["peak_lim_db"] / 20)
        a = np.abs(pd)
        n_clip = int(np.sum(a > lim))
        pd = np.where(a > lim, pd * lim / np.maximum(a, 1e-12), pd)
        return pd, n_clip

    # ------------------------------------------------------------ 남은 시간 (측정 횟수 × 한 번 걸리는 시간)
    def eta_reset(self, total):
        self.eta = dict(total=int(total), done=0, per=None, t_last=None, lvl=None)

    def eta_level(self, planned):
        """한 레벨 시작: 이 레벨에서 할 측정 수 (계획). 앞 레벨이 일찍 끝났으면 그만큼 전체에서 뺌"""
        e = getattr(self, "eta", None)
        if e is None:
            return
        self.eta_level_end()
        e["lvl"] = (planned, e["done"])

    def eta_level_end(self):
        e = getattr(self, "eta", None)
        if e is None or e.get("lvl") is None:
            return
        planned, d0 = e["lvl"]
        used = e["done"] - d0
        e["total"] += used - planned                       # 목표 ACLR 에 일찍 닿음 · 반복이 더 됨 → 바로잡기
        e["lvl"] = None

    def eta_left(self):
        """남은 초 (지금 측정에서 이미 지난 시간을 빼서 1초씩 줄어듦) · None = 모름"""
        e = getattr(self, "eta", None)
        if not e:
            return None
        left = max(e["total"] - e["done"], 0)
        per = e["per"] or (5.0 if self.p.get("method") == "nn" else 4.0)
        since = time.time() - (e["t_last"] or getattr(self, "cur", {}).get("t", time.time()))
        return max(left * per - min(since, per * 0.95), 0.0)

    def eta_text(self):
        e = getattr(self, "eta", None)
        if not e:
            return ""
        left = max(e["total"] - e["done"], 0)
        per = e["per"] or (5.0 if self.p.get("method") == "nn" else 4.0)
        sec = left * per
        if left == 0:
            return "곧 끝"
        t = ("%d분 %02d초" % (sec // 60, sec % 60)) if sec >= 60 else "%d초" % max(sec, 1)
        return "남은 약 %s (%d/%d)" % (t, e["done"], e["total"])

    def _eta_tick(self, t_start):
        e = getattr(self, "eta", None)
        if e is None:
            return
        now = time.time()
        dt = now - (e["t_last"] if e["t_last"] is not None else t_start)   # 학습 · 계산 시간도 포함
        e["per"] = dt if e["per"] is None else 0.6 * e["per"] + 0.4 * dt
        e["t_last"] = now
        e["done"] += 1

    def auto_model(self, y_off, label_pre, step):
        """DPD 모델 (K · M · L) 자동: ① 계산으로 36 조합의 검증 NMSE → 후보 3개 ② 후보마다 실제로 한 번 DPD 측정
        → ACLR 가장 좋은 것. 반환 (y_al, pd, last, w) - 이어서 그 모델로 반복"""
        p = self.p
        x = self.sig.x
        t0 = time.time()
        self.log("▶ %sDPD 모델 자동 찾기 ① 계산 (K · M · L 조합)…" % label_pre)
        self.on_progress(self.eta_text() + " · DPD 모델 찾는 중 (계산)")
        res = C.model_search(y_off / self.G, x, p["odd_only"], p["lam"], n_fit=min(int(p["n_fit"]), 30000),
                             cancelled=lambda: self.stop)
        self.check()
        cands = C.pick_models(res, 3)
        self.log("  %d 조합 %.1f초 · 후보: %s" % (len(res), time.time() - t0, " · ".join(
            "K%d M%d L%d (%.1f dB, %d 계수)" % (K, M, L, nm, nc) for nm, nc, K, M, L in cands)))
        best = None
        for i, (nm, nc, K, M, L) in enumerate(cands):
            self.check()
            name = "K%d M%d L%d" % (K, M, L)
            self.log("▶ %sDPD 모델 자동 찾기 ② 실측 %d/%d: %s" % (label_pre, i + 1, len(cands), name))
            self.model = self.make_model(K, M, L)
            w, nmse = self.model.fit(y_off / self.G, x, n_fit=p["n_fit"])
            self.model.w = w
            pd, _ = self.dpd_signal(w)
            y_al, last = self.measure(pd, "%s후보 %s" % (label_pre, name), 1, nmse, step)
            sc = max(last["aclr_l"], last["aclr_u"])
            if best is None or sc < best[0]:
                best = (sc, (K, M, L), y_al, pd, last, w)
        sc, (K, M, L), y_al, pd, last, w = best
        self.model = self.make_model(K, M, L)
        self.model.w = w
        p["K"], p["M"], p["L"] = K, M, L
        self.chosen = (K, M, L)
        self.log("  ✔ 고른 모델: K%d M%d L%d (ACLR %.1f dBc) → 이 모델로 반복" % (K, M, L, sc))
        return y_al, pd, last, w

    def _dpd_level(self, y_al, w, label_pre, step, target=None, start=None):
        """한 SG 레벨에서 DPD 반복 (w = 시작 계수, 앞 레벨 것) → (마지막 결과, 계수)
        start = (pd, last): 이미 그 계수로 측정한 결과 (자동 모델 찾기 뒤) → 첫 반복을 이어서"""
        x = self.sig.x
        pd = x
        last = None
        n = int(self.p["iters"])
        if start is not None:
            pd, last = start
            n = max(n - 1, 1)
            if target is not None and max(last["aclr_l"], last["aclr_u"]) <= target:
                self.log("  목표 ACLR %.1f dBc 이내 → 반복 끝" % target)
                return last, w, pd
        for it in range(1, n + 1):
            self.check()
            self.log("▶ %sDPD 반복 %d / %d" % (label_pre, it, n))
            if w is not None and it == 1 and last is None:
                # 앞 레벨 계수로 먼저 한 번 보내 보고 (학습 없이) 그 결과로 이어서 학습 → 반복이 줄어듦
                pd, _ = self.dpd_signal(w)
                self.model.w = w
                y_al, last = self.measure(pd, "%sDPD 0 (이전 계수)" % label_pre, it, None, step)
                if target is not None and max(last["aclr_l"], last["aclr_u"]) <= target:
                    self.log("  목표 ACLR %.1f dBc 이내 → 다음 레벨" % target)
                    return last, w, pd
            meth = self.p.get("method", "ila")
            mu = float(self.p["mu"])
            if meth == "nn":
                # 신경망: 이전 가중치에서 이어서 학습 (ILA 방식, 섞지 않음)
                self.on_progress("%s · 신경망 학습 중 · %d 번째" % (self.eta_text(), it))
                t0 = time.time()
                w, nmse = self.model.fit(y_al / self.G, pd, n_fit=self.p["n_fit"], init=w, cancelled=lambda: self.stop)
                self.check()
                self.log("  신경망 학습 %.1f초 (가중치 %d 개)" % (time.time() - t0, self.model.n_coef()))
            elif meth == "dla" and w is not None:
                # 직접 학습: PA 출력 오차 (원래 신호 - 출력/G) 를 원래 신호 basis 로 맞춰 계수에 더함
                e = x - y_al / self.G
                dw, _ = self.model.fit(x, e, n_fit=self.p["n_fit"])
                w = w + mu * dw
                nmse = 10 * np.log10(np.mean(np.abs(e) ** 2) / np.mean(np.abs(x) ** 2))
            else:
                wn, nmse = self.model.fit(y_al / self.G, pd, n_fit=self.p["n_fit"])
                w = wn if w is None else (1 - mu) * w + mu * wn
            self.model.w = w
            pd, n_clip = self.dpd_signal(w)
            if n_clip:
                self.log("  최고값 제한 (+%.1f dB) 에 걸린 샘플 %d 개" % (self.p["peak_lim_db"], n_clip))
            y_al, last = self.measure(pd, "%sDPD %d" % (label_pre, it), it, nmse, step)
            if target is not None and max(last["aclr_l"], last["aclr_u"]) <= target:
                self.log("  목표 ACLR %.1f dBc 이내 → 반복 끝" % target)
                break
        return last, w, pd

    def run(self, do_dpd=True):
        """DPD OFF 측정 → (do_dpd) DPD 반복. 결과 목록 반환"""
        self.stop = False
        self.results = []
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        x = self.sig.x
        self.G = None
        auto = self.p.get("auto_model") and self.p.get("method") != "nn"
        n_it = int(self.p["iters"])
        self.eta_reset(1 if not do_dpd else 1 + (3 + max(n_it - 1, 1) if auto else n_it))
        self.eta_level(self.eta["total"])
        self.log("▶ DPD OFF 측정")
        y_al, r0 = self.measure(x, "DPD OFF", 0, step="SG %.2f dBm" % self.p["sg_dbm"])
        if not do_dpd:
            return self.results
        tgt = self.p.get("target_aclr")
        stp = "SG %.2f dBm" % self.p["sg_dbm"]
        if self.p.get("auto_model") and self.p.get("method") != "nn":
            y_al, pd, last, w = self.auto_model(y_al, "", stp)
            last, w, pd = self._dpd_level(y_al, w, "", stp, tgt, start=(pd, last))
        else:
            last, w, pd = self._dpd_level(y_al, None, "", stp, tgt)
        self.last_pd = pd
        return self.results

    def _ilc_level(self, y_al, label_pre, step):
        """ILC: 모델 없이 측정을 되풀이하며 'PA 출력 = 원래 신호' 가 되는 입력을 샘플마다 직접 찾음 → 이 PA 의 한계 ACLR"""
        p, x = self.p, self.sig.x
        n = int(p.get("ilc_iters", 10))
        g = float(p.get("ilc_gain", 0.8))
        lim = np.max(np.abs(x)) * 10 ** (p["peak_lim_db"] / 20)
        u = x.copy()
        best = None
        for k in range(1, n + 1):
            self.check()
            self.log("▶ %sILC %d / %d (한계 ACLR 찾기)" % (label_pre, k, n))
            e = x - y_al / self.G
            gk = g if k <= 3 else g * 3.0 / k          # 뒤로 갈수록 작게 → 측정 잡음이 쌓이지 않게
            u = u + gk * e
            a = np.abs(u)
            u = np.where(a > lim, u * lim / np.maximum(a, 1e-12), u)
            nm = 10 * np.log10(np.mean(np.abs(e) ** 2) / np.mean(np.abs(x) ** 2))
            y_al, r = self.measure(u, "%sILC %d" % (label_pre, k), k, nm, step, kind="ilc")
            sc = max(r["aclr_l"], r["aclr_u"])
            if best is None or sc < best[0]:
                best = (sc, r)
            elif sc > best[0] + 3:
                self.log("  ILC 가 나빠짐 → 멈춤 (최고값 제한 · SG 최대 · 잡음 한계)")
                break
        self.log("  ✔ 한계 ACLR (ILC 최고): %.1f / %.1f dBc · Pout %.2f dBm" % (best[1]["aclr_l"], best[1]["aclr_u"], best[1]["pout"]))
        return best[1]

    def run_ilc(self, levels=None):
        """ILC 로 한계 ACLR: levels 없으면 지금 SG 레벨 한 번, 있으면 레벨마다 (DPD OFF → ILC)"""
        self.stop = False
        self.results = []
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        x = self.sig.x
        base = self.p["sg_dbm"]
        levels = levels or [base]
        per_lv = 1 + int(self.p.get("ilc_iters", 10))
        self.eta_reset(per_lv * len([l for l in levels if l <= self.p["sg_max_dbm"] + 1e-9]))
        try:
            for i, lv in enumerate(levels):
                self.check()
                if lv > self.p["sg_max_dbm"] + 1e-9:
                    break
                self.eta_level(per_lv)
                self.p["sg_dbm"] = lv
                step = "레벨 %d/%d · SG %.2f dBm" % (i + 1, len(levels), lv) if len(levels) > 1 else "SG %.2f dBm" % lv
                self.G = None
                self.log("━━ %s · DPD OFF" % step)
                y_al, r_off = self.measure(x, "OFF", 0, step=step)
                self._ilc_level(y_al, "", step)
        finally:
            self.p["sg_dbm"] = base
        return self.results

    def run_sweep(self, levels, pout_stop=None):
        """파워 스윕: SG 레벨마다 DPD OFF 측정 → DPD 학습 (앞 레벨 계수로 시작) → DPD ON 측정"""
        self.stop = False
        self.results = []
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        x = self.sig.x
        w = None
        base = self.p["sg_dbm"]
        tgt = self.p.get("target_aclr")
        auto = self.p.get("auto_model") and self.p.get("method") != "nn"
        n_it = int(self.p["iters"])
        nl = len([l for l in levels if l <= self.p["sg_max_dbm"] + 1e-9])
        plan = lambda first: 1 + ((3 + max(n_it - 1, 1)) if (first and auto) else (n_it + (0 if first else 1)))
        self.eta_reset(sum(plan(i == 0) for i in range(nl)))
        try:
            for i, lv in enumerate(levels):
                self.check()
                if lv > self.p["sg_max_dbm"] + 1e-9:
                    self.log("SG %.2f dBm > SG 최대 → 스윕 끝" % lv)
                    break
                self.eta_level(plan(w is None))
                self.p["sg_dbm"] = lv
                step = "레벨 %d/%d · SG %.2f dBm" % (i + 1, len(levels), lv)
                self.log("━━ %s" % step)
                self.G = None
                y_al, r_off = self.measure(x, "OFF", 0, step=step)
                if self.p.get("auto_model") and self.p.get("method") != "nn" and w is None:          # 첫 레벨에서만 모델을 찾고 다음 레벨은 그 모델로
                    y_al, pd, last, w = self.auto_model(y_al, "", step)
                    last, w, pd = self._dpd_level(y_al, w, "", step, tgt, start=(pd, last))
                else:
                    last, w, pd = self._dpd_level(y_al, w, "", step, tgt)
                self.last_pd = pd
                if pout_stop is not None and r_off["pout"] >= pout_stop:
                    self.log("Pout %.2f dBm ≥ 멈춤 %.2f dBm → 스윕 끝" % (r_off["pout"], pout_stop))
                    break
                self.eta_level_end()
        finally:
            self.p["sg_dbm"] = base
        return self.results

    def abort(self, rf_off=True):
        """즉시 중지: 장비와 주고받던 것을 바로 끊고, 새로 연결해서 SG RF OFF · FSW 원래 모드로 (다른 스레드에서 부름)"""
        self.stop = True
        self.on_result = lambda r: None                  # 끊긴 실행의 결과는 화면에 안 올림
        self.on_progress = lambda s: None
        smw, fsw = self.smw, self.fsw
        self.smw = self.fsw = None
        for d in (smw, fsw):
            io = getattr(d, "io", None)
            if io is not None:
                io.abort()
        if smw is not None and rf_off:
            try:
                if getattr(smw, "io", None) is None:
                    smw.rf(False)                                  # 가상 장비
                else:
                    io = I.ScpiSocket(smw.io.host, smw.io.port, timeout=5.0, name="SMW")
                    io.write("OUTP1 OFF")
                    io.opc()
                    io.close()
                self.log("SG RF OFF")
            except Exception as e:
                self.log("⚠ SG RF OFF 실패: %s - SMW 에서 RF 를 직접 꺼 주세요" % e)
        if fsw is not None and getattr(fsw, "io", None) is not None and fsw.prev:
            try:
                fsw.io = I.ScpiSocket(fsw.io.host, fsw.io.port, timeout=10.0, name="FSW")
                fsw.restore()
                fsw.io.close()
            except Exception as e:
                self.log("⚠ FSW 원래 모드로 못 되돌림: %s" % e)

    def fsw_restore(self):
        f = self.fsw
        if f is not None and hasattr(f, "restore"):
            f.restore()

    def rf_off(self):
        try:
            if self.smw is not None:
                self.smw.rf(False)
                self.log("SG RF OFF")
        except Exception as e:
            self.log("RF OFF 실패: %s" % e)

    def close(self):
        try:
            self.fsw_restore()
        except Exception:
            pass
        for d in (self.smw, self.fsw):
            try:
                d.close()
            except Exception:
                pass
        self.smw = self.fsw = None
