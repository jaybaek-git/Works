# -*- coding: utf-8 -*-
"""PA DPD Tester - 측정 · DPD 반복 (화면 없이 동작, 화면은 콜백으로 결과를 받음)

순서: 신호 만들기 → [DPD OFF 측정] → 반복 { 받은 IQ 로 postdistorter 학습 (ILA) → 예왜곡 신호 보내기 → 측정 }
"""
import math
import time

import numpy as np

import bench_link as BL
import dpd_core as C
import instruments as I


class Stop(Exception):
    pass


DEFAULTS = dict(
    smw_host="demo", fsw_host="demo", file_max_msps=0.0, auto_model=True,
    model="gmp", method="ila", dvr_seg=8, torch_dir="", aclr_src="fsw", iq_avg=2, focus_mhz="", focus_w=4.0, ref_margin_db=3.0, fsw_park=True, nn_hidden=24, nn_epochs=30, ilc_iters=15, ilc_gain=0.8,
    freq_ghz=3.6, sg_dbm=-10.0, sg_max_dbm=0.0, in_loss_db=0.5, out_loss_db=40.0, cal_db=0.0,
    fsw_ref_dbm="auto", fsw_att_db="auto", fsw_rbw_khz=0.0,
    os=4, n_sym=28, mod="256QAM", cfr_on=True, papr_db=8.0,
    sig_src="nr", wv_path="", ch_bw_mhz=98.28, adj_mhz=100.0,
    rec=None, auto_cal=False,
    K=7, M=4, L=1, odd_only=False, lam=1e-6, iters=4, mu=0.7, peak_lim_db=3.0, n_fit=40000, target_aclr=None,
)


MODEL_NAMES = {"gmp": "GMP", "sgmp": "구간 GMP", "dvr": "DVR", "nn": "신경망", "pnn": "위상정규 신경망", "tnn": "torch 신경망"}


def migrate_method(p):
    """예전 설정 (method = ila / dla / nn) → 모델 (model) + 학습 방식 (method = ila / dla)"""
    if p.get("method") == "nn":
        p["model"], p["method"] = "nn", "ila"
    p.setdefault("model", "gmp")
    if p.get("method") not in ("ila", "dla", "ilcm"):
        p["method"] = "ila"
    return p


def is_nn(p):
    return p.get("model") in ("nn", "pnn", "tnn")


def method_label(p):
    m = p.get("model", "gmp")
    if p.get("method") == "ilcm":
        return "%s-ILC→모델" % MODEL_NAMES.get(m, m)
    if is_nn(p):
        return MODEL_NAMES[m]
    return "%s-%s" % (MODEL_NAMES.get(m, m), "DLA" if p.get("method") == "dla" else "ILA")


class Engine:
    def __init__(self, p, log=None, on_result=None, on_progress=None, dc_reader=None):
        self.p = dict(DEFAULTS)
        self.p.update(p or {})
        migrate_method(self.p)
        self.log = log or (lambda s: None)
        self.on_result = on_result or (lambda r: None)
        self.on_progress = on_progress or (lambda s: None)
        self.dc_reader = dc_reader or (lambda: None)      # () → (Vdd V, Id A, 측정 시각, 출처) 또는 None
        self._cal_done = False
        self.stop = False
        self.smw = self.fsw = None
        self.sig = None
        self.model = None
        self.G = None
        self.results = []
        self.tag = None            # 방식 비교 때 결과에 붙일 방식 이름
        self.compare = []

    # ------------------------------------------------------------ 준비
    def check(self):
        if self.stop:
            raise Stop()

    def connect(self):
        if self.smw is None:
            self.log("장비 연결: SMW %s · FSW %s" % (self.p["smw_host"], self.p["fsw_host"]))
            self.smw, self.fsw = I.open_pair(self.p["smw_host"], self.p["fsw_host"],
                                             int(self.p.get("smw_port") or 5025), int(self.p.get("fsw_port") or 5025))
            self.smw.log = self.fsw.log = self.log
            self.log("  SMW: %s" % self.smw.idn)
            self.log("  FSW: %s" % self.fsw.idn)

    def make_signal(self):
        p = self.p
        t0 = time.time()
        if p.get("sig_src") == "file":
            self.sig = C.FileSignal(p["wv_path"], max_fs=float(p.get("file_max_msps") or 0) * 1e6 or None,
                                    up=int(p.get("file_up") or 1))
            if getattr(self.sig, "up", 1) > 1:
                self.log("신호 파일 %.2f MSps → ×%d = %.2f MSps 로 올려서 보냄 · 받음 (FSW I/Q 대역 ≈ ±%.0f MHz)"
                         % (self.sig.fs_file / 1e6, self.sig.up, self.sig.fs / 1e6, 0.4 * self.sig.fs / 1e6))
            if self.sig.drop_db is not None:
                self.log("신호 파일 %.2f MSps → %.2f MSps 로 줄여서 사용 (FSW 캡처 · 계산용, 잘린 대역 밖 성분 %.1f dB)"
                         % (self.sig.fs_file / 1e6, self.sig.fs / 1e6, self.sig.drop_db))
            self.log("신호: %s · %.2f MSps · %d 샘플 (%.3f ms) · PAPR %.2f dB - EVM 은 파형 비교"
                     % (p["wv_path"], self.sig.fs / 1e6, len(self.sig.x), len(self.sig.x) / self.sig.fs * 1e3, C.papr(self.sig.x)))
            if len(self.sig.x) > 2000000:
                self.log("  ⚠ 샘플이 많아 (%d) 한 번 측정에 시간이 걸립니다" % len(self.sig.x))
        else:
            self.sig = C.NRSignal(os=p["os"], n_sym=p["n_sym"], mod=p["mod"])
            pk0 = C.papr(self.sig.x)
            if p["cfr_on"]:
                pk = self.sig.cfr(p["papr_db"])
            else:
                pk = pk0
            self.log("신호: NR 100 MHz 1C · %s · %d 심볼 · %.2f MSps · %d 샘플 · PAPR %.2f → %.2f dB (%.1f초)"
                     % (p["mod"], p["n_sym"], self.sig.fs / 1e6, len(self.sig.x), pk0, pk, time.time() - t0))
        self.model = self.make_model()
        self.G = None
        self._plan = None
        self._wlog = False
        try:
            cars = C.find_carriers(self.sig.x, self.sig.fs)
            edge = max(abs(fc) + w / 2 for fc, w in cars) if cars else 0
            K = max(1, int(p.get("cap_up") or 1))
            if K > 1:
                self.log("  FSW 는 ×%d (%.2f MSps) 로 받음 → I/Q 대역 ≈ ±%.0f MHz (SMW 는 %.2f MSps 그대로 · 학습은 %.2f MSps)"
                         % (K, self.sig.fs * K / 1e6, 0.4 * self.sig.fs * K / 1e6, self.sig.fs / 1e6, self.sig.fs / 1e6))
            if edge > 0.4 * self.sig.fs * K:
                self.log("  ⚠ 신호 끝 (±%.0f MHz) 이 FSW I/Q 쓸 수 있는 대역 (≈ ±%.0f MHz = 0.8 × 샘플레이트) 보다 넓음 → "
                         "반송파 끝이 잘려 DPD · ACLR 이 틀림. 1 신호 샘플레이트 (400 MHz: '1000 MSps 넘으면 절반으로') 를 확인하세요" % (edge / 1e6, 0.4 * self.sig.fs * K / 1e6))
            if len(cars) > 1:
                bwm, adj = self.aclr_plan()[1:]
                self.log("  반송파 %d 개: %s → ACLR 은 반송파마다 양옆 (채널 %.2f MHz · 간격 %.1f MHz, 그 반송파 기준 dBc)"
                         % (len(cars), " · ".join("%+.1f MHz (폭 %.0f)" % (fc / 1e6, w / 1e6) for fc, w in cars),
                            bwm / 1e6, adj / 1e6))
        except Exception as ex:
            self.log("  (반송파 찾기 실패: %s)" % ex)
        return self.sig

    def aclr_plan(self):
        """ACLR · 집중 구간 기준 → (반송파 [(fc, 폭)], 채널 폭 Hz, 인접 간격 Hz)
        반송파 1 개 = 지금처럼 신호 가운데 (0 Hz) 기준 · 여러 개 = 반송파마다 그 중심 기준"""
        p = self.p
        bwc, adj = p.get("ch_bw_mhz", 98.28) * 1e6, p.get("adj_mhz", 100.0) * 1e6
        key = (id(self.sig), bwc, adj)
        if getattr(self, "_plan", None) and self._plan[0] == key:
            return self._plan[1]
        cars = C.find_carriers(self.sig.x, self.sig.fs) if self.sig is not None else []
        if len(cars) <= 1:
            plan = ([(0.0, bwc)], bwc, adj)
        else:
            occ = min(w for _f, w in cars)
            if bwc > occ * 1.05:                       # 채널 폭 칸이 반송파보다 넓음 (예: 400 MHz 칸에 100 MHz 반송파) → 반송파에 맞춤
                nom = C.nominal_bw(occ)
                plan = (cars, min(occ, nom * 0.9828), nom)
            else:
                plan = (cars, bwc, adj)
        self._plan = (key, plan)
        return plan

    def aclr_multi(self, f_hz, psd):
        """반송파 여러 개: → (아래 바깥, 위 바깥, 안쪽 [..], 이름 [..], 다 잼?) · 1 개면 None"""
        cars, bwm, adj = self.aclr_plan()
        if len(cars) <= 1:
            return None
        lst = C.aclr_carriers(f_hz, psd, cars, bwm, adj)
        if not lst:
            return None
        lo, hi = lst[0], lst[-1]
        inner = [d for d in lst if d is not lo and d is not hi]
        nm = lambda d: "C%d %s" % (d["car"] + 1, "아래" if d["side"] == "L" else "위")
        return (lo["dbc"], hi["dbc"], [d["dbc"] for d in inner], [nm(d) for d in inner],
                all(d["ok"] for d in lst), [(nm(d), d["f0"] / 1e6, d["dbc"]) for d in lst])

    def make_model(self, K=None, M=None, L=None):
        p = self.p
        K = p["K"] if K is None else K
        M = p["M"] if M is None else M
        L = p["L"] if L is None else L
        mdl = p.get("model", "gmp")
        if mdl == "tnn":
            import dpd_torch
            ok, msg = dpd_torch.load(p.get("torch_dir") or None)
            if ok:
                m = dpd_torch.TorchNNModel(M, int(p.get("nn_hidden", 24)), int(p.get("nn_epochs", 30)))
            else:
                # torch 가 없으면 멈추지 않고 numpy 위상정규 신경망으로 대신 (같은 구조 · 작고 느림)
                if not getattr(self, "_torch_warned", False):
                    self.log("  ⚠ torch 를 못 읽음 (%s) → numpy 위상정규 신경망으로 대신 돌림" % msg)
                    self._torch_warned = True
                m = C.NNModel(M, int(p.get("nn_hidden", 24)), int(p.get("nn_epochs", 30)), pn=True)
                m.fallback = True
        elif is_nn(p):
            m = C.NNModel(M, int(p.get("nn_hidden", 24)), int(p.get("nn_epochs", 30)), pn=(mdl == "pnn"))
        elif mdl == "dvr":
            m = C.DVRModel(int(p.get("dvr_seg", 8)), M, p["lam"])
        elif mdl == "sgmp":
            m = C.SegGMPModel(K, M, L, p["odd_only"], p["lam"])
        else:
            m = C.DPDModel(K, M, L, p["odd_only"], p["lam"])
        m.w = None
        return m

    # ------------------------------------------------------------ 한 번 측정
    def measure(self, pd, label, it=0, nmse=None, step="", kind=None):
        p, sig, x = self.p, self.sig, self.sig.x
        t_meas = time.time()
        self.cur = dict(label=label, step=step, t=t_meas)
        et = self.eta_text()
        self.on_progress("%s측정 중 · %s%s" % ((et + " · ") if et else "", label, (" · " + step) if step else ""))
        lvl = p["sg_dbm"] + 20 * math.log10(C.rms(pd) / C.rms(x))      # 원래 신호와 같은 크기 비율로 (SMW 는 RMS 를 레벨에 맞춤)
        clipped = False
        if lvl > p["sg_max_dbm"]:
            self.log("  ⚠ SG 레벨 %.2f dBm > 최대 %.2f dBm → 최대로 제한" % (lvl, p["sg_max_dbm"]))
            lvl, clipped = p["sg_max_dbm"], True
        self.check()
        wv = C.write_wv(None, pd, sig.fs, comment="PA DPD Tester %s" % label)
        self.log("  %s: SG %.2f dBm 로 신호 보내는 중 (%.1f MB)…" % (label, lvl, len(wv) / 1e6))
        self.smw.load_wave(wv, p["freq_ghz"] * 1e9, lvl, rf_on=True)
        self.check()
        att = None if str(p["fsw_att_db"]).strip().lower() in ("auto", "") else float(p["fsw_att_db"])
        ref_auto = str(p.get("fsw_ref_dbm", "auto")).strip().lower() in ("auto", "")
        ref = self._next_ref(pd, lvl) if ref_auto else float(p["fsw_ref_dbm"])
        self.fsw.park = bool(p.get("fsw_park", True))      # 받은 뒤 FSW 화면을 Mod. 화면에 둘지 (화면 정리 때도 씀)
        rbw = float(p.get("fsw_rbw_khz") or 0) * 1e3 or None
        K = max(1, int(p.get("cap_up") or 1))          # FSW 만 K 배 빠르게 받음 (SMW 는 신호 샘플레이트 그대로) → I/Q 대역 넓게
        bw = self.fsw.setup(p["freq_ghz"] * 1e9, sig.fs * K, ref if ref == ref else 10.0, att, rbw)
        if ref_auto and ref != ref:
            # 처음 (이 실행 · 이 레벨에서 아직 모름): FSW 자동 레벨로 Ref Level · 감쇠를 신호에 맞춤 → ADC 를 꽉 채워 잡음 바닥 ↓
            al_ = self.fsw.auto_level()
            if al_:
                ref = al_[0]
                self.log("  FSW 자동 레벨: Ref %.1f dBm · 감쇠 %.0f dB" % al_)
            else:
                ref = 10.0
                self.log("  ⚠ FSW 자동 레벨 안 됨 → Ref 10 dBm 로 한 번 받아 보고 맞춤")
        k_avg = max(1, int(p.get("iq_avg", 2)))
        L = len(pd)
        CAP = 4000000                                  # 한 번에 받는 최대 샘플 (FSW 메모리 · 전송 시간) - 넘으면 여러 번 받아 평균
        per_cap = max(1, min(k_avg, CAP // max(L * K, 1)))
        n = per_cap * L + 2000 if per_cap > 1 else L + 20000
        y = None
        m_ref = float(p.get("ref_margin_db", 3.0) or 3.0)      # Ref 여유 (최고값 위로)
        extra = getattr(self, "_ref_extra", 0.0)                 # 과입력 (IF OVLD) 으로 더 올린 만큼 (이 실행 동안 기억)
        for attempt in range(4):
            time.sleep(0.2)
            t_cap = time.time()
            self.log("  FSW I/Q 받는 중: %d 샘플 · %.2f MSps (%.2f ms, %.1f MB) · Ref %.1f dBm…"
                     % (n * K, sig.fs * K / 1e6, n / sig.fs * 1e3, n * K * 8 / 1e6, ref))
            self.fsw.overload(clear_only=True)
            y = self.fsw.capture(n * K, (L + 20000) * K)
            y_wide = y
            if K > 1:
                y = C.down_k(y, K)                     # 학습 · 정렬은 신호 샘플레이트로 (넓게 받은 것은 스펙트럼 · ACLR 에)
            if len(y) < n:
                self.log("    FSW 한 번에 %d 샘플만 받음 (한 주기 + 여유로 계산)" % len(y))
            self.check()
            pk = 10 * np.log10(max(float(np.max(np.abs(y)) ** 2) / (2 * 50.0), 1e-30) * 1e3)   # FSW 입력 최고 전력 dBm
            self._ref_mem = (pk, C.papr(pd), lvl)
            ov = self.fsw.overload()
            if ov:
                # FSW 과입력 → 그 I/Q 는 FSW 자체 왜곡이 섞임 (DPD 가 그걸 고치려다 막힘) → Ref ↑ (IF) · 감쇠 ↑ (RF) 하고 다시
                if ref_auto and attempt < 3:
                    extra += 3.0
                    self._ref_extra = extra
                    ref += 3.0
                    if "RF" in ov and att is None:
                        self.log("  ⚠ FSW %s → Ref +3 dB (%.1f dBm) 로 다시 받음 (감쇠 auto 라 같이 올라감)" % (ov, ref))
                    else:
                        self.log("  ⚠ FSW %s → Ref +3 dB (%.1f dBm) 로 다시 받음" % (ov, ref))
                    self.fsw.set_ref(ref)
                    if att is not None:
                        self.fsw.io.write("INP:ATT %.0f" % att)
                    continue
                self.log("  ⚠ FSW %s 인 채로 받음 - I/Q 에 FSW 왜곡이 섞임 (Ref Level · 감쇠 ↑)" % ov)
                break
            if not ref_auto or attempt >= 1:
                if pk > ref - 0.2:
                    self.log("  ⚠ FSW 입력 최고값 %.1f dBm 이 Ref %.1f dBm 에 닿음 - 찌그러짐 (Ref ↑ 또는 auto)" % (pk, ref))
                break
            if pk > ref - 0.3 or pk < ref - 6.0 - extra:
                new = pk + (m_ref if pk <= ref - 0.3 else m_ref + 1.5) + extra
                self.log("  FSW 입력 최고 %.1f dBm · Ref %.1f → %.1f dBm 로 맞춰 다시 받음" % (pk, ref, new))
                ref = new
                self.fsw.set_ref(ref)
                continue
            break
        self.fsw.park = bool(p.get("fsw_park", True))
        k_avg_need = k_avg > per_cap                      # 여러 번 받아야 하면 다 받은 뒤에 화면을 돌림
        if not k_avg_need:
            self.fsw.park_spec(p["freq_ghz"] * 1e9)        # FSW 화면을 Mod. 화면 (ACLR 스펙트럼) 으로
        # Vdd 전원 전류: 이 신호를 보낸 뒤에 읽은 값 (최대 1.5초 기다림)
        dc = None
        t_end = time.time() + 1.5
        while True:
            try:
                dc = self.dc_reader()
            except Exception:
                dc = None
            if dc is None or dc[2] >= t_cap or time.time() > t_end or self.stop:
                break
            time.sleep(0.1)
        y_al, g, d = C.align(pd, y)
        n_per = 1
        acc = y_al.copy()
        n_cap = 1
        while True:
            # 받은 I/Q 안의 주기마다 맞춰 평균 → 측정 잡음 10·log(주기 수) dB 줄어듦 (ILC · DLA 의 바닥이 낮아짐)
            k0 = 1 if n_cap == 1 else 0
            for kk in range(k0, per_cap + 1):
                if n_per >= k_avg or len(y) < (kk + 1) * L + 1000 and not (kk == 0 and len(y) >= L):
                    break
                try:
                    y2, _, _ = C.align(pd, y[kk * L:])
                    acc += y2 * np.exp(1j * np.angle(np.vdot(y2, y_al)))
                    n_per += 1
                except Exception:
                    break
            if n_per >= k_avg or n_cap >= 2 * k_avg:
                break
            self.check()                                # 모자라면 한 번 더 받음 (SMW 는 같은 신호를 계속 내보내는 중)
            y = self.fsw.capture(n * K, (L + 20000) * K)
            if K > 1:
                y = C.down_k(y, K)
            n_cap += 1
        if n_cap > 1:
            self.log("    I/Q 평균 %d 주기 (%d 번 받음)" % (n_per, n_cap))
        if k_avg_need:
            self.fsw.park_spec(p["freq_ghz"] * 1e9)
        y_al = acc / n_per
        if self.G is None:
            self.G = C.small_signal_gain(x, y_al)
        else:
            # 측정마다 SMW · FSW 사이 위상이 달라짐 → 작은 신호 구간 위상을 처음 측정 (DPD OFF) 에 맞춤
            c = C.small_signal_gain(pd, y_al)
            y_al = y_al * np.exp(1j * (np.angle(self.G) - np.angle(c)))
        pout = C.iq_power_dbm(y_al, p["out_loss_db"] + p["cal_db"])
        rec = p.get("rec")
        rec_p = BL.pout_at_sg(rec, lvl) if rec else float("nan")
        if rec and p.get("auto_cal") and it in (0, -1) and not self._cal_done and math.isfinite(rec_p):
            self._cal_done = True
            # Bench 기록 (같은 SG 레벨의 DUT Pout) 에 맞춰 Pout 보정값을 정함 → 이후 측정도 같은 보정
            d = rec_p - pout
            p["cal_db"] = p["cal_db"] + d
            pout = rec_p
            self.log("  Pout 보정 = %.2f dB (Bench 기록: SG %.2f dBm → DUT Pout %.2f dBm 에 맞춤)" % (p["cal_db"], lvl, rec_p))
        bwc, adj = p.get("ch_bw_mhz", 98.28) * 1e6, p.get("adj_mhz", 100.0) * 1e6
        y_sp, fs_sp = (y_wide, sig.fs * K) if K > 1 else (y_al, sig.fs)   # 스펙트럼 · I/Q ACLR = 넓게 받은 그대로 (정렬 필요 없음)
        al, au, full = C.aclr(y_sp, fs_sp, bwc, adj)
        if bw == bw and bw > 0 and bw / 2 < adj + bwc / 2:
            full = False                           # FSW 분석 대역폭이 인접 채널 끝 (±149.14 MHz) 보다 좁음
        a_in = a_nm = a_pos = None
        mc = self.aclr_multi(*C.welch_psd(y_sp, fs_sp))
        if mc is not None:                         # 반송파 여러 개: 반송파마다 양옆
            al, au, a_in, a_nm, full, a_pos = mc
            cars_, bwm_, adj_ = self.aclr_plan()
            edge = max(abs(fc) for fc, _w in cars_) + adj_ + bwm_ / 2
            if bw == bw and bw > 0 and bw / 2 < edge:
                full = False
        a_in_iq = list(a_in) if a_in is not None else None
        ev = C.evm_any(sig, y_al)
        f, sdb = C.spectrum_db(y_sp, fs_sp)
        f = f / 1e6
        iq_f, iq_db = np.asarray(f), np.asarray(sdb)
        mod_f = mod_db = None
        al_iq, au_iq, src_used = float(al), float(au), "iq"
        src_set = p.get("aclr_src", "fsw")
        use_mod = (src_set == "fsw" or (src_set == "fsw_end" and (it == 0 or getattr(self, "_force_mod", False)))) and kind != "lock"
        if p.get("mod_every") and src_set != "iq" and kind != "lock":
            use_mod = True                             # 그래프를 ACLR (Mod. 화면) 스펙트럼으로 → 반복마다 Mod. 화면 한 번 (약 1 초)
        if use_mod and not getattr(self, "_mod_fail", False):
            # ACLR 은 FSW Mod. 화면 (사용자가 맞춘 스펙트럼 ACLR 측정, 설정 그대로) 에서 → I/Q 잡음 바닥에 안 막힘
            try:
                self.check()
                m = self.fsw.mod_aclr(p["freq_ghz"] * 1e9, rbw, att)
                al, au, full, src_used = m["aclr_l"], m["aclr_u"], True, "fsw"
                if m.get("f"):
                    f, sdb = np.asarray(m["f"]), np.asarray(m["db"])
                    mod_f, mod_db = f, sdb
                if mc is not None:
                    # 반송파 여러 개: FSW 결과 순서가 반송파 수에 따라 달라짐 → FSW 트레이스를 반송파마다 직접 적분
                    if not getattr(self, "_mc_raw_logged", False):
                        self._mc_raw_logged = True
                        self.log("    FSW ACP 결과 원래 값: %s (참고 · 반송파 여러 개는 트레이스로 계산)" % m.get("raw"))
                    if m.get("f"):
                        lin = 10 ** (np.asarray(m["db"]) / 10)
                        mf = self.aclr_multi(np.asarray(m["f"]) * 1e6, lin)
                        if mf is not None:
                            al, au, a_in, a_nm, full, a_pos = mf
                        else:
                            al, au, src_used = al_iq, au_iq, "iq"
                    else:
                        al, au, src_used = al_iq, au_iq, "iq"
                        self.log("  ⚠ FSW 트레이스를 못 읽어 반송파 ACLR 은 I/Q 계산 값")
            except Stop:
                raise
            except Exception as ex:
                self._mod_fail = True
                self.log("  ⚠ FSW Mod. 화면 ACLR 못 읽음 → 이번 실행은 I/Q 계산 ACLR 로 (%s)" % ex)
                self.fsw._parked = getattr(self.fsw, "_parked", False)
                self.fsw.select_iq(sig.fs)
        xin, gam, pm = C.am_curves(x, y_al, self.G)
        pin = lvl - p["in_loss_db"]
        vdd = idd = pdc = de = pae = float("nan")
        src = ""
        if dc is None and isinstance(self.smw, I.DemoSMW):
            # 데모: 가상 전원 (Vdd 48 V, Doherty 비슷한 효율 곡선)
            po_w = 10 ** ((pout - 30) / 10)
            eff = 0.18 + 0.40 * min(1.0, (po_w / 8.0) ** 0.45)
            dc = (48.0, po_w / eff / 48.0 + 0.25, time.time(), "demo")
        if dc is not None and dc[0] is not None and dc[1] is not None:
            vdd, idd, _t, src = dc
            pdc = vdd * idd
            if pdc > 0:
                po_w = 10 ** ((pout - 30) / 10)
                de = 100 * po_w / pdc
                pae = 100 * (po_w - 10 ** ((pin - 30) / 10)) / pdc
        r = dict(label=label, it=it, sg=lvl, pin=pin, pout=pout, gain=pout - pin, aclr_l=float(al), aclr_u=float(au),
                 aclr_full=bool(full), evm=ev, rec_pout=rec_p, cal_db=p["cal_db"], ch_bw=bwc / 1e6, adj=adj / 1e6,
                 evm_kind="OFDM" if getattr(sig, "X", None) is not None else "파형", papr=C.papr(pd), nmse=nmse, delay=d, fsw_bw=bw, clipped=clipped,
                 spec_f=np.asarray(f).tolist(), spec_db=np.asarray(sdb).tolist(), aclr_src=src_used,
                 iq_f=iq_f.tolist(), iq_db=iq_db.tolist(),
                 mod_f=None if mod_f is None else np.asarray(mod_f).tolist(), mod_db=None if mod_db is None else np.asarray(mod_db).tolist(),
                 aclr_iq_l=al_iq, aclr_iq_u=au_iq, aclr_in=a_in, aclr_in_nm=a_nm, aclr_iq_in=a_in_iq, aclr_pos=a_pos, n_avg=n_per, fsw_ref=ref, am_x=xin.tolist(), am_g=gam.tolist(), am_p=pm.tolist(),
                 t=time.strftime("%H:%M:%S"), kind=kind or ("off" if it == 0 else "dpd"), step=step, base_sg=p["sg_dbm"],
                 vdd=vdd, id=idd, pdc=pdc, de=de, pae=pae, dc_src=src, method=self.tag)
        if a_pos:                                   # 반송파 여러 개: 그래프용 반송파 위치 · 실제 쓴 채널 폭 · 간격
            cars_, bwm_, adj_ = self.aclr_plan()
            r["cars"], r["ch_bw"], r["adj"] = [fc / 1e6 for fc, _w in cars_], bwm_ / 1e6, adj_ / 1e6
        fd = self.focus_dbc(y_al) if self.focus_band() else None
        if fd is not None:
            r["focus_l"], r["focus_u"] = float(fd[0]), float(fd[1])
        if kind == "lock":                          # Pout 맞추기: 결과 표 · 기록에는 안 넣음
            return y_al, r
        # 이 측정의 입력 신호 (SMW 로 보낸 것) 보관 → 나중에 골라서 .wv 저장 · 다시 내보내기 (중지해도)
        if not hasattr(self, "pd_store"):
            self.pd_store, self._pd_n = {}, 0
        self._pd_n += 1
        r["pd_id"] = self._pd_n
        self.pd_store[self._pd_n] = (np.asarray(pd, dtype=np.complex64), float(p["sg_dbm"]), float(p["freq_ghz"]),
                                     np.asarray(y_al / self.G, dtype=np.complex64))      # (입력, SG, GHz, PA 출력 / 이득)
        if r["kind"] != "off":
            sc = C.aclr_worst(r)
            if getattr(self, "_best_id", None) is None or sc < self._best_sc:
                self._best_id, self._best_sc = self._pd_n, sc
        while len(self.pd_store) > 30:                     # 오래된 것부터 버림 (메모리) - 가장 좋은 것은 남김
            old = [k for k in sorted(self.pd_store) if k != getattr(self, "_best_id", None)]
            self.pd_store.pop(old[0])
        self.results.append(r)
        self._y_last = y_al
        self._eta_tick(t_meas)
        if a_in:
            self.log("    반송파 ACLR: " + " · ".join("%s %.1f" % (n_, v_) for n_, _f0, v_ in (a_pos or [])) + " dBc")
        self.log("  %s: Pout %.2f dBm%s · ACLR %.1f / %.1f%s dBc%s · EVM %.2f %% · PAPR %.2f dB%s%s"
                 % (label, pout, " (반송파 합)" if a_in else "", al, au, (" · 안쪽 " + " / ".join("%.1f" % v_ for v_ in a_in)) if a_in else "", (" (Mod. 화면 · I/Q 계산 %.1f / %.1f)" % (al_iq, au_iq)) if src_used == "fsw" else "", ev, r["papr"], (" · DE %.1f %% (Id %.3f A)" % (de, idd)) if de == de else "", "" if full else "  (⚠ 샘플레이트 · FSW 대역폭이 모자라 인접 채널 일부만 - ACLR 이 실제보다 좋게 나올 수 있음)"))
        self.on_result(r)
        return y_al, r

    # ------------------------------------------------------------ DPD
    def dpd_signal(self, w):
        x = self.sig.x
        pd = self.model.apply(x, w)
        lim = np.max(np.abs(x)) * 10 ** (self.p["peak_lim_db"] / 20)
        a = np.abs(pd)
        n_clip = int(np.sum(a > lim))
        pd = np.where(a > lim, pd * lim / np.maximum(a, 1e-12), pd)
        return pd, n_clip

    # ------------------------------------------------------------ 남은 시간 (측정 횟수 × 한 번 걸리는 시간)
    def _next_ref(self, pd, lvl):
        """다음 측정의 FSW Ref Level: 앞 측정 최고값 + 레벨 변화 + PAPR 변화 + 1.5 dB 여유 (모르면 nan → 자동 레벨)"""
        m = getattr(self, "_ref_mem", None)
        if not m:
            return float("nan")
        pk, papr0, lvl0 = m
        return pk + (lvl - lvl0) + (C.papr(pd) - papr0) + float(self.p.get("ref_margin_db", 3.0) or 3.0) + getattr(self, "_ref_extra", 0.0)

    def eta_reset(self, total):
        self._ref_mem = None              # 실행마다 처음엔 FSW 자동 레벨
        self._ref_extra = 0.0
        self._best_id = None              # 이번 실행에서 가장 좋은 측정 (보관 신호 지울 때 남김)
        self._mod_fail = False
        self.eta = dict(total=int(total), done=0, per=None, t_last=None, lvl=None)

    def eta_level(self, planned):
        """한 레벨 시작: 이 레벨에서 할 측정 수 (계획). 앞 레벨이 일찍 끝났으면 그만큼 전체에서 뺌"""
        e = getattr(self, "eta", None)
        if e is None:
            return
        self.eta_level_end()
        e["lvl"] = (planned, e["done"])

    def eta_level_end(self):
        e = getattr(self, "eta", None)
        if e is None or e.get("lvl") is None:
            return
        planned, d0 = e["lvl"]
        used = e["done"] - d0
        e["total"] += used - planned                       # 목표 ACLR 에 일찍 닿음 · 반복이 더 됨 → 바로잡기
        e["lvl"] = None

    def eta_left(self):
        """남은 초 (지금 측정에서 이미 지난 시간을 빼서 1초씩 줄어듦) · None = 모름"""
        e = getattr(self, "eta", None)
        if not e:
            return None
        left = max(e["total"] - e["done"], 0)
        per = e["per"] or (5.0 if is_nn(self.p) else 4.0)
        since = time.time() - (e["t_last"] or getattr(self, "cur", {}).get("t", time.time()))
        return max(left * per - min(since, per * 0.95), 0.0)

    def eta_text(self):
        e = getattr(self, "eta", None)
        if not e:
            return ""
        left = max(e["total"] - e["done"], 0)
        per = e["per"] or (5.0 if is_nn(self.p) else 4.0)
        sec = left * per
        if left == 0:
            return "곧 끝"
        t = ("%d분 %02d초" % (sec // 60, sec % 60)) if sec >= 60 else "%d초" % max(sec, 1)
        return "남은 약 %s (%d/%d)" % (t, e["done"], e["total"])

    def _eta_tick(self, t_start):
        e = getattr(self, "eta", None)
        if e is None:
            return
        now = time.time()
        dt = now - (e["t_last"] if e["t_last"] is not None else t_start)   # 학습 · 계산 시간도 포함
        e["per"] = dt if e["per"] is None else 0.6 * e["per"] + 0.4 * dt
        e["t_last"] = now
        e["done"] += 1

    def auto_model(self, y_off, label_pre, step):
        """DPD 모델 (K · M · L) 자동: ① 계산으로 36 조합의 검증 NMSE → 후보 3개 ② 후보마다 실제로 한 번 DPD 측정
        → ACLR 가장 좋은 것. 반환 (y_al, pd, last, w) - 이어서 그 모델로 반복"""
        p = self.p
        x = self.sig.x
        t0 = time.time()
        self.log("▶ %sDPD 모델 자동 찾기 ① 계산 (K · M · L 조합)…" % label_pre)
        self.on_progress(self.eta_text() + " · DPD 모델 찾는 중 (계산)")
        # 메모리 깊이 · 교차 지연은 "샘플 수" → 샘플레이트가 491.52 MSps 의 몇 배인지만큼 후보도 늘림 (같은 시간을 보게)
        ratio = max(1, int(round(self.sig.fs / 491.52e6)))
        Ms = tuple(sorted({max(1, int(round(m * ratio))) for m in (2, 3, 4, 6)}))
        Ls = tuple(sorted({int(round(l * ratio)) for l in (0, 1, 2)})) if ratio <= 2 else (0, ratio, 2 * ratio)
        if ratio > 1:
            self.log("  샘플레이트 %.2f MSps (491.52 의 %d배) → M 후보 %s · L 후보 %s" % (self.sig.fs / 1e6, ratio, Ms, Ls))
        res = C.model_search(y_off / self.G, x, p["odd_only"], p["lam"], n_fit=min(int(p["n_fit"]), 30000),
                             Ms=Ms, Ls=Ls, cancelled=lambda: self.stop)
        self.check()
        cands = C.pick_models(res, 3)
        self.log("  %d 조합 %.1f초 · 후보: %s" % (len(res), time.time() - t0, " · ".join(
            "K%d M%d L%d (%.1f dB, %d 계수)" % (K, M, L, nm, nc) for nm, nc, K, M, L in cands)))
        best = None
        for i, (nm, nc, K, M, L) in enumerate(cands):
            self.check()
            name = "K%d M%d L%d" % (K, M, L)
            self.log("▶ %sDPD 모델 자동 찾기 ② 실측 %d/%d: %s" % (label_pre, i + 1, len(cands), name))
            self.model = self.make_model(K, M, L)
            w, nmse = self.model.fit(y_off / self.G, x, n_fit=p["n_fit"])
            self.model.w = w
            pd, _ = self.dpd_signal(w)
            y_al, last = self.measure(pd, "%s후보 %s" % (label_pre, name), 1, nmse, step)
            sc = C.aclr_worst(last)
            if best is None or sc < best[0]:
                best = (sc, (K, M, L), y_al, pd, last, w)
        sc, (K, M, L), y_al, pd, last, w = best
        self.model = self.make_model(K, M, L)
        self.model.w = w
        p["K"], p["M"], p["L"] = K, M, L
        self.chosen = (K, M, L)
        self.log("  ✔ 고른 모델: K%d M%d L%d (ACLR %.1f dBc) → 이 모델로 반복" % (K, M, L, sc))
        return y_al, pd, last, w

    def w_mode(self):
        """보정 기준: 'time' = 시간 영역 (전 대역 똑같이) · 'focus' = 주파수 영역 집중 구간 · 'aclr' = 주파수 영역 ACLR 인접 채널 자동"""
        m = self.p.get("w_mode")
        if m in ("time", "focus", "aclr"):
            return m
        return "focus" if self.p.get("focus_on", True) else "time"     # 예전 설정

    def weight_bands(self):
        """주파수 가중을 줄 구간 [(f_lo, f_hi) Hz] 또는 None (시간 영역)"""
        mode = self.w_mode()
        cars, bwm, adj = self.aclr_plan()
        if mode == "focus":
            fb = self.focus_band()
            if fb is None:
                return None
            return [b_ for fc, _w in cars for b_ in ((fc - fb[1], fc - fb[0]), (fc + fb[0], fc + fb[1]))]
        if mode == "aclr":
            out = []
            for i, (fc, _w) in enumerate(cars):
                for s_ in (-1, 1):
                    f0 = fc + s_ * adj
                    if any(j != i and abs(f0 - fj) < 0.5 * (wj + bwm) * 0.9 for j, (fj, wj) in enumerate(cars)):
                        continue
                    out.append((f0 - bwm / 2, f0 + bwm / 2))
            return out or None
        return None

    def focus_band(self):
        """집중 구간 (반송파 중심에서 떨어진 MHz, 예 '50-70') → (f1, f2) Hz 또는 None (보정 기준이 '집중 구간' 일 때만)"""
        if self.w_mode() != "focus":
            return None
        t = str(self.p.get("focus_mhz") or "").replace("~", "-").replace(",", "-").replace(" ", "")
        try:
            a, b = [float(v) for v in t.split("-") if v][:2]
        except (ValueError, TypeError):
            return None
        a, b = sorted((abs(a), abs(b)))
        return (a * 1e6, b * 1e6) if b > a else None

    def focus_weight(self, e):
        """오차 e 에 주파수 가중: 집중 구간 (양쪽) 밖을 1/가중 으로 줄임 → ILC · DLA 가 그 구간을 먼저 고침"""
        bands = self.weight_bands()
        if not getattr(self, "_wlog", False):
            self._wlog = True
            nm = {"time": "시간 영역 (전 대역 똑같이)", "focus": "주파수 영역 · 집중 구간", "aclr": "주파수 영역 · ACLR 인접 채널 자동"}[self.w_mode()]
            self.log("  보정 기준: %s%s" % (nm, (" · 가중 %s 배 · " % (self.p.get("focus_w") or 4) +
                                                 ", ".join("%.0f~%.0f" % (a_ / 1e6, b_ / 1e6) for a_, b_ in bands) + " MHz") if bands else
                                         (" (집중 구간 비어 있음 → 시간 영역)" if self.w_mode() == "focus" else "")))
        if not bands:
            return e                                   # 시간 영역: 전 대역 똑같이
        wgt = max(1.0, float(self.p.get("focus_w") or 4.0))
        f = np.fft.fftfreq(len(e), 1.0 / self.sig.fs)
        m = np.zeros(len(f), bool)
        for lo_, hi_ in bands:                         # 집중 구간 (반송파마다 ±) 또는 ACLR 인접 채널
            m |= (f >= lo_) & (f <= hi_)
        W = np.where(m, 1.0, 1.0 / wgt)               # 나머지를 줄임 (집중 구간 이득은 그대로 → 넘치지 않음)
        return np.fft.ifft(np.fft.fft(e) * W)

    def focus_dbc(self, y_al):
        """집중 구간 전력 (채널 대비 dBc, 아래 / 위) - I/Q 로 계산"""
        fb = self.focus_band()
        if fb is None:
            return None
        f, psd = C.welch_psd(y_al, self.sig.fs)
        cars, bwm, _adj = self.aclr_plan()
        mid, bw = 0.5 * (fb[0] + fb[1]), fb[1] - fb[0]
        lo, hi = [], []
        for fc, _w in cars:                            # 반송파마다 그 중심 기준, 그 반송파 전력 대비
            pc, _ = C.band_power(f, psd, fc, bwm)
            for s_, acc in ((-1, lo), (1, hi)):
                f0 = fc + s_ * mid
                if any(abs(f0 - fj) < 0.5 * (wj + bw) * 0.9 for fj, wj in cars if fj != fc and len(cars) > 1):
                    continue                           # 다른 반송파 안이면 뺌
                pa, _ = C.band_power(f, psd, f0, bw)
                acc.append(10 * np.log10(pa / pc))
        return (max(lo) if lo else float("nan")), (max(hi) if hi else float("nan"))

    def _final_mod(self, pd, label, step, kind=None):
        """ACLR 읽기 = 'OFF · 최종만' 일 때: 그 레벨 마지막 신호를 한 번 더 보내 FSW Mod. 화면 ACLR 로 잼 (그동안 반복은 I/Q 값)"""
        if self.p.get("aclr_src") != "fsw_end" or getattr(self, "_mod_fail", False) or self.p.get("mod_every"):
            return None                                  # 반복마다 Mod. 화면으로 쟀으면 다시 잴 필요 없음
        self.check()
        self._force_mod = True
        try:
            self.log("▶ %s최종 - FSW Mod. 화면 ACLR" % label)
            _y, r = self.measure(pd, "%s최종 (Mod. 화면)" % label, 99, None, step, kind=kind)
        finally:
            self._force_mod = False
        return r

    def _dpd_level(self, y_al, w, label_pre, step, target=None, start=None):
        if self.p.get("method") == "ilcm" and start is None:
            # ILC → 모델: 먼저 ILC 로 이 PA 에 맞는 입력 u 를 직접 찾고 → 모델이 '원래 신호 x → u' 를 배우게 (측정 잡음 덜 탐)
            self.log("▶ %sILC → 모델: ILC %d 번으로 정답 입력 찾기" % (label_pre, int(self.p.get("ilc_iters", 10))))
            self._ilc_level(y_al, label_pre + "ILC · ", step)
            u = self._ilc_u
            x = self.sig.x
            self.check()
            t0 = time.time()
            if is_nn(self.p):
                w, nm = self.model.fit(x, u, n_fit=self.p["n_fit"], init=None, cancelled=lambda: self.stop)
            else:
                w, nm = self.model.fit(x, u, n_fit=self.p["n_fit"])
            self.model.w = w
            self.log("  모델 학습 (x → ILC 입력) %.1f초 · 오차 %.1f dB" % (time.time() - t0, nm))
            pd, n_clip = self.dpd_signal(w)
            y_al, last = self.measure(pd, "%sILC→모델" % label_pre, 1, nm, step)
            start = (pd, last)
        last, w, pd = self._dpd_level_core(y_al, w, label_pre, step, target, start)
        r = self._final_mod(pd, label_pre, step)
        self.last_pd, self.last_sg = pd, self.p["sg_dbm"]
        self._resume = dict(kind="dpd", sg=self.p["sg_dbm"], w=w, pd=pd, last=(r or last), y_al=getattr(self, "_y_last", y_al))
        return (r or last), w, pd

    def _dpd_level_core(self, y_al, w, label_pre, step, target=None, start=None):
        """한 SG 레벨에서 DPD 반복 (w = 시작 계수, 앞 레벨 것) → (마지막 결과, 계수)
        start = (pd, last): 이미 그 계수로 측정한 결과 (자동 모델 찾기 뒤) → 첫 반복을 이어서"""
        x = self.sig.x
        pd = x
        last = None
        n = int(self.p["iters"])
        if start is not None:
            pd, last = start
            n = max(n - 1, 1)
            if target is not None and C.aclr_worst(last) <= target:
                self.log("  목표 ACLR %.1f dBc 이내 → 반복 끝" % target)
                return last, w, pd
        for it in range(1, n + 1):
            self.check()
            self.log("▶ %sDPD 반복 %d / %d" % (label_pre, it, n))
            if w is not None and it == 1 and last is None:
                # 앞 레벨 계수로 먼저 한 번 보내 보고 (학습 없이) 그 결과로 이어서 학습 → 반복이 줄어듦
                pd, _ = self.dpd_signal(w)
                self.model.w = w
                y_al, last = self.measure(pd, "%sDPD 0 (이전 계수)" % label_pre, it, None, step)
                if target is not None and C.aclr_worst(last) <= target:
                    self.log("  목표 ACLR %.1f dBc 이내 → 다음 레벨" % target)
                    return last, w, pd
            meth = self.p.get("method", "ila")
            mu = float(self.p["mu"])
            if is_nn(self.p):
                # 신경망: 이전 가중치에서 이어서 학습 (ILA 방식, 섞지 않음)
                self.on_progress("%s · 신경망 학습 중 · %d 번째" % (self.eta_text(), it))
                t0 = time.time()
                w, nmse = self.model.fit(y_al / self.G, pd, n_fit=self.p["n_fit"], init=w, cancelled=lambda: self.stop)
                self.check()
                self.log("  신경망 학습 %.1f초 (가중치 %d 개)" % (time.time() - t0, self.model.n_coef()))
            elif meth == "dla" and w is not None:
                # 직접 학습: PA 출력 오차 (원래 신호 - 출력/G) 를 원래 신호 basis 로 맞춰 계수에 더함
                e = self.focus_weight(x - y_al / self.G)
                dw, _ = self.model.fit(x, e, n_fit=self.p["n_fit"])
                w = w + mu * dw
                nmse = 10 * np.log10(np.mean(np.abs(e) ** 2) / np.mean(np.abs(x) ** 2))
            else:
                wn, nmse = self.model.fit(y_al / self.G, pd, n_fit=self.p["n_fit"])
                w = wn if w is None else (1 - mu) * w + mu * wn
            self.model.w = w
            pd, n_clip = self.dpd_signal(w)
            if n_clip:
                self.log("  최고값 제한 (+%.1f dB) 에 걸린 샘플 %d 개" % (self.p["peak_lim_db"], n_clip))
            y_al, last = self.measure(pd, "%sDPD %d" % (label_pre, it), it, nmse, step)
            if target is not None and C.aclr_worst(last) <= target:
                self.log("  목표 ACLR %.1f dBc 이내 → 반복 끝" % target)
                break
        return last, w, pd

    def lock_sg(self):
        """목표 Pout (p['pout_lock']) 이 있으면: DPD OFF 신호를 보내며 실제 Pout 을 재서 SG 를 맞춤 → 그 SG 로 고정
        (기울기는 잰 두 점으로 · 압축되면 더 크게 움직임 · SG 최대에서 멈춤)"""
        tgt = self.p.get("pout_lock")
        try:
            tgt = float(tgt)
        except (TypeError, ValueError):
            return None
        if tgt != tgt:
            return None
        x = self.sig.x
        sg = float(self.p["sg_dbm"])
        sg_max = float(self.p.get("sg_max_dbm", 0.0))
        tol = float(self.p.get("pout_lock_tol", 0.1) or 0.1)
        hist = []
        self.log("▶ Pout 맞추기: 목표 %.2f dBm (SG %.2f dBm 부터, ±%.2f dB 안)" % (tgt, sg, tol))
        po = float("nan")
        for k in range(10):
            self.check()
            sg = min(sg, sg_max)
            self.p["sg_dbm"] = sg
            self.G = None
            _y, r = self.measure(x, "Pout 맞추기 %d" % (k + 1), -1, step="SG %.2f dBm" % sg, kind="lock")
            po = r["pout"]
            hist.append((sg, po))
            err = tgt - po
            self.log("  %d) SG %.2f dBm → Pout %.2f dBm (목표와 %+.2f dB)" % (k + 1, sg, po, -err))
            if abs(err) <= tol:
                break
            slope = 1.0
            if len(hist) >= 2:
                (s1, p1), (s2, p2) = hist[-2], hist[-1]
                if abs(s2 - s1) > 0.005:
                    slope = min(max((p2 - p1) / (s2 - s1), 0.2), 1.5)
            new = round(sg + min(max(err / slope, -6.0), 6.0), 2)
            if new > sg_max:
                if sg >= sg_max - 1e-6:
                    self.log("  ⚠ SG 최대 (%.2f dBm) 에서도 목표 Pout 에 못 미침 → SG 최대로 진행 (2 카드 SG 최대 확인)" % sg_max)
                    break
                new = sg_max
            sg = new
        else:
            self.log("  ⚠ 10 번 안에 목표 ±%.2f dB 에 못 맞춤 → 마지막 SG 로 진행" % tol)
        self.p["sg_dbm"] = sg
        self.G = None
        self.log("  ✔ SG %.2f dBm 로 고정 (Pout %.2f dBm) → DPD 시작" % (sg, po))
        cb = getattr(self, "on_lock", None)
        if cb:
            try:
                cb(sg)
            except Exception:
                pass
        return sg

    def run(self, do_dpd=True):
        """DPD OFF 측정 → (do_dpd) DPD 반복. 결과 목록 반환"""
        self._wlog = False
        self.stop = False
        self.results = []
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        self.lock_sg()
        x = self.sig.x
        self.G = None
        auto = self.p.get("auto_model") and self.p.get("model", "gmp") == "gmp"
        n_it = int(self.p["iters"])
        self.eta_reset(1 if not do_dpd else 1 + (3 + max(n_it - 1, 1) if auto else n_it))
        self.eta_level(self.eta["total"])
        self.log("▶ DPD OFF 측정")
        y_al, r0 = self.measure(x, "DPD OFF", 0, step="SG %.2f dBm" % self.p["sg_dbm"])
        if not do_dpd:
            return self.results
        tgt = self.p.get("target_aclr")
        stp = "SG %.2f dBm" % self.p["sg_dbm"]
        if self.p.get("auto_model") and self.p.get("model", "gmp") == "gmp":
            y_al, pd, last, w = self.auto_model(y_al, "", stp)
            last, w, pd = self._dpd_level(y_al, w, "", stp, tgt, start=(pd, last))
        else:
            last, w, pd = self._dpd_level(y_al, None, "", stp, tgt)
        self.last_pd = pd
        return self.results

    def run_compare(self, methods, with_ilc=False):
        """방식 비교: 같은 SG 레벨 · 같은 DPD OFF 측정에서 출발해 방식마다 DPD 반복 → 방식별 최고 결과 요약
        methods = [(model, learn), ...]  예: [("gmp","ila"), ("gmp","dla"), ("dvr","ila"), ("nn","ila")]"""
        self._wlog = False
        self.stop = False
        self.results = []
        self.compare = []
        self._cmp_best = None
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        self.lock_sg()
        x = self.sig.x
        p = self.p
        keep = {k: p.get(k) for k in ("model", "method", "K", "M", "L")}
        n_it = int(p["iters"])
        tot = 1
        for mdl, lrn in methods:
            tot += (3 + max(n_it - 1, 1)) if (mdl == "gmp" and p.get("auto_model")) else n_it
        if with_ilc:
            tot += int(p.get("ilc_iters", 10))
        self.eta_reset(tot)
        self.eta_level(tot)
        stp = "SG %.2f dBm" % p["sg_dbm"]
        self.G = None
        self.tag = "OFF"
        self.log("━━ 방식 비교 · %d 가지%s · %s" % (len(methods), " + ILC 한계" if with_ilc else "", stp))
        y_off, r_off = self.measure(x, "DPD OFF", 0, step=stp)
        try:
            for i, (mdl, lrn) in enumerate(methods):
                self.check()
                p.update(keep)
                p["model"], p["method"] = mdl, lrn
                name = method_label(p)
                self.model = self.make_model()
                if getattr(self.model, "fallback", False):
                    name += " (numpy 대신)"
                self.tag = name
                self.log("━━ 방식 %d / %d: %s" % (i + 1, len(methods), name))
                t0 = time.time()
                n0 = len(self.results)
                try:
                    if mdl == "gmp" and p.get("auto_model"):
                        y_al, pd, last, w = self.auto_model(y_off, name + " · ", stp)
                        last, w, pd = self._dpd_level(y_al, w, name + " · ", stp, p.get("target_aclr"), start=(pd, last))
                    else:
                        last, w, pd = self._dpd_level(y_off, None, name + " · ", stp, p.get("target_aclr"))
                    err = ""
                except Stop:
                    raise
                except Exception as e:                     # 한 방식이 실패해도 다음 방식은 계속
                    self.log("  ⚠ %s 실패: %s" % (name, e))
                    err = str(e)
                pd_m = getattr(self, "last_pd", None)
                rs = [r for r in self.results[n0:] if r.get("kind") == "dpd"]
                if any(r.get("aclr_src") == "fsw" for r in rs):          # Mod. 화면 값이 있으면 그것끼리 (I/Q 값과 섞지 않음)
                    rs = [r for r in rs if r.get("aclr_src") == "fsw"]
                best = min(rs, key=lambda r: C.aclr_worst(r)) if rs else None
                self.compare.append(dict(name=name, model=mdl, learn=lrn, best=best, t=time.time() - t0,
                                         n_coef=self.model.n_coef() if self.model is not None else 0,
                                         kml=("M%d H%d" % (p["M"], p.get("nn_hidden", 24)) if mdl in ("nn", "pnn", "tnn") else
                                              "구간 %d · M%d" % (p.get("dvr_seg", 8), p["M"]) if mdl == "dvr" else
                                              "K%d M%d L%d" % (p["K"], p["M"], p["L"])), err=err))
                if best is not None:
                    sc_ = C.aclr_worst(best)
                    if getattr(self, "_cmp_best", None) is None or sc_ < self._cmp_best[0]:
                        self._cmp_best = (sc_, pd_m, p["sg_dbm"])
            if with_ilc:
                self.check()
                self.tag = "ILC 한계"
                t0 = time.time()
                b = self._ilc_level(y_off, "ILC · ", stp)
                self.compare.append(dict(name="ILC 한계", model="ilc", learn="", best=b, t=time.time() - t0, n_coef=0, kml="-", err=""))
        finally:
            p.update(keep)
            self.model = self.make_model()
            self.tag = None
        self.log("━━ 방식 비교 결과 (DPD OFF %.1f / %.1f dBc)" % (r_off["aclr_l"], r_off["aclr_u"]))
        for c in self.compare:
            b = c["best"]
            if b:
                self.log("  %-14s ACLR %.1f / %.1f dBc · EVM %.2f %% · Pout %.2f dBm · %.0f초 · 계수 %d"
                         % (c["name"], b["aclr_l"], b["aclr_u"], b["evm"], b["pout"], c["t"], c["n_coef"]))
            else:
                self.log("  %-14s 결과 없음 %s" % (c["name"], c["err"]))
        self.compare_off = r_off
        if self._cmp_best and self._cmp_best[1] is not None:
            self.last_pd, self.last_sg = self._cmp_best[1], self._cmp_best[2]     # 최종 신호 = 가장 좋은 방식
        return self.results

    def _ilc_level(self, y_al, label_pre, step, resume=None):
        """ILC: 모델 없이 측정을 되풀이하며 'PA 출력 = 원래 신호' 가 되는 입력을 샘플마다 직접 찾음 → 이 PA 의 한계 ACLR"""
        p, x = self.p, self.sig.x
        n = int(p.get("ilc_iters", 10))
        g = float(p.get("ilc_gain", 0.8))
        lim = np.max(np.abs(x)) * 10 ** (p["peak_lim_db"] / 20)
        u = x.copy()
        best = None            # (점수, 결과, 그때 입력 u, 그때 y_al)
        gk = g
        k0 = 0
        if resume:                                         # 이어서: 앞 ILC 의 가장 좋았던 입력 · 이득에서 계속
            u, y_al, gk, best, k0 = resume["u"].copy(), resume["y_al"], resume["gk"], resume["best"], resume["k"]
            n = int(resume["n"])
        for k in range(k0 + 1, k0 + n + 1):
            self.check()
            self.log("▶ %sILC %d / %d (한계 ACLR 찾기 · 이득 %.2f)" % (label_pre, k, k0 + n, gk))
            e = x - y_al / self.G
            u = u + gk * self.focus_weight(e)
            a = np.abs(u)
            n_clip = int(np.sum(a > lim))
            u = np.where(a > lim, u * lim / np.maximum(a, 1e-12), u)
            if n_clip:
                self.log("  최고값 제한 (+%.1f dB) 에 걸린 샘플 %d 개 (많으면 ILC 가 못 내려감 → 4 카드 최고값 제한 ↑)" % (p["peak_lim_db"], n_clip))
            nm = 10 * np.log10(np.mean(np.abs(e) ** 2) / np.mean(np.abs(x) ** 2))
            y_al, r = self.measure(u, "%sILC %d" % (label_pre, k), k, nm, step, kind="ilc")
            sc = C.aclr_worst(r)
            fd = self.focus_dbc(y_al)
            if fd is not None:                         # 집중 구간을 정했으면 그 구간 전력으로 좋고 나쁨을 판단
                sc = max([v_ for v_ in fd if v_ == v_] or [sc])
                self.log("  집중 구간 %s MHz: %.1f / %.1f dBc" % (self.p.get("focus_mhz"), fd[0], fd[1]))
            if best is None or sc < best[0]:
                best = (sc, r, u.copy(), y_al)
            elif sc > best[0] + 0.5:
                # 나빠지면 가장 좋았던 입력으로 돌아가서 이득을 반으로 (측정 잡음 · 과보정) → 천천히 더 내려감
                # (정한 반복 횟수는 끝까지 돌림 · 이득은 0.1 아래로 안 내림)
                gk = max(gk * 0.5, 0.1)
                u, y_al = best[2].copy(), best[3]
                self.log("  ILC 나빠짐 (%.1f > 최고 %.1f dBc%s) → 최고 때로 돌아가 이득 %.2f"
                         % (sc, best[0], " · 집중 구간" if fd is not None else "", gk))
            if r.get("clipped"):
                self.log("  ⚠ SG 레벨이 SG 최대에 걸림 → ILC 가 입력을 더 못 키움 (2 카드 SG 최대 확인)")
        self._ilc_u = best[2]
        self._resume = dict(kind="ilc", sg=self.p["sg_dbm"], u=best[2], y_al=best[3], gk=gk, best=best, k=k0 + n,
                            label_pre=label_pre, step=step)
        r_fin = self._final_mod(best[2], label_pre, step, kind="ilc")
        self.last_pd, self.last_sg = best[2], self.p["sg_dbm"]       # 최종 신호 = ILC 가장 좋았던 입력
        best = (best[0], r_fin or best[1])
        self.log("  ✔ 한계 ACLR (ILC 최고): %.1f / %.1f dBc · Pout %.2f dBm" % (best[1]["aclr_l"], best[1]["aclr_u"], best[1]["pout"]))
        return best[1]

    def run_ilc(self, levels=None):
        """ILC 로 한계 ACLR: levels 없으면 지금 SG 레벨 한 번, 있으면 레벨마다 (DPD OFF → ILC)"""
        self._wlog = False
        self.stop = False
        self.results = []
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        x = self.sig.x
        if not levels:
            self.lock_sg()                             # 한 레벨 ILC: 목표 Pout 에 SG 맞춘 뒤
        base = self.p["sg_dbm"]
        levels = levels or [base]
        per_lv = 1 + int(self.p.get("ilc_iters", 10))
        self.eta_reset(per_lv * len([l for l in levels if l <= self.p["sg_max_dbm"] + 1e-9]))
        try:
            for i, lv in enumerate(levels):
                self.check()
                if lv > self.p["sg_max_dbm"] + 1e-9:
                    break
                self.eta_level(per_lv)
                self.p["sg_dbm"] = lv
                step = "레벨 %d/%d · SG %.2f dBm" % (i + 1, len(levels), lv) if len(levels) > 1 else "SG %.2f dBm" % lv
                self.G = None
                self.log("━━ %s · DPD OFF" % step)
                y_al, r_off = self.measure(x, "OFF", 0, step=step)
                self._ilc_level(y_al, "", step)
        finally:
            self.p["sg_dbm"] = base
        return self.results

    def run_sweep(self, levels, pout_stop=None):
        """파워 스윕: SG 레벨마다 DPD OFF 측정 → DPD 학습 (앞 레벨 계수로 시작) → DPD ON 측정"""
        self.stop = False
        self.results = []
        self._cal_done = False
        self.connect()
        if self.sig is None:
            self.make_signal()
        x = self.sig.x
        w = None
        base = self.p["sg_dbm"]
        tgt = self.p.get("target_aclr")
        auto = self.p.get("auto_model") and self.p.get("model", "gmp") == "gmp"
        n_it = int(self.p["iters"])
        nl = len([l for l in levels if l <= self.p["sg_max_dbm"] + 1e-9])
        plan = lambda first: 1 + ((3 + max(n_it - 1, 1)) if (first and auto) else (n_it + (0 if first else 1)))
        self.eta_reset(sum(plan(i == 0) for i in range(nl)))
        try:
            for i, lv in enumerate(levels):
                self.check()
                if lv > self.p["sg_max_dbm"] + 1e-9:
                    self.log("SG %.2f dBm > SG 최대 → 스윕 끝" % lv)
                    break
                self.eta_level(plan(w is None))
                self.p["sg_dbm"] = lv
                step = "레벨 %d/%d · SG %.2f dBm" % (i + 1, len(levels), lv)
                self.log("━━ %s" % step)
                self.G = None
                y_al, r_off = self.measure(x, "OFF", 0, step=step)
                if self.p.get("auto_model") and self.p.get("model", "gmp") == "gmp" and w is None:          # 첫 레벨에서만 모델을 찾고 다음 레벨은 그 모델로
                    y_al, pd, last, w = self.auto_model(y_al, "", step)
                    last, w, pd = self._dpd_level(y_al, w, "", step, tgt, start=(pd, last))
                else:
                    last, w, pd = self._dpd_level(y_al, w, "", step, tgt)
                self.last_pd = pd
                if pout_stop is not None and r_off["pout"] >= pout_stop:
                    self.log("Pout %.2f dBm ≥ 멈춤 %.2f dBm → 스윕 끝" % (r_off["pout"], pout_stop))
                    break
                self.eta_level_end()
        finally:
            self.p["sg_dbm"] = base
        return self.results

    def run_more(self, n):
        """끝난 (또는 중지한) DPD · ILC 를 그 결과에서 이어서 n 번 더 (같은 SG 레벨 · 같은 계수 / 입력)"""
        self._wlog = False
        st = getattr(self, "_resume", None)
        if not st:
            raise RuntimeError("이어서 할 결과가 없음 - DPD 또는 ILC 를 먼저 실행")
        self.stop = False
        self.results = []
        self.connect()
        if self.sig is None:
            raise RuntimeError("신호가 없음")
        p = self.p
        base, base_it = p["sg_dbm"], p["iters"]
        p["sg_dbm"] = st["sg"]
        self.eta_reset(int(n) + 1)
        self.eta_level(int(n) + 1)
        stp = "SG %.2f dBm · 이어서" % st["sg"]
        try:
            if st["kind"] == "ilc":
                self.log("━━ ILC 이어서 %d 번 (지금까지 %d 번 · 최고 %.1f dBc)" % (n, st["k"], st["best"][0]))
                rs = dict(st)
                rs["n"] = n
                self._ilc_level(st["y_al"], st.get("label_pre", ""), stp, resume=rs)
            else:
                self.log("━━ DPD 이어서 %d 번 (%s)" % (n, method_label(p)))
                self.model.w = st["w"]
                p["iters"] = int(n) + 1                      # start 를 주면 반복 = iters - 1
                tgt = p.get("target_aclr")
                self._dpd_level(st["y_al"], st["w"], "이어서 · ", stp, tgt, start=(st["pd"], st["last"]))
        finally:
            p["sg_dbm"], p["iters"] = base, base_it
        return self.results

    def send_final(self, pd=None, sg=None):
        """최종 DPD 신호 (마지막 실행의 마지막 · 가장 좋은 입력) 를 SMW 로 보내고 RF 를 켜 둠 (계속 내보냄)"""
        pd = getattr(self, "last_pd", None) if pd is None else pd
        if pd is None:
            raise RuntimeError("보낼 최종 DPD 신호가 없음 - DPD (또는 ILC) 를 먼저 실행")
        self.stop = False
        self.connect()
        p, x = self.p, self.sig.x
        sg = getattr(self, "last_sg", p["sg_dbm"]) if sg is None else sg
        lvl = sg + 20 * math.log10(C.rms(pd) / C.rms(x))
        if lvl > p["sg_max_dbm"]:
            self.log("  ⚠ SG 레벨 %.2f dBm > 최대 %.2f dBm → 최대로 제한" % (lvl, p["sg_max_dbm"]))
            lvl = p["sg_max_dbm"]
        wv = C.write_wv(None, pd, self.sig.fs, comment="PA DPD Tester final DPD")
        self.log("▶ 최종 DPD 신호 내보내기: SG %.2f dBm · %.2f GHz · PAPR %.2f dB (%.1f MB) - RF 켜 둠"
                 % (lvl, p["freq_ghz"], C.papr(pd), len(wv) / 1e6))
        self.smw.load_wave(wv, p["freq_ghz"] * 1e9, lvl, rf_on=True)
        self.log("  ✔ SMW 가 최종 DPD 신호를 계속 내보내는 중 (끄려면 [SG RF OFF] 또는 Bench)")
        return lvl

    def abort(self, rf_off=True):
        """즉시 중지: 장비와 주고받던 것을 바로 끊고, 새로 연결해서 SG RF OFF · FSW 원래 모드로 (다른 스레드에서 부름)"""
        self.stop = True
        self.on_result = lambda r: None                  # 끊긴 실행의 결과는 화면에 안 올림
        self.on_progress = lambda s: None
        smw, fsw = self.smw, self.fsw
        self.smw = self.fsw = None
        for d in (smw, fsw):
            io = getattr(d, "io", None)
            if io is not None:
                io.abort()
        if smw is not None and rf_off:
            try:
                if getattr(smw, "io", None) is None:
                    smw.rf(False)                                  # 가상 장비
                else:
                    io = I.ScpiSocket(smw.io.host, smw.io.port, timeout=5.0, name="SMW")
                    io.write("OUTP1 OFF")
                    io.opc()
                    io.close()
                self.log("SG RF OFF")
            except Exception as e:
                self.log("⚠ SG RF OFF 실패: %s - SMW 에서 RF 를 직접 꺼 주세요" % e)
        if fsw is not None and getattr(fsw, "io", None) is not None and fsw.prev:
            try:
                fsw.io = I.ScpiSocket(fsw.io.host, fsw.io.port, timeout=10.0, name="FSW")
                fsw.restore()
                fsw.io.close()
            except Exception as e:
                self.log("⚠ FSW 원래 모드로 못 되돌림: %s" % e)

    def fsw_restore(self):
        f = self.fsw
        if f is not None and hasattr(f, "restore"):
            f.restore()

    def rf_off(self):
        try:
            if self.smw is not None:
                self.smw.rf(False)
                self.log("SG RF OFF")
        except Exception as e:
            self.log("RF OFF 실패: %s" % e)

    def close(self):
        try:
            self.fsw_restore()
        except Exception:
            pass
        for d in (self.smw, self.fsw):
            try:
                d.close()
            except Exception:
                pass
        self.smw = self.fsw = None
