@echo off
cd /d %~dp0
set PYTHONUTF8=1
echo ============================================
echo  PA DPD Tester v0.2.3.33 - EXE build
echo ============================================
call :findpy
if not defined PY (
  echo [ERROR] Python 3.9+ not found.
  echo   - Install from python.org ^(check "Add python.exe to PATH"^), or
  echo   - turn OFF "App execution aliases" for python.exe in Windows Settings
  echo     ^(Settings - Apps - Advanced app settings - App execution aliases^)
  pause
  exit /b 1
)
echo Using: %PY%
%PY% --version
%PY% -m pip install --upgrade pyinstaller numpy openpyxl
if errorlevel 1 (
  echo [ERROR] package install failed. Check proxy / pip settings.
  pause
  exit /b 1
)
set NAME=PA-DPD-Tester_v0.2.3.33
%PY% -m PyInstaller --noconfirm --clean --onedir --windowed --name "%NAME%" --icon assets\dpd.ico ^
  --add-data "assets\dpd.png;assets" --add-data "assets\dpd.ico;assets" ^
  --hidden-import dpd_engine --hidden-import dpd_core --hidden-import instruments --hidden-import demo_pa --hidden-import bench_link --hidden-import dpd_torch ^
  --exclude-module matplotlib --exclude-module PySide6 --exclude-module PyQt5 --exclude-module pandas --exclude-module scipy ^
  pa_dpd_tester.py
if errorlevel 1 (
  echo [ERROR] Build failed.
  pause
  exit /b 1
)
powershell -NoProfile -Command "Compress-Archive -Force -Path 'dist\%NAME%' -DestinationPath 'dist\%NAME%-win64.zip'"
echo.
echo  DONE:  dist\%NAME%\%NAME%.exe
echo         dist\%NAME%-win64.zip  (give this zip to other PCs - unzip, run the exe inside)
echo.
pause
exit /b 0

:findpy
REM 1) python on PATH (skip the Microsoft Store stub)  2) py launcher  3) usual install folders
set PY=
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
if not errorlevel 1 (
  set PY=python
  goto :eof
)
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
if not errorlevel 1 (
  set PY=py -3
  goto :eof
)
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*" "%ProgramFiles%\Python3*" "C:\Python3*") do (
  if exist "%%~D\python.exe" (
    "%%~D\python.exe" -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
    if not errorlevel 1 set PY="%%~D\python.exe"
  )
)
goto :eof
