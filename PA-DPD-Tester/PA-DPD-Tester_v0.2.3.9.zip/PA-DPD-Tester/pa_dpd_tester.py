# -*- coding: utf-8 -*-
"""PA DPD Tester - SMW200A + FSW 로 PA 에 간단한 DPD (메모리 다항식 / GMP) 를 적용해 성능 확인

- 신호: 5G NR 100 MHz 1 캐리어 (SCS 30 kHz, 273 RB) OFDM 만들기 또는 내 .wv (암호화 없는 것)
- 순서: [DPD OFF 측정] → DPD 반복 (간접 학습 ILA) → 매번 Pout · ACLR · EVM · PAPR
- 화면은 PA Bench Monitor 와 같은 모양 (위쪽 줄 · 큰 숫자 · 번호 카드 · 화이트/블랙) → 나중에 합칠 때 그대로
- 장비에는 아무것도 설치하지 않음 (LAN, SCPI raw socket 5025). 주소에 demo = 가상 PA
"""
import json
import math
import re
import os
import queue
import sys
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
from tkinter import filedialog, messagebox, ttk

import bench_link as BL

try:
    import dpd_engine as E
except Exception as _e:                     # numpy 가 없는 등
    E = None
    _IMPORT_ERR = _e

VERSION = "v0.2.3.9"
APP = "PA DPD Tester"

SET_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "PADPDTester")
SET_FILE = os.path.join(SET_DIR, "settings.json")

# PA Bench Monitor 와 같은 색 · 테마
BG = "#0b0f14"
DASH = "#141b22"
TOPBAR = "#1c2530"
C_ACLR = "#ffb74d"       # 주황 (Bench SG 색)
C_EVM = "#4fc3f7"        # 하늘 (Bench SA 색)
C_POUT = "#39ff88"       # 초록 (Bench 전류 색)
C_PAPR = "#e0e0e0"
C_EFF = "#ce93d8"        # 보라 (효율)
THEMES = {
    "light": dict(bg="#e9edf1", panel="#ffffff", border="#cfd8dc", fg="#1f2933", dim="#546e7a", unit="#78909c",
                  entry="#ffffff", entry_bd="#b0bec5", accent="#1e88e5", line="#eceff1", sel="#e3f2fd",
                  head="#eceff1", plot_bg="#ffffff", grid="#e6e6e6", plot_fg="#333333", plot_dim="#a0a0a0",
                  btn="#ffffff", btn_act="#eef2f5", warn="#c0504d", ok="#2e7d32", info="#1f4f8f",
                  log_bg="#263238", log_fg="#eceff1"),
    "dark": dict(bg="#0f141a", panel="#18212a", border="#2b3743", fg="#dfe6ec", dim="#9fb0bd", unit="#7d8f9c",
                 entry="#0f151b", entry_bd="#3a4855", accent="#1e88e5", line="#26313c", sel="#173451",
                 head="#1f2a35", plot_bg="#11181f", grid="#22303b", plot_fg="#cfd8dc", plot_dim="#6c7a86",
                 btn="#22303c", btn_act="#2c3b48", warn="#ef9a9a", ok="#81c784", info="#90caf9",
                 log_bg="#0b0f14", log_fg="#cfd8dc"),
}
THEME = dict(THEMES["light"])
C_OFF = "#9e9e9e"
C_DPD = "#1e88e5"
C_ITER = ["#c6dbef", "#9ecae1", "#6baed6", "#4292c6", "#2171b5", "#08519c"]
F = ("맑은 고딕", 9)
FB = ("맑은 고딕", 9, "bold")


def fnum(s, d=0.0):
    try:
        return float(str(s).strip())
    except (ValueError, TypeError):
        return d


def mix(c1, c2, k):
    a = [int(c1.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4)]
    b = [int(c2.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4)]
    return "#%02x%02x%02x" % tuple(int(round(x + (y - x) * k)) for x, y in zip(a, b))


# ---------------------------------------------------------------- 그래프 (Tk Canvas, 테마 색)
class Plot(tk.Canvas):
    def __init__(self, master, title="", xl="", yl="", **kw):
        super().__init__(master, highlightthickness=1, bd=0, **kw)
        self.title, self.xl, self.yl = title, xl, yl
        self.series = []
        self.xr = self.yr = None
        self.vlines = []
        self.user_yr = None                 # 더블클릭으로 정한 세로축 (None = 자동)
        self.store = None                   # (설정 dict, 키) - 정한 범위를 기억
        self.cur_yr = (0, 1)
        self.bind("<Configure>", lambda e: self.redraw())
        self.bind("<Double-Button-1>", lambda e: self.ask_range())

    def remember(self, settings, key):
        self.store = (settings, key)
        v = settings.get(key)
        self.user_yr = (float(v[0]), float(v[1])) if isinstance(v, (list, tuple)) and len(v) == 2 else None

    def ask_range(self):
        """세로축 범위 창 (가운데): 최소 · 최대 입력 → 적용, [자동] = 기본값으로"""
        top = tk.Toplevel(self)
        top.title("세로축 범위")
        top.transient(self.winfo_toplevel())
        top.resizable(False, False)
        f = ttk.Frame(top, padding=14)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="%s - 세로축 (%s)" % (self.title.split(" (")[0], self.yl), font=FB).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
        y0, y1 = self.cur_yr
        v_hi, v_lo = tk.StringVar(value="%g" % round(y1, 2)), tk.StringVar(value="%g" % round(y0, 2))
        ttk.Label(f, text="최대").grid(row=1, column=0, sticky="w")
        e1 = ttk.Entry(f, textvariable=v_hi, width=10, justify="right")
        e1.grid(row=1, column=1, padx=6, pady=2)
        ttk.Label(f, text="최소").grid(row=2, column=0, sticky="w")
        ttk.Entry(f, textvariable=v_lo, width=10, justify="right").grid(row=2, column=1, padx=6, pady=2)
        ttk.Label(f, text="지금: %s" % ("직접 정한 범위" if self.user_yr else "자동 (기본값)"), foreground="#78909c").grid(
            row=3, column=0, columnspan=3, sticky="w", pady=(4, 8))
        bf = ttk.Frame(f)
        bf.grid(row=4, column=0, columnspan=3, sticky="e")

        def keep(v):
            self.user_yr = v
            if self.store:
                st, k = self.store
                if v is None:
                    st.pop(k, None)
                else:
                    st[k] = list(v)
            self.redraw()

        def ok(e=None):
            try:
                a, b = float(v_lo.get()), float(v_hi.get())
            except ValueError:
                return
            if b <= a:
                a, b = b, a
            if b > a:
                keep((a, b))
            top.destroy()
        ttk.Button(bf, text="적용", command=ok).pack(side="left", padx=3)
        ttk.Button(bf, text="자동 (기본값)", command=lambda: (keep(None), top.destroy())).pack(side="left", padx=3)
        ttk.Button(bf, text="취소", command=top.destroy).pack(side="left", padx=3)
        top.bind("<Return>", ok)
        top.bind("<Escape>", lambda e: top.destroy())
        top.update_idletasks()
        rt = self.winfo_toplevel()
        x = rt.winfo_rootx() + (rt.winfo_width() - top.winfo_width()) // 2
        y = rt.winfo_rooty() + (rt.winfo_height() - top.winfo_height()) // 2
        top.geometry("+%d+%d" % (x, y))
        e1.focus_set()
        e1.select_range(0, "end")
        top.grab_set()

    def set(self, series, xr=None, yr=None, vlines=(), bubbles=()):
        self.series, self.xr, self.yr, self.vlines = series, xr, yr, list(vlines)
        self.bubbles = list(bubbles)
        self.redraw()

    @staticmethod
    def nice(lo, hi, n=5):
        if not (math.isfinite(lo) and math.isfinite(hi)) or hi <= lo:
            hi = lo + 1
        raw = (hi - lo) / n
        mag = 10 ** math.floor(math.log10(raw))
        step = min((m * mag for m in (1, 2, 2.5, 5, 10) if m * mag >= raw), default=mag * 10)
        v = math.floor(lo / step) * step
        out = []
        while v <= hi + step * 1e-6:
            if v >= lo - step * 1e-6:
                out.append(round(v, 10))
            v += step
        return out

    def redraw(self):
        T = THEME
        self.configure(bg=T["plot_bg"], highlightbackground=T["border"])
        self.delete("all")
        W, H = self.winfo_width(), self.winfo_height()
        if W < 50 or H < 50:
            return
        L, R, Tp, B = 52, 12, 26, 34
        self.create_text(L, 13, text=self.title, anchor="w", font=FB, fill=T["plot_fg"])
        self.create_text(W - R, 13, text=("세로축 직접 · " if self.user_yr else "") + "더블클릭 = 범위", anchor="e",
                         font=("맑은 고딕", 7), fill=T["plot_dim"])
        xs = [v for s in self.series for v in s["x"]]
        ys = [v for s in self.series for v in s["y"]]
        x0, x1 = self.xr if self.xr else ((min(xs), max(xs)) if xs else (0, 1))
        if self.user_yr:
            y0, y1 = self.user_yr
        elif self.yr:
            y0, y1 = self.yr
        elif ys:
            y0, y1 = min(ys), max(ys)
            pad = (y1 - y0) * 0.08 or 1
            y0, y1 = y0 - pad, y1 + pad
        else:
            y0, y1 = 0, 1
        x1 = x1 if x1 > x0 else x0 + 1
        y1 = y1 if y1 > y0 else y0 + 1
        self.cur_yr = (y0, y1)
        px = lambda v: L + (v - x0) / (x1 - x0) * (W - L - R)
        py = lambda v: H - B - (v - y0) / (y1 - y0) * (H - Tp - B)
        for t in self.nice(x0, x1, 6):
            self.create_line(px(t), Tp, px(t), H - B, fill=T["grid"])
            self.create_text(px(t), H - B + 4, text="%g" % t, anchor="n", font=("맑은 고딕", 8), fill=T["plot_dim"])
        for t in self.nice(y0, y1, 5):
            self.create_line(L, py(t), W - R, py(t), fill=T["grid"])
            self.create_text(L - 4, py(t), text="%g" % t, anchor="e", font=("맑은 고딕", 8), fill=T["plot_dim"])
        self.create_rectangle(L, Tp, W - R, H - B, outline=T["border"])
        self.create_text((L + W - R) / 2, H - 3, text=self.xl, anchor="s", font=("맑은 고딕", 8), fill=T["plot_dim"])
        self.create_text(6, Tp - 3, text=self.yl, anchor="sw", font=("맑은 고딕", 8), fill=T["plot_dim"])
        for v, col in self.vlines:
            if x0 <= v <= x1:
                self.create_line(px(v), Tp, px(v), H - B, fill=col, dash=(3, 3))
        for s in self.series:
            pts = [(px(a), py(b)) for a, b in zip(s["x"], s["y"])
                   if math.isfinite(a) and math.isfinite(b) and x0 <= a <= x1 and y0 <= b <= y1]
            if not pts:
                continue
            if s.get("dots"):
                r = s.get("r", 1)
                for a, b in pts:
                    self.create_rectangle(a - r, b - r, a + r, b + r, outline="", fill=s["color"])
            elif len(pts) > 1:
                self.create_line(*[c for p in pts for c in p], fill=s["color"], width=s.get("width", 1),
                                 dash=s.get("dash") or "")
            if s.get("marks"):
                r = s.get("r", 3)
                for a, b in pts:
                    if s.get("hollow"):
                        self.create_oval(a - r, b - r, a + r, b + r, outline=s["color"], width=2, fill=T["plot_bg"])
                    else:
                        self.create_oval(a - r, b - r, a + r, b + r, outline="", fill=s["color"])
        for bub in getattr(self, "bubbles", []):
            bx, by, txt, col = bub[:4]
            left = len(bub) > 4 and bub[4] == "l"
            if not (math.isfinite(bx) and math.isfinite(by)) or not (x0 <= bx <= x1 and y0 <= by <= y1):
                continue
            a, b = px(bx), py(by)
            self.create_oval(a - 8, b - 8, a + 8, b + 8, outline=col, width=3)
            t = self.create_text(0, 0, text=txt, fill="white", font=FB)
            bb = self.bbox(t)
            tw, th = bb[2] - bb[0] + 14, bb[3] - bb[1] + 6
            bx0 = min(max((a - 12 - tw) if left else (a + 12), L + 2), W - R - tw - 2)
            by0 = max(b - th - 10, Tp + 2)
            if len(bub) > 5:                                  # 줄 번호: 위쪽에 겹치지 않게 쌓고 점까지 선으로
                by0 = Tp + 4 + bub[5] * (th + 4)
                self.create_line(a, b - 8, bx0 + (tw if left else 0), by0 + th / 2, fill=col, width=1)
            self.create_rectangle(bx0, by0, bx0 + tw, by0 + th, fill=col, outline="")
            self.coords(t, bx0 + tw / 2, by0 + th / 2)
            self.tag_raise(t)
        ly = Tp + 8
        for s in self.series:
            if s.get("label"):
                self.create_line(W - R - 150, ly, W - R - 128, ly, fill=s["color"], width=3, dash=s.get("dash") or "")
                self.create_text(W - R - 124, ly, text=s["label"], anchor="w", font=("맑은 고딕", 8), fill=T["plot_fg"])
                ly += 14


class ScrollFrame(ttk.Frame):
    """세로 스크롤 틀 (내용은 .body)"""

    def __init__(self, parent, **kw):
        super().__init__(parent, **kw)
        self.cv = tk.Canvas(self, highlightthickness=0, bd=0)
        self.vsb = ttk.Scrollbar(self, orient="vertical", command=self.cv.yview)
        self.cv.configure(yscrollcommand=self.vsb.set)
        self.cv.pack(side="left", fill="both", expand=True)
        self.vsb.pack(side="right", fill="y")
        self.body = ttk.Frame(self.cv)
        self.win = self.cv.create_window(0, 0, window=self.body, anchor="nw")
        self.body.bind("<Configure>", lambda e: self.cv.configure(scrollregion=(0, 0, self.body.winfo_reqwidth(),
                                                                                 self.body.winfo_reqheight())))
        self.cv.bind("<Configure>", lambda e: self.cv.itemconfigure(self.win, width=e.width))
        self._scrollable = True
        # 마우스가 이 틀 (카드 · 칸 · 버튼 위 어디든) 에 들어오면 휠을 이 틀이 받음 (Bench 안에서도)
        self.bind("<Enter>", self._wheel_on, add="+")
        self.bind_all("<MouseWheel>", self._wheel, add="+")

    def _wheel_on(self, e=None):
        for ev in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.bind_all(ev, wheel_any, add="")

    def _wheel(self, e):
        return wheel_any(e)

    def scroll(self, e):
        if self.body.winfo_reqheight() <= self.cv.winfo_height():
            return
        n = -1 if (getattr(e, "delta", 0) > 0 or getattr(e, "num", 0) == 4) else 1
        self.cv.yview_scroll(n * 2, "units")


def wheel_any(e):
    """마우스 아래에서 가장 가까운 스크롤 틀을 굴림 (DPD 카드 · Bench 틀 모두)"""
    try:
        w = e.widget.winfo_containing(e.x_root, e.y_root)
    except (tk.TclError, KeyError, AttributeError):
        return
    while w is not None:
        if isinstance(w, (tk.Text, ttk.Treeview, tk.Listbox)):
            return                                    # 로그 · 표는 자기 스크롤
        if getattr(w, "_scrollable", False) and hasattr(w, "scroll"):
            w.scroll(e)
            return "break"
        if hasattr(w, "cv") and hasattr(w, "vsb"):    # Bench 의 ScrollFrame
            try:
                if w.vsb.winfo_ismapped():
                    n = -1 if (getattr(e, "delta", 0) > 0 or getattr(e, "num", 0) == 4) else 1
                    w.cv.yview_scroll(n * 2, "units")
                    return "break"
            except tk.TclError:
                pass
        w = w.master


# ---------------------------------------------------------------- 화면
class Tip:
    """마우스를 올리면 오른쪽 옆에 짧은 설명 (0.4초 뒤), 마우스가 나가거나 누르면 사라짐"""
    cur = None

    def __init__(self, w, text):
        self.w, self.text, self.top, self.job = w, text, None, None
        w.bind("<Enter>", self.enter, add="+")
        w.bind("<Leave>", self.hide, add="+")
        w.bind("<ButtonPress>", self.hide, add="+")
        w.bind("<Motion>", self.move, add="+")

    def enter(self, e):
        self.hide()
        self.job = self.w.after(400, lambda: self.show(e.x_root, e.y_root))

    def move(self, e):
        if self.top is not None:
            self.place(e.x_root, e.y_root)

    def place(self, x, y):
        t = self.top
        t.update_idletasks()
        sw, sh = t.winfo_screenwidth(), t.winfo_screenheight()
        w_, h_ = t.winfo_reqwidth(), t.winfo_reqheight()
        x_ = x + 18 if x + 18 + w_ < sw else x - 18 - w_
        y_ = min(y + 12, sh - h_ - 8)
        t.geometry("+%d+%d" % (x_, y_))

    def show(self, x, y):
        self.job = None
        if Tip.cur is not None and Tip.cur is not self:
            Tip.cur.hide()
        Tip.cur = self
        t = self.top = tk.Toplevel(self.w)
        t.overrideredirect(True)
        try:
            t.attributes("-topmost", True)
        except tk.TclError:
            pass
        title, _, body = self.text.partition("\n")
        f = tk.Frame(t, bg="#263238", highlightthickness=1, highlightbackground="#546e7a")
        f.pack()
        tk.Label(f, text=title, bg="#263238", fg="#ffd54f", font=("맑은 고딕", 10, "bold"), justify="left",
                 anchor="w").pack(fill="x", padx=10, pady=(6, 2))
        if body:
            tk.Label(f, text=body, bg="#263238", fg="#eceff1", font=("맑은 고딕", 9), justify="left", anchor="w",
                     wraplength=340).pack(fill="x", padx=10, pady=(0, 7))
        self.place(x, y)

    def hide(self, e=None):
        if self.job is not None:
            try:
                self.w.after_cancel(self.job)
            except tk.TclError:
                pass
            self.job = None
        if self.top is not None:
            try:
                self.top.destroy()
            except tk.TclError:
                pass
            self.top = None
        if Tip.cur is self:
            Tip.cur = None


# 칸 설명 (첫 줄 = 제목, 아래 = 무엇 · 이렇게 바꾸세요) - 사용 가이드 PPT 와 같은 내용
TIPS = {
    "bw_mode": "대역\n100 MHz DPD: NR 100 MHz 만들기 또는 내 .wv.\n400 MHz DPD: 내 .wv 만 (샘플레이트 그대로, 줄이기 없음).\n파일 · ACLR 채널 폭 · 간격은 대역마다 따로 기억.",
    "sig_src": "신호\nNR 100 MHz 1C 를 직접 만들거나, 내 .wv (R&S, 암호화 안 된 것) 를 불러옴.\n회사 신호가 있으면 내 .wv, 아니면 NR.",
    "wv_path": "내 .wv 파일\nSMW 에서 재생할 신호. 샘플레이트 그대로 씀.",
    "file_halve": "500 MSps 넘으면 절반으로 (100 MHz DPD 만)\n끄면 (기본) 내 .wv 샘플레이트 그대로.\n켜면 계산 · 전송이 2배 빨라지지만 샘플레이트 1/4 밖이 잘림.",
    "carrier": "캐리어\n1C (100 MHz). 2C 는 다음 버전.",
    "mod": "변조\nQPSK ~ 256QAM. 보통 256QAM (EVM 기준이 가장 엄격).",
    "n_sym": "OFDM 심볼 수\n신호 길이 (14 = 0.5 ms). 길수록 통계가 정확하지만 측정 · 전송이 느려짐.\n기본 28, 느리면 14.",
    "papr_db": "CFR 목표 PAPR\n피크를 잘라 PAPR 을 이 값으로 맞춤.\n기본 8 dB. PA 포화 (AM-AM 끝 처짐) 가 심하면 7 ~ 7.5.",
    "cfr_on": "CFR 사용\n피크 자르기. 끄면 원래 PAPR (약 11 dB) 그대로 → SG 최대 · PA 포화에 쉽게 걸림. 보통 켬.",
    "os": "샘플레이트\n×2 / ×3 / ×4 (245.76 ~ 491.52 MSps).\nDPD 는 신호보다 3 ~ 5 배 넓은 대역을 봐야 해서 ×4 권장.",
    "ch_bw_mhz": "ACLR 채널 폭\n채널 전력을 재는 폭 (MHz). NR 100 MHz = 98.28, 400 MHz 기본 380.16.\n내 .wv 일 때 신호 규격에 맞게 입력 (대역마다 기억).",
    "adj_mhz": "인접 채널 간격\n채널 중심 ~ 인접 채널 중심 (MHz). 100 MHz = 100, 400 MHz = 400.",
    "freq_ghz": "주파수\nSMW · FSW 중심 주파수 (GHz). 예 3.35 / 3.6 / 3.75.",
    "sg_dbm": "SG 레벨 (RMS)\n한 레벨 실행 때 SMW 출력. 3 카드 [SG 레벨 정하기] 로 목표 Pout 에서 자동 입력 가능.",
    "sg_max_dbm": "SG 최대\nDPD 가 SG 를 올려도 이 값을 넘지 않음 (PA 보호). 넘으면 최대로 제한하고 로그에 경고.",
    "in_loss_db": "입력 손실 (SG → PA)\n케이블 손실 dB. Pin · Gain · PAE 계산에 씀.",
    "out_loss_db": "출력 손실 (PA → FSW)\n감쇠기 포함 dB. 틀리면 Pout · PAE 가 전부 틀림 → 꼭 확인.",
    "cal_db": "Pout 보정\nPout 에 더하는 값. 3 카드 '기록에 맞춤' 이 켜져 있으면 자동으로 바뀜.",
    "fsw_ref_dbm": "FSW Ref Level (I/Q 받기)\nauto (권장) = 처음엔 FSW 자동 레벨, 그 뒤엔 측정 최고값 + 1.5 dB 로 매번 맞춤 → ADC 를 꽉 채워 잡음 바닥 ↓.\n숫자 (dBm) = 고정. 너무 높으면 잡음 바닥 ↑ (DPD 가 그 바닥에서 멈춤), 너무 낮으면 과입력.",
    "fsw_rbw_khz": "FSW RBW (kHz)\n예 100 → FSW Mod. 화면 ACLR 측정과 I/Q 화면 스펙트럼 창에 RBW 100 kHz.\nMod. 화면은 측정 때만 바꾸고 끝나면 원래대로 (Bench Mod. 측정 그대로). 빈칸 = FSW 화면 설정 그대로.\n작을수록 잡음 바닥 ↓ · 스윕 느려짐.",
    "fsw_att_db": "FSW 감쇠 (dB)\nauto = Ref Level 에 맞춰 자동. 숫자 = 고정 (I/Q 받기 · Mod. 화면 ACLR 측정 모두, Mod. 화면은 끝나면 원래대로).\n작을수록 잡음 바닥 ↓ · 너무 작으면 과입력 (FSW 경고).",
    "iq_avg": "I/Q 평균 주기\n신호 몇 주기를 받아 평균할지 (2 기본 · 4 = 잡음 3 dB 더 ↓).\n많을수록 DLA · ILC 가 더 내려가지만 받는 시간이 늘어남.",
    "aclr_src": "ACLR 읽기\nFSW Mod. 화면 (권장): Bench Mod. 측정에 맞춘 FSW 스펙트럼 ACLR (RBW · 평균 그대로) 을 매번 한 번 재서 씀 → I/Q 잡음에 안 막힘.\nI/Q 계산: 받은 I/Q 로 직접 계산 (빠름, 잡음 바닥이 높을 수 있음).\n학습은 둘 다 I/Q.",
    "bench_loss": "Bench 손실 표 사용\n켜 두면 주파수별 입력 · 출력 손실을 Bench 설정에서 그대로 가져옴.",
    "b_stype": "샘플 종류\nBench 의 샘플 종류. 바꾸면 그 샘플에서 쓰던 1 ~ 5 카드 설정으로 자동 전환.",
    "b_rec": "기록\nSG → Pout 계산에 쓸 .pam 기록. 지금 샘플 번호 (★) → 가까운 주파수 → Mod. → 최근 순서로 자동 선택.",
    "b_target": "목표 Pout\n원하는 DUT 출력 (dBm). [SG 레벨 정하기] 를 누르면 기록에서 SG 레벨을 계산해 2 카드에 넣음.",
    "auto_cal": "Pout 보정을 기록에 맞춤\nDPD OFF 측정 때 같은 SG 의 기록 Pout 과 비교해 보정값을 자동으로 → Bench 와 Pout 이 같아짐. 켬 권장.",
    "method": "학습 방식\nILA (간접): PA 출력 → 입력 역모델을 배움. 기본 · 안정.\nDLA (직접): 출력 오차를 직접 줄임 - 보통 0.5 ~ 3 dB 더 (조금 느림).\n신경망은 학습 방식 없음.",
    "model": "DPD 모델\nGMP: 기본 · 빠름.\n구간 GMP: Doherty 피크 켜지는 레벨 앞뒤로 GMP 두 벌 (경계 자동).\nDVR: 크기 구간마다 다른 기울기 - Doherty 꺾임에 강함.\n신경망 · 위상정규 신경망: 포화 근처 · 특이한 PA.\n[목록 편집…] 으로 안 쓰는 모델 숨기기.",
    "dvr_seg": "DVR 구간 수\n입력 크기를 몇 구간으로 나눠 기울기를 따로 줄지 (6 ~ 12, 기본 8).\n많을수록 꺾임을 잘 따라가지만 계수 · 잡음이 늘어남.",
    "K": "비선형 차수 K\n|x| 의 몇 제곱까지 쓸지 (5 ~ 9, 기본 7).\n피크 근처 압축 보정이 모자라면 ↑, 결과가 흔들리면 ↓.",
    "M": "메모리 깊이 M\n지금 + 이전 몇 샘플까지 볼지 (2 ~ 6, 기본 4).\nAM-AM 이 두껍게 퍼지면 (메모리 효과) ↑. 신경망도 씀.",
    "L": "GMP 교차 지연 L\n앞뒤 샘플 크기를 섞은 항 (0 ~ 2, 기본 1).\nDoherty · 넓은 대역이면 1 ~ 2. 0 = 메모리 다항식.",
    "iters": "반복 횟수\n학습 → 측정을 몇 번 (3 ~ 5). 보통 2 ~ 3 번째에 거의 수렴.",
    "mu": "섞기 비율 μ\n새 계수를 얼마나 반영 (0.5 ~ 1, 기본 0.7). 반복마다 ACLR 이 흔들리면 0.5.",
    "peak_lim_db": "최고값 제한\nDPD 가 피크를 원래보다 몇 dB 까지 키울 수 있나 (기본 3).\nSG 최대 · PA 포화에 걸리면 2.",
    "lam": "정규화 λ\n계수가 너무 커지지 않게 누르는 값 (기본 1e-6).\n결과가 들쭉날쭉하거나 계수가 폭주하면 1e-5 ~ 1e-4.",
    "n_fit": "학습 샘플 수\n한 번 학습에 쓰는 샘플 (기본 40000). 늘리면 정확 ↑ · 느려짐 (2 ~ 10만).",
    "nn_hidden": "신경망 은닉 크기\n은닉층 크기 (16 ~ 32, 기본 24). 크면 강하지만 학습이 느림.",
    "nn_epochs": "신경망 학습 횟수\n(20 ~ 50, 기본 30). 결과가 덜 좋으면 ↑.",
    "ilc_iters": "ILC 반복\n한계 ACLR 찾기 반복 (10 ~ 15).",
    "ilc_gain": "ILC 이득\n한 번에 고치는 양 (기본 0.8). 흔들리면 0.5.",
    "odd_only": "홀수 차수만\nK = 1, 3, 5 … 만 사용. 보통 끔 (짝수 항도 도움이 됨).",
    "auto_model": "K · M · L 자동\n계산으로 36 조합 → 후보 3개 실측 → ACLR 가장 좋은 것. 고른 값은 칸에 들어가고 샘플별 기억.\n처음 · 새 샘플이면 켬, 주파수 · 샘플 비교 측정이면 끄고 고정.",
    "run_mode": "실행 방식\n한 레벨: 2 카드 SG 레벨에서. 파워 스윕: SG 시작 ~ 끝을 간격마다 (레벨마다 OFF → DPD).\n처음엔 한 레벨로 확인 → 파워 스윕.",
    "sw_start": "SG 시작\n파워 스윕 첫 SG 레벨 (dBm).",
    "sw_stop": "SG 끝\n파워 스윕 마지막 SG 레벨. SG 최대 이하.",
    "sw_step": "SG 간격\n레벨 간격 dB (보통 1).",
    "pout_stop": "Pout 멈춤\n이 Pout 을 넘으면 스윕 끝 (PA 보호). 빈칸 = 끝까지.",
    "target_aclr": "목표 ACLR\n닿으면 그 레벨 반복을 끝냄 (dBc, 기본 -50). 빈칸 = 반복 수만큼.",
    "run_name": "기록 이름\n기록 목록 · 엑셀 이름. 빈칸 = 샘플 종류 · 시각.",
    "rf_off_end": "끝나면 SG RF OFF\n끝나거나 오류가 나면 RF 를 끔. 켬 권장 (중지는 항상 RF OFF).",
    "y_q": "세로축\nACLR vs Pout 그래프의 세로축 값.",
}
BTN_TIPS = {
    "btn_off": "DPD OFF 측정만\nDPD 없이 한 번 측정 - 연결 · 손실 · Pout 확인용.",
    "btn_go": "▶ DPD 실행\nDPD OFF → (K · M · L 자동) → DPD 반복. 파워 스윕이면 레벨마다, 앞 레벨 계수로 시작.",
    "cb_model": TIPS["model"],
    "btn_xloss": "추가 손실 표 (커플러 · 아이솔레이터 등)\n케이블 손실 (Bench 표 또는 위 칸) 에 주파수마다 더할 In · Out 손실.\nBench 케이블 손실 txt 와 같은 형식 · txt 불러오기 / 저장. 비우면 0 dB.",
    "btn_stop5": "DPD 측정 중지\nDPD 측정만 바로 멈춤 (SG RF OFF · FSW 원래 화면).\n바이어스 · 파워서플라이는 그대로. Bench 오른쪽 위 [긴급 정지] 와 다름.",
    "btn_cmp": "방식 비교 실행\n같은 SG 레벨 · 같은 DPD OFF 에서 고른 방식들을 차례로 DPD.\n끝나면 요약 표 (★ = 가장 좋은 것) + 방식마다 기록.\n처음 몇 번 해 보고 맞는 방식을 4 카드에 넣으면 됨.",
    "btn_models": "모델 목록 편집\n4 카드 · 방식 비교에 보일 모델을 넣고 빼기 (숨김일 뿐 · 언제든 다시).",
    "btn_ilc": "한계 ACLR (ILC)\n모델 없이 측정을 되풀이해 이 PA 를 DPD 로 어디까지 만들 수 있나 (기준선).\nDPD 와 3 dB 넘게 차이 나면 모델 · 방식을 바꿔 볼 것.",
}


class App:
    FIELDS = [
        # (키, 이름, 기본값, 단위, 카드)
        ("smw_host", "SMW200A 주소", "demo", "", "dev"),
        ("fsw_host", "FSW 주소", "demo", "", "dev"),
        ("mod", "변조", "256QAM", "", "sig"),
        ("n_sym", "OFDM 심볼 수", "28", "개 (14 = 0.5 ms)", "sig"),
        ("papr_db", "CFR 목표 PAPR", "8.0", "dB", "sig"),
        ("freq_ghz", "주파수", "3.6", "GHz", "rf"),
        ("sg_dbm", "SG 레벨 (RMS)", "-10", "dBm", "rf"),
        ("sg_max_dbm", "SG 최대", "0", "dBm (넘지 않음)", "rf"),
        ("in_loss_db", "입력 손실 (SG→PA)", "0.5", "dB", "rf"),
        ("out_loss_db", "출력 손실 (PA→FSW)", "40", "dB (감쇠기 포함)", "rf"),
        ("cal_db", "Pout 보정", "0", "dB", "rf"),
        ("fsw_ref_dbm", "FSW Ref Level", "auto", "dBm 또는 auto (권장)", "rf"),
        ("fsw_att_db", "FSW 감쇠", "auto", "dB 또는 auto", "rf"),
        ("fsw_rbw_khz", "FSW RBW", "", "kHz (빈칸 = 화면 그대로)", "rf"),
        ("iq_avg", "I/Q 평균", "2", "주기 (2 ~ 8)", "rf"),
        ("K", "비선형 차수 K", "7", "", "dpd"),
        ("M", "메모리 깊이 M", "4", "탭", "dpd"),
        ("L", "GMP 교차 지연 L", "1", "0 = 메모리 다항식", "dpd"),
        ("dvr_seg", "DVR 구간 수", "8", "개 (6 ~ 12)", "dpd"),
        ("iters", "반복 횟수", "4", "번", "dpd"),
        ("mu", "섞기 비율 μ", "0.7", "1 = 새 계수만", "dpd"),
        ("peak_lim_db", "최고값 제한", "3", "dB (원래 최고값 +)", "dpd"),
        ("lam", "정규화 λ", "1e-6", "", "dpd"),
        ("n_fit", "학습 샘플 수", "40000", "개", "dpd"),
        ("nn_hidden", "신경망 은닉 크기", "24", "개 (신경망만)", "dpd"),
        ("nn_epochs", "신경망 학습 횟수", "30", "번 (신경망만)", "dpd"),
        ("ilc_iters", "ILC 반복", "15", "번 (한계 ACLR)", "dpd"),
        ("ilc_gain", "ILC 이득", "0.8", "(작을수록 천천히 · 안정)", "dpd"),
    ]
    MODELS = (("gmp", "GMP"), ("sgmp", "구간 GMP"), ("dvr", "DVR"), ("nn", "신경망"), ("pnn", "위상정규 신경망"),
              ("tnn", "torch 신경망"))
    MODEL_TIP = {"gmp": "기본 · 빠르고 안정", "sgmp": "Doherty 피크 레벨 앞뒤로 GMP 두 벌",
                 "dvr": "크기 구간마다 다른 기울기 (Doherty 꺾임에 강함)", "nn": "작은 신경망 (ARVTDNN)",
                 "pnn": "신경망 + 위상 정규화 (진폭 왜곡부터 배움)",
                 "tnn": "PyTorch 큰 신경망 (2층 · 위상 정규화) - torch 없으면 numpy 로 대신"}
    # 모델마다 보이는 칸 (없는 칸은 모든 모델 공통)
    MODEL_ROWS = {"K": ("gmp", "sgmp"), "L": ("gmp", "sgmp"), "dvr_seg": ("dvr",), "mu": ("gmp", "sgmp", "dvr"),
                  "lam": ("gmp", "sgmp", "dvr"), "nn_hidden": ("nn", "pnn", "tnn"), "nn_epochs": ("nn", "pnn", "tnn"),
                  "_odd": ("gmp", "sgmp"), "_auto": ("gmp",), "_learn": ("gmp", "sgmp", "dvr")}
    CMP_DEF = ["gmp:ila", "gmp:dla", "sgmp:ila", "dvr:ila", "nn:ila", "pnn:ila"]
    OS_TXT = {"2": "245.76 MSps · 인접 채널 일부만", "3": "368.64 MSps", "4": "491.52 MSps (권장)"}

    def __init__(self, root, host=None, dash_parent=None, main_parent=None):
        """host = PA Bench Monitor (합친 프로그램 안 DPD 측정 화면). 그때는 위쪽 바 · 창 설정 · Esc 는 Bench 가 맡고,
        설정은 Bench 설정 안 'dpd' 에 저장, 큰 숫자는 dash_parent 에, 아래 화면은 main_parent 에 만듦"""
        self.root = root
        self.host = host
        self.dash_parent, self.main_parent = dash_parent, main_parent
        if host is not None:
            ds = host.s.get("dpd")
            if not isinstance(ds, dict) or not ds:
                ds = self.load_settings()                # 예전 PA DPD Tester 설정을 처음 한 번 가져옴
                host.s["dpd"] = ds
            self.s = ds
        else:
            self.s = self.load_settings()
            root.title("%s %s" % (APP, VERSION))
            try:
                base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
                ico = os.path.join(base, "assets", "dpd.png")
                if os.path.isfile(ico):
                    self._icon = tk.PhotoImage(file=ico)
                    root.iconphoto(True, self._icon)
            except Exception:
                pass
            root.geometry(self.s.get("geometry", "1500x920"))
        if not self.s.get("_mig_ref_auto"):
            # 예전 기본값 (FSW Ref 10 dBm 고정) → auto : 고정 Ref 가 높으면 I/Q 잡음 바닥이 올라가 DPD 가 거기서 멈춤
            for d_ in [self.s] + [v_ for v_ in (self.s.get("dpd_by_type") or {}).values() if isinstance(v_, dict)]:
                if str(d_.get("fsw_ref_dbm", "")).strip() in ("10", "10.0"):
                    d_["fsw_ref_dbm"] = "auto"
            self.s["_mig_ref_auto"] = 1
        self.v = {}
        self.q = queue.Queue()
        self.engine = None
        self.worker = None
        self.results = []
        self.recs = []
        self.bench = None
        self._themed = []
        if host is not None:
            self.apply_theme(host.s.get("theme", "light"), redraw=False, styles=False)
        else:
            self.apply_theme(self.s.get("theme", "light"), redraw=False)
        self.build()
        if host is None:
            root.protocol("WM_DELETE_WINDOW", self.on_close)
            root.bind_all("<Escape>", lambda e: self.stop())
        root.after(100, self.pump)
        if E is None:
            messagebox.showerror(APP, "계산 모듈을 불러오지 못했습니다 (numpy 필요):\n%s" % _IMPORT_ERR)

    # ------------------------------------------------------------ 설정
    def load_settings(self):
        try:
            with open(SET_FILE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def save_settings(self):
        s = self.s
        try:
            if getattr(self, "_cur_type", None) is not None:
                self.store_type(key=self._cur_type)      # 지금 샘플 종류 · 대역의 값
        except Exception:
            pass

        for k, var in self.v.items():
            s[k] = var.get()
        if self.host is not None:
            return                                     # Bench 가 자기 설정 파일에 같이 저장 (30초마다 · 닫을 때)
        try:
            s["geometry"] = self.root.geometry()
            os.makedirs(SET_DIR, exist_ok=True)
            with open(SET_FILE, "w", encoding="utf-8") as f:
                json.dump(s, f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    # ------------------------------------------------------------ 테마 (PA Bench Monitor 와 같음)
    @staticmethod
    def draw_switch(img, bg, track, knob, on, W=30, H=16):
        def hx(c):
            c = c.lstrip("#")
            return [int(c[i:i + 2], 16) for i in (0, 2, 4)]
        Bc, TR, KN = hx(bg), hx(track), hx(knob)
        r = H / 2.0
        kr = r - 2.0
        kx = (W - r) if on else r
        rows = []
        SS = 3
        for y in range(H):
            line = []
            for x in range(W):
                ct = ck = 0
                for sy in range(SS):
                    for sx in range(SS):
                        px_, py_ = x + (sx + 0.5) / SS, y + (sy + 0.5) / SS
                        cx = min(max(px_, r), W - r)
                        if (px_ - cx) ** 2 + (py_ - r) ** 2 <= r * r:
                            ct += 1
                            if (px_ - kx) ** 2 + (py_ - r) ** 2 <= kr * kr:
                                ck += 1
                a, k = ct / 9.0, ck / 9.0
                col = [Bc[i] + (TR[i] - Bc[i]) * a for i in range(3)]
                col = [col[i] + (KN[i] - col[i]) * k for i in range(3)]
                line.append("#%02x%02x%02x" % tuple(int(round(v)) for v in col))
            rows.append("{" + " ".join(line) + "}")
        img.put(" ".join(rows))

    def apply_switch_style(self, st):
        T = THEME
        off_t = "#455a64" if self.s.get("theme") == "dark" else "#b0bec5"
        if not hasattr(self, "_sw_imgs"):
            self._sw_imgs = {k: tk.PhotoImage(width=30, height=16) for k in ("on", "off", "don", "doff")}
            im = self._sw_imgs
            try:
                st.element_create("Switchp.indicator", "image", im["off"], ("disabled", "selected", im["don"]),
                                  ("disabled", im["doff"]), ("selected", im["on"]), border=0, padding=(0, 0, 6, 0), sticky="w")
            except tk.TclError:
                pass
        im = self._sw_imgs
        bg = T["panel"]
        self.draw_switch(im["on"], bg, T["accent"], "#ffffff", True)
        self.draw_switch(im["off"], bg, off_t, "#ffffff", False)
        self.draw_switch(im["don"], bg, mix(T["accent"], bg, 0.55), mix("#ffffff", bg, 0.3), True)
        self.draw_switch(im["doff"], bg, mix(off_t, bg, 0.55), mix("#ffffff", bg, 0.3), False)
        try:
            st.layout("Card.TCheckbutton", [("Checkbutton.padding", {"sticky": "nswe", "children": [
                ("Switchp.indicator", {"side": "left", "sticky": ""}),
                ("Checkbutton.focus", {"side": "left", "sticky": "w", "children": [("Checkbutton.label", {"sticky": "nswe"})]})]})])
            st.configure("Card.TCheckbutton", padding=(1, 2, 4, 2))
        except tk.TclError:
            pass

    def apply_theme(self, name="light", redraw=True, styles=True):
        name = name if name in THEMES else "light"
        self.s["theme"] = name
        THEME.clear()
        THEME.update(THEMES[name])
        T = THEME
        if not styles:                                 # Bench 안: ttk 모양은 Bench 가 정함 → 색만 다시 칠함
            for w, opts in list(self._themed):
                try:
                    w.configure(**{k: THEME[v] for k, v in opts.items()})
                except tk.TclError:
                    pass
            if redraw and hasattr(self, "p_spec"):
                for p in (self.p_spec, self.p_trend, self.p_amam, self.p_ampm, self.p_hist):
                    p.redraw()
            if hasattr(self, "f_recinfo"):
                self.show_rec()
            return
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure(".", background=T["bg"], foreground=T["fg"], fieldbackground=T["entry"], font=F,
                     bordercolor=T["border"], lightcolor=T["panel"], darkcolor=T["border"], troughcolor=T["bg"],
                     selectbackground=T["accent"], selectforeground="white", insertcolor=T["fg"])
        st.map(".", foreground=[("disabled", T["unit"])])
        for sty in ("TFrame", "TLabel", "TCheckbutton", "TRadiobutton"):
            st.configure(sty, background=T["bg"], foreground=T["fg"])
        st.configure("Card.TFrame", background=T["panel"])
        st.configure("Card.TLabel", background=T["panel"], foreground=T["fg"])
        st.configure("Lab.TLabel", background=T["panel"], foreground=T["dim"])
        st.configure("Unit.TLabel", background=T["panel"], foreground=T["unit"])
        st.configure("Hint.TLabel", background=T["panel"], foreground=T["unit"], font=("맑은 고딕", 8))
        st.configure("Info.TLabel", background=T["panel"], foreground=T["info"])
        st.configure("Head.TLabel", background=T["panel"], foreground=T["fg"], font=("맑은 고딕", 10, "bold"))
        st.configure("Num.TLabel", background=T["accent"], foreground="white", font=("맑은 고딕", 8, "bold"), anchor="center", width=2)
        st.configure("Card.TCheckbutton", background=T["panel"], foreground=T["fg"])
        st.map("Card.TCheckbutton", background=[("active", T["panel"])])
        self.apply_switch_style(st)
        st.configure("TEntry", fieldbackground=T["entry"], foreground=T["fg"], bordercolor=T["entry_bd"],
                     lightcolor=T["entry"], darkcolor=T["entry"], padding=(4, 2))
        st.map("TEntry", bordercolor=[("focus", T["accent"])], lightcolor=[("focus", T["accent"])])
        st.configure("TCombobox", fieldbackground=T["entry"], foreground=T["fg"], background=T["btn"],
                     arrowcolor=T["fg"], bordercolor=T["entry_bd"])
        st.map("TCombobox", fieldbackground=[("readonly", T["entry"])], foreground=[("readonly", T["fg"])],
               selectbackground=[("readonly", T["entry"])], selectforeground=[("readonly", T["fg"])])
        self.root.option_add("*TCombobox*Listbox.background", T["entry"])
        self.root.option_add("*TCombobox*Listbox.foreground", T["fg"])
        st.configure("TButton", background=T["btn"], foreground=T["fg"], bordercolor=T["entry_bd"],
                     lightcolor=T["btn"], darkcolor=T["btn"], padding=(8, 3), focuscolor=T["btn"])
        st.map("TButton", background=[("pressed", T["btn_act"]), ("active", T["btn_act"])])
        st.configure("Pri.TButton", background=T["accent"], foreground="white", bordercolor="#1565c0",
                     lightcolor=T["accent"], darkcolor=T["accent"], font=FB)
        st.map("Pri.TButton", background=[("pressed", "#1565c0"), ("active", "#1976d2"), ("disabled", T["border"])])
        st.configure("Seg.Toolbutton", background=T["panel"], foreground=T["accent"], padding=(10, 3), borderwidth=1,
                     relief="solid", bordercolor=T["accent"], lightcolor=T["panel"], darkcolor=T["panel"], font=F, anchor="center")
        st.map("Seg.Toolbutton", background=[("selected", T["accent"]), ("active", T["sel"])], foreground=[("selected", "white")],
               lightcolor=[("selected", T["accent"])], darkcolor=[("selected", T["accent"])], relief=[("selected", "solid")])
        st.configure("Tab.Toolbutton", background=T["head"], foreground=T["dim"], padding=(16, 6), font=("맑은 고딕", 10),
                     borderwidth=0, relief="flat", lightcolor=T["head"], darkcolor=T["head"])
        st.map("Tab.Toolbutton", background=[("selected", T["accent"]), ("active", T["sel"])], foreground=[("selected", "white")],
               lightcolor=[("selected", T["accent"])], darkcolor=[("selected", T["accent"])], relief=[("selected", "flat")])
        st.configure("Treeview", background=T["panel"], fieldbackground=T["panel"], foreground=T["fg"], bordercolor=T["border"], rowheight=22)
        st.map("Treeview", background=[("selected", T["sel"])], foreground=[("selected", T["fg"])])
        st.configure("Treeview.Heading", background=T["head"], foreground=T["dim"], bordercolor=T["border"], font=FB, relief="flat")
        for sb_ in ("TScrollbar", "Vertical.TScrollbar", "Horizontal.TScrollbar"):
            st.configure(sb_, background=T["border"], troughcolor=T["bg"], bordercolor=T["bg"], arrowcolor=T["dim"],
                         lightcolor=T["border"], darkcolor=T["border"], gripcount=0)
        st.configure("TPanedwindow", background=T["bg"])
        self.root.configure(bg=T["bg"])
        for w, opts in list(self._themed):
            try:
                w.configure(**{k: THEME[v] for k, v in opts.items()})
            except tk.TclError:
                pass
        if hasattr(self, "theme_btns"):
            for k, b in self.theme_btns.items():
                b.configure(bg="#1e88e5" if k == name else "#263340")
        if redraw and hasattr(self, "p_spec"):
            for p in (self.p_spec, self.p_trend, self.p_amam, self.p_ampm, self.p_hist):
                p.redraw()
        if hasattr(self, "f_recinfo"):
            self.show_rec()

    def reg(self, w, **opts):
        self._themed.append((w, opts))
        try:
            w.configure(**{k: THEME[v] for k, v in opts.items()})
        except tk.TclError:
            pass
        return w

    def card(self, parent, title, num=None, right_text=None):
        """PA Bench Monitor 와 같은 카드: 번호 · 제목 · 구분선 · 내용"""
        outer = tk.Frame(parent, highlightthickness=1, bd=0)
        self.reg(outer, bg="panel", highlightbackground="border", highlightcolor="border")
        hd = ttk.Frame(outer, style="Card.TFrame")
        hd.pack(fill="x", padx=10, pady=(7, 5))
        arrow = None
        if num is not None:
            arrow = ttk.Label(hd, text="▾", style="Head.TLabel", width=2, cursor="hand2")
            arrow.pack(side="left")
            ttk.Label(hd, text=str(num), style="Num.TLabel").pack(side="left", padx=(0, 7))
        ttk.Label(hd, text=title, style="Head.TLabel").pack(side="left")
        rt = ttk.Label(hd, text=right_text or "", style="Hint.TLabel")
        rt.pack(side="right")
        sep = tk.Frame(outer, height=1)
        self.reg(sep, bg="line")
        sep.pack(fill="x")
        body = ttk.Frame(outer, style="Card.TFrame", padding=(10, 6, 10, 8))
        body.pack(fill="both", expand=True)
        outer.body, outer.right = body, rt
        if num is not None:
            # 제목 줄을 누르면 접기 · 펼치기 (▾ 펼침 · ▸ 접힘), 상태는 설정에 기억
            key = str(num)

            def show(open_):
                if open_:
                    sep.pack(fill="x")
                    body.pack(fill="both", expand=True)
                else:
                    sep.pack_forget()
                    body.pack_forget()
                arrow.configure(text="▾" if open_ else "▸")

            def toggle(e=None):
                fold = self.s.setdefault("fold", {})
                fold[key] = not fold.get(key, False)
                show(not fold[key])
                self.save_settings()
            for w in [hd] + list(hd.winfo_children()):
                if w is not rt:
                    w.bind("<Button-1>", toggle)
            hd.configure(cursor="hand2")
            if self.s.get("fold", {}).get(key):
                show(False)
            outer.toggle = toggle
        return outer

    def seg(self, parent, var, items):
        f = ttk.Frame(parent, style="Card.TFrame")
        for val, txt in items:
            ttk.Radiobutton(f, text=txt, value=val, variable=var, style="Seg.Toolbutton").pack(side="left")
        return f

    def set_theme(self, name):
        self.apply_theme(name)
        self.save_settings()

    # ------------------------------------------------------------ 화면 만들기
    def attach_tips(self):
        """칸 · 버튼에 마우스를 올리면 설명 (TIPS). 그 칸과 같은 줄 이름 (왼쪽 글자) 에도"""
        names = {}
        for k, var in self.v.items():
            names[str(var)] = k

        def walk(w):
            for c in w.winfo_children():
                key = None
                for opt in ("textvariable", "variable"):
                    try:
                        key = names.get(str(c.cget(opt)))
                    except tk.TclError:
                        pass
                    if key:
                        break
                if key and key in TIPS:
                    Tip(c, TIPS[key])
                    try:                                  # 같은 줄 왼쪽 이름에도
                        gi = c.grid_info()
                        if gi:
                            for sib in c.master.grid_slaves(row=int(gi["row"]), column=0):
                                if sib is not c and not getattr(sib, "_tip", False):
                                    Tip(sib, TIPS[key])
                                    sib._tip = True
                    except (tk.TclError, KeyError, ValueError):
                        pass
                walk(c)
        walk(self.left_root if hasattr(self, "left_root") else self.root)
        for attr, txt in BTN_TIPS.items():
            if hasattr(self, attr):
                Tip(getattr(self, attr), txt)

    def build(self):
        if self.host is None:
            self.build_topbar()
            self.build_dashboard()
            main = ttk.PanedWindow(self.root, orient="horizontal")
            main.pack(fill="both", expand=True, padx=6, pady=(6, 6))
        else:
            self.chips = {}
            self.build_tiles(self.dash_parent)
            main = ttk.PanedWindow(self.main_parent, orient="horizontal")
            main.pack(fill="both", expand=True)
        self.main_pw = main
        left = ScrollFrame(main)
        self.reg(left.cv, bg="bg")
        main.add(left, weight=0)
        inner = left.body
        right = ttk.Frame(main)
        main.add(right, weight=1)
        self.build_left(inner)
        self.build_right(right)
        self.left_sf = left

        def no_combo_wheel(w):
            # 왼쪽 카드의 고르기 칸 (Combobox) 위에서 휠 = 값 바뀌지 않고 카드 스크롤
            for c_ in w.winfo_children():
                if isinstance(c_, ttk.Combobox):
                    c_.bind("<MouseWheel>", lambda e: (wheel_any(e), "break")[1])
                    c_.bind("<Button-4>", lambda e: (wheel_any(e), "break")[1])
                    c_.bind("<Button-5>", lambda e: (wheel_any(e), "break")[1])
                no_combo_wheel(c_)
        no_combo_wheel(inner)
        self.left_root = main
        try:
            self.attach_tips()
        except Exception as e:
            print("tips", e)
        self.log("%s %s - 주소에 demo 를 넣으면 장비 없이 가상 PA 로 확인합니다." % (APP, VERSION))
        self.sig_src_changed()
        self.bench_refresh()
        self.update_chips()
        self.refresh_hist_list()
        self.draw_hist()

    def build_topbar(self):
        bar = tk.Frame(self.root, bg=TOPBAR)
        bar.pack(side="top", fill="x")
        tk.Label(bar, text=APP, bg=TOPBAR, fg="white", font=("맑은 고딕", 12, "bold")).pack(side="left", padx=(12, 4), pady=6)
        tk.Label(bar, text=VERSION + "  (NR 100 MHz · 메모리 다항식 / GMP)", bg=TOPBAR, fg="#90a4ae",
                 font=("맑은 고딕", 8)).pack(side="left", padx=(0, 14))
        self.chips = {}
        for key, name in (("smw", "SMW200A"), ("fsw", "FSW"), ("psu", "Vdd 전원"), ("bench", "PA Bench 기록")):
            c = tk.Label(bar, text="● " + name, bg="#263340", fg="#78909c", font=("맑은 고딕", 8), padx=8, pady=2)
            c.pack(side="left", padx=2)
            self.chips[key] = c
        mk = dict(relief="flat", padx=10, pady=2, activeforeground="#ffffff", font=F, bd=0)
        tk.Button(bar, text="⚙ 장비 설정", command=lambda: self.show_tab("equip"), bg="#2f3d4a", fg="#e0e0e0",
                  activebackground="#3c4d5c", **mk).pack(side="left", padx=(12, 3))
        tk.Button(bar, text="SG RF OFF", command=self.rf_off, bg="#2f3d4a", fg="#e0e0e0",
                  activebackground="#3c4d5c", **mk).pack(side="left", padx=3)
        self.btn_cfg = tk.Button(bar, text="💾 설정 ▾", command=self.cfg_menu, bg="#2f3d4a", fg="#e0e0e0",
                                 activebackground="#3c4d5c", **mk)
        self.btn_cfg.pack(side="left", padx=3)
        tf = tk.Frame(bar, bg="#455a64")
        tf.pack(side="left", padx=(10, 3))
        self.theme_btns = {}
        for key, txt in (("light", "☀ 화이트"), ("dark", "🌙 블랙")):
            b = tk.Button(tf, text=txt, command=lambda k=key: self.set_theme(k), relief="flat", bd=0, padx=10, pady=1,
                          font=F, bg="#1e88e5" if self.s.get("theme", "light") == key else "#263340", fg="white",
                          activebackground="#1976d2", activeforeground="white")
            b.pack(side="left", padx=1, pady=1)
            self.theme_btns[key] = b
        self.btn_stop = tk.Button(bar, text="■ 중지 (Esc)", command=self.stop, bg="#c62828", fg="white",
                                  activebackground="#e53935", activeforeground="white", relief="flat", bd=0, padx=16, pady=3,
                                  font=("맑은 고딕", 10, "bold"))
        self.btn_stop.pack(side="right", padx=10, pady=5)

    def build_dashboard(self):
        d = tk.Frame(self.root, bg=DASH)
        d.pack(side="top", fill="x")
        cols = tk.Frame(d, bg=DASH)
        cols.pack(fill="x", padx=8, pady=6)
        self.big = {}
        for i, (key, title, color) in enumerate((("aclr", "ACLR  L / U", C_ACLR),
                                                 ("pout", "Pout · DUT", C_POUT), ("eff", "PAE (효율)", C_EFF),
                                                 ("papr", "PAPR · DPD 신호", C_PAPR))):
            cols.columnconfigure(i, weight={"aclr": 13, "papr": 8}.get(key, 10), uniform="c")
            box = tk.Frame(cols, bg=BG, highlightthickness=1, highlightbackground="#2b3540")
            box.grid(row=0, column=i, sticky="nsew", padx=4)
            tk.Label(box, text=title, bg=BG, fg="#b0bec5", font=("맑은 고딕", 12, "bold")).pack(anchor="w", padx=12, pady=(5, 0))
            v = tk.Label(box, text="---", bg=BG, fg=color, font=("Consolas", 34, "bold"), anchor="w", width=1)
            v.pack(fill="x", padx=10)
            sub = tk.Label(box, text="", bg=BG, fg="#90a4ae", font=("Consolas", 11), anchor="w")
            sub.pack(fill="x", padx=12, pady=(0, 6))
            self.big[key] = (v, sub, color)
        # 진행 상태 (PA Bench Monitor 의 오른쪽 위 작은 상태판처럼) - 모양 A / B / C (설정 status_ui)
        ui = self.s.get("status_ui", "A")
        self.st_donut = None
        self.st_rows = {}
        if ui == "B":                                   # B: 큰 숫자 아래 얇은 진행 줄 (전체 폭)
            strip = tk.Frame(d, bg=BG, highlightthickness=1, highlightbackground="#2b3540")
            strip.pack(fill="x", padx=12, pady=(0, 6))
            self.st_state = tk.Label(strip, text="● 대기", bg="#37474f", fg="white", font=("맑은 고딕", 10, "bold"), padx=8)
            self.st_state.pack(side="left", padx=(6, 8), pady=4)
            self.st_bar = tk.Canvas(strip, width=180, height=8, bg="#263340", highlightthickness=0, bd=0)
            self.st_bar.pack(side="left", padx=(0, 6))
            self.st_left = tk.Label(strip, text="", bg=BG, fg="#ffd54f", font=("Consolas", 13, "bold"), width=6, anchor="w")
            self.st_left.pack(side="left")
            for k, t_ in (("prog", ""), ("stage", "단계"), ("level", "레벨"), ("model", "모델"), ("dc", "Vdd · Id")):
                if t_:
                    tk.Label(strip, text=t_, bg=BG, fg="#78909c", font=("맑은 고딕", 9)).pack(side="left", padx=(14, 4))
                lb = tk.Label(strip, text="-", bg=BG, fg="#cfd8dc", font=("Consolas", 10), anchor="w")
                lb.pack(side="left")
                self.st_rows[k] = lb
        else:
            cols.columnconfigure(4, weight=12 if ui == "A" else 11, uniform="c")
            box = tk.Frame(cols, bg=BG, highlightthickness=1, highlightbackground="#2b3540")
            box.grid(row=0, column=4, sticky="nsew", padx=4)
            if ui == "C":                               # C: 왼쪽 동그란 남은 시간 + 오른쪽 4줄
                self.st_donut = tk.Canvas(box, width=96, height=96, bg=BG, highlightthickness=0, bd=0)
                self.st_donut.pack(side="left", padx=(10, 6), pady=6)
                rt = tk.Frame(box, bg=BG)
                rt.pack(side="left", fill="both", expand=True, pady=6, padx=(0, 8))
                self.st_state = tk.Label(rt, text="● 대기", bg="#37474f", fg="white", font=("맑은 고딕", 10, "bold"), padx=8)
                self.st_state.pack(anchor="w", pady=(0, 4))
                self.st_left = tk.Label(rt)               # 남은 시간은 동그라미 안에
                self.st_bar = None
                g = tk.Frame(rt, bg=BG)
                g.pack(fill="x")
                g.columnconfigure(1, weight=1)
                for r_, (k, t_) in enumerate((("stage", "단계"), ("level", "레벨"), ("model", "모델"), ("dc", "Vdd·Id"))):
                    tk.Label(g, text=t_, bg=BG, fg="#78909c", font=("맑은 고딕", 9), anchor="w").grid(row=r_, column=0, sticky="w")
                    lb = tk.Label(g, text="-", bg=BG, fg="#cfd8dc", font=("Consolas", 10), anchor="w", width=1)
                    lb.grid(row=r_, column=1, sticky="ew", padx=(6, 0))
                    self.st_rows[k] = lb
                self.st_rows["prog"] = tk.Label(rt)
            else:                                       # A: 상태 · 남은 시간 · 막대 + 2열 칸
                hd = tk.Frame(box, bg=BG)
                hd.pack(fill="x", padx=10, pady=(6, 2))
                self.st_state = tk.Label(hd, text="● 대기", bg="#37474f", fg="white", font=("맑은 고딕", 10, "bold"), padx=8)
                self.st_state.pack(side="left")
                self.st_left = tk.Label(hd, text="", bg=BG, fg="#ffd54f", font=("Consolas", 15, "bold"))
                self.st_left.pack(side="right")
                self.st_bar = tk.Canvas(box, height=6, bg="#263340", highlightthickness=0, bd=0)
                self.st_bar.pack(fill="x", padx=10, pady=(2, 4))
                g = tk.Frame(box, bg=BG)
                g.pack(fill="both", expand=True, padx=10, pady=(0, 6))
                g.columnconfigure(1, weight=1)
                for r_, (k, t_) in enumerate((("stage", "단계"), ("level", "레벨"), ("model", "모델"))):
                    tk.Label(g, text=t_, bg=BG, fg="#78909c", font=("맑은 고딕", 9), anchor="w").grid(row=r_, column=0, sticky="w")
                    lb = tk.Label(g, text="-", bg=BG, fg="#cfd8dc", font=("Consolas", 10), anchor="w", width=1)
                    lb.grid(row=r_, column=1, sticky="ew", padx=(8, 0))
                    self.st_rows[k] = lb
                self.st_rows["prog"] = tk.Label(hd, text="", bg=BG, fg="#90a4ae", font=("Consolas", 10))
                self.st_rows["prog"].pack(side="right", padx=(0, 10))
                self.st_rows["dc"] = tk.Label(g)
        self.st_last = None                         # 끝 · 중지 표시
        self.root.after(500, self.tick_status)
        d.bind("<Configure>", lambda e: self.root.after_idle(self.fit_big))

    def build_tiles(self, cols):
        """Bench 안: 큰 숫자 3칸 (ACLR · Pout · PAE, PAE 아래 줄에 DE · Id · PAPR) - Bench 큰 숫자와 같은 칸 크기"""
        self.big = {}
        for i, (key, title, color) in enumerate((("aclr", "ACLR  L / U", C_ACLR), ("pout", "Pout · DUT", C_POUT),
                                                 ("eff", "PAE (효율)", C_EFF))):
            box = tk.Frame(cols, bg=BG, highlightthickness=1, highlightbackground="#2b3540")
            box.grid(row=0, column=i, sticky="nsew", padx=4)
            tk.Label(box, text=title, bg=BG, fg="#b0bec5", font=("맑은 고딕", 12, "bold")).pack(anchor="w", padx=12, pady=(5, 0))
            v = tk.Label(box, text="---", bg=BG, fg=color, font=("Consolas", 34, "bold"), anchor="w", width=1)
            v.pack(fill="x", padx=10)
            sub = tk.Label(box, text="", bg=BG, fg="#90a4ae", font=("Consolas", 11), anchor="w", width=1)
            sub.pack(fill="x", padx=12, pady=(0, 6))
            self.big[key] = (v, sub, color)
        cols.bind("<Configure>", lambda e: self.root.after_idle(self.fit_big), add="+")
        self.st_rows, self.st_bar, self.st_donut = {}, None, None
        self.st_last = None

    def status_info(self):
        """Bench 공통 진행 줄에 보여 줄 것 → (상태 글, 색, 진행 0~1 또는 None, 남은 시간 글, [(이름, 값)])"""
        eng, run = self.engine, bool(self.worker)
        e = getattr(eng, "eta", None) if eng is not None else None
        done, tot = (e["done"], e["total"]) if e else (0, 0)
        if run:
            prog = getattr(self, "_last_prog", "") or ""
            st, col = ("● 모델 계산", "#6a1b9a") if "계산" in prog else ("● 신경망 학습", "#6a1b9a") if "학습 중" in prog else ("● DPD 측정 중", "#2e7d32")
            left = eng.eta_left() if eng is not None and hasattr(eng, "eta_left") else None
            lt = ("%d:%02d" % (left // 60, left % 60)) if left is not None else ""
        else:
            st, col = self.st_last or ("● 대기", "#37474f")
            lt = ""
        info = self._stage_info()
        items = [("진행", ("%d / %d 측정" % (done, tot)) if tot else "-"), ("단계", info[0]), ("레벨", info[1]), ("모델", info[2])]
        return st, col, (min(done / tot, 1.0) if tot else None), lt, items

    def _stage_info(self):
        eng = self.engine
        p = self.params_safe()
        cur = getattr(eng, "cur", None) if eng is not None else None
        lab = cur.get("label", "") if cur else ""
        stage = "-"
        if lab:
            import re
            m = re.match(r"(?:.*\s)?DPD (\d+)$", lab)
            if lab.endswith("OFF"):
                stage = "DPD OFF 측정"
            elif "후보" in lab:
                stage = "모델 후보 실측 · " + lab.split("후보", 1)[1].strip()
            elif lab.startswith("ILC"):
                stage = "%s / %s (한계 ACLR)" % (lab, p.get("ilc_iters", "?"))
            elif "이전 계수" in lab:
                stage = "DPD 0 (앞 레벨 계수)"
            elif m:
                stage = "DPD 반복 %s / %s" % (m.group(1), p.get("iters", "?"))
            else:
                stage = lab
        stp = cur.get("step", "") if cur else ""
        mtxt = self.model_text(p, eng)
        return stage, (stp.replace("레벨 ", "") if stp else "-"), mtxt

    def follow_sample(self, name):
        """Bench 에서 고른 샘플 종류 · 번호를 3 카드에 → 그 샘플에서 쓰던 DPD 설정 · 그 번호의 기록으로"""
        if not name or self.worker:
            return
        num = self.sample_num()
        if self.v["b_stype"].get() != name:
            self.bench_refresh()
            vals = list(self.cb_stype.cget("values") or ())
            if name in vals:
                self.v["b_stype"].set(name)
                self._rec_num = num
                self.load_records()
        elif num != getattr(self, "_rec_num", None):
            self._rec_num = num                        # 같은 종류 · 다른 번호 (S1 → S2): 기록만 다시 고름
            self.bench_refresh()
            self.load_records()

    def shutdown(self):
        """Bench 를 닫을 때: 측정 중이면 멈추고 설정 정리 · 장비 연결 끊기"""
        try:
            if self.worker and self.engine is not None:
                self.engine.abort(rf_off=True)
        except Exception:
            pass
        BL.set_busy(False)
        self.save_settings()
        try:
            if self.engine is not None:
                self.engine.close()
        except Exception:
            pass

    def tick_status(self):
        """오른쪽 위 진행 상태판 (0.4초마다): 상태 · 남은 시간 · 진행 막대 · 단계 · 레벨 · 모델 · Vdd/Id"""
        try:
            self._tick_status()
        except Exception:
            pass
        self.root.after(400, self.tick_status)

    def _tick_status(self):
        if not hasattr(self, "st_state"):
            return
        eng, run = self.engine, bool(self.worker)
        R = self.st_rows
        e = getattr(eng, "eta", None) if eng is not None else None
        p = self.params_safe()
        if run:
            prog = getattr(self, "_last_prog", "") or ""
            st, col = ("● 모델 계산", "#6a1b9a") if "계산" in prog else ("● 신경망 학습", "#6a1b9a") if "학습 중" in prog else ("● 측정 중", "#2e7d32")
            self.st_state.configure(text=st, bg=col)
            left = eng.eta_left() if eng is not None and hasattr(eng, "eta_left") else None
            self.st_left.configure(text=("%d:%02d" % (left // 60, left % 60)) if left is not None else "")
        else:
            txt, col = self.st_last or ("● 대기", "#37474f")
            self.st_state.configure(text=txt, bg=col)
            self.st_left.configure(text="")
        done, tot = (e["done"], e["total"]) if e else (0, 0)
        R["prog"].configure(text=("%d / %d 측정" % (done, tot)) if tot else "-")
        cv = self.st_bar
        if cv is not None:
            W = max(cv.winfo_width(), 10)
            H_ = max(cv.winfo_height(), 6)
            cv.delete("all")
            if tot:
                cv.create_rectangle(0, 0, W * min(done / tot, 1.0), H_, fill="#43a047" if not run else "#ffb300", outline="")
        dn = self.st_donut
        if dn is not None:
            dn.delete("all")
            dn.create_oval(8, 8, 88, 88, outline="#263340", width=9)
            if tot:
                dn.create_arc(8, 8, 88, 88, start=90, extent=-359.9 * min(done / tot, 1.0), style="arc",
                              outline="#43a047" if not run else "#ffb300", width=9)
            left = eng.eta_left() if (run and eng is not None and hasattr(eng, "eta_left")) else None
            dn.create_text(48, 42, text=("%d:%02d" % (left // 60, left % 60)) if left is not None else ("완료" if tot and not run else "-"),
                           fill="#ffd54f", font=("Consolas", 15, "bold"))
            dn.create_text(48, 63, text=("%d / %d" % (done, tot)) if tot else "", fill="#90a4ae", font=("Consolas", 9))
        cur = getattr(eng, "cur", None) if eng is not None else None
        lab = cur.get("label", "") if cur else ""
        stage = "-"
        if lab:
            import re
            m = re.match(r"(?:.*\s)?DPD (\d+)$", lab)
            if lab.endswith("OFF"):
                stage = "DPD OFF 측정"
            elif "후보" in lab:
                stage = "모델 후보 실측 · " + lab.split("후보", 1)[1].strip()
            elif lab.startswith("ILC"):
                stage = "%s / %s (한계 ACLR)" % (lab, p.get("ilc_iters", "?"))
            elif "이전 계수" in lab:
                stage = "DPD 0 (앞 레벨 계수)"
            elif m:
                stage = "DPD 반복 %s / %s" % (m.group(1), p.get("iters", "?"))
            else:
                stage = lab
        R["stage"].configure(text=stage)
        stp = cur.get("step", "") if cur else ""
        R["level"].configure(text=stp.replace("레벨 ", "") if stp else "-")
        mtxt = self.model_text(p, eng)
        R["model"].configure(text=mtxt)
        dc = self.read_dc()
        R["dc"].configure(text=("%.1f V · %.3f A" % (dc[0], dc[1])) if dc else "Bench 전원 없음",
                          fg="#cfd8dc" if dc else "#78909c")

    def params_safe(self):
        out = {}
        for k in ("iters", "ilc_iters", "K", "M", "L", "method", "model", "auto_model", "dvr_seg", "nn_hidden"):
            try:
                out[k] = self.v[k].get()
            except Exception:
                pass
        return out

    def fit_big(self):
        if self.host is not None and hasattr(self.host, "fit_big"):
            return self.host.fit_big()                 # Bench 안: 모든 큰 숫자를 같은 크기로 (Bench 가 정함)
        fonts = self.__dict__.setdefault("_bigf", {})
        w = max(self.root.winfo_width(), 600)
        base = int(max(18, min(40, w / 46)))
        if self.host is not None:
            base = getattr(self.host, "_big_base", base)       # Bench 큰 숫자와 같은 크기
        need = base                                     # 모든 칸 같은 크기 (가장 긴 값 기준), 커지는 건 창 크기가 바뀔 때만
        for key, (v, sub, col) in self.big.items():
            avail = v.winfo_width() - 6
            if avail < 40:
                continue
            size = need
            while size > 12:
                f = fonts.get(size) or fonts.setdefault(size, tkfont.Font(family="Consolas", size=size, weight="bold"))
                if f.measure(v.cget("text")) <= avail:
                    break
                size -= 1
            need = min(need, size)
        if w != getattr(self, "_big_w", None) or need < getattr(self, "_big_size", 999):
            self._big_size, self._big_w = need, w
        for key, (v, sub, col) in self.big.items():
            if getattr(v, "_sz", None) != self._big_size:
                v.configure(font=("Consolas", self._big_size, "bold"))
                v._sz = self._big_size

    def field(self, body, r, key, name, dflt, unit, width=8):
        ttk.Label(body, text=name, style="Lab.TLabel").grid(row=r, column=0, sticky="w", pady=2, padx=(0, 8))
        var = tk.StringVar(value=str(self.s.get(key, dflt)))
        self.v[key] = var
        if key == "mod":
            w = ttk.Combobox(body, textvariable=var, values=["QPSK", "16QAM", "64QAM", "256QAM"], state="readonly", width=9)
        else:
            w = ttk.Entry(body, textvariable=var, width=width, justify="right" if width < 12 else "left")
        w.grid(row=r, column=1, sticky="w")
        ttk.Label(body, text=unit, style="Unit.TLabel").grid(row=r, column=2, sticky="w", padx=(5, 0))
        return w

    def build_left(self, inner):
        W = 400
        fields = {}
        for key, name, dflt, unit, card in self.FIELDS:
            fields.setdefault(card, []).append((key, name, dflt, unit))
        # 1 신호
        c = self.card(inner, "신호", 1)
        c.pack(fill="x", padx=(2, 6), pady=(0, 6))
        b = c.body
        self.v["bw_mode"] = tk.StringVar(value=str(self.s.get("bw_mode", "100")))
        ttk.Label(b, text="대역", style="Lab.TLabel").grid(row=0, column=0, sticky="w", pady=2)
        self.seg(b, self.v["bw_mode"], (("100", "100 MHz DPD"), ("400", "400 MHz DPD"))).grid(row=0, column=1, columnspan=2, sticky="w")
        self.v["sig_src"] = tk.StringVar(value=self.s.get("sig_src", "nr"))
        self.v["wv_path"] = tk.StringVar(value=self.s.get("wv_path", ""))
        self.lbl_src = ttk.Label(b, text="신호", style="Lab.TLabel")
        self.lbl_src.grid(row=1, column=0, sticky="w", pady=2)
        self.seg_src = self.seg(b, self.v["sig_src"], (("nr", "NR 100 MHz 1C 만들기"), ("file", "내 .wv")))
        self.seg_src.grid(row=1, column=1, columnspan=2, sticky="w")
        self.f_file = ttk.Frame(b, style="Card.TFrame")
        self.f_file.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(4, 0))
        ln1 = ttk.Frame(self.f_file, style="Card.TFrame")
        ln1.pack(side="top", fill="x")
        self.btn_wv = ttk.Button(ln1, text="불러오기…", command=self.pick_wv)
        self.btn_wv.pack(side="left")
        self.lbl_wv = ttk.Label(ln1, text="", style="Info.TLabel", wraplength=280)
        self.lbl_wv.pack(side="left", padx=(6, 0))
        self.lbl_wv_dir = ttk.Label(self.f_file, text="", style="Unit.TLabel", wraplength=360)
        self.lbl_wv_dir.pack(side="top", anchor="w", pady=(2, 0))
        self.v["file_halve"] = tk.BooleanVar(value=bool(self.s.get("file_halve", False)))
        self.chk_halve = ttk.Checkbutton(self.f_file, text="500 MSps 넘으면 절반으로 (빠르게)", variable=self.v["file_halve"],
                                         style="Card.TCheckbutton")
        self.chk_halve.pack(side="top", anchor="w", pady=(4, 0))
        self.f_nr = ttk.Frame(b, style="Card.TFrame")
        self.f_nr.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(4, 0))
        nb = self.f_nr
        ttk.Label(nb, text="캐리어", style="Lab.TLabel").grid(row=0, column=0, sticky="w", pady=2, padx=(0, 8))
        self.v["carrier"] = tk.StringVar(value="1C")
        self.seg(nb, self.v["carrier"], (("1C", "1C (100 MHz)"), ("2C", "2C · 다음 버전"))).grid(row=0, column=1, columnspan=2, sticky="w")
        self.v["carrier"].trace_add("write", lambda *a: self.v["carrier"].get() != "1C" and self.v["carrier"].set("1C"))
        r = 1
        for key, name, dflt, unit in fields["sig"]:
            self.field(nb, r, key, name, dflt, unit)
            r += 1
        ttk.Label(nb, text="샘플레이트", style="Lab.TLabel").grid(row=r, column=0, sticky="w", pady=2)
        self.v["os"] = tk.StringVar(value=str(self.s.get("os", "4")))
        self.seg(nb, self.v["os"], (("2", "×2"), ("3", "×3"), ("4", "×4"))).grid(row=r, column=1, sticky="w")
        self.lbl_os = ttk.Label(nb, text="", style="Unit.TLabel")
        self.lbl_os.grid(row=r, column=2, sticky="w", padx=(5, 0))
        self.v["os"].trace_add("write", lambda *a: self.lbl_os.configure(text=self.OS_TXT.get(self.v["os"].get(), "")))
        self.lbl_os.configure(text=self.OS_TXT.get(self.v["os"].get(), ""))
        self.v["cfr_on"] = tk.BooleanVar(value=bool(self.s.get("cfr_on", True)))
        ttk.Checkbutton(nb, text="CFR 사용 (클리핑 + 필터로 PAPR 줄이기)", variable=self.v["cfr_on"],
                        style="Card.TCheckbutton").grid(row=r + 1, column=0, columnspan=3, sticky="w", pady=(4, 0))
        af = ttk.Frame(b, style="Card.TFrame")
        af.grid(row=4, column=0, columnspan=3, sticky="ew", pady=(6, 0))
        ttk.Label(af, text="ACLR 채널", style="Lab.TLabel").pack(side="left")
        self.v["ch_bw_mhz"] = tk.StringVar(value=str(self.s.get("ch_bw_mhz", "98.28")))
        self.e_chbw = ttk.Entry(af, textvariable=self.v["ch_bw_mhz"], width=6, justify="right")
        self.e_chbw.pack(side="left", padx=3)
        ttk.Label(af, text="MHz · 인접 간격", style="Lab.TLabel").pack(side="left")
        self.v["adj_mhz"] = tk.StringVar(value=str(self.s.get("adj_mhz", "100")))
        self.e_adj = ttk.Entry(af, textvariable=self.v["adj_mhz"], width=5, justify="right")
        self.e_adj.pack(side="left", padx=3)
        ttk.Label(af, text="MHz", style="Unit.TLabel").pack(side="left")
        bf = ttk.Frame(b, style="Card.TFrame")
        bf.grid(row=5, column=0, columnspan=3, sticky="ew", pady=(8, 0))
        ttk.Button(bf, text="신호 만들기", command=self.make_signal).pack(side="left")
        ttk.Button(bf, text=".wv 저장…", command=self.save_wv_orig).pack(side="left", padx=4)
        self.lbl_sig = ttk.Label(b, text="", style="Hint.TLabel", wraplength=W - 40)
        self.lbl_sig.grid(row=6, column=0, columnspan=3, sticky="w", pady=(4, 0))
        self._bw_cur = self.v["bw_mode"].get()
        self.v["bw_mode"].trace_add("write", lambda *a: self.bw_changed())
        self.v["sig_src"].trace_add("write", lambda *a: self.sig_src_changed())
        self.v["wv_path"].trace_add("write", lambda *a: self.sig_src_changed())

        # 2 RF · 손실
        c = self.card(inner, "RF · 케이블 손실", 2)
        c.pack(fill="x", padx=(2, 6), pady=(0, 6))
        b = c.body
        r = 0
        for key, name, dflt, unit in fields["rf"]:
            self.field(b, r, key, name, dflt, unit)
            r += 1
        self.v["bench_loss"] = tk.BooleanVar(value=bool(self.s.get("bench_loss", True)))
        ttk.Checkbutton(b, text="손실 = PA Bench Monitor 손실 표 사용", variable=self.v["bench_loss"],
                        style="Card.TCheckbutton", command=self.apply_bench_loss).grid(row=r, column=0, columnspan=3, sticky="w", pady=(4, 0))
        self.lbl_loss = ttk.Label(b, text="", style="Info.TLabel", wraplength=W - 40)
        self.lbl_loss.grid(row=r + 1, column=0, columnspan=3, sticky="w")
        self.v["aclr_src"] = tk.StringVar(value=self.s.get("aclr_src", "fsw"))
        ttk.Label(b, text="ACLR 읽기", style="Lab.TLabel").grid(row=r + 4, column=0, sticky="w", pady=(8, 0))
        self.seg(b, self.v["aclr_src"], (("fsw", " FSW Mod. 화면 "), ("iq", " I/Q 계산 "))).grid(
            row=r + 4, column=1, columnspan=2, sticky="w", pady=(8, 0))
        ttk.Label(b, text="FSW Mod. 화면 = Bench Mod. 측정에 맞춘 스펙트럼 ACLR 설정 그대로 (학습은 I/Q)", style="Unit.TLabel",
                  wraplength=W - 40).grid(row=r + 5, column=0, columnspan=3, sticky="w")
        ttk.Label(b, text="추가 손실", style="Lab.TLabel").grid(row=r + 2, column=0, sticky="w", pady=(8, 0))
        xf = ttk.Frame(b, style="Card.TFrame")
        xf.grid(row=r + 2, column=1, columnspan=2, sticky="w", pady=(8, 0))
        self.btn_xloss = ttk.Button(xf, text="표 편집…", command=self.edit_xloss)
        self.btn_xloss.pack(side="left")
        ttk.Button(xf, text="없음", command=self.clear_xloss).pack(side="left", padx=(4, 0))
        self.lbl_xloss = ttk.Label(b, text="", style="Info.TLabel", wraplength=W - 40)
        self.lbl_xloss.grid(row=r + 3, column=0, columnspan=3, sticky="w")
        self.v["freq_ghz"].trace_add("write", lambda *a: self.apply_bench_loss())

        # 3 Bench 기록 → Pout
        c = self.card(inner, "PA Bench 기록 → Pout", 3, "읽기만 함")
        c.pack(fill="x", padx=(2, 6), pady=(0, 6))
        b = c.body
        ttk.Label(b, text="샘플 종류", style="Lab.TLabel").grid(row=0, column=0, sticky="w", pady=2, padx=(0, 8))
        self.v["b_stype"] = tk.StringVar(value=self.s.get("b_stype", ""))
        self.cb_stype = ttk.Combobox(b, textvariable=self.v["b_stype"], state="readonly", width=14)
        self.cb_stype.grid(row=0, column=1, sticky="w")
        self.cb_stype.bind("<<ComboboxSelected>>", lambda e: self.load_records())
        ttk.Button(b, text="새로 읽기", command=self.bench_refresh).grid(row=0, column=2, sticky="w", padx=(4, 0))
        ttk.Label(b, text="기록", style="Lab.TLabel").grid(row=1, column=0, sticky="w", pady=2)
        self.v["b_rec"] = tk.StringVar(value="")
        self.cb_rec = ttk.Combobox(b, textvariable=self.v["b_rec"], state="readonly", width=30)
        self.cb_rec.grid(row=1, column=1, columnspan=2, sticky="ew")
        self.cb_rec.bind("<<ComboboxSelected>>", lambda e: self.show_rec())
        rf_ = ttk.Frame(b, style="Card.TFrame")
        rf_.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(4, 2))
        self.lbl_rec = ttk.Label(rf_, text="", style="Hint.TLabel", wraplength=W - 40)
        self.lbl_rec.pack(anchor="w")
        self.f_recinfo = tk.Frame(rf_, highlightthickness=0, bd=0)          # 기록 내용 (이름 · 값 두 줄 칸)
        self.reg(self.f_recinfo, bg="head")
        self.f_recinfo.pack(fill="x")
        ttk.Label(b, text="목표 Pout", style="Lab.TLabel").grid(row=3, column=0, sticky="w", pady=(4, 2))
        tf_ = ttk.Frame(b, style="Card.TFrame")
        tf_.grid(row=3, column=1, columnspan=2, sticky="w", pady=(4, 2))
        self.v["b_target"] = tk.StringVar(value=str(self.s.get("b_target", "")))
        ttk.Entry(tf_, textvariable=self.v["b_target"], width=7, justify="right").pack(side="left")
        ttk.Label(tf_, text="dBm", style="Unit.TLabel").pack(side="left", padx=(4, 6))
        ttk.Button(tf_, text="→ SG 레벨 정하기", command=self.sg_from_target).pack(side="left")
        self.v["auto_cal"] = tk.BooleanVar(value=bool(self.s.get("auto_cal", True)))
        ttk.Checkbutton(b, text="DPD OFF 측정 때 Pout 보정을 이 기록에 맞춤", variable=self.v["auto_cal"],
                        style="Card.TCheckbutton").grid(row=4, column=0, columnspan=3, sticky="w", pady=(4, 0))

        # 4 DPD
        c = self.card(inner, "DPD (모델 · 학습)", 4, "GMP · DVR · 신경망")
        c.pack(fill="x", padx=(2, 6), pady=(0, 6))
        b = c.body
        self.dpd_body = b
        m0 = self.s.get("model") or ("nn" if self.s.get("method") == "nn" else "gmp")
        self.v["model"] = tk.StringVar(value=m0)
        self.v["method"] = tk.StringVar(value=self.s.get("method") if self.s.get("method") in ("ila", "dla") else "ila")
        ttk.Label(b, text="모델", style="Lab.TLabel").grid(row=0, column=0, sticky="w")
        mf = ttk.Frame(b, style="Card.TFrame")
        mf.grid(row=0, column=1, columnspan=2, sticky="w", pady=(0, 2))
        self._model_disp = tk.StringVar()
        self.cb_model = ttk.Combobox(mf, textvariable=self._model_disp, state="readonly", width=15)
        self.cb_model.pack(side="left")
        self.cb_model.bind("<<ComboboxSelected>>", lambda e: self.v["model"].set(
            {n: k for k, n in self.MODELS}.get(self._model_disp.get(), "gmp")))
        self.btn_models = ttk.Button(mf, text="목록 편집…", command=self.edit_models)
        self.btn_models.pack(side="left", padx=(4, 0))
        self.lbl_model = ttk.Label(b, text="", style="Unit.TLabel")
        self.lbl_model.grid(row=1, column=1, columnspan=2, sticky="w")
        ttk.Label(b, text="학습", style="Lab.TLabel").grid(row=2, column=0, sticky="w")
        self.seg(b, self.v["method"], (("ila", " ILA (간접) "), ("dla", " DLA (직접) "))).grid(
            row=2, column=1, columnspan=2, sticky="w", pady=(2, 4))
        self.dpd_rows = {"_learn": 2}
        r = 3
        for key, name, dflt, unit in fields["dpd"]:
            self.field(b, r, key, name, dflt, unit)
            self.dpd_rows[key] = r
            r += 1
        self.v["odd_only"] = tk.BooleanVar(value=bool(self.s.get("odd_only", False)))
        ttk.Checkbutton(b, text="홀수 차수만 (K = 1, 3, 5, …)", variable=self.v["odd_only"],
                        style="Card.TCheckbutton").grid(row=r, column=0, columnspan=3, sticky="w", pady=(4, 0))
        self.v["auto_model"] = tk.BooleanVar(value=bool(self.s.get("auto_model", True)))
        ttk.Checkbutton(b, text="K · M · L 자동 (계산으로 후보 3개 → 실측 ACLR 로 고름)", variable=self.v["auto_model"],
                        style="Card.TCheckbutton").grid(row=r + 1, column=0, columnspan=3, sticky="w", pady=(2, 0))
        self.dpd_rows["_odd"], self.dpd_rows["_auto"] = r, r + 1
        self.lbl_auto = ttk.Label(b, text="", style="Lab.TLabel")
        self.lbl_auto.grid(row=r + 2, column=0, columnspan=3, sticky="w")
        ttk.Label(b, text="Ctrl+Z = 이 카드 값 되돌리기", style="Unit.TLabel").grid(row=r + 3, column=0, columnspan=3, sticky="w")
        self.dpd_row_w = {k: list(b.grid_slaves(row=r_)) for k, r_ in self.dpd_rows.items()}   # 숨겼다 다시 보이려고 미리
        self.v["model"].trace_add("write", lambda *a: self.model_changed())
        self.v["method"].trace_add("write", lambda *a: self.method_compat())
        self.refresh_models()
        self.dpd_keys = [k for k, *_ in fields["dpd"]] + ["odd_only", "auto_model", "model", "method"]
        self.setup_undo(self.dpd_keys)
        self._cur_type = self.type_name()
        self.show_auto_kml()

        # 5 실행
        c = self.card(inner, "실행", 5)
        c.pack(fill="x", padx=(2, 6), pady=(0, 6))
        b = c.body
        b.columnconfigure(0, weight=1)
        b.columnconfigure(1, weight=1)
        self.v["run_mode"] = tk.StringVar(value=self.s.get("run_mode", "sweep"))
        ttk.Label(b, text="방식", style="Lab.TLabel").grid(row=0, column=0, sticky="w")
        self.seg(b, self.v["run_mode"], (("one", "한 레벨 (위 SG 레벨)"), ("sweep", "파워 스윕"))).grid(row=0, column=1, sticky="w")
        sw = ttk.Frame(b, style="Card.TFrame")
        sw.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        self.f_sweep = sw
        for i, (key, name, dflt, unit) in enumerate((("sw_start", "SG 시작", "-15", "dBm"), ("sw_stop", "SG 끝", "0", "dBm"),
                                                      ("sw_step", "간격", "1", "dB"),
                                                      ("sw_pout_stop", "Pout 멈춤", "", "dBm (빈칸 = 끝까지)"))):
            self.field(sw, i, key, name, dflt, unit, width=7)
        of = ttk.Frame(b, style="Card.TFrame")
        of.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(4, 0))
        for i, (key, name, dflt, unit) in enumerate((("target_aclr", "목표 ACLR", "-50", "dBc (닿으면 반복 끝 · 빈칸 = 끝까지)"),
                                                      ("run_name", "기록 이름", "", "(빈칸 = 샘플 종류 · 시각)"))):
            self.field(of, i, key, name, dflt, unit, width=7 if key == "target_aclr" else 16)
        self.v["run_mode"].trace_add("write", lambda *a: self.run_mode_changed())
        self.btn_off = ttk.Button(b, text="DPD OFF 측정만", command=lambda: self.start(False))
        self.btn_off.grid(row=3, column=0, sticky="ew", padx=(0, 4), pady=(8, 0))
        self.btn_go = ttk.Button(b, text="▶ DPD 실행", style="Pri.TButton", command=lambda: self.start(True))
        self.btn_go.grid(row=3, column=1, sticky="ew", pady=(8, 0))
        self.btn_ilc = ttk.Button(b, text="한계 ACLR 측정 (ILC · 모델 없이 직접 찾기)", command=lambda: self.start(True, ilc=True))
        self.btn_ilc.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(4, 0))
        self.btn_cmp = ttk.Button(b, text="방식 비교 실행… (같은 SG 레벨에서 여러 방식)", command=self.ask_compare)
        self.btn_cmp.grid(row=5, column=0, columnspan=2, sticky="ew", pady=(4, 0))
        self.btn_stop5 = tk.Button(b, text="■ DPD 측정 중지 (Esc · 바이어스 그대로)", command=self.stop, bg="#b0bec5", fg="white",
                                   activebackground="#b71c1c", activeforeground="white", disabledforeground="#e0e0e0",
                                   relief="flat", bd=0, font=("맑은 고딕", 10, "bold"), pady=4, state="disabled", cursor="hand2")
        self.btn_stop5.grid(row=6, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        self.v["rf_off_end"] = tk.BooleanVar(value=bool(self.s.get("rf_off_end", True)))
        ttk.Checkbutton(b, text="끝나면 SG RF OFF", variable=self.v["rf_off_end"], style="Card.TCheckbutton").grid(
            row=7, column=0, columnspan=2, sticky="w", pady=(6, 0))
        self.run_mode_changed()

    def build_right(self, right):
        T = THEME
        # 탭 (Bench 와 같은 모양)
        tb = ttk.Frame(right)
        tb.pack(fill="x")
        self.v_tab = tk.StringVar(value="aclr")
        tabs_ = [("aclr", "ACLR vs Pout"), ("graph", "스펙트럼 · AM-AM · AM-PM"), ("equip", "장비 (SMW · FSW)"), ("log", "로그")]
        if self.host is not None:                          # Bench 안: 장비는 Bench [장비 설정] 에서 연결 → 탭 빼기
            tabs_ = [t_ for t_ in tabs_ if t_[0] != "equip"]
        for key, txt in tabs_:
            ttk.Radiobutton(tb, text=txt, value=key, variable=self.v_tab, style="Tab.Toolbutton",
                            command=lambda: self.show_tab(self.v_tab.get())).pack(side="left")
        self.tabs = {}
        holder = ttk.Frame(right)
        holder.pack(fill="both", expand=True)
        # 그래프
        g = ttk.Frame(holder)
        g.columnconfigure(0, weight=3)
        g.columnconfigure(1, weight=2)
        g.rowconfigure(0, weight=1)
        g.rowconfigure(1, weight=1)
        self.p_spec = Plot(g, "스펙트럼 (채널 최고 = 0 dB)", "주파수 오프셋 MHz", "dB")
        self.p_spec.remember(self.s, "yr_spec")
        self.p_spec.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=(6, 6))
        self.p_trend = Plot(g, "측정 순서별 ACLR (빨강 L · 주황 U)", "측정 순서", "dBc")
        self.p_trend.remember(self.s, "yr_trend")
        self.p_trend.grid(row=0, column=1, sticky="nsew", pady=(6, 6))
        self.p_amam = Plot(g, "AM-AM (원래 신호 → PA 출력, 작은 신호 이득 = 0)", "입력 dB (최고값 기준)", "dB")
        self.p_amam.remember(self.s, "yr_amam")
        self.p_amam.grid(row=1, column=0, sticky="nsew", padx=(0, 6))
        self.p_ampm = Plot(g, "AM-PM", "입력 dB (최고값 기준)", "°")
        self.p_ampm.remember(self.s, "yr_ampm")
        self.p_ampm.grid(row=1, column=1, sticky="nsew")
        self.tabs["graph"] = g
        # ACLR vs Pout (PA Analyzer 처럼: 과거 기록과 겹쳐 보기)
        a = ttk.Frame(holder)
        a.columnconfigure(0, weight=1)
        a.rowconfigure(1, weight=1)
        bar = ttk.Frame(a)
        bar.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(6, 4))
        self.v["y_q"] = tk.StringVar(value=self.s.get("y_q", "aclr"))
        ttk.Label(bar, text="세로축").pack(side="left", padx=(0, 6))
        for val, txt in (("aclr", "ACLR (나쁜 쪽)"), ("aclr_l", "ACLR L"), ("aclr_u", "ACLR U"), ("evm", "EVM"),
                         ("de", "DE"), ("pae", "PAE")):
            ttk.Radiobutton(bar, text=txt, value=val, variable=self.v["y_q"], style="Seg.Toolbutton",
                            command=self.draw_hist).pack(side="left")
        ttk.Label(bar, text="   점선 = DPD OFF · 실선 = DPD ON · 색 = 주파수 (같은 주파수는 같은 색)", foreground=T["unit"]).pack(side="left")
        self.p_hist = Plot(a, "ACLR vs Pout", "DUT Pout (dBm)", "dBc")
        self.p_hist.remember(self.s, "yr_hist_" + self.s.get("y_q", "aclr"))
        self.p_hist.grid(row=1, column=0, sticky="nsew", padx=(0, 6))
        side = self.card(a, "기록", None, "")
        side.grid(row=1, column=1, sticky="ns")
        self.hist_card = side
        hb = side.body
        self.htree = ttk.Treeview(hb, columns=("on", "name", "ghz", "n", "when"), show="headings", height=8, selectmode="extended")
        for c_, h, w_ in (("on", "표시", 36), ("name", "이름", 130), ("ghz", "GHz", 50), ("n", "점", 34), ("when", "날짜", 92)):
            self.htree.heading(c_, text=h)
            self.htree.column(c_, width=w_, anchor="center" if c_ != "name" else "w", stretch=c_ == "name")
        self.htree.pack(fill="both", expand=True)
        hb.pack_propagate(True)
        self.htree.bind("<Button-1>", self.hist_click)
        self.htree.bind("<Double-1>", lambda e: self.hist_rename())
        hb2 = ttk.Frame(hb, style="Card.TFrame")
        hb2.pack(fill="x", pady=(6, 0))
        for txt, cmd in (("전체 표시", lambda: self.hist_show(True)), ("숨김", lambda: self.hist_show(False)),
                         ("이름", self.hist_rename), ("삭제", self.hist_delete)):
            ttk.Button(hb2, text=txt, command=cmd).pack(side="left", padx=(0, 3))
        ttk.Button(hb, text="PA Analyzer 용 엑셀 내보내기…", command=self.hist_export).pack(fill="x", pady=(6, 0))
        ttk.Label(hb, text="표시 칸 클릭 = 켜기/끄기 · 이름 더블클릭 = 바꾸기", style="Hint.TLabel").pack(anchor="w", pady=(4, 0))
        self.tabs["aclr"] = a
        self.root.after(1000, self.live_dc)
        # 장비
        e = ttk.Frame(holder)
        c = self.card(e, "장비 연결", None, "LAN · SCPI 5025 · demo = 가상 PA")
        c.pack(fill="x", padx=0, pady=6)
        r = 0
        for key, name, dflt, unit, card in self.FIELDS:
            if card == "dev":
                self.field(c.body, r, key, name, dflt, unit, width=20)
                r += 1
        ttk.Label(c.body, text="SMW 는 /var/user/pa_dpd_tx_0.wv · _1.wv 에 번갈아 저장, FSW 는 'DPD IQ' I/Q Analyzer 채널을 만들어 씀.\n"
                               "10 MHz 기준 클럭을 연결하면 가장 안정적입니다.", style="Hint.TLabel").grid(row=r, column=0, columnspan=3, sticky="w", pady=(6, 0))
        self.lbl_idn = ttk.Label(c.body, text="", style="Info.TLabel")
        self.lbl_idn.grid(row=r + 1, column=0, columnspan=3, sticky="w", pady=(4, 0))
        for k in ("smw_host", "fsw_host"):
            self.v[k].trace_add("write", lambda *a: self.update_chips())
        self.tabs["equip"] = e
        # 로그
        lg = ttk.Frame(holder)
        self.txt = tk.Text(lg, font=("Consolas", 9), relief="flat", wrap="none", bd=0)
        self.reg(self.txt, bg="log_bg", fg="log_fg", insertbackground="log_fg")
        self.txt.pack(fill="both", expand=True, pady=6)
        self.tabs["log"] = lg
        self.show_tab("aclr")
        # 아래: 측정 기록 (Bench 의 측정 기록과 같은 자리)
        rec = self.card(right, "측정 기록", None, "")
        rec.pack(side="bottom", fill="x", pady=(6, 0), before=holder)
        self.rec_card = rec
        top = ttk.Frame(rec.body, style="Card.TFrame")
        top.pack(fill="x", pady=(0, 4))
        self.lbl_last = ttk.Label(top, text="", style="Info.TLabel")
        self.lbl_last.pack(side="left")
        for txt, cmd in (("계수 CSV…", self.save_coef), ("DPD 신호 .wv…", self.save_wv_dpd), ("엑셀 저장…", self.save_xlsx)):
            ttk.Button(top, text=txt, command=cmd).pack(side="right", padx=(4, 0))
        cols = ("label", "sg", "pin", "pout", "rec", "gain", "aclr_l", "aclr_u", "evm", "id", "de", "pae", "papr", "nmse", "t")
        heads = ("단계", "SG(dBm)", "Pin(dBm)", "Pout(dBm)", "기록 Pout", "Gain(dB)", "ACLR L(dBc)", "ACLR U(dBc)",
                 "EVM(%)", "Id(mA)", "DE(%)", "PAE(%)", "PAPR(dB)", "학습 NMSE", "시각")
        self.tree = ttk.Treeview(rec.body, columns=cols, show="headings", height=5)
        for c_, h in zip(cols, heads):
            self.tree.heading(c_, text=h)
            self.tree.column(c_, width=72 if c_ != "label" else 80, anchor="center")
        self.tree.pack(fill="x")
        # 한 줄 로그 (로그 탭이 아닐 때도 마지막 줄은 보이게)
        self.lbl_status = ttk.Label(right, text="", foreground=T["dim"])
        self.lbl_status.pack(side="bottom", fill="x", pady=(4, 0), before=rec)

    # ------------------------------------------------------------ 설정 저장 · 불러오기
    PRESET_DIR = os.path.join(SET_DIR, "presets")
    YR_KEYS = ("yr_spec", "yr_trend", "yr_amam", "yr_ampm")

    def cfg_menu(self):
        m = tk.Menu(self.root, tearoff=0, font=("맑은 고딕", 10))
        m.add_command(label="지금 설정 저장 (다음 실행 때 그대로)", command=lambda: (self.save_settings(), self.log("설정 저장됨")))
        m.add_separator()
        m.add_command(label="torch 폴더 지정… (torch 신경망 · 선택)", command=self.pick_torch)
        m.add_separator()
        m.add_command(label="설정을 파일로 저장…", command=self.cfg_save_as)
        m.add_command(label="설정 파일 불러오기…", command=self.cfg_load)
        m.add_separator()
        m.add_command(label="기본값으로 되돌리기", command=self.cfg_default)
        b = self.btn_cfg
        m.tk_popup(b.winfo_rootx(), b.winfo_rooty() + b.winfo_height())

    def cfg_values(self):
        d = {k: var.get() for k, var in self.v.items()}
        for k in self.YR_KEYS + tuple(k for k in self.s if k.startswith("yr_hist_")):
            if k in self.s:
                d[k] = self.s[k]
        return d

    def cfg_apply(self, d):
        for k, val in d.items():
            if k in self.v:
                try:
                    self.v[k].set(val)
                except tk.TclError:
                    pass
        for k in self.YR_KEYS:
            if k in d:
                self.s[k] = d[k]
            else:
                self.s.pop(k, None)
        for pl, k in ((self.p_spec, "yr_spec"), (self.p_trend, "yr_trend"), (self.p_amam, "yr_amam"), (self.p_ampm, "yr_ampm")):
            pl.remember(self.s, k)
            pl.redraw()
        for k in [k for k in self.s if k.startswith("yr_hist_")]:
            self.s.pop(k)
        self.s.update({k: v for k, v in d.items() if k.startswith("yr_hist_")})
        try:
            self.run_mode_changed()
        except Exception:
            pass
        self.draw_hist()

    def cfg_save_as(self):
        os.makedirs(self.PRESET_DIR, exist_ok=True)
        path = filedialog.asksaveasfilename(parent=self.root, title="설정 저장", initialdir=self.PRESET_DIR,
                                            defaultextension=".json", filetypes=[("DPD 설정", "*.json")],
                                            initialfile="DPD설정_%s.json" % time.strftime("%m%d_%H%M"))
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"app": "PA DPD Tester " + VERSION, "settings": self.cfg_values()}, f, ensure_ascii=False, indent=1)
            self.log("설정 파일 저장: %s" % path)
        except Exception as e:
            messagebox.showerror(APP, "저장하지 못했습니다: %s" % e)

    def cfg_load(self):
        os.makedirs(self.PRESET_DIR, exist_ok=True)
        path = filedialog.askopenfilename(parent=self.root, title="설정 불러오기", initialdir=self.PRESET_DIR,
                                          filetypes=[("DPD 설정", "*.json")])
        if not path:
            return
        try:
            with open(path, encoding="utf-8") as f:
                d = json.load(f)
            self.cfg_apply(d.get("settings", d))
            self.save_settings()
            self.log("설정 불러옴: %s" % path)
        except Exception as e:
            messagebox.showerror(APP, "불러오지 못했습니다: %s" % e)

    def cfg_default(self):
        if not messagebox.askyesno(APP, "입력 칸 · 그래프 세로축을 기본값으로 되돌릴까요?\n(장비 주소 · 기록 · 샘플별 K·M·L 은 그대로)"):
            return
        d = {key: dflt for key, name, dflt, unit, card in self.FIELDS
             if key not in ("smw_host", "fsw_host")}
        d.update(odd_only=False, auto_model=True, cfr_on=True, auto_cal=True)
        for k in [k for k in self.s if k.startswith("yr_")]:
            self.s.pop(k)
        self.cfg_apply(d)
        self.save_settings()
        self.log("기본값으로 되돌림")

    def setup_undo(self, keys):
        """4 DPD 카드 값 되돌리기 (Ctrl+Z): 바뀔 때마다 이전 값을 쌓음 (같은 칸을 연달아 치면 한 번으로)"""
        self.undo_stack, self._undo_prev, self._undo_busy, self._undo_t = [], {}, False, (None, 0.0)
        for k in keys:
            var = self.v[k]
            self._undo_prev[k] = var.get()

            def on_w(*_, k=k, var=var):
                new = var.get()
                old = self._undo_prev.get(k)
                self._undo_prev[k] = new
                if self._undo_busy or new == old:
                    return
                lk, lt = self._undo_t
                now = time.time()
                if not (lk == k and now - lt < 1.5 and self.undo_stack and self.undo_stack[-1][0] == k):
                    self.undo_stack.append((k, old))
                    del self.undo_stack[:-100]
                self._undo_t = (k, now)
            var.trace_add("write", on_w)
        if self.host is None:                            # Bench 안에서는 Bench 의 Ctrl+Z 가 DPD 화면일 때 이걸 부름
            self.root.bind_all("<Control-z>", self.undo)
            self.root.bind_all("<Control-Z>", self.undo)

    def undo(self, e=None):
        if not getattr(self, "undo_stack", None):
            self.log("되돌릴 값이 없습니다")
            return "break"
        item = self.undo_stack.pop()
        grp = item if isinstance(item, list) else [item]
        self._undo_busy = True
        txt = []
        try:
            for k, old in grp:
                cur = self.v[k].get()
                self.v[k].set(old)
                self._undo_prev[k] = self.v[k].get()
                txt.append("%s %s → %s" % (k, cur, old))
        finally:
            self._undo_busy = False
        self._undo_t = (None, 0.0)
        self.log("되돌림: " + " · ".join(txt))
        return "break"

    def take_auto_kml(self):
        """자동으로 고른 K · M · L → 4 카드 칸에 넣고 샘플 종류별로 기억"""
        eng = self.engine
        ch = getattr(eng, "chosen", None) if eng is not None else None
        if not ch:
            return
        eng.chosen = None
        grp = [(k, self.v[k].get()) for k, v_ in zip(("K", "M", "L"), ch) if self.v[k].get() != str(v_)]
        self._undo_busy = True
        try:
            for k, v_ in zip(("K", "M", "L"), ch):
                self.v[k].set(str(v_))
                self._undo_prev[k] = str(v_)
        finally:
            self._undo_busy = False
        if grp:
            self.undo_stack.append(grp)                 # 자동으로 바뀐 K · M · L 은 Ctrl+Z 한 번에 되돌림
        self.store_type()
        self.show_auto_kml()
        self.save_settings()

    # ------------------------------------------------------------ 샘플 종류마다 4 DPD 카드 값 기억
    def type_name(self, st=None, bw=None):
        """기억 이름 = 샘플 종류 (+ ' · 400 MHz') → 샘플 종류 × 대역마다 1 ~ 5 카드 값을 따로 기억"""
        st = self.v["b_stype"].get() if st is None else st
        bw = (self.v["bw_mode"].get() if "bw_mode" in self.v else "100") if bw is None else bw
        return (st or "(샘플 종류 없음)") + ("" if bw == "100" else " · %s MHz" % bw)

    # 샘플과 상관없는 것 (장비 주소 등) · 신호 파일 위치와 대역은 따로 (대역마다 공통)
    TYPE_SKIP = ("smw_host", "fsw_host", "b_stype", "b_rec", "y_q", "wv_path", "bw_mode", "torch_dir")

    def type_keys(self):
        """샘플 종류마다 따로 기억하는 칸: 1 신호 · 2 RF · 3 목표 · 4 DPD · 5 실행 (장비 주소 · 그래프 보기는 빼고)"""
        if not getattr(self, "dpd_keys", None):
            return []
        return [k for k in self.v if k not in self.TYPE_SKIP]

    def store_type(self, st=None, key=None):
        """지금 칸 값 → 기억 (key = 이미 만든 기억 이름 · 샘플 종류 × 대역)"""
        keys = self.type_keys()
        if not keys:
            return
        name = key if key is not None else (st if (st is not None and st == getattr(self, "_cur_type", None)) else self.type_name(st))
        self.s.setdefault("dpd_by_type", {})[name] = {k: self.v[k].get() for k in keys}

    def show_auto_kml(self):
        st = self.type_name()
        mem = self.s.get("dpd_by_type", {}).get(st)
        if hasattr(self, "lbl_auto"):
            self.lbl_auto.configure(text=("샘플 '%s' 설정 기억 중 · K%s M%s L%s · 반복 %s" % (
                st, mem.get("K"), mem.get("M"), mem.get("L"), mem.get("iters"))) if mem else
                "샘플 종류마다 설정 (1 ~ 5 카드) 을 따로 기억 - 바꾸면 그 샘플에서 쓰던 값으로")

    def apply_auto_kml(self):
        """샘플 종류를 바꾸면: 지금 값은 이전 종류에 저장 → 새 종류의 값을 칸에 (Ctrl+Z 한 번에 되돌림)"""
        new = self.type_name()
        old = getattr(self, "_cur_type", None)
        if old is not None and old == new:
            self.show_auto_kml()
            return                                         # 같은 종류 다시 읽기: 칸은 그대로
        if old is not None:
            self.store_type(key=old)
        self._cur_type = new
        mem = dict(self.s.get("dpd_by_type", {}).get(new) or {})
        if mem and "model" not in mem and "method" in mem:              # 예전 기억 (방식 = ILA / DLA / 신경망)
            mem["model"] = "nn" if mem["method"] == "nn" else "gmp"
            if mem["method"] == "nn":
                mem["method"] = "ila"
        if not mem and new in self.s.get("auto_kml", {}):              # 예전 버전 (K · M · L 만) 기억
            mem = dict(zip(("K", "M", "L"), (str(v) for v in self.s["auto_kml"][new])))
        grp, changed = [], []
        if mem and getattr(self, "dpd_keys", None):
            self._undo_busy = True
            try:
                for k in self.type_keys():
                    if k in mem and str(self.v[k].get()) != str(mem[k]):
                        old_v = self.v[k].get()
                        try:
                            self.v[k].set(mem[k])
                        except tk.TclError:
                            continue
                        changed.append(k)
                        if k in self.dpd_keys:
                            grp.append((k, old_v))
                            self._undo_prev[k] = self.v[k].get()
            finally:
                self._undo_busy = False
            if grp:
                self.undo_stack.append(grp)
            if changed:
                for fn in ("run_mode_changed", "sig_src_changed"):
                    try:
                        getattr(self, fn)()
                    except Exception:
                        pass
                self.log("샘플 '%s' 에서 쓰던 설정으로 (%d 칸): %s" % (new, len(changed), " · ".join(
                    "%s %s" % (k, self.v[k].get()) for k in changed[:8]) + (" …" if len(changed) > 8 else "")))
        self.show_auto_kml()

    def read_dc(self):
        """Vdd 전원 (Vdd V, Id A, 측정 시각, 출처) - PA Bench Monitor 가 공유하는 값만 읽음 (전원에는 연결 안 함)"""
        h = self.host
        if h is not None:                              # 합친 프로그램: Bench 파워서플라이 값을 바로
            pp = getattr(h, "psu_panel", None)
            try:
                i, v, t = pp.e_last
                if pp.inst.get("e") is not None and i == i and v == v and time.time() - t < 5:
                    return (v, i, t, "파워서플라이")
            except Exception:
                pass
            return None
        d = BL.read_live()
        if d and d.get("vdd") is not None and d.get("id") is not None:
            return (float(d["vdd"]), float(d["id"]), float(d["t"]), "PA Bench")
        return None

    def live_dc(self):
        """측정하지 않을 때 DE 칸 아래에 지금 Vdd · Id 표시 (출처 포함) · 연결 표시"""
        try:
            dc = self.read_dc()
            ch = self.chips.get("psu")
            if ch is not None:
                ch.configure(fg="#39ff88" if dc else "#78909c", text="● Vdd 전원%s" % ((" (" + dc[3] + ")") if dc else ""))
            if not self.worker and not self.results:
                v_, sb_, col_ = self.big["eff"]
                sb_.configure(text=("지금 Id %.3f A · Vdd %.2f V (%s)" % (dc[1], dc[0], dc[3])) if dc else
                              "Vdd 전류 없음 - PA Bench Monitor 에서 파워서플라이 연결")
        except Exception:
            pass
        self.root.after(1000, self.live_dc)

    def show_tab(self, key):
        self.v_tab.set(key)
        for k, f in self.tabs.items():
            if k == key:
                f.pack(fill="both", expand=True)
            else:
                f.pack_forget()

    def update_chips(self):
        def chip(k, on, warn=False):
            c = self.chips.get(k)
            if c:
                c.configure(fg="#39ff88" if on else ("#ffd54f" if warn else "#78909c"))
        conn = self.engine is not None and getattr(self.engine, "smw", None) is not None
        demo = self.v.get("smw_host") and self.v["smw_host"].get().strip().lower() == "demo"
        chip("smw", conn, demo)
        chip("fsw", conn, demo)
        chip("bench", bool(self.recs))
        if conn:
            self.lbl_idn.configure(text="SMW: %s\nFSW: %s" % (self.engine.smw.idn, self.engine.fsw.idn))

    # ------------------------------------------------------------ 신호 파일
    def pick_wv(self):
        p = filedialog.askopenfilename(title=".wv 불러오기 (암호화 안 된 R&S 파형)", filetypes=[("R&S waveform", "*.wv")],
                                       initialdir=self.s.get("wv_dir_" + self.v["bw_mode"].get()) or self.s.get("wv_dir") or None)
        if not p:
            return
        try:
            x, fs = E.C.read_wv(p)
        except Exception as e:
            messagebox.showerror(APP, str(e))
            return
        self.s["wv_dir"] = os.path.dirname(p)
        self.s["wv_dir_" + self.v["bw_mode"].get()] = os.path.dirname(p)
        self.s["wv_" + self.v["bw_mode"].get()] = p                 # 100 / 400 MHz 마다 파일 기억
        self.v["wv_path"].set(p)
        self.v["sig_src"].set("file")
        self.log("불러옴: %s (%d 샘플 · %.2f MSps)" % (p, len(x), fs / 1e6))

    ACLR_DEF = {"100": ("98.28", "100"), "400": ("380.16", "400")}

    def bw_changed(self):
        """100 / 400 MHz DPD 바꾸기: 파일 · ACLR 채널 폭 · 간격을 대역마다 따로 기억해 바꿔 끼움"""
        new = self.v["bw_mode"].get()
        old = getattr(self, "_bw_cur", new)
        if new == old:
            return
        try:
            self.store_type(key=self.type_name(bw=old))  # 지금 값 (K · M · L 등) 은 이전 대역 이름으로 기억
        except Exception:
            pass
        self.s["wv_" + old] = self.v["wv_path"].get()
        self.s["aclr_" + old] = (self.v["ch_bw_mhz"].get(), self.v["adj_mhz"].get())
        self.s["src_" + old] = self.v["sig_src"].get()
        self._bw_cur = new
        ch, adj = self.s.get("aclr_" + new) or self.ACLR_DEF[new]
        self.v["ch_bw_mhz"].set(ch)
        self.v["adj_mhz"].set(adj)
        self.v["wv_path"].set(self.s.get("wv_" + new, ""))
        self.v["sig_src"].set("file" if new == "400" else self.s.get("src_100", self.v["sig_src"].get()))
        self.sig_src_changed()
        self.log("대역 %s MHz DPD - 신호 파일 · ACLR 채널 %s MHz · 간격 %s MHz" % (new, ch, adj))
        if getattr(self, "dpd_keys", None):
            self._cur_type = None                       # 이전 대역 값은 위에서 저장 → 이 대역에서 쓰던 값 불러오기
            self.apply_auto_kml()

    def sig_src_changed(self):
        w400 = self.v["bw_mode"].get() == "400" if "bw_mode" in self.v else False
        if w400 and self.v["sig_src"].get() != "file":
            self.v["sig_src"].set("file")                  # 400 MHz 는 내 .wv 만
            return
        f = self.v["sig_src"].get() == "file"
        p = self.v["wv_path"].get()
        if hasattr(self, "lbl_src"):
            for w_ in (self.lbl_src, self.seg_src):
                w_.grid_remove() if w400 else w_.grid()
            if w400:
                self.chk_halve.pack_forget()               # 400 MHz 는 줄이기 없음
                self.v["file_halve"].set(False)
            elif not self.chk_halve.winfo_ismapped():
                self.chk_halve.pack(side="top", anchor="w", pady=(4, 0))
            self.btn_wv.configure(text="파일 바꾸기…" if (p and os.path.isfile(p)) else "불러오기…")
            self.lbl_wv_dir.configure(text=("위치: " + os.path.dirname(p)) if p else "")
        if hasattr(self, "f_nr"):
            if f:
                self.f_nr.grid_remove()
                self.f_file.grid()
            else:
                self.f_file.grid_remove()
                self.f_nr.grid()
            for e_ in (self.e_chbw, self.e_adj):
                e_.configure(state="normal" if f else "disabled")
            if not f and not w400:
                self.v["ch_bw_mhz"].set("98.28")
                self.v["adj_mhz"].set("100")
        txt = "(파일을 고르세요)"
        if p and os.path.isfile(p):
            txt = os.path.basename(p)
            try:
                raw = open(p, "rb").read(4096).decode("latin-1")
                i = raw.find("{CLOCK:")
                if i >= 0:
                    txt += " · %.2f MSps" % (float(raw[i + 7:raw.find("}", i)]) / 1e6)
            except Exception:
                pass
        self.lbl_wv.configure(text=txt)
        if self.engine is not None:
            self.engine.sig = None

    # ------------------------------------------------------------ PA Bench 연동
    def bench_refresh(self):
        self.bench = self.host.s if self.host is not None else BL.load_settings()
        if not self.bench:
            self.cb_stype.configure(values=[])
            self.lbl_rec.configure(text="PA Bench Monitor 설정을 찾지 못했습니다 (%s)" % BL.BENCH_SET)
            self.lbl_loss.configure(text="")
            return
        names = BL.sample_types(self.bench)
        self.cb_stype.configure(values=names)
        if self.v["b_stype"].get() not in names:
            self.v["b_stype"].set(self.bench.get("stype") if self.bench.get("stype") in names else (names[0] if names else ""))
        self.apply_bench_loss()
        self.load_records()

    # ------------------------------------------------------------ 추가 손실 (커플러 · 아이솔레이터, 주파수마다)
    @staticmethod
    def parse_loss_text(text):
        """Bench 케이블 손실 txt 와 같은 형식: 한 줄에 주파수(GHz) · In(dB) · Out(dB) (탭 · 공백 · 쉼표), 숫자 3개 줄만"""
        rows = []
        for line in text.splitlines():
            parts = line.replace(",", " ").replace(";", " ").split()
            vals = [fnum(x, float("nan")) for x in parts[:3]]
            if len(vals) == 3 and all(v_ == v_ for v_ in vals):
                rows.append(vals)
        return sorted(rows)

    @staticmethod
    def loss_text(rows):
        return "Freq(GHz)\tIn loss(dB)\tOut loss(dB)\n" + "".join("%.6g\t%.3f\t%.3f\n" % tuple(r) for r in rows)

    def xloss_at(self, g=None):
        """지금 주파수의 추가 손실 (In, Out, 쓴 행 GHz) - Bench 손실 표처럼 가장 가까운 주파수 행"""
        rows = self.s.get("xloss") or []
        g = fnum(self.v["freq_ghz"].get(), float("nan")) if g is None else g
        if not rows or g != g:
            return 0.0, 0.0, None
        r = min(rows, key=lambda r: abs(r[0] - g))
        return float(r[1]), float(r[2]), float(r[0])

    def show_xloss(self):
        if not hasattr(self, "lbl_xloss"):
            return
        rows = self.s.get("xloss") or []
        if not rows:
            self.lbl_xloss.configure(text="없음 (0 dB) - 지금 케이블 손실 그대로")
            return
        xi, xo, fr = self.xloss_at()
        li = fnum(self.v["in_loss_db"].get(), 0.0)
        lo = fnum(self.v["out_loss_db"].get(), 0.0)
        self.lbl_xloss.configure(text="%s · %.6g GHz 행: In +%.2f · Out +%.2f dB\n→ 측정 손실 In %.2f · Out %.2f dB"
                                 % (os.path.basename(self.s.get("xloss_file") or "") or "직접 입력", fr, xi, xo, li + xi, lo + xo))

    def clear_xloss(self):
        if self.s.get("xloss") and not messagebox.askyesno(APP, "추가 손실 표를 비울까요? (0 dB 로)"):
            return
        self.s["xloss"], self.s["xloss_file"] = [], ""
        self.show_xloss()
        self.save_settings()

    def edit_xloss(self):
        """추가 손실 표 편집 창: Bench 케이블 손실 txt 와 같은 형식 · txt 불러오기 / 저장"""
        top = tk.Toplevel(self.root)
        top.title("추가 손실 표 (커플러 · 아이솔레이터 등)")
        top.transient(self.root.winfo_toplevel())
        f = ttk.Frame(top, padding=12)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="케이블 손실에 더할 값 - 한 줄에 주파수(GHz) · In(dB) · Out(dB)", font=FB).pack(anchor="w")
        ttk.Label(f, text="Bench 케이블 손실 txt 와 같은 형식 (탭 · 공백 · 쉼표). 지금 주파수와 가장 가까운 행을 씀. 빈 표 = 0 dB",
                  foreground="#78909c").pack(anchor="w", pady=(0, 6))
        txt = tk.Text(f, width=46, height=14, font=("Consolas", 10), undo=True)
        txt.pack(fill="both", expand=True)
        rows = self.s.get("xloss") or []
        txt.insert("1.0", self.loss_text(rows) if rows else self.loss_text([[3.35, 0, 0], [3.6, 0, 0], [3.75, 0, 0]]))
        info = ttk.Label(f, text="", foreground="#78909c")
        info.pack(anchor="w", pady=(4, 6))
        src = {"file": self.s.get("xloss_file") or ""}

        def check(*a):
            n = len(self.parse_loss_text(txt.get("1.0", "end")))
            info.configure(text="읽히는 행 %d 개%s" % (n, (" · " + os.path.basename(src["file"])) if src["file"] else ""))
        txt.bind("<KeyRelease>", check)
        check()
        bf = ttk.Frame(f)
        bf.pack(fill="x")

        def load():
            path = filedialog.askopenfilename(parent=top, title="추가 손실 txt 불러오기",
                                              initialdir=os.path.dirname(src["file"]) if src["file"] else None,
                                              filetypes=[("텍스트 파일", "*.txt"), ("CSV", "*.csv"), ("모든 파일", "*.*")])
            if not path:
                return
            try:
                try:
                    with open(path, encoding="utf-8-sig") as fh:
                        t = fh.read()
                except UnicodeDecodeError:
                    with open(path, encoding="cp949", errors="replace") as fh:
                        t = fh.read()
            except OSError as e:
                messagebox.showerror(APP, "파일을 읽지 못했습니다.\n%s" % e, parent=top)
                return
            txt.delete("1.0", "end")
            txt.insert("1.0", t)
            src["file"] = path
            check()

        def save():
            rows_ = self.parse_loss_text(txt.get("1.0", "end"))
            path = filedialog.asksaveasfilename(parent=top, title="추가 손실 txt 저장", defaultextension=".txt",
                                                initialdir=os.path.dirname(src["file"]) if src["file"] else None,
                                                initialfile=os.path.basename(src["file"]) if src["file"] else "extra_loss.txt",
                                                filetypes=[("텍스트 파일", "*.txt")])
            if not path:
                return
            with open(path, "w", encoding="utf-8-sig", newline="\r\n") as fh:
                fh.write(self.loss_text(rows_))
            src["file"] = path
            check()

        def ok():
            rows_ = self.parse_loss_text(txt.get("1.0", "end"))
            if not rows_ and txt.get("1.0", "end").strip() and not messagebox.askyesno(
                    APP, "읽히는 행이 없습니다. 추가 손실을 0 dB 로 할까요?", parent=top):
                return
            self.s["xloss"], self.s["xloss_file"] = rows_, src["file"]
            self.show_xloss()
            self.save_settings()
            self.log("추가 손실 표: %d 개 주파수%s" % (len(rows_), (" (%s)" % os.path.basename(src["file"])) if src["file"] else ""))
            top.destroy()
        ttk.Button(bf, text="txt 불러오기…", command=load).pack(side="left")
        ttk.Button(bf, text="txt 저장…", command=save).pack(side="left", padx=4)
        ttk.Button(bf, text="취소", command=top.destroy).pack(side="right")
        ttk.Button(bf, text="적용", command=ok).pack(side="right", padx=4)
        top.bind("<Escape>", lambda e: top.destroy())
        self.center_popup(top)
        top.grab_set()
        txt.focus_set()

    def apply_bench_loss(self):
        self.root.after_idle(self.show_xloss)
        if not hasattr(self, "lbl_loss"):
            return
        on = bool(self.v["bench_loss"].get())
        if not on:
            self.lbl_loss.configure(text="손실은 위 칸 값 사용")
            return
        r = BL.losses_at(self.bench, fnum(self.v["freq_ghz"].get(), float("nan"))) if self.bench else None
        if r is None:
            self.lbl_loss.configure(text="PA Bench Monitor 손실 표 없음 → 위 칸 값 사용")
            return
        li, lo, how = r
        self.v["in_loss_db"].set("%.2f" % li)
        self.v["out_loss_db"].set("%.2f" % lo)
        self.lbl_loss.configure(text="In %.2f dB · Out %.2f dB  (%s)" % (li, lo, how))

    def load_records(self):
        self.apply_auto_kml()
        self.recs = []
        st = self.v["b_stype"].get()
        pam = BL.latest_pam(self.bench, st) if (self.bench and st) else None
        if not pam:
            self.cb_rec.configure(values=[])
            self.v["b_rec"].set("")
            self.lbl_rec.configure(text="이 샘플 종류의 .pam 기록이 없습니다" if st else "")
            return
        try:
            recs = BL.read_records(pam)
        except Exception as e:
            self.lbl_rec.configure(text=".pam 읽기 실패: %s" % e)
            return
        g = fnum(self.v["freq_ghz"].get(), float("nan"))
        num = self.sample_num()
        self._rec_num = num
        mine = lambda r: bool(num) and num.lower() in [t.lower() for t in re.split(r"[\s_\-·,/()]+", "%s %s" % (r["name"], r["display"])) if t]
        # 지금 샘플 번호 (예: S2) 기록 먼저 → 지금 주파수에 가까운 것 → Mod. → 최근 순서
        recs.sort(key=lambda r: r["when"], reverse=True)
        recs.sort(key=lambda r: (0 if mine(r) else 1,
                                 abs(r["freq_ghz"] - g) if (g == g and r["freq_ghz"] == r["freq_ghz"]) else 99, 0 if r["mod"] else 1))
        self.recs = recs
        labels = ["%s%s · %.6g GHz%s" % ("★ " if mine(r) else "", r["display"], r["freq_ghz"], "" if r["mod"] else " (Pulse)") for r in recs]
        if num and recs and not mine(recs[0]):
            self.log("⚠ 샘플 '%s' 기록이 이 .pam 에 없어 다른 샘플 기록 (%s) 으로 - [기록] 에서 확인하세요" % (num, recs[0]["display"]))
        self.cb_rec.configure(values=labels)
        self.v["b_rec"].set(labels[0] if labels else "")
        self.pam_path = pam
        self.show_rec()
        self.update_chips()

    def sample_num(self):
        """지금 샘플 번호 (Bench 에서 고른 S1 · S2 …) - 같은 번호 기록을 먼저 고름"""
        try:
            if self.host is not None:
                return (self.host.var_sample.get() or "").strip()
            return str((self.bench or {}).get("sample") or "").strip()
        except Exception:
            return ""

    def cur_rec(self):
        labels = list(self.cb_rec.cget("values") or [])
        cur = self.v["b_rec"].get()
        if cur in labels and labels.index(cur) < len(self.recs):
            return self.recs[labels.index(cur)]
        return None

    def show_rec(self):
        """3 카드 기록 내용: 파일 · 기록 · SG · Pout · 손실 을 이름 / 값 칸으로"""
        f = self.f_recinfo
        for w in f.winfo_children():
            w.destroy()
        r = self.cur_rec()
        if r is None:
            f.pack_forget()
            self.lbl_rec.pack(anchor="w")
            return
        self.lbl_rec.pack_forget()
        f.pack(fill="x")
        num = getattr(self, "_rec_num", "") or ""
        mine = bool(num) and self.v["b_rec"].get().startswith("★")
        rows = [("파일", os.path.basename(getattr(self, "pam_path", "")) or "-", None),
                ("기록", "%s%s" % (r["display"], ("  ★ 지금 샘플 %s" % num) if mine else ""), None),
                ("신호", "%.6g GHz · %s" % (r["freq_ghz"], "Mod. (변조)" if r["mod"] else "Pulse"),
                 None if r["mod"] else "#ef6c00"),
                ("SG", "%.1f ~ %.1f dBm  (%d 점)" % (min(r["sg"]), max(r["sg"]), len(r["sg"])), None),
                ("Pout", "%.2f ~ %.2f dBm" % (min(r["pout"]), max(r["pout"])), None)]
        if r.get("inl") == r.get("inl") and r.get("outl") == r.get("outl"):
            rows.append(("손실", "In %.2f · Out %.2f dB  (기록할 때)" % (r["inl"], r["outl"]), None))
        T = THEME
        for i, (k, v_, col) in enumerate(rows):
            tk.Label(f, text=k, font=("맑은 고딕", 9), fg=T["dim"], bg=T["head"], anchor="w", width=5).grid(
                row=i, column=0, sticky="w", padx=(8, 4), pady=(3 if i == 0 else 0, 3 if i == len(rows) - 1 else 0))
            tk.Label(f, text=v_, font=("맑은 고딕", 9, "bold"), fg=col or T["fg"], bg=T["head"], anchor="w",
                     wraplength=300, justify="left").grid(row=i, column=1, sticky="w", pady=(3 if i == 0 else 0, 3 if i == len(rows) - 1 else 0))
        if not r["mod"]:
            tk.Label(f, text="⚠ Pulse 기록 - DPD 는 Mod. 기록이 더 맞음", font=("맑은 고딕", 9), fg="#ef6c00", bg=T["head"],
                     anchor="w").grid(row=len(rows), column=0, columnspan=2, sticky="w", padx=8, pady=(0, 3))

    def sg_from_target(self):
        r = self.cur_rec()
        t = fnum(self.v["b_target"].get(), float("nan"))
        if r is None or t != t:
            messagebox.showinfo(APP, "기록을 고르고 목표 Pout 을 넣으세요.")
            return
        sg = BL.sg_for_pout(r, t)
        if sg != sg:
            return
        out = t > max(r["pout"]) or t < min(r["pout"])
        mx = fnum(self.v["sg_max_dbm"].get(), 0.0)
        if sg > mx:
            messagebox.showwarning(APP, "필요한 SG %.2f dBm 이 SG 최대 %.2f dBm 보다 큽니다." % (sg, mx))
            return
        self.v["sg_dbm"].set("%.2f" % sg)
        self.log("목표 Pout %.2f dBm → SG %.2f dBm (Bench 기록 보간%s)" % (t, sg, ", 기록 범위 밖 - 연장" if out else ""))

    # ------------------------------------------------------------ 모델 (GMP · 구간 GMP · DVR · 신경망) 선택
    def model_text(self, p, eng):
        """상태 · 기록 이름에 쓸 '방식 · 크기' 글"""
        if eng is not None and self.worker is not None:
            p = eng.p
        q = dict(p)
        try:
            E.migrate_method(q)
            meth = E.method_label(q)
        except Exception:
            meth = str(q.get("method", ""))
        mdl = getattr(eng, "model", None) if eng is not None else None
        m = q.get("model", "gmp")
        if mdl is not None and hasattr(mdl, "H"):
            return "%s · M%d H%d" % (meth, mdl.M, mdl.H)
        if mdl is not None and hasattr(mdl, "nseg"):
            return "%s · 구간%d M%d" % (meth, mdl.nseg, mdl.M)
        if mdl is not None:
            return "%s · K%d M%d L%d" % (meth, mdl.K, mdl.M, mdl.L)
        if m in ("nn", "pnn", "tnn"):
            return "%s · M%s H%s" % (meth, q.get("M"), q.get("nn_hidden"))
        if m == "dvr":
            return "%s · 구간%s M%s" % (meth, q.get("dvr_seg"), q.get("M"))
        return "%s · K%s M%s L%s%s" % (meth, q.get("K"), q.get("M"), q.get("L"),
                                       " (자동)" if q.get("auto_model") and m == "gmp" else "")

    def pick_torch(self):
        """torch 폴더 (pip --target 으로 받은 곳) 를 정하고 바로 읽어 봄 → 되면 모델 목록에 torch 신경망 넣기"""
        d = filedialog.askdirectory(parent=self.root, title="torch 폴더 (pip install --target 으로 받은 곳)",
                                    initialdir=self.s.get("torch_dir") or os.path.expanduser("~"))
        if not d:
            return
        import dpd_torch
        if dpd_torch.available() and self.s.get("torch_dir") != d:
            messagebox.showinfo(APP, "torch 는 이미 읽혀 있습니다. 새 폴더는 프로그램을 다시 켜면 적용됩니다.")
            self.s["torch_dir"] = d
            self.save_settings()
            return
        self.root.configure(cursor="watch")
        self.root.update()
        try:
            ok, msg = dpd_torch.load(d)
        finally:
            self.root.configure(cursor="")
        if ok:
            self.s["torch_dir"] = d
            on = self.models_on()
            if "tnn" not in on:
                self.s["models_on"] = on + ["tnn"]
            self.refresh_models()
            self.save_settings()
            self.log("torch 읽음: " + msg)
            messagebox.showinfo(APP, "torch 를 읽었습니다.\n%s\n\n4 카드 모델에 'torch 신경망' 이 생겼습니다." % msg)
        else:
            self.log("torch 못 읽음: " + msg)
            messagebox.showwarning(APP, "torch 를 못 읽었습니다.\n%s\n\n이 프로그램은 %s 입니다. torch 폴더도 같은 버전 파이썬으로 받아야 합니다:\n"
                                   "python -m pip install --target <폴더> torch --index-url https://download.pytorch.org/whl/cpu"
                                   % (msg, dpd_torch.py_tag()))

    def models_on(self):
        on = [k for k in self.s.get("models_on", [k for k, _ in self.MODELS if k != "tnn"]) if k in dict(self.MODELS)]
        return on or ["gmp"]

    def refresh_models(self):
        on = self.models_on()
        names = dict(self.MODELS)
        self.cb_model.configure(values=[names[k] for k in on])
        if self.v["model"].get() not in on:
            self.v["model"].set(on[0])
        self.model_changed()

    def method_compat(self):
        if self.v["method"].get() == "nn":           # 예전 설정 · 기억 (방식 = 신경망)
            self.v["method"].set("ila")
            self.v["model"].set("nn")

    def model_changed(self):
        m = self.v["model"].get()
        if m not in dict(self.MODELS):
            self.v["model"].set("gmp")
            return
        self._model_disp.set(dict(self.MODELS)[m])
        tip = self.MODEL_TIP.get(m, "")
        if m == "tnn":
            tip = "PyTorch 2층 신경망 · " + (("torch 폴더: %s" % self.s["torch_dir"]) if self.s.get("torch_dir")
                                              else "torch 폴더 안 정함") + " · 못 읽으면 numpy 신경망으로 대신"
        self.lbl_model.configure(text=tip)
        for key, models in self.MODEL_ROWS.items():
            for w in self.dpd_row_w.get(key, ()):
                if m in models:
                    w.grid()
                else:
                    w.grid_remove()

    def center_popup(self, top):
        top.update_idletasks()
        rt = self.root.winfo_toplevel()
        x = rt.winfo_rootx() + (rt.winfo_width() - top.winfo_width()) // 2
        y = rt.winfo_rooty() + (rt.winfo_height() - top.winfo_height()) // 2
        top.geometry("+%d+%d" % (max(x, 0), max(y, 0)))

    def edit_models(self):
        """4 카드 모델 목록에 넣고 뺄 것 고르기 (써 본 뒤 필요 없는 건 빼 두기)"""
        top = tk.Toplevel(self.root)
        top.title("DPD 모델 목록")
        top.transient(self.root.winfo_toplevel())
        top.resizable(False, False)
        f = ttk.Frame(top, padding=14)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="4 카드 · 방식 비교에 보일 모델", font=FB).pack(anchor="w", pady=(0, 6))
        on = self.models_on()
        vs = {}
        for k, n in self.MODELS:
            vs[k] = tk.BooleanVar(value=k in on)
            ttk.Checkbutton(f, text="%s  -  %s" % (n, self.MODEL_TIP[k]), variable=vs[k]).pack(anchor="w", pady=1)
        ttk.Label(f, text="빼도 지운 게 아니라 숨김 - 언제든 다시 넣을 수 있음", foreground="#78909c").pack(anchor="w", pady=(6, 4))
        tf = ttk.Frame(f)
        tf.pack(fill="x", pady=(0, 8))
        ttk.Label(tf, text="torch 폴더: %s" % (self.s.get("torch_dir") or "안 정함 (torch 신경망 쓸 때만)"),
                  foreground="#78909c").pack(side="left")
        ttk.Button(tf, text="torch 폴더…", command=lambda: (top.destroy(), self.pick_torch())).pack(side="right")
        bf = ttk.Frame(f)
        bf.pack(anchor="e")

        def ok():
            sel = [k for k, _ in self.MODELS if vs[k].get()]
            if not sel:
                messagebox.showwarning(APP, "모델을 하나 이상 고르세요", parent=top)
                return
            self.s["models_on"] = sel
            self.refresh_models()
            self.save_settings()
            top.destroy()
        ttk.Button(bf, text="적용", command=ok).pack(side="left", padx=3)
        ttk.Button(bf, text="취소", command=top.destroy).pack(side="left", padx=3)
        top.bind("<Escape>", lambda e: top.destroy())
        self.center_popup(top)
        top.grab_set()

    def cmp_items(self):
        """방식 비교 후보: 켜 둔 모델 × 학습 방식"""
        out = []
        names = dict(self.MODELS)
        for k in self.models_on():
            if k in ("nn", "pnn", "tnn"):
                out.append(("%s:ila" % k, names[k]))
            else:
                out.append(("%s:ila" % k, "%s-ILA" % names[k]))
                out.append(("%s:dla" % k, "%s-DLA" % names[k]))
        return out

    def ask_compare(self):
        if E is None or self.worker:
            return
        top = tk.Toplevel(self.root)
        top.title("방식 비교 실행")
        top.transient(self.root.winfo_toplevel())
        top.resizable(False, False)
        f = ttk.Frame(top, padding=14)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="같은 SG 레벨 · 같은 DPD OFF 측정에서 방식마다 DPD", font=FB).pack(anchor="w")
        ttk.Label(f, text="SG %s dBm · 반복 %s 번씩 · 결과는 방식마다 따로 기록 + 요약 표" % (
            self.v["sg_dbm"].get(), self.v["iters"].get()), foreground="#78909c").pack(anchor="w", pady=(0, 8))
        sel0 = self.s.get("cmp_sel", self.CMP_DEF)
        vs = {}
        g = ttk.Frame(f)
        g.pack(anchor="w")
        for i, (k, n) in enumerate(self.cmp_items()):
            vs[k] = tk.BooleanVar(value=k in sel0)
            ttk.Checkbutton(g, text=n, variable=vs[k]).grid(row=i // 2, column=i % 2, sticky="w", padx=(0, 18), pady=1)
        v_ilc = tk.BooleanVar(value=bool(self.s.get("cmp_ilc", False)))
        ttk.Checkbutton(f, text="ILC 한계도 같이 (기준선 · +%s 번 측정)" % self.v["ilc_iters"].get(), variable=v_ilc).pack(anchor="w", pady=(8, 0))
        lbl = ttk.Label(f, text="", foreground="#78909c")
        lbl.pack(anchor="w", pady=(6, 8))

        def est(*a):
            n = sum(1 for v in vs.values() if v.get())
            it = int(fnum(self.v["iters"].get(), 4))
            m = 1 + n * it + (int(fnum(self.v["ilc_iters"].get(), 10)) if v_ilc.get() else 0)
            lbl.configure(text="측정 약 %d 번 · 대략 %d ~ %d 분" % (m, max(1, m * 4 // 60), max(1, m * 7 // 60 + 1)))
        for v in list(vs.values()) + [v_ilc]:
            v.trace_add("write", est)
        est()
        bf = ttk.Frame(f)
        bf.pack(anchor="e")

        def ok():
            sel = [k for k, _ in self.cmp_items() if vs[k].get()]
            if not sel:
                messagebox.showwarning(APP, "비교할 방식을 하나 이상 고르세요", parent=top)
                return
            self.s["cmp_sel"], self.s["cmp_ilc"] = sel, bool(v_ilc.get())
            top.destroy()
            self.start(True, compare=([tuple(k.split(":")) for k in sel], bool(v_ilc.get())))
        ttk.Button(bf, text="▶ 비교 시작", command=ok).pack(side="left", padx=3)
        ttk.Button(bf, text="취소", command=top.destroy).pack(side="left", padx=3)
        top.bind("<Escape>", lambda e: top.destroy())
        self.center_popup(top)
        top.grab_set()

    def show_compare(self, comp, off):
        """방식 비교 결과 표 (가운데 창) · 고른 방식을 4 카드에 바로 넣기"""
        if not comp:
            return
        top = tk.Toplevel(self.root)
        top.title("방식 비교 결과")
        top.transient(self.root.winfo_toplevel())
        f = ttk.Frame(top, padding=12)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="방식 비교 · DPD OFF ACLR %.1f / %.1f dBc · Pout %.2f dBm" % (off["aclr_l"], off["aclr_u"], off["pout"]),
                  font=FB).pack(anchor="w", pady=(0, 6))
        cols = ("name", "aclr", "imp", "evm", "pout", "pae", "t", "nc", "size")
        hd = ("방식", "최고 ACLR L / U", "개선", "EVM", "Pout", "PAE", "시간", "계수", "크기")
        wd = (130, 120, 60, 60, 70, 60, 55, 55, 110)
        tv = ttk.Treeview(f, columns=cols, show="headings", height=min(len(comp), 10), selectmode="browse")
        for c_, h, w in zip(cols, hd, wd):
            tv.heading(c_, text=h)
            tv.column(c_, width=w, anchor="w" if c_ in ("name", "size") else "e")
        tv.pack(fill="both", expand=True)
        ok_ = [c for c in comp if c["best"] and c["model"] != "ilc"]
        best = min(ok_, key=lambda c: max(c["best"]["aclr_l"], c["best"]["aclr_u"])) if ok_ else None
        o = max(off["aclr_l"], off["aclr_u"])
        iid = {}
        for c in comp:
            b = c["best"]
            if b:
                w = max(b["aclr_l"], b["aclr_u"])
                vals = (("★ " if c is best else "") + c["name"], "%.1f / %.1f" % (b["aclr_l"], b["aclr_u"]), "%.1f dB" % (o - w),
                        "%.2f %%" % b["evm"], "%.2f" % b["pout"], ("%.1f %%" % b["pae"]) if b.get("pae") == b.get("pae") else "-",
                        "%.0f초" % c["t"], str(c["n_coef"] or "-"), c["kml"])
            else:
                vals = (c["name"], "실패", "", "", "", "", "%.0f초" % c["t"], "", (c.get("err") or "")[:30])
            iid[tv.insert("", "end", values=vals)] = c
        ttk.Label(f, text="★ = ACLR 가장 좋은 방식 · 개선 = DPD OFF 대비 · ILC 한계와 1 ~ 2 dB 안이면 모델은 충분",
                  foreground="#78909c").pack(anchor="w", pady=(6, 6))
        bf = ttk.Frame(f)
        bf.pack(anchor="e")

        def use():
            sel = tv.selection()
            c = iid.get(sel[0]) if sel else best
            if not c or c["model"] == "ilc":
                return
            self.v["model"].set(c["model"])
            if c["learn"]:
                self.v["method"].set(c["learn"])
            self.log("4 카드 모델 → %s" % c["name"])
            top.destroy()
        ttk.Button(bf, text="고른 방식을 4 카드에 넣기", command=use).pack(side="left", padx=3)
        ttk.Button(bf, text="닫기", command=top.destroy).pack(side="left", padx=3)
        top.bind("<Escape>", lambda e: top.destroy())
        self.center_popup(top)

    # ------------------------------------------------------------ 값 모으기
    def params(self):
        p = {}
        for key, name, dflt, unit, card in self.FIELDS:
            val = self.v[key].get().strip()
            if key == "fsw_rbw_khz":
                p[key] = max(fnum(val, 0.0), 0.0) if val else 0.0
            elif key in ("smw_host", "fsw_host", "mod", "fsw_att_db", "fsw_ref_dbm"):
                p[key] = val
            elif key in ("n_sym", "K", "M", "L", "iters", "n_fit", "nn_hidden", "nn_epochs", "ilc_iters", "dvr_seg", "iq_avg"):
                p[key] = int(fnum(val, float(dflt)))
            else:
                p[key] = fnum(val, float(dflt))
        p["os"] = int(fnum(self.v["os"].get(), 4))
        p["cfr_on"] = bool(self.v["cfr_on"].get())
        p["odd_only"] = bool(self.v["odd_only"].get())
        p["auto_model"] = bool(self.v["auto_model"].get())
        p["bw_mode"] = self.v["bw_mode"].get()
        p["file_max_msps"] = 500.0 if (self.v["file_halve"].get() and p["bw_mode"] == "100") else 0.0  # 기본: 그대로
        p["method"] = self.v["method"].get()
        p["aclr_src"] = self.v["aclr_src"].get()
        r_ = str(p.get("fsw_ref_dbm", "")).strip().lower()
        if r_ not in ("auto", "") and fnum(r_, float("nan")) != fnum(r_, float("nan")):
            raise ValueError("FSW Ref Level 은 숫자 (dBm) 또는 auto")
        p["model"] = self.v["model"].get()
        p["torch_dir"] = self.s.get("torch_dir", "")
        E.migrate_method(p)
        p["sig_src"] = "file" if p["bw_mode"] == "400" else self.v["sig_src"].get()
        p["wv_path"] = self.v["wv_path"].get()
        if p["sig_src"] == "file" and not os.path.isfile(p["wv_path"]):
            raise ValueError("불러올 .wv 파일을 고르세요" + (" (400 MHz DPD 는 내 .wv 신호로)" if p["bw_mode"] == "400" else ""))
        p["ch_bw_mhz"] = fnum(self.v["ch_bw_mhz"].get(), 98.28)
        p["adj_mhz"] = fnum(self.v["adj_mhz"].get(), 100.0)
        if p["sig_src"] == "nr":
            p["ch_bw_mhz"], p["adj_mhz"] = 98.28, 100.0
        xi, xo, _fr = self.xloss_at(p["freq_ghz"])          # 커플러 · 아이솔레이터 등 추가 손실 (주파수마다)
        p["in_loss_db"] += xi
        p["out_loss_db"] += xo
        p["xloss_in"], p["xloss_out"] = xi, xo
        if self.host is not None:                          # Bench 안: 장비 주소는 Bench [장비 설정] 의 것
            for k, hv in (("smw_host", "var_smw_host"), ("fsw_host", "var_fsw_host")):
                try:
                    p[k] = getattr(self.host, hv).get().strip() or p[k]
                except Exception:
                    pass
        p["rec"] = self.cur_rec()
        p["auto_cal"] = bool(self.v["auto_cal"].get()) and p["rec"] is not None
        if p["K"] < 1 or p["M"] < 1 or p["n_sym"] < 2:
            raise ValueError("K, M 은 1 이상 · 심볼 수는 2 이상")
        return p

    def log(self, s):
        self.txt.insert("end", time.strftime("%H:%M:%S  ") + s + "\n")
        self.txt.see("end")
        if hasattr(self, "lbl_status"):
            self.lbl_status.configure(text=s.strip())

    # ------------------------------------------------------------ 실행
    def busy(self, on):
        self.btn_go.configure(state="disabled" if on else "normal")
        self.btn_off.configure(state="disabled" if on else "normal")
        self.btn_ilc.configure(state="disabled" if on else "normal")
        if hasattr(self, "btn_cmp"):
            self.btn_cmp.configure(state="disabled" if on else "normal")
        if hasattr(self, "btn_stop5"):
            self.btn_stop5.configure(state="normal" if on else "disabled", bg="#c62828" if on else "#b0bec5")
        if hasattr(self, "btn_stop"):
            self.btn_stop.configure(state="normal" if on else "disabled")

    def get_engine(self, p):
        if self.engine is None or self.engine.p.get("smw_host") != p["smw_host"] or self.engine.p.get("fsw_host") != p["fsw_host"]:
            if self.engine is not None:
                self.engine.close()
            self.engine = E.Engine(p, log=lambda s: self.q.put(("log", s)), on_result=lambda r: self.q.put(("res", r)),
                                   on_progress=lambda s: self.q.put(("prog", s)), dc_reader=self.read_dc)
            ks = getattr(self, "_keep_sig", None)
            if ks is not None:
                self.engine.sig, self._keep_sig = ks, None
        else:
            sig_keys = ("os", "n_sym", "mod", "cfr_on", "papr_db", "sig_src", "wv_path", "file_max_msps")
            mdl_keys = ("K", "M", "L", "odd_only", "lam", "model", "method", "nn_hidden", "nn_epochs", "dvr_seg", "torch_dir")
            if any(self.engine.p.get(k) != p[k] for k in sig_keys):
                self.engine.sig = None            # 신호가 바뀌면 다시 만들기 (모델도 같이)
                self.engine.p.update(p)
            elif self.engine.sig is not None and any(self.engine.p.get(k) != p[k] for k in mdl_keys):
                self.engine.p.update(p)
                self.engine.model = self.engine.make_model()          # 모델만 새로
            self.engine.p.update(p)
        return self.engine

    def make_signal(self):
        if E is None or self.worker:
            return
        try:
            p = self.params()
        except ValueError as e:
            messagebox.showwarning(APP, str(e))
            return
        eng = self.get_engine(p)
        self.busy(True)

        def job():
            try:
                sig = eng.make_signal()
                self.q.put(("sig", "%d 샘플 · %.2f MSps · 길이 %.3f ms · PAPR %.2f dB"
                            % (len(sig.x), sig.fs / 1e6, len(sig.x) / sig.fs * 1e3, E.C.papr(sig.x))))
            except Exception as e:
                self.q.put(("err", "신호 만들기 실패: %s" % e))
            self.q.put(("done", None))
        self.worker = threading.Thread(target=job, daemon=True)
        self.worker.start()

    def run_mode_changed(self):
        if self.v["run_mode"].get() == "sweep":
            self.f_sweep.grid()
            self.btn_go.configure(text="▶ 파워 스윕 + DPD")
        else:
            self.f_sweep.grid_remove()
            self.btn_go.configure(text="▶ DPD 실행 (OFF → 반복)")

    def sweep_levels(self):
        a, b, st = (fnum(self.v[k].get(), float("nan")) for k in ("sw_start", "sw_stop", "sw_step"))
        if not (a == a and b == b and st == st) or st <= 0:
            raise ValueError("파워 스윕: SG 시작 · 끝 · 간격을 확인하세요")
        n = int(math.floor(abs(b - a) / st + 1e-6)) + 1
        if n > 60:
            raise ValueError("파워 스윕 레벨이 너무 많습니다 (%d개, 60개까지)" % n)
        sgn = 1 if b >= a else -1
        return [round(a + sgn * st * k, 3) for k in range(n)]

    def start(self, do_dpd, ilc=False, compare=None):
        if E is None or self.worker:
            return
        sweep = do_dpd and self.v["run_mode"].get() == "sweep" and compare is None
        try:
            p = self.params()
            levels = self.sweep_levels() if sweep else None
        except ValueError as e:
            messagebox.showwarning(APP, str(e))
            return
        if sweep and max(levels) > p["sg_max_dbm"]:
            if not messagebox.askyesno(APP, "스윕 끝 (%.2f dBm) 이 SG 최대 (%.2f dBm) 보다 큽니다.\nSG 최대까지만 측정할까요?"
                                       % (max(levels), p["sg_max_dbm"])):
                return
            levels = [l for l in levels if l <= p["sg_max_dbm"] + 1e-9]
        if not sweep and p["sg_dbm"] > p["sg_max_dbm"]:
            messagebox.showwarning(APP, "SG 레벨 (%.2f) 이 SG 최대 (%.2f) 보다 큽니다." % (p["sg_dbm"], p["sg_max_dbm"]))
            return
        t = fnum(self.v["target_aclr"].get(), float("nan"))
        p["target_aclr"] = t if t == t else None
        pstop = fnum(self.v["sw_pout_stop"].get(), float("nan"))
        self.save_settings()
        eng = self.get_engine(p)
        self.results = []
        for i in self.tree.get_children():
            self.tree.delete(i)
        if compare is not None:
            self.cmp_mode, self.cmp_runs, self.cmp_off, self.cur_run = True, {}, None, None
            self.cmp_name = self.v["run_name"].get().strip() or ("%s %s" % (self.v["b_stype"].get().strip() or "DPD",
                                                                              time.strftime("%m-%d %H:%M"))).strip()
            self.cmp_p = p
        else:
            self.cmp_mode = False
            self.new_run(p, sweep, ilc)
        self.busy(True)
        self._last_prog = ""
        self._had_err = False
        rf_end = bool(self.v["rf_off_end"].get())

        rid = self.run_id = getattr(self, "run_id", 0) + 1
        hb = {"on": True}

        def heartbeat():                               # 측정하는 동안 Bench 에 "장비 쓰는 중" 알림 (0.5초마다)
            while hb["on"] and getattr(self, "run_id", 0) == rid:
                BL.set_busy(True)
                time.sleep(0.5)
            if getattr(self, "run_id", 0) == rid or not self.worker:
                BL.set_busy(False)

        def wait_bench():
            """PA Bench Monitor 가 SMW · FSW 에 연결돼 있으면 읽기를 멈출 때까지 기다림 (최대 5초)"""
            d = BL.read_ack()
            if d is None:
                return
            if d.get("sweep"):
                raise RuntimeError("PA Bench Monitor 가 자동 측정 중입니다. 끝난 뒤에 실행하세요.")
            conn = [k for k, v in (d.get("inst") or {}).items() if v.get("connected")]
            if not conn:
                return
            self.q.put(("log", "PA Bench Monitor 가 %s 에 연결돼 있음 → 읽기 멈추기를 기다리는 중…" % " · ".join(c.upper() for c in conn)))
            t_end = time.time() + 5.0
            while time.time() < t_end:
                eng.check()
                d = BL.read_ack() or {}
                inst = d.get("inst") or {}
                if all(inst.get(k, {}).get("paused") or not inst.get(k, {}).get("connected") for k in conn):
                    time.sleep(0.4)                    # 하던 읽기가 끝날 시간
                    self.q.put(("log", "  Bench 읽기 멈춤 확인 → 측정 시작 (끝나면 Bench 가 다시 읽음)"))
                    return
                time.sleep(0.2)
            self.q.put(("log", "  ⚠ Bench 가 멈춤 확인을 안 보냄 (Bench v2.3.24 이상 필요) - 그대로 진행. "
                               "안 되면 Bench 에서 SMW · FSW 연결을 끊어 주세요"))

        def job():
            threading.Thread(target=heartbeat, daemon=True).start()
            try:
                wait_bench()
                if eng.sig is None:
                    sig = eng.make_signal()
                    self.q.put(("sig", "%d 샘플 · %.2f MSps · PAPR %.2f dB" % (len(sig.x), sig.fs / 1e6, E.C.papr(sig.x))))
                if compare is not None:
                    eng.run_compare(compare[0], compare[1])
                    self.q.put(("cmp", (list(eng.compare), getattr(eng, "compare_off", None))))
                elif ilc:
                    eng.run_ilc(levels if sweep else None)
                elif sweep:
                    eng.run_sweep(levels, pstop if pstop == pstop else None)
                else:
                    eng.run(do_dpd)
                self.q.put(("log", "✔ 끝"))
            except E.Stop:
                self.q.put(("log", "■ 중지됨"))
            except Exception as e:
                if not eng.stop:                         # 중지로 끊긴 건 오류로 안 띄움
                    self.q.put(("err", "측정 실패: %s" % e))
            finally:
                if not eng.stop:                         # 중지면 abort 가 따로 RF OFF · FSW 복귀
                    if rf_end:
                        eng.rf_off()
                    try:
                        eng.fsw_restore()               # 끝 · 오류 모두 FSW 를 원래 모드로
                    except Exception:
                        pass
                hb["on"] = False
                self.q.put(("done", rid))
        self.worker = threading.Thread(target=job, daemon=True)
        self.worker.start()

    # ------------------------------------------------------------ 기록 (ACLR vs Pout, 과거와 비교)
    HIST_FILE = os.path.join(SET_DIR, "history.json")

    def load_hist(self):
        if not hasattr(self, "hist"):
            try:
                with open(self.HIST_FILE, encoding="utf-8") as f:
                    self.hist = json.load(f)
            except Exception:
                self.hist = []
        return self.hist

    def save_hist(self):
        try:
            os.makedirs(SET_DIR, exist_ok=True)
            tmp = self.HIST_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.hist[-300:], f, ensure_ascii=False)
            os.replace(tmp, self.HIST_FILE)
        except Exception as e:
            self.log("기록 저장 실패: %s" % e)

    def new_run(self, p, sweep, ilc=False):
        self.load_hist()
        st = self.v["b_stype"].get().strip()
        name = self.v["run_name"].get().strip() or ("%s %s" % (st or "DPD", time.strftime("%m-%d %H:%M"))).strip()
        sig = ("내 .wv %s" % os.path.basename(p["wv_path"])) if p["sig_src"] == "file" else \
              "NR100 1C %s ×%d CFR %s" % (p["mod"], p["os"], ("%.1f" % p["papr_db"]) if p["cfr_on"] else "OFF")
        run = dict(id="%d" % (time.time() * 1000), name=name, when=time.strftime("%Y-%m-%d %H:%M"), freq=p["freq_ghz"],
                   stype=st, sig=sig, dpd=("ILC 한계" if ilc else self.model_text(p, None)),
                   sweep=bool(sweep), on=True, pts=[])
        self.hist.append(run)
        self.cur_run = run
        self.refresh_hist_list()

    def add_hist_point(self, r):
        pt = dict(kind=r.get("kind", "dpd"), base=r.get("base_sg"), sg=r["sg"], pout=r["pout"],
                  aclr_l=r["aclr_l"], aclr_u=r["aclr_u"], evm=r["evm"], label=r["label"],
                  de=r.get("de"), pae=r.get("pae"), id=r.get("id"), pdc=r.get("pdc"))
        if getattr(self, "cmp_mode", False):
            # 방식 비교: 방식마다 기록 하나 (같은 DPD OFF 점을 앞에)
            m = r.get("method") or "?"
            if m == "OFF":
                self.cmp_off = pt
                return
            run = self.cmp_runs.get(m)
            if run is None:
                p = self.cmp_p
                sig = ("내 .wv %s" % os.path.basename(p["wv_path"])) if p["sig_src"] == "file" else \
                      "NR100 1C %s ×%d CFR %s" % (p["mod"], p["os"], ("%.1f" % p["papr_db"]) if p["cfr_on"] else "OFF")
                run = dict(id="%d" % (time.time() * 1000), name="%s · %s" % (self.cmp_name, m), when=time.strftime("%Y-%m-%d %H:%M"),
                           freq=p["freq_ghz"], stype=self.v["b_stype"].get().strip(), sig=sig, dpd="비교: " + m,
                           sweep=False, on=True, pts=[dict(self.cmp_off)] if self.cmp_off else [])
                self.load_hist().append(run)
                self.cmp_runs[m] = run
            run["pts"].append(pt)
            self.refresh_hist_list()
            self.draw_hist()
            return
        run = getattr(self, "cur_run", None)
        if run is None:
            return
        run["pts"].append(pt)
        self.refresh_hist_list()
        self.draw_hist()

    @staticmethod
    def run_curves(run):
        """기록 → (OFF 점들, ON 점들): 레벨(base SG)마다 OFF 1개 · DPD 는 그 레벨의 마지막 결과"""
        off, on = {}, {}
        for q in run.get("pts", []):
            k = round(q.get("base") if q.get("base") is not None else q["sg"], 3)
            if q["kind"] == "ilc" and k in on and max(on[k]["aclr_l"], on[k]["aclr_u"]) <= max(q["aclr_l"], q["aclr_u"]):
                continue                                   # ILC 는 그 레벨에서 가장 좋은 것
            (off if q["kind"] == "off" else on)[k] = q
        return [off[k] for k in sorted(off)], [on[k] for k in sorted(on)]

    def yval(self, q):
        y = self.v["y_q"].get()
        if y == "aclr":
            return max(q["aclr_l"], q["aclr_u"])
        v = q.get(y)
        return v if isinstance(v, (int, float)) and v is not None else float("nan")

    def hist_colors(self):
        """주파수 → 고정 색 (낮은 주파수부터 파랑 · 초록 · 빨강 …, PA Bench Monitor 와 같은 순서)"""
        pal = ["#1f77b4", "#2ca02c", "#d62728", "#ff7f0e", "#9467bd", "#8c564b", "#e377c2", "#17becf", "#bcbd22", "#7f7f7f"]
        fs = sorted({round(fnum(r.get("freq"), 0), 6) for r in self.load_hist()})
        return {f: pal[i % len(pal)] for i, f in enumerate(fs)}

    def draw_hist(self):
        if not hasattr(self, "p_hist"):
            return
        self.p_hist.remember(self.s, "yr_hist_" + self.v["y_q"].get())     # 세로축 값 (ACLR · EVM · DE …) 마다 따로
        fc = self.hist_colors()
        shown = [r for r in self.load_hist() if r.get("on") and r.get("pts")]
        same = {}
        ser = []
        for r in shown:
            f = round(fnum(r.get("freq"), 0), 6)
            n = same.get(f, 0)
            same[f] = n + 1
        seen = {}
        for r in shown:
            f = round(fnum(r.get("freq"), 0), 6)
            k = seen.get(f, 0)
            seen[f] = k + 1
            col = fc.get(f, "#1f77b4")
            if same[f] > 1:                              # 같은 주파수 여러 기록 → 예전 것일수록 옅게
                col = mix(col, THEME["plot_bg"], 0.55 * (same[f] - 1 - k) / max(same[f] - 1, 1))
            off, on = self.run_curves(r)
            nm = "%s %.4g GHz" % (r["name"], fnum(r.get("freq"), 0))
            if off:
                ser.append(dict(x=[q["pout"] for q in off], y=[self.yval(q) for q in off], color=col, width=2, dash=(5, 4),
                                marks=True, hollow=True, r=3, label=nm + " OFF"))
            if on:
                ser.append(dict(x=[q["pout"] for q in on], y=[self.yval(q) for q in on], color=col, width=2,
                                marks=True, r=3, label=nm + " DPD"))
        bub = []
        if self.worker and getattr(self, "cur_run", None) and self.cur_run.get("pts"):
            q = self.cur_run["pts"][-1]
            y = self.yval(q)
            unit = "%" if self.v["y_q"].get() in ("evm", "de", "pae") else "dBc"
            bub.append((q["pout"], y, "● 측정 중 %.1f %s" % (y, unit) if unit == "dBc" else "● 측정 중 %.1f %%" % y,
                        "#e53935" if q["kind"] == "off" else "#1e88e5"))
        ylab = {"aclr": "ACLR 나쁜 쪽 (dBc)", "aclr_l": "ACLR L (dBc)", "aclr_u": "ACLR U (dBc)", "evm": "EVM (%)",
                "de": "DE (%)", "pae": "PAE (%)"}[self.v["y_q"].get()]
        self.p_hist.title = ylab.split(" (")[0] + " vs Pout"
        self.p_hist.yl = "%" if self.v["y_q"].get() in ("evm", "de", "pae") else "dBc"
        self.p_hist.set(ser[-24:], bubbles=bub)

    def refresh_hist_list(self):
        if not hasattr(self, "htree"):
            return
        sel = set(self.htree.selection())
        self.htree.delete(*self.htree.get_children())
        for r in reversed(self.load_hist()):
            off, on = self.run_curves(r)
            self.htree.insert("", "end", iid=r["id"], values=("☑" if r.get("on") else "☐", r["name"], "%.4g" % fnum(r.get("freq"), 0),
                                                              len(off) + len(on), r.get("when", "")[2:]))
        for i in sel:
            if self.htree.exists(i):
                self.htree.selection_add(i)

    def hist_run(self, iid):
        return next((r for r in self.load_hist() if r["id"] == iid), None)

    def hist_click(self, e):
        if self.htree.identify_column(e.x) != "#1":
            return
        iid = self.htree.identify_row(e.y)
        r = self.hist_run(iid) if iid else None
        if r is not None:
            r["on"] = not r.get("on")
            self.save_hist()
            self.refresh_hist_list()
            self.draw_hist()
            return "break"

    def hist_show(self, on):
        sel = self.htree.selection()
        for r in self.load_hist():
            if not sel or r["id"] in sel:
                r["on"] = on
        self.save_hist()
        self.refresh_hist_list()
        self.draw_hist()

    def hist_rename(self):
        sel = self.htree.selection()
        r = self.hist_run(sel[0]) if sel else None
        if r is None:
            return
        from tkinter import simpledialog
        nm = simpledialog.askstring(APP, "기록 이름", initialvalue=r["name"], parent=self.root)
        if nm:
            r["name"] = nm.strip()
            self.save_hist()
            self.refresh_hist_list()
            self.draw_hist()

    def hist_delete(self):
        sel = self.htree.selection()
        if not sel:
            return
        if not messagebox.askyesno(APP, "고른 기록 %d개를 지울까요?" % len(sel)):
            return
        self.hist = [r for r in self.load_hist() if r["id"] not in sel]
        self.save_hist()
        self.refresh_hist_list()
        self.draw_hist()

    def hist_export(self):
        """PA Analyzer 가 읽는 엑셀: 기록 × (DPD OFF / DPD ON) 마다 시트 하나 (조건 + 표, ACLR · EVM 열)"""
        sel = self.htree.selection()
        runs = [r for r in self.load_hist() if (r["id"] in sel if sel else r.get("on")) and r.get("pts")]
        if not runs:
            messagebox.showinfo(APP, "내보낼 기록을 고르세요 (고른 게 없으면 표시 중인 기록).")
            return
        try:
            import openpyxl
        except ImportError:
            messagebox.showerror(APP, "openpyxl 이 없습니다.")
            return
        path = self.ask("PA Analyzer 용 엑셀", ".xlsx", [("Excel", "*.xlsx")], "DPD_ACLR_%s.xlsx" % self.stamp())
        if not path:
            return
        wb = openpyxl.Workbook()
        wb.remove(wb.active)
        used = set()
        for r in runs:
            for kind, pts in zip(("OFF", "DPD"), self.run_curves(r)):
                if not pts:
                    continue
                nm = ("%s %s" % (r["name"], kind))[:28]
                for ch in '[]:*?/\\':
                    nm = nm.replace(ch, "_")
                base, k = nm, 2
                while nm in used:
                    nm = "%s(%d)" % (base[:25], k)
                    k += 1
                used.add(nm)
                ws = wb.create_sheet(nm)
                ws.append(["FREQ", "%.6g GHz" % fnum(r.get("freq"), 0)])
                ws.append(["DUT", "%s %s" % (r["name"], "DPD OFF" if kind == "OFF" else "DPD ON")])
                ws.append(["Signal", r.get("sig", "")])
                ws.append(["DPD", r.get("dpd", "") if kind == "DPD" else "OFF"])
                ws.append([])
                ws.append(["SG Pout (dBm)", "DUT_Pout (dBm)", "ACLR (dBc)", "EVM (%)", "Id (mA)", "DC_Power(mW)", "DE(%)", "PAE(%)",
                           "Lower (dBc)", "Upper (dBc)"])

                def rr(v, n):
                    return round(v, n) if isinstance(v, (int, float)) and v is not None and math.isfinite(v) else None
                for q in pts:
                    ws.append([rr(q["sg"], 3), rr(q["pout"], 3), rr(max(q["aclr_l"], q["aclr_u"]), 3), rr(q["evm"], 3),
                               rr((q.get("id") or float("nan")) * 1e3, 2), rr((q.get("pdc") or float("nan")) * 1e3, 1),
                               rr(q.get("de"), 3), rr(q.get("pae"), 3), rr(q["aclr_l"], 3), rr(q["aclr_u"], 3)])
        try:
            wb.save(path)
        except PermissionError:
            messagebox.showerror(APP, "파일이 열려 있어 저장하지 못했습니다:\n%s" % path)
            return
        self.remember_dir(path)
        self.log("PA Analyzer 용 엑셀 저장: %s (시트 %d개) - PA Analyzer 에서 엑셀 불러오기로 열면 됩니다" % (path, len(used)))

    def stop(self):
        """즉시 중지: 장비 통신을 바로 끊고 화면은 바로 '중지됨' (계산 중이던 스레드는 뒤에서 조용히 끝남)"""
        eng = self.engine
        if eng is None or not self.worker:
            return
        self.engine = None                                    # 다음 실행은 새 연결 (신호는 이어 씀)
        self._keep_sig = eng.sig
        threading.Thread(target=lambda: eng.abort(rf_off=True), daemon=True).start()   # 중지 = 안전하게 RF OFF
        self.run_id = getattr(self, "run_id", 0) + 1         # 하트비트 멈춤 · 이전 실행 끝 알림 무시
        BL.set_busy(False)                                     # Bench 가 바로 다시 읽게
        self.worker = None
        self.st_last = ("■ 중지 %s" % time.strftime("%H:%M"), "#c62828")
        self.log("■ 중지")
        self.busy(False)
        self.update_chips()
        if getattr(self, "cur_run", None) is not None:
            if not self.cur_run.get("pts"):
                self.hist = [r for r in self.load_hist() if r is not self.cur_run]
            self.save_hist()
            self.refresh_hist_list()
            self.cur_run = None
        self.draw_hist()
        self.big["aclr"][1].configure(text="■ 중지됨", fg="#90a4ae")

    def rf_off(self):
        if self.engine and not self.worker:
            self.engine.rf_off()
        elif self.engine:
            self.stop()

    def pump(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "log":
                    self.log(val)
                elif kind == "err":
                    self._had_err = True
                    self.log("✖ " + val)
                    messagebox.showerror(APP, val)
                elif kind == "sig":
                    self.lbl_sig.configure(text=val)
                elif kind == "cmp":
                    if val[1] is not None:
                        self.show_compare(*val)
                elif kind == "res":
                    self.add_result(val)
                    self.add_hist_point(val)
                elif kind == "prog":
                    self._last_prog = val
                    v_, sb_, col_ = self.big["aclr"]
                    sb_.configure(text="● " + val, fg="#ffd54f")
                elif kind == "done":
                    if val is not None and val != getattr(self, "run_id", 0):
                        continue                         # 중지한 이전 실행의 끝 알림
                    if val is not None and self.worker is None:
                        continue
                    self.worker = None
                    self.busy(False)
                    self.update_chips()
                    self.take_auto_kml()
                    self.st_last = (("✖ 실패 %s" if getattr(self, "_had_err", False) else "✔ 끝 %s") % time.strftime("%H:%M"),
                                    "#c62828" if getattr(self, "_had_err", False) else "#1565c0")
                    if getattr(self, "cmp_mode", False):
                        self.cmp_mode = False
                        self.hist = [r for r in self.load_hist() if r.get("pts") and any(q["kind"] != "off" for q in r["pts"])
                                     or r not in self.cmp_runs.values()]
                        self.save_hist()
                        self.refresh_hist_list()
                    if getattr(self, "cur_run", None) is not None:
                        if not self.cur_run.get("pts"):
                            self.hist = [r for r in self.load_hist() if r is not self.cur_run]
                        self.save_hist()
                        self.refresh_hist_list()
                        self.cur_run = None
                    self.draw_hist()
                    if self.results:
                        last = self.results[-1]
                        offs = [q for q in self.results if q.get("kind") == "off" and q.get("base_sg") == last.get("base_sg")]
                        off = offs[-1] if offs else self.results[0]
                        txt = "✔ 끝 · %s" % last["label"] if last is off else "✔ 끝 · 같은 SG 의 OFF %.1f / %.1f → %.1f dB 개선" % (
                            off["aclr_l"], off["aclr_u"], max(off["aclr_l"], off["aclr_u"]) - max(last["aclr_l"], last["aclr_u"]))
                        self.big["aclr"][1].configure(text=txt, fg="#90a4ae")
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    # ------------------------------------------------------------ 결과 표시
    def add_result(self, r):
        self.results.append(r)
        f = lambda v, n=2: ("%.*f" % (n, v)) if isinstance(v, (int, float)) and v is not None and math.isfinite(v) else "-"
        idm = r.get("id")
        self.tree.insert("", "end", values=(r["label"], f(r["sg"]), f(r["pin"]), f(r["pout"]), f(r.get("rec_pout")), f(r["gain"]),
                                             f(r["aclr_l"], 1), f(r["aclr_u"], 1), f(r["evm"]),
                                             f(idm * 1e3 if isinstance(idm, float) else None, 1), f(r.get("de"), 1), f(r.get("pae"), 1),
                                             f(r["papr"]),
                                             f(r["nmse"], 1) if r.get("nmse") is not None else "-", r["t"]))
        self.tree.see(self.tree.get_children()[-1])
        last = r
        offs = [q for q in self.results if q.get("kind", "off") == "off" and q.get("base_sg") == r.get("base_sg")]
        off = offs[-1] if offs else self.results[0]          # 같은 SG 레벨의 DPD OFF 와 비교
        is_off = last is off

        def tile(k, big, sub):
            if k not in self.big:                 # 메인에서 뺀 칸 (EVM)
                return
            v, sb, col = self.big[k]
            v.configure(text=big)
            if not (k == "aclr" and self.worker):
                sb.configure(text=sub, fg="#90a4ae")
        tile("aclr", "%.1f / %.1f" % (last["aclr_l"], last["aclr_u"]),
             ("DPD OFF (dBc)" if is_off else "%s · OFF %.1f / %.1f → %.1f dB 개선" % (
                 last["label"], off["aclr_l"], off["aclr_u"], max(off["aclr_l"], off["aclr_u"]) - max(last["aclr_l"], last["aclr_u"])))
             + ("" if last.get("aclr_full", True) else "  ⚠ 일부 대역"))
        tile("evm", "%.2f %%" % last["evm"], ("%s EVM" % ("파형" if last.get("evm_kind") == "파형" else "OFDM"))
             + ("" if is_off else " · OFF %.2f %%" % off["evm"]))
        rp = last.get("rec_pout")
        tile("pout", "%.2f dBm" % last["pout"], "Gain %.2f dB · Pin %.2f dBm%s" % (
            last["gain"], last["pin"], (" · 기록 %.2f" % rp) if isinstance(rp, float) and math.isfinite(rp) else ""))
        de, pae = last.get("de"), last.get("pae")
        ok_ = isinstance(pae, float) and math.isfinite(pae)
        tile("eff", ("%.1f %%" % pae) if ok_ else "---",
             ("DE %.1f %%%s · Id %.3f A%s" % (de, "" if is_off or "papr" not in self.big or not isinstance(off.get("pae"), float) or not math.isfinite(off["pae"])
                                              else " · OFF %.1f %%" % off["pae"], last["id"],
                                              "" if "papr" in self.big else " · PAPR %.2f dB" % last["papr"])) if ok_ else
             "Vdd 전류 없음 - PA Bench Monitor 에서 파워서플라이 연결")
        tile("papr", "%.2f dB" % last["papr"], "SG %.2f dBm%s" % (last["sg"], "" if is_off else " · OFF %.2f dB" % off["papr"]))
        self.root.after_idle(self.fit_big)
        self.lbl_last.configure(text="%s · %s" % (last["label"], last["t"]))
        if isinstance(last.get("cal_db"), float):
            self.v["cal_db"].set("%.2f" % last["cal_db"])
        self.draw()

    def draw(self):
        rs = self.results
        if not rs:
            return
        off, last = rs[0], rs[-1]
        ser = []
        for i, r in enumerate(rs[1:-1]):
            ser.append(dict(x=r["spec_f"], y=r["spec_db"], color=C_ITER[min(i, len(C_ITER) - 1)]))
        ser.append(dict(x=off["spec_f"], y=off["spec_db"], color=C_OFF, width=2, label="DPD OFF"))
        if last is not off:
            ser.append(dict(x=last["spec_f"], y=last["spec_db"], color=C_DPD, width=2, label=last["label"]))
        fmax = max(abs(off["spec_f"][0]), abs(off["spec_f"][-1]))
        cb_, ad_ = off.get("ch_bw", 98.28) / 2, off.get("adj", 100.0)
        fmax = min(fmax, ad_ + cb_ * 2 + 20)                  # 인접 채널 조금 바깥까지만 (넓으면 잘 안 보임)

        def at(r, f0):                                        # 그 주파수의 스펙트럼 높이 (±2 MHz 평균, 마커 위치)
            v = [y for x, y in zip(r["spec_f"], r["spec_db"]) if abs(x - f0) <= 2.0 and math.isfinite(y)]
            return sum(v) / len(v) if v else float("nan")
        # 세로축: 위 +5 dB, 아래 = DPD ON 인접 채널 바닥보다 15 dB 아래 (10 dB 단위, -40 ~ -90)
        fl = [at(r, f0) for r in (off, last) for f0 in (-ad_, ad_)]
        fl = [v for v in fl if math.isfinite(v)]
        lo = max(-90.0, min(-40.0, math.floor((min(fl) - 15) / 10) * 10)) if fl else -90.0
        bub = []
        for f0, side, key in ((-ad_, "l", "aclr_l"), (ad_, "r", "aclr_u")):
            r0 = 0 if side == "l" else 1                       # 오른쪽은 범례 아래부터
            bub.append((f0, at(off, f0), "OFF %.1f dBc" % off[key], C_OFF, side, r0))
            if last is not off:
                bub.append((f0, at(last, f0), "%s %.1f dBc" % (last["label"], last[key]), C_DPD, side, r0 + 1))
        self.p_spec.set(ser, xr=(-fmax, fmax), yr=(lo, 5), bubbles=bub,
                        vlines=[(-ad_ - cb_, "#ef9a9a"), (-cb_, "#90caf9"), (cb_, "#90caf9"), (ad_ + cb_, "#ef9a9a")])
        its = list(range(len(rs)))
        self.p_trend.set([dict(x=its, y=[r["aclr_l"] for r in rs], color="#e53935", width=2, label="ACLR L"),
                          dict(x=its, y=[r["aclr_u"] for r in rs], color="#fb8c00", width=2, label="ACLR U"),
                          dict(x=its, y=[r["aclr_l"] for r in rs], color="#e53935", dots=True, r=3),
                          dict(x=its, y=[r["aclr_u"] for r in rs], color="#fb8c00", dots=True, r=3)],
                         xr=(-0.2, max(its) + 0.2 if max(its) > 0 else 1))
        ser = [dict(x=off["am_x"], y=off["am_g"], color=C_OFF, dots=True, label="DPD OFF")]
        if last is not off:
            ser.append(dict(x=last["am_x"], y=last["am_g"], color=C_DPD, dots=True, label=last["label"]))
        g0 = sorted(off["am_g"])[len(off["am_g"]) // 2] if off["am_g"] else 0
        self.p_amam.set(ser, xr=(-30, 1), yr=(g0 - 4, g0 + 3))
        ser = [dict(x=off["am_x"], y=off["am_p"], color=C_OFF, dots=True, label="DPD OFF")]
        if last is not off:
            ser.append(dict(x=last["am_x"], y=last["am_p"], color=C_DPD, dots=True, label=last["label"]))
        self.p_ampm.set(ser, xr=(-30, 1), yr=(-20, 20))

    # ------------------------------------------------------------ 저장
    def ask(self, title, ext, ft, name):
        return filedialog.asksaveasfilename(title=title, defaultextension=ext, filetypes=ft, initialfile=name,
                                            initialdir=self.s.get("save_dir") or None)

    def remember_dir(self, path):
        if path:
            self.s["save_dir"] = os.path.dirname(path)

    def stamp(self):
        return time.strftime("%Y%m%d_%H%M")

    def save_wv_orig(self):
        if not self.engine or self.engine.sig is None:
            messagebox.showinfo(APP, "먼저 [신호 만들기] 를 누르세요.")
            return
        p = self.ask(".wv 저장", ".wv", [("R&S waveform", "*.wv")], "NR100M_1C_%s.wv" % self.stamp())
        if p:
            E.C.write_wv(p, self.engine.sig.x, self.engine.sig.fs, "NR 100 MHz 1C (PA DPD Tester)")
            self.remember_dir(p)
            self.log("저장: %s" % p)

    def save_wv_dpd(self):
        pd = getattr(self.engine, "last_pd", None) if self.engine else None
        if pd is None:
            messagebox.showinfo(APP, "DPD 를 실행한 뒤에 저장할 수 있습니다.")
            return
        p = self.ask("DPD 신호 .wv 저장", ".wv", [("R&S waveform", "*.wv")], "NR100M_1C_DPD_%s.wv" % self.stamp())
        if p:
            E.C.write_wv(p, pd, self.engine.sig.fs, "NR 100 MHz 1C + DPD (PA DPD Tester)")
            self.remember_dir(p)
            self.log("저장: %s  (SG 레벨은 표의 마지막 SG 값으로)" % p)

    def save_coef(self):
        m = self.engine.model if self.engine else None
        if m is None or m.w is None:
            messagebox.showinfo(APP, "DPD 를 실행한 뒤에 저장할 수 있습니다.")
            return
        p = self.ask("DPD 계수 저장", ".csv", [("CSV", "*.csv")], "DPD_coef_%s.csv" % self.stamp())
        if p and not hasattr(m, "term_names"):            # 신경망: 가중치를 CSV 한 줄씩
            with open(p, "w", encoding="utf-8-sig") as f:
                f.write("# 신경망 DPD (ARVTDNN) M=%d hidden=%d\nname,index,value\n" % (m.M, m.H))
                for k_, a_ in m.w.items():
                    for i_, v_ in enumerate(E.np.ravel(a_)):
                        f.write("%s,%d,%.9e\n" % (k_, i_, v_))
            self.remember_dir(p)
            self.log("저장: %s" % p)
            return
        if p:
            names = m.term_names()
            with open(p, "w", encoding="utf-8-sig") as f:
                f.write("# K=%d M=%d L=%d odd=%s lambda=%g\nterm,re,im\n" % (m.K, m.M, m.L, m.odd, m.lam))
                for nm, c in zip(names, m.w):
                    f.write("%s,%.9e,%.9e\n" % (nm, c.real, c.imag))
            self.remember_dir(p)
            self.log("저장: %s" % p)

    def save_xlsx(self):
        if not self.results:
            messagebox.showinfo(APP, "저장할 결과가 없습니다.")
            return
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
        except ImportError:
            messagebox.showerror(APP, "openpyxl 이 없습니다.")
            return
        path = self.ask("결과 엑셀 저장", ".xlsx", [("Excel", "*.xlsx")], "DPD_%s.xlsx" % self.stamp())
        if not path:
            return
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "결과"
        p = self.params()
        ws.append(["PA DPD Tester %s" % VERSION, time.strftime("%Y-%m-%d %H:%M")])
        ws.append(["신호", "NR 100 MHz 1C · %s · %d 심볼 · ×%d · CFR %s %.1f dB" % (p["mod"], p["n_sym"], p["os"], "ON" if p["cfr_on"] else "OFF", p["papr_db"])])
        ws.append(["DPD", "K=%d M=%d L=%d %s λ=%g μ=%g 반복 %d" % (p["K"], p["M"], p["L"], "홀수만" if p["odd_only"] else "", p["lam"], p["mu"], p["iters"])])
        ws.append(["RF", "%.4f GHz · 입력 손실 %.2f dB · 출력 손실 %.2f dB · 보정 %.2f dB" % (p["freq_ghz"], p["in_loss_db"], p["out_loss_db"], p["cal_db"])])
        ws.append([])
        hd = ["단계", "SG dBm", "Pin dBm", "Pout dBm", "Gain dB", "ACLR L dBc", "ACLR U dBc", "EVM %", "PAPR dB", "학습 NMSE dB", "시각"]
        ws.append(hd)
        for c in ws[ws.max_row]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="1565C0")
            c.alignment = Alignment(horizontal="center")
        for r in self.results:
            ws.append([r["label"], round(r["sg"], 2), round(r["pin"], 2), round(r["pout"], 2), round(r["gain"], 2),
                       round(r["aclr_l"], 2), round(r["aclr_u"], 2), round(r["evm"], 3), round(r["papr"], 2),
                       round(r["nmse"], 2) if r.get("nmse") is not None else None, r["t"]])
        for col, w in zip("ABCDEFGHIJK", (10, 9, 9, 10, 9, 11, 11, 8, 9, 12, 9)):
            ws.column_dimensions[col].width = w
        ws2 = wb.create_sheet("스펙트럼")
        ws2.append(["MHz"] + [r["label"] + " dB" for r in self.results])
        for i, fval in enumerate(self.results[0]["spec_f"]):
            ws2.append([round(fval, 3)] + [round(r["spec_db"][i], 2) if i < len(r["spec_db"]) else None for r in self.results])
        ws3 = wb.create_sheet("AM-AM AM-PM")
        off, last = self.results[0], self.results[-1]
        ws3.append(["OFF 입력 dB", "OFF 이득 dB", "OFF 위상 °", "", last["label"] + " 입력 dB", "이득 dB", "위상 °"])
        for i in range(max(len(off["am_x"]), len(last["am_x"]))):
            a = [off["am_x"][i], off["am_g"][i], off["am_p"][i]] if i < len(off["am_x"]) else [None] * 3
            b = [last["am_x"][i], last["am_g"][i], last["am_p"][i]] if i < len(last["am_x"]) else [None] * 3
            ws3.append([round(v, 3) if v is not None else None for v in a] + [None] + [round(v, 3) if v is not None else None for v in b])
        try:
            self.xlsx_charts(wb, ws, ws2, ws3, len(self.results))
        except Exception as e:                         # 그래프가 안 들어가도 데이터는 저장
            self.log("⚠ 엑셀 그래프 만들기 실패: %s" % e)
        try:
            wb.save(path)
        except PermissionError:
            messagebox.showerror(APP, "파일이 열려 있어 저장하지 못했습니다:\n%s" % path)
            return
        self.remember_dir(path)
        self.log("저장: %s (그래프 포함)" % path)

    def xlsx_charts(self, wb, ws, ws2, ws3, n):
        """엑셀 안에 그래프 (엑셀에서 바로 고칠 수 있는 진짜 차트): 측정 순서별 ACLR · 스펙트럼 · AM-AM · AM-PM · ACLR vs Pout"""
        from openpyxl.chart import ScatterChart, LineChart, Reference, Series
        from openpyxl.chart.marker import Marker

        def style_line(sr, color, width=1.5, dash=None, marker=False):
            sr.graphicalProperties.line.solidFill = color
            sr.graphicalProperties.line.width = int(width * 12700)
            if dash:
                sr.graphicalProperties.line.dashStyle = dash
            sr.marker = Marker(symbol="circle", size=5) if marker else Marker(symbol="none")
            if marker:
                sr.marker.graphicalProperties.solidFill = color
                sr.marker.graphicalProperties.line.solidFill = color
            sr.smooth = False

        def axes(ch, xt, yt, xmin=None, xmax=None, ymin=None, ymax=None):
            ch.x_axis.title, ch.y_axis.title = xt, yt
            for ax, lo, hi in ((ch.x_axis, xmin, xmax), (ch.y_axis, ymin, ymax)):
                if lo is not None:
                    ax.scaling.min = lo
                if hi is not None:
                    ax.scaling.max = hi
                ax.delete = False
            ch.x_axis.crosses = "min"                   # 가로축 글자를 아래에 (값이 모두 음수여도)
            ch.y_axis.crosses = "min"
            ch.legend.position = "b"
            ch.width, ch.height = 22, 11

        hdr_row = 6                                     # 결과 표 머리 줄
        r0, r1 = hdr_row + 1, hdr_row + n
        # 1) 측정 순서별 ACLR (결과 시트)
        lc = LineChart()
        lc.title = "측정 순서별 ACLR"
        for col, color in ((6, "E53935"), (7, "FB8C00")):
            ref = Reference(ws, min_col=col, min_row=hdr_row, max_row=r1)
            lc.add_data(ref, titles_from_data=True)
        lc.set_categories(Reference(ws, min_col=1, min_row=r0, max_row=r1))
        for sr, color in zip(lc.series, ("E53935", "FB8C00")):
            style_line(sr, color, 2, marker=True)
        lc.y_axis.title, lc.x_axis.title = "dBc", "단계"
        lc.x_axis.delete = lc.y_axis.delete = False
        lc.x_axis.crosses = "min"
        lc.legend.position = "b"
        lc.width, lc.height = 22, 10
        ws.add_chart(lc, "M2")
        # 2) 스펙트럼: OFF (회색 굵게) · 중간 (옅은 파랑) · 마지막 (파랑 굵게)
        sc = ScatterChart()
        sc.title = "스펙트럼 (채널 최고 = 0 dB)"
        sc.style = 13
        nr = ws2.max_row
        xref = Reference(ws2, min_col=1, min_row=2, max_row=nr)
        for i in range(n):
            yref = Reference(ws2, min_col=2 + i, min_row=1, max_row=nr)
            sr = Series(yref, xref, title_from_data=True)
            if i == 0:
                style_line(sr, "9E9E9E", 2)
            elif i == n - 1:
                style_line(sr, "1E88E5", 2)
            else:
                style_line(sr, "90CAF9", 0.75)
            sc.series.append(sr)
        lo = min(min(v for v in r["spec_db"] if v == v) for r in self.results)
        axes(sc, "주파수 오프셋 (MHz)", "dB", ymin=max(-100, math.floor(lo / 10) * 10), ymax=5)
        ws2.add_chart(sc, "%s2" % ws2.cell(row=1, column=n + 3).column_letter)
        # 3) AM-AM · AM-PM (점)
        nr3 = ws3.max_row
        for title, yt, ycol_off, ycol_on, anchor in (("AM-AM (작은 신호 이득 = 0)", "이득 dB", 2, 6, "I2"),
                                                     ("AM-PM", "위상 °", 3, 7, "I26")):
            ch = ScatterChart()
            ch.title = title
            ch.style = 13
            for xc, yc, color in ((1, ycol_off, "9E9E9E"), (5, ycol_on, "1E88E5")):
                sr = Series(Reference(ws3, min_col=yc, min_row=1, max_row=nr3), Reference(ws3, min_col=xc, min_row=2, max_row=nr3),
                            title_from_data=True)
                sr.marker = Marker(symbol="circle", size=3)
                sr.marker.graphicalProperties.solidFill = color
                sr.marker.graphicalProperties.line.solidFill = color
                sr.graphicalProperties.line.noFill = True
                ch.series.append(sr)
            axes(ch, "입력 dB (최고값 기준)", yt, xmin=-30, xmax=1)
            ws3.add_chart(ch, anchor)
        # 4) ACLR vs Pout (레벨마다 OFF · DPD 마지막) - 파워 스윕이면 곡선, 한 레벨이면 점 2개
        lv = {}
        for r in self.results:
            k = round(r.get("base_sg") if r.get("base_sg") is not None else r["sg"], 3)
            d = lv.setdefault(k, {})
            if r.get("kind") == "off":
                d["off"] = r
            elif r.get("kind") == "ilc":
                if "on" not in d or max(r["aclr_l"], r["aclr_u"]) < max(d["on"]["aclr_l"], d["on"]["aclr_u"]):
                    d["on"] = r
            else:
                d["on"] = r
        ws4 = wb.create_sheet("ACLR vs Pout")
        ws4.append(["SG 레벨 dBm", "OFF Pout dBm", "OFF ACLR dBc", "DPD Pout dBm", "DPD ACLR dBc", "OFF PAE %", "DPD PAE %"])
        for k in sorted(lv):
            o, d = lv[k].get("off"), lv[k].get("on")
            rr = lambda q, key: (round(max(q["aclr_l"], q["aclr_u"]), 2) if key == "aclr" else
                                 (round(q[key], 2) if isinstance(q.get(key), float) and math.isfinite(q[key]) else None)) if q else None
            ws4.append([k, rr(o, "pout"), rr(o, "aclr"), rr(d, "pout"), rr(d, "aclr"), rr(o, "pae"), rr(d, "pae")])
        m = ws4.max_row
        ch = ScatterChart()
        ch.title = "ACLR (나쁜 쪽) vs Pout"
        ch.style = 13
        for xc, yc, color, dash in ((2, 3, "FB8C00", "dash"), (4, 5, "1E88E5", None)):
            sr = Series(Reference(ws4, min_col=yc, min_row=1, max_row=m), Reference(ws4, min_col=xc, min_row=2, max_row=m),
                        title_from_data=True)
            style_line(sr, color, 2, dash=dash, marker=True)
            ch.series.append(sr)
        axes(ch, "DUT Pout (dBm)", "ACLR (dBc)")
        ws4.add_chart(ch, "I2")
        for col, w in zip("ABCDEFG", (12, 13, 13, 13, 13, 11, 11)):
            ws4.column_dimensions[col].width = w

    def on_close(self):
        if self.worker and self.engine:
            if not messagebox.askyesno(APP, "측정 중입니다. 멈추고 닫을까요?"):
                return
            self.engine.stop = True
        self.save_settings()
        if self.engine:
            self.engine.close()
        self.root.destroy()


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
