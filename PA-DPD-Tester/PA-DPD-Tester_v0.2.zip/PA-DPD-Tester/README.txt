PA DPD Tester v0.2
==================
SMW200A (신호) + FSW (I/Q 받기) 로 PA 샘플에 간단한 DPD 를 걸어 성능 (ACLR · EVM · Pout) 을 비교하는 프로그램.
장비에는 아무것도 설치하지 않음 (LAN, SCPI raw socket 5025 포트). 주소에 demo = 가상 PA 로 확인.

■ v0.2 변경점
  - 화면을 PA Bench Monitor 와 같은 모양으로: 위쪽 줄 (연결 상태 · 장비 설정 · SG RF OFF · 화이트/블랙 · 중지 Esc),
     큰 숫자 4칸 (ACLR · EVM · Pout · PAPR), 번호 카드 (1 신호 · 2 RF · 3 Bench 기록 · 4 DPD · 5 실행), 토글 스위치 · 분할 버튼
  - [ACLR vs Pout] 그래프 (PA Analyzer 처럼): 점선 = DPD OFF · 실선 = DPD ON · 색 = 주파수 고정색, 세로축 ACLR 나쁜 쪽 / L / U / EVM
     오른쪽 [기록] 목록: 실행할 때마다 자동 저장 (이름 · 주파수 · 날짜), 표시 칸 클릭으로 과거 기록과 겹쳐 보기 · 이름 바꾸기 · 삭제
     [PA Analyzer 용 엑셀 내보내기]: 기록 × (OFF / DPD) 마다 시트 (FREQ · DUT + SG · DUT_Pout · ACLR · EVM 열) → PA Analyzer 에서 엑셀 불러오기
  - 파워 스윕: SG 시작 · 끝 · 간격 → 레벨마다 DPD OFF 측정 → DPD 학습 (이전 레벨 계수로 시작해 반복이 줄어듦) → DPD ON 측정
     목표 ACLR (예: -50 dBc) 에 닿으면 그 레벨 반복 끝 · SG 최대 · Pout 멈춤 넘으면 스윕 끝
  - 측정 중 표시: 그래프의 지금 점에 "● 측정 중 -52.9 dBc" 말풍선, ACLR 칸에 "● 측정 중 · DPD 1 · 레벨 5/5 · SG 0.00 dBm"
  - 프로그램 아이콘 (스펙트럼: DPD OFF 어깨 + DPD ON)

■ v0.1.2 변경점
  - build_exe.bat / run_without_build.bat: Python 을 못 찾던 문제 → python · py -3 · 기본 설치 폴더 순서로 찾음
     (Windows "앱 실행 별칭" 의 python.exe (Microsoft Store 바로가기) 때문에 못 찾는 경우도 피함)

■ v0.1.1 변경점
  - 신호: [내 .wv 파일] 선택 가능 (암호화 안 된 R&S .wv, 샘플레이트 = 파일의 CLOCK 그대로 FSW 캡처에도 사용)
     ACLR 채널 대역 · 인접 간격을 직접 입력 (예: NR 100 MHz = 98.28 / 100 MHz) · EVM 은 파형 비교 (보낸 신호 대비 오차)
     암호화된 파일이면 알려 줌 (SMW · WinIQSIM 표준 옵션으로 만든 파일은 암호화돼 있을 수 있음)
  - 케이블 손실: "손실 = PA Bench Monitor 손실 표 사용" → Bench 설정의 주파수별 In / Out 손실 (가까운 주파수 행) 을 그대로
  - ④ PA Bench 기록 → Pout: Bench 샘플 종류의 가장 최근 .pam 기록 (SG 레벨 → DUT Pout) 을 읽어
     · 목표 Pout → [SG 레벨 정하기] (기록 보간, Mod. 기록 우선)
     · DPD OFF 측정 때 Pout 보정을 그 기록 (같은 SG 레벨의 DUT Pout) 에 자동으로 맞춤 · 결과에 기록 Pout 같이 표시
     (Bench 파일은 읽기만 함)

■ 실행
  - EXE 만들기: build_exe.bat 더블클릭 → dist\PA-DPD-Tester_v0.2\PA-DPD-Tester_v0.2.exe
  - 빌드 없이: run_without_build.bat (처음 한 번 python -m pip install numpy openpyxl)

■ 순서
  ① 장비 주소 (SMW200A · FSW IP)
  ② 신호: 5G NR 100 MHz 1 캐리어 (SCS 30 kHz, 273 RB), 변조 · 심볼 수 · 샘플레이트 ×2/×3/×4 · CFR 목표 PAPR
     [신호 만들기] → [.wv 저장] 으로 SMW 에 직접 넣어 쓸 수도 있음 (암호화 없는 R&S .wv)
  ③ RF: 주파수 · SG 레벨 (RMS) · SG 최대 · 입력 손실 · 출력 손실 (감쇠기 포함) · Pout 보정 · FSW Ref Level / 감쇠
  ④ DPD: 메모리 다항식 (L = 0) / GMP (L ≥ 1), 차수 K · 메모리 M · 반복 횟수 · 섞기 μ · 최고값 제한 · 정규화 λ
  ⑤ [DPD OFF 측정만] 또는 [▶ DPD 실행] → DPD OFF 측정 후 반복마다 표 · 그래프 갱신
     결과 엑셀 (결과 · 스펙트럼 · AM-AM/PM) · DPD 신호 .wv · 계수 CSV 저장

■ DPD 방식 (간접 학습 ILA)
  1) 보낸 신호 x(DPD 입력)와 받은 PA 출력 y 를 정렬 (지연 = 크기끼리 상관, 소수 지연, 작은 주파수 차이 · 위상 보정)
  2) y / G (G = 작은 신호 이득) → x 로 가는 postdistorter 를 정규화 최소제곱으로 학습
  3) 그 계수를 DPD 로 써서 예왜곡 신호를 SMW 에 다시 보내고 측정 (반복할 때 새 계수와 μ 비율로 섞음)
  - SMW 는 .wv 의 RMS 를 설정 레벨에 맞추므로, DPD 신호의 RMS 가 달라진 만큼 SG 레벨을 같이 바꿔 같은 크기로 보냄
  - SG 최대를 넘으면 최대로 제한 · 원래 최고값 + [3] dB 를 넘는 샘플은 잘라 냄

■ 측정값
  - Pout = FSW I/Q 평균 전력 (50 Ω, |IQ| = 첨두 전압 기준) + 출력 손실 + 보정 → 처음엔 파워미터로 보정값을 맞추세요
  - ACLR: 채널 / 인접 (±100 MHz) 98.28 MHz 대역 전력 비. 샘플레이트 · FSW 분석 대역폭이 ±149 MHz 를 못 덮으면 ⚠ 표시
  - EVM: 심볼별 FFT → 서브캐리어별 채널 추정 등화 → 보낸 QAM 과 비교 (CFR 로 생긴 EVM 포함)

■ 장비 준비 · 주의
  - SMW 와 FSW 의 10 MHz 기준 클럭을 연결하면 가장 안정적 (작은 주파수 차이는 프로그램이 보정)
  - ×4 (491.52 MSps) 는 FSW 분석 대역폭 약 400 MHz 옵션이 필요. 없으면 ×3 / ×2 (인접 채널 일부만 측정)
  - FSW 에 'DPD IQ' 이름의 I/Q Analyzer 채널을 만들어 씀
  - SG 레벨 · SG 최대는 PA 가 견딜 수 있는 값으로. 끝나면 SG RF OFF (옵션)
  - 2 캐리어 (2C) · 신경망 DPD 는 다음 버전

■ 파일
  pa_dpd_tester.py (화면) · dpd_engine.py (측정 · 반복) · dpd_core.py (신호 · DPD · ACLR/EVM) · instruments.py (SMW · FSW) · bench_link.py (Bench 설정 · 기록 읽기) · demo_pa.py (가상 PA)
