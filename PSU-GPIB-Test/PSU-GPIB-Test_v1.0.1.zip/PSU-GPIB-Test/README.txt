﻿PSU GPIB Test v1.0.1  (전원 연결 확인용 임시 프로그램)
==================================================
Keysight E36155A (드레인 Vdd 48 V) 와 Keysight N6705C (게이트 바이어스, CH1 노랑 · CH2 초록 · CH3 파랑)
가 PC 에서 GPIB 로 잘 읽히는지만 확인하는 프로그램입니다.
※ 기본은 읽기만 합니다 (전압 · 전류 · 출력 상태). 전원 설정이나 출력은 바꾸지 않습니다.
   (5번 'SCPI 직접 보내기' 에 쓰기 명령을 직접 넣을 때만 확인창 후 보냄)

■ v1.0.1 변경점
  - 기본 주소: E36155A (48 V 드레인) = GPIB0::6::INSTR,  N6705C (게이트 바이어스) = GPIB0::5::INSTR
  - 주소 오타 자동 수정: GPIBO(영문 O) → GPIB0, ::INSTR 빠짐 등
  - 화면을 실제 장비 앞면처럼: 회색 베젤 + 검은 화면
     · E36155A: 큰 전압(노랑) · 전류(하늘) 숫자, Set / Limit, OUTPUT ON 표시, 오른쪽 손잡이 · On/Off 모양
     · N6705C : 채널 1 노랑 · 2 초록 · 3 파랑 · 4 빨강 칸 (모듈 이름 · On/Off · 전압 · 전류 · Set · Lim),
                아래 채널별 On/Off 버튼 모양 (켜지면 초록), 안 읽는 채널은 흐리게
     · 위쪽 라벨: 드레인 Vdd / 게이트 바이어스

■ 1. PC 준비 (GPIB)
  1) GPIB 어댑터 드라이버 + VISA 설치 (둘 중 하나)
     · Keysight USB-GPIB (82357B 등)  → Keysight IO Libraries Suite 설치 (VISA 포함)
     · NI GPIB-USB-HS / PCIe-GPIB     → NI-488.2 + NI-VISA 설치
     (이미 다른 프로그램이 GPIB 로 장비를 쓰고 있으면 대부분 설치되어 있음)
  2) 장비마다 GPIB 주소를 서로 다르게 (0~30)
     · E36155A : [Utility] (또는 Menu) → I/O Config → GPIB → Address
     · N6705C  : [Menu] → Utilities → I/O Config → GPIB → Address
     · 예: E36155A = 6, N6705C = 5 (지금 설정)  (같은 버스에 다른 장비가 있으면 그 주소와도 다르게)
  3) Keysight Connection Expert (또는 NI MAX) 에서 두 장비가 보이는지 확인
     → 주소 모양: GPIB0::5::INSTR

■ 2. 실행
  · 빌드 없이: run_without_build.bat (처음 한 번 python -m pip install pyvisa)
  · exe 만들기: build_exe.bat → dist\PSU-GPIB-Test_v1.0.1.exe (exe 도 VISA 설치는 필요)

■ 3. 사용
  1) [장비 찾기] → VISA 주소 목록과 *IDN? 응답 표시 (E36155A / N6705C 가 보이면 성공)
     목록에서 더블클릭하면 아래 주소 칸에 들어감
  2) E36155A / N6705C [연결] → 장비 이름(IDN) 표시, N6705C 는 채널별 모듈 이름(N6781A 등)도 표시
  3) [한 번 읽기] / [▶ 계속 읽기] → 측정 전압 · 측정 전류 · 설정 전압 · 전류 제한 · 출력 ON/OFF
     N6705C 는 체크한 채널만 (기본 1 · 2 · 3 = 노랑 · 초록 · 파랑)
  4) 기록 창에 통신 내용 · 오류 표시
  · LAN 으로 연결한 장비도 같은 방법: TCPIP0::192.168.0.13::inst0::INSTR
  · 장비 없이 화면 확인: 주소에 DEMO::E36155A / DEMO::N6705C

■ 사용하는 SCPI (읽기)
  공통   : *IDN?   SYST:ERR?
  E36155A: MEAS:VOLT?  MEAS:CURR?  VOLT?  CURR?  OUTP?
  N6705C : SYST:CHAN:MOD? (@1:4)  MEAS:VOLT? (@1,2,3)  MEAS:CURR? (@1,2,3)  VOLT? (@..)  CURR? (@..)  OUTP? (@..)

■ 연결이 안 될 때
  · "VISA 라이브러리를 찾지 못했습니다" → IO Libraries Suite / NI-VISA 설치
  · 목록에 장비가 없음 → GPIB 케이블 · 장비 전원 · 장비의 인터페이스 설정(GPIB 켜짐) 확인, Connection Expert 에서 Rescan
  · 응답 없음(timeout) → 주소 번호 확인, 같은 주소를 쓰는 장비가 있는지 확인
  · 연결이 잘 되면 이 설정(주소)으로 PA Bench Monitor 에 넣을 예정
