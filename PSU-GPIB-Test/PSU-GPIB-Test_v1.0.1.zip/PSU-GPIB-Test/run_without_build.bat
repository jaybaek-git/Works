@echo off
cd /d %~dp0
REM First time only:  python -m pip install pyvisa
python psu_gpib_test.py
if errorlevel 1 pause
