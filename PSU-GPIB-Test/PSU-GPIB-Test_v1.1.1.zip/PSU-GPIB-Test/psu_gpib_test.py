# -*- coding: utf-8 -*-
"""
PSU GPIB Test v1.0  -  전원 연결 확인용 임시 프로그램
  · Keysight E36155A  (드레인 Vdd, 48 V)
  · Keysight N6705C   (게이트 바이어스, CH1 노랑 · CH2 초록 · CH3 파랑 · CH4 빨강)

GPIB (USB-GPIB 어댑터) · LAN · USB 모두 VISA 로 연결 (pyvisa + Keysight IO Libraries / NI-VISA).
기본은 '읽기만' - 전원 설정 · 출력은 바꾸지 않음. (아래 'SCPI 직접 보내기' 는 사용자가 직접 보낼 때만)
장비 없이 화면 확인: 주소에 DEMO 입력.
"""
import datetime
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox

APP = "PSU GPIB Test"
VERSION = "v1.1.1"
CH_COLORS = {1: ("#f2c200", "노랑"), 2: ("#2e9e3f", "초록"), 3: ("#1f6fd1", "파랑"), 4: ("#d32f2f", "빨강")}


# ---------------------------------------------------------------- 장비 없이 시험용
class DemoInst:
    def __init__(self, kind):
        self.kind = kind
        self.out = {1: True, 2: True, 3: True, 4: False}
        self.e_out = True
        self.ev, self.ei = 48.0, 3.0
        self.vset = {1: -2.85, 2: -3.10, 3: -5.00, 4: 0.0}
        self.iset = {1: 0.02, 2: 0.02, 3: 0.02, 4: 0.1}

    def query(self, cmd):
        import random
        c = cmd.strip().upper()
        time.sleep(0.01)
        if c == "*IDN?":
            return ("Keysight Technologies,E36155A,MY59000123,1.0.4-1.0.2" if self.kind == "E36155A"
                    else "Keysight Technologies,N6705C,MY56001234,D.03.10.1730")
        if c.startswith("SYST:ERR"):
            return '+0,"No error"'
        if self.kind == "E36155A":
            if c.startswith("MEAS:VOLT"):
                return "%+.6E" % (self.ev + random.uniform(-0.003, 0.003) if self.e_out else 0.0)
            if c.startswith("MEAS:CURR"):
                return "%+.6E" % (0.252 + random.uniform(-0.002, 0.002) if self.e_out else 0.0)
            if c.startswith("VOLT?"):
                return "%+.6E" % self.ev
            if c.startswith("CURR?"):
                return "%+.6E" % self.ei
            if c.startswith("OUTP?"):
                return "1" if self.e_out else "0"
        else:
            chs = [int(x) for x in c.split("(@")[1].rstrip(")").split(",")] if "(@" in c else [1]
            vset, iset = self.vset, self.iset
            if c.startswith("SYST:CHAN:MOD?"):
                return ",".join({1: "N6781A", 2: "N6781A", 3: "N6784A", 4: "N6731B"}[n] for n in chs)
            if c.startswith("SYST:CHAN:COUN?"):
                return "4"
            if c.startswith("MEAS:VOLT"):
                return ",".join("%+.6E" % ((vset[n] + random.uniform(-0.0005, 0.0005)) if self.out[n] else 0.0) for n in chs)
            if c.startswith("MEAS:CURR"):
                return ",".join("%+.6E" % ((-1.2e-6 + random.uniform(-2e-7, 2e-7)) if self.out[n] else 0.0) for n in chs)
            if c.startswith("VOLT?"):
                return ",".join("%+.6E" % vset[n] for n in chs)
            if c.startswith("CURR?"):
                return ",".join("%+.6E" % iset[n] for n in chs)
            if c.startswith("OUTP?"):
                return ",".join("1" if self.out[n] else "0" for n in chs)
        return "0"

    def write(self, cmd):
        c = cmd.strip().upper()
        chs = [int(x) for x in c.split("(@")[1].rstrip(")").split(",")] if "(@" in c else None
        val = c.split()[1].split(",")[0] if " " in c else ""
        if self.kind == "E36155A":
            if c.startswith("OUTP"):
                self.e_out = val in ("ON", "1")
            elif c.startswith("VOLT "):
                self.ev = float(val)
            elif c.startswith("CURR "):
                self.ei = float(val)
        else:
            for n in chs or [1]:
                if c.startswith("OUTP"):
                    self.out[n] = val in ("ON", "1")
                elif c.startswith("VOLT "):
                    self.vset[n] = float(val)
                elif c.startswith("CURR "):
                    self.iset[n] = float(val)

    def close(self):
        pass


# ---------------------------------------------------------------- 다이얼 (마우스 휠로 값 조정)
class Dial(tk.Canvas):
    """손잡이 모양. 휠 위 = 올림, 휠 아래 = 내림 (Shift = 10배). on_turn(+1/-1, 배수) 호출."""

    def __init__(self, parent, bg, size=54, accent="#cfd3d7", on_turn=None):
        super().__init__(parent, width=size, height=size, bg=bg, highlightthickness=0, cursor="hand2")
        self.size, self.accent, self.on_turn, self.angle = size, accent, on_turn, -90.0
        self.enabled = True
        self.bind("<MouseWheel>", lambda e: self.turn(1 if e.delta > 0 else -1, e))
        self.bind("<Button-4>", lambda e: self.turn(1, e))
        self.bind("<Button-5>", lambda e: self.turn(-1, e))
        self.configure(takefocus=1)
        self.bind("<Enter>", lambda e: self.focus_set())              # 마우스를 올리면 방향키도 이 다이얼로
        self.bind("<Up>", lambda e: self.turn(1, e))
        self.bind("<Down>", lambda e: self.turn(-1, e))
        self.bind("<Right>", lambda e: self.turn(1, e))
        self.bind("<Left>", lambda e: self.turn(-1, e))
        self.bind("<FocusIn>", lambda e: self.configure(highlightthickness=1, highlightbackground="white"))
        self.bind("<FocusOut>", lambda e: self.configure(highlightthickness=0))
        self.draw()

    def turn(self, d, e=None):
        mult = 10 if (e is not None and (e.state & 0x0001)) else 1
        if self.on_turn and self.on_turn(d, mult) is not False:
            self.angle += 18 * d
            self.draw()
        return "break"

    def draw(self):
        import math
        self.delete("all")
        s = self.size
        c = s / 2
        r = s / 2 - 3
        self.create_oval(c - r - 1, c - r + 1, c + r + 1, c + r + 3, fill="#1e2226", outline="")   # 그림자
        self.create_oval(c - r, c - r, c + r, c + r, fill="#8e959c" if self.enabled else "#5a5f64",
                         outline="#2b2f33", width=2)
        r2 = r * 0.72
        self.create_oval(c - r2, c - r2, c + r2, c + r2, fill="#b9bfc5" if self.enabled else "#6c7176",
                         outline="#7b8288")
        for k in range(12):          # 홈
            a = math.radians(k * 30)
            self.create_line(c + r * 0.82 * math.cos(a), c + r * 0.82 * math.sin(a),
                             c + r * 0.98 * math.cos(a), c + r * 0.98 * math.sin(a), fill="#5d646b")
        a = math.radians(self.angle)
        self.create_line(c + r2 * 0.25 * math.cos(a), c + r2 * 0.25 * math.sin(a),
                         c + r2 * 0.95 * math.cos(a), c + r2 * 0.95 * math.sin(a),
                         fill=self.accent, width=3, capstyle="round")

    def set_enabled(self, on):
        self.enabled = on
        self.draw()


# ---------------------------------------------------------------- VISA
class Visa:
    def __init__(self):
        self.rm = None
        self.err = ""
        self.backend = ""

    def open_rm(self, lib=""):
        try:
            import pyvisa
        except ImportError:
            self.err = "pyvisa 가 없습니다.  명령 프롬프트에서:  python -m pip install pyvisa"
            return False
        try:
            self.rm = pyvisa.ResourceManager(lib) if lib else pyvisa.ResourceManager()
            self.backend = str(self.rm.visalib)
            return True
        except Exception as e:   # VISA 라이브러리(Keysight IO Libraries / NI-VISA) 없음
            self.err = ("VISA 라이브러리를 찾지 못했습니다: %s\n\n"
                        "Keysight IO Libraries Suite (또는 NI-VISA) 를 설치하세요.\n"
                        "GPIB 어댑터(82357B 등) 드라이버도 함께 설치됩니다." % e)
            self.rm = None
            return False

    def list(self):
        if self.rm is None:
            return []
        try:
            return list(self.rm.list_resources("?*::INSTR"))
        except Exception:
            try:
                return list(self.rm.list_resources())
            except Exception:
                return []

    def open(self, res, timeout_ms=3000):
        if res.strip().upper().startswith("DEMO"):
            return DemoInst("N6705C" if "N67" in res.upper() else "E36155A")
        if self.rm is None:
            raise RuntimeError(self.err or "VISA 없음")
        inst = self.rm.open_resource(res.strip())
        inst.timeout = timeout_ms
        inst.read_termination = "\n"
        inst.write_termination = "\n"
        return inst


def fix_addr(a):
    """흔한 오타 고침: GPIBO(영문 O) → GPIB0, 공백 제거, ::INSTR 빠짐"""
    import re
    a = (a or "").strip().replace(" ", "")
    a = re.sub(r"(?i)^gpib[oO]", "GPIB0", a)
    a = re.sub(r"(?i)^gpib(\d*)::", lambda m: "GPIB%s::" % (m.group(1) or "0"), a)
    if re.match(r"(?i)^gpib\d+::\d+$", a):
        a += "::INSTR"
    return a


def fnum(s):
    try:
        return float(str(s).strip().split(",")[0])
    except ValueError:
        return float("nan")


def flist(s):
    out = []
    for x in str(s).strip().split(","):
        try:
            out.append(float(x))
        except ValueError:
            out.append(float("nan"))
    return out


# ---------------------------------------------------------------- 통신 스레드
class Worker(threading.Thread):
    def __init__(self, app):
        super().__init__(daemon=True)
        self.app = app
        self.tasks = queue.Queue()
        self.alive = True

    def run(self):
        nxt, last_full = 0.0, 0.0
        while self.alive:
            try:
                fn = self.tasks.get(timeout=0.002)
            except queue.Empty:
                fn = None
            try:
                if fn is not None:
                    fn()
                    continue
                a = self.app
                now = time.time()
                if a.polling and now >= nxt:
                    full = now - last_full > 1.0 or a.force_full     # 설정값 · 출력 상태는 1초마다
                    if full:
                        last_full, a.force_full = now, False
                    a.read_job(full=full)
                    nxt = now + a.poll_dt
            except Exception as e:
                self.app.post("log", "오류: %s" % e, "err")


class App:
    def __init__(self, root):
        self.root = root
        root.title("%s %s - E36155A / N6705C 연결 확인" % (APP, VERSION))
        root.geometry("1060x760")
        root.option_add("*Font", ("맑은 고딕", 9))
        self.q = queue.Queue()
        self.visa = Visa()
        self.inst = {"e": None, "n": None}
        self.worker = Worker(self)
        self.worker.start()
        self.polling = False
        self.poll_dt = 1.0
        self.force_full = False
        self.read_chs = [1, 2, 3]
        self.rate_n, self.rate_t = 0, time.time()
        self.sets = {}            # (k, ch) → {"v": 설정 V, "i": 전류 제한, "o": 출력}
        self.pending = {}         # (k, ch) → {"v"/"i": 보낼 값} (휠 돌리는 중)
        self.edit_t = {}          # (k, ch) → 마지막으로 돌린 시각 (그동안 읽은 값으로 덮지 않음)
        self.build()
        self.on_ctrl_toggle()
        root.after(100, self.pump)
        root.after(300, self.init_visa)
        root.protocol("WM_DELETE_WINDOW", self.on_close)

    def post(self, *msg):
        self.q.put(msg)

    # ------------------------------------------------ 화면
    def build(self):
        pad = dict(padx=4, pady=3)
        top = ttk.LabelFrame(self.root, text=" 1. VISA / 장비 찾기 ", padding=6)
        top.pack(fill="x", padx=8, pady=(8, 4))
        self.lbl_visa = ttk.Label(top, text="VISA 확인 중...", foreground="#666")
        self.lbl_visa.grid(row=0, column=0, columnspan=4, sticky="w")
        ttk.Button(top, text="장비 찾기 (주소 목록 + *IDN?)", command=self.scan).grid(row=1, column=0, sticky="w", **pad)
        ttk.Label(top, text="GPIB 주소 예: GPIB0::5::INSTR   LAN 예: TCPIP0::192.168.0.13::inst0::INSTR   장비 없이: DEMO",
                  foreground="#666").grid(row=1, column=1, sticky="w", **pad)
        self.found = ttk.Treeview(top, columns=("r", "i"), show="headings", height=4)
        self.found.heading("r", text="VISA 주소")
        self.found.heading("i", text="*IDN? (더블클릭 = 아래 칸에 넣기)")
        self.found.column("r", width=260)
        self.found.column("i", width=640)
        self.found.grid(row=2, column=0, columnspan=4, sticky="we", pady=(4, 0))
        self.found.bind("<Double-1>", self.pick_found)

        mid = ttk.Frame(self.root)
        mid.pack(fill="x", padx=8, pady=4)
        BEZEL, LCD, DIM = "#41464d", "#0a0f14", "#5a6470"

        # ---- E36155A: 실제 앞면처럼 (회색 베젤 + 검은 화면, 큰 V / A 숫자)
        ew = ttk.Frame(mid)
        ew.pack(side="left", fill="both", expand=True, padx=(0, 4))
        cf = ttk.Frame(ew)
        cf.pack(fill="x")
        ttk.Label(cf, text="E36155A 주소", font=("맑은 고딕", 9, "bold")).pack(side="left")
        self.var_e = tk.StringVar(value="GPIB0::6::INSTR")
        ttk.Entry(cf, textvariable=self.var_e, width=24).pack(side="left", padx=4)
        self.btn_e = ttk.Button(cf, text="연결", command=lambda: self.connect("e"))
        self.btn_e.pack(side="left")
        ep = tk.Frame(ew, bg=BEZEL, bd=3, relief="raised")
        ep.pack(fill="both", expand=True, pady=(4, 0))
        hd = tk.Frame(ep, bg=BEZEL)
        hd.pack(fill="x", padx=8, pady=(6, 2))
        tk.Label(hd, text="E36155A", bg=BEZEL, fg="#e8e8e8", font=("Arial", 11, "bold")).pack(side="left")
        tk.Label(hd, text="  DC Power Supply", bg=BEZEL, fg="#c9cdd2", font=("Arial", 8)).pack(side="left")
        tk.Label(hd, text="드레인 Vdd", bg="#ffb300", fg="black", font=("맑은 고딕", 8, "bold")).pack(side="right")
        body = tk.Frame(ep, bg=BEZEL)
        body.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        scr = tk.Frame(body, bg=LCD, bd=2, relief="sunken")
        scr.pack(side="left", fill="both", expand=True)
        self.e_vals = {}
        self.lbl_e_idn = tk.Label(scr, text="연결 안 됨", bg=LCD, fg=DIM, font=("Consolas", 8), anchor="w")
        self.lbl_e_idn.pack(fill="x", padx=6, pady=(4, 0))
        for k, col, big in (("vm", "#ffd54a", 30), ("im", "#4fc3f7", 30)):
            lb = tk.Label(scr, text="---", bg=LCD, fg=col, font=("Consolas", big, "bold"), anchor="e")
            lb.pack(fill="x", padx=10)
            self.e_vals[k] = lb
        st = tk.Frame(scr, bg=LCD)
        st.pack(fill="x", padx=6, pady=(2, 6))
        for k, t in (("vs", "Set"), ("is", "Limit")):
            tk.Label(st, text=t, bg=LCD, fg=DIM, font=("Consolas", 9)).pack(side="left", padx=(4, 2))
            lb = tk.Label(st, text="---", bg=LCD, fg="#e0e0e0", font=("Consolas", 10))
            lb.pack(side="left", padx=(0, 8))
            self.e_vals[k] = lb
        self.e_vals["o"] = tk.Label(st, text=" OFF ", bg="#333", fg="#999", font=("Consolas", 10, "bold"))
        self.e_vals["o"].pack(side="right", padx=4)
        kp = tk.Frame(body, bg=BEZEL)           # 오른쪽: 출력 On/Off 버튼 + 다이얼 (휠로 조정)
        kp.pack(side="left", fill="y", padx=(10, 0))
        self.e_led = tk.Button(kp, text=" On/Off ", bg="#555", fg="white", font=("Arial", 9, "bold"), bd=2,
                               relief="raised", activebackground="#777", command=lambda: self.toggle_out("e", None))
        self.e_led.pack(pady=(2, 4), fill="x")
        self.var_e_val = tk.StringVar(value="")
        ee = tk.Entry(kp, textvariable=self.var_e_val, width=9, justify="center", font=("Consolas", 12, "bold"),
                      bg="#10161c", fg="#ffd54a", insertbackground="white", relief="sunken")
        ee.pack(pady=(0, 4))
        ee.bind("<Return>", lambda e: self.entry_set("e", None))
        ee.bind("<Up>", lambda e: self.key_turn("e", None, 1, e))
        ee.bind("<Down>", lambda e: self.key_turn("e", None, -1, e))
        self.e_entry = ee
        self.var_e_dmode = tk.StringVar(value="V")
        self.e_dial = Dial(kp, BEZEL, size=60, accent="#ffd54a",
                           on_turn=lambda d, m: self.dial_turn("e", None, d, m))
        self.e_dial.pack()
        mf = tk.Frame(kp, bg=BEZEL)
        mf.pack()
        for t in ("V", "I"):
            tk.Radiobutton(mf, text={"V": "전압", "I": "전류"}[t], value=t, variable=self.var_e_dmode, bg=BEZEL,
                           fg="#e0e0e0", selectcolor="#2b2f33", activebackground=BEZEL, font=("맑은 고딕", 8),
                           command=lambda: self.dial_mode("e", None)).pack(side="left")
        self.lbl_e_step = tk.Label(kp, text="휠 ±0.1 V", bg=BEZEL, fg="#c9cdd2", font=("맑은 고딕", 8))
        self.lbl_e_step.pack()

        # ---- N6705C: 4채널 화면 (채널 색: 1 노랑 · 2 초록 · 3 파랑 · 4 빨강)
        nw = ttk.Frame(mid)
        nw.pack(side="left", fill="both", expand=True, padx=(4, 0))
        cf = ttk.Frame(nw)
        cf.pack(fill="x")
        ttk.Label(cf, text="N6705C 주소", font=("맑은 고딕", 9, "bold")).pack(side="left")
        self.var_n = tk.StringVar(value="GPIB0::5::INSTR")
        ttk.Entry(cf, textvariable=self.var_n, width=24).pack(side="left", padx=4)
        self.btn_n = ttk.Button(cf, text="연결", command=lambda: self.connect("n"))
        self.btn_n.pack(side="left")
        ttk.Label(cf, text="  읽을 채널:").pack(side="left")
        self.ch_on = {}
        for ch in range(1, 5):
            v = tk.BooleanVar(value=ch <= 3)
            self.ch_on[ch] = v
            ttk.Checkbutton(cf, text=str(ch), variable=v, command=self.dim_channels).pack(side="left")
        npnl = tk.Frame(nw, bg=BEZEL, bd=3, relief="raised")
        npnl.pack(fill="both", expand=True, pady=(4, 0))
        hd = tk.Frame(npnl, bg=BEZEL)
        hd.pack(fill="x", padx=8, pady=(6, 2))
        tk.Label(hd, text="N6705C", bg=BEZEL, fg="#e8e8e8", font=("Arial", 11, "bold")).pack(side="left")
        tk.Label(hd, text="  DC Power Analyzer", bg=BEZEL, fg="#c9cdd2", font=("Arial", 8)).pack(side="left")
        tk.Label(hd, text="게이트 바이어스", bg="#7e57c2", fg="white", font=("맑은 고딕", 8, "bold")).pack(side="right")
        scr = tk.Frame(npnl, bg=LCD, bd=2, relief="sunken")
        scr.pack(fill="both", expand=True, padx=8)
        self.lbl_n_idn = tk.Label(scr, text="연결 안 됨", bg=LCD, fg=DIM, font=("Consolas", 8), anchor="w")
        self.lbl_n_idn.grid(row=0, column=0, columnspan=4, sticky="we", padx=6, pady=(4, 2))
        self.n_vals = {}
        self.n_cells = {}
        for ch in range(1, 5):
            col, name = CH_COLORS[ch]
            scr.columnconfigure(ch - 1, weight=1, uniform="ch")
            cell = tk.Frame(scr, bg=LCD, highlightthickness=2, highlightbackground=col)
            cell.grid(row=1, column=ch - 1, sticky="nsew", padx=3, pady=(0, 6))
            top = tk.Frame(cell, bg=col)
            top.pack(fill="x")
            tk.Label(top, text=" %d " % ch, bg=col, fg="black" if ch == 1 else "white",
                     font=("Arial", 12, "bold")).pack(side="left")
            row = {"mod": tk.Label(top, text="---", bg=col, fg="black" if ch == 1 else "white", font=("Arial", 8))}
            row["mod"].pack(side="left")
            row["o"] = tk.Label(top, text="Off", bg=col, fg="black" if ch == 1 else "white", font=("Arial", 8, "bold"))
            row["o"].pack(side="right", padx=3)
            row["vm"] = tk.Label(cell, text="---", bg=LCD, fg=col, font=("Consolas", 15, "bold"), anchor="e")
            row["vm"].pack(fill="x", padx=4, pady=(4, 0))
            row["im"] = tk.Label(cell, text="---", bg=LCD, fg="#e0e0e0", font=("Consolas", 12, "bold"), anchor="e")
            row["im"].pack(fill="x", padx=4)
            row["vs"] = tk.Label(cell, text="Set ---", bg=LCD, fg=DIM, font=("Consolas", 8), anchor="e")
            row["vs"].pack(fill="x", padx=4)
            row["is"] = tk.Label(cell, text="Lim ---", bg=LCD, fg=DIM, font=("Consolas", 8), anchor="e")
            row["is"].pack(fill="x", padx=4, pady=(0, 4))
            self.n_vals[ch] = row
            self.n_cells[ch] = cell
        keys = tk.Frame(npnl, bg=BEZEL)       # 채널 On/Off 버튼 + 다이얼 (휠로 조정)
        keys.pack(fill="x", padx=8, pady=(4, 8))
        self.n_leds, self.n_dials, self.var_n_dmode, self.lbl_n_step = {}, {}, {}, {}
        for ch in range(1, 5):
            col, _ = CH_COLORS[ch]
            keys.columnconfigure(ch - 1, weight=1)
            led = tk.Button(keys, text="%d  On/Off" % ch, bg="#555", fg="white", font=("Arial", 8, "bold"),
                            bd=2, relief="raised", highlightthickness=2, highlightbackground=col,
                            activebackground="#777", command=lambda c=ch: self.toggle_out("n", c))
            led.grid(row=0, column=ch - 1, padx=6, sticky="we")
            self.n_leds[ch] = led
            vv = tk.StringVar(value="")
            ne = tk.Entry(keys, textvariable=vv, width=9, justify="center", font=("Consolas", 11, "bold"),
                          bg="#10161c", fg=col, insertbackground="white", relief="sunken")
            ne.grid(row=1, column=ch - 1, pady=(4, 0))
            ne.bind("<Return>", lambda e, c=ch: self.entry_set("n", c))
            ne.bind("<Up>", lambda e, c=ch: self.key_turn("n", c, 1, e))
            ne.bind("<Down>", lambda e, c=ch: self.key_turn("n", c, -1, e))
            self.n_entry_var = getattr(self, "n_entry_var", {})
            self.n_entry = getattr(self, "n_entry", {})
            self.n_entry_var[ch], self.n_entry[ch] = vv, ne
            dl = Dial(keys, BEZEL, size=46, accent=col, on_turn=lambda d, m, c=ch: self.dial_turn("n", c, d, m))
            dl.grid(row=2, column=ch - 1, pady=(4, 0))
            self.n_dials[ch] = dl
            v = tk.StringVar(value="V")
            self.var_n_dmode[ch] = v
            mf = tk.Frame(keys, bg=BEZEL)
            mf.grid(row=3, column=ch - 1)
            for t in ("V", "I"):
                tk.Radiobutton(mf, text={"V": "전압", "I": "전류"}[t], value=t, variable=v, bg=BEZEL, fg="#e0e0e0",
                               selectcolor="#2b2f33", activebackground=BEZEL, font=("맑은 고딕", 8),
                               command=lambda c=ch: self.dial_mode("n", c)).pack(side="left")
            lb = tk.Label(keys, text="휠 ±0.001 V", bg=BEZEL, fg="#c9cdd2", font=("맑은 고딕", 8))
            lb.grid(row=4, column=ch - 1)
            self.lbl_n_step[ch] = lb
        self.dim_channels()

        # 읽기 / 직접 보내기
        cf = ttk.LabelFrame(self.root, text=" 제어 (출력 On/Off · 다이얼) - 잠금을 풀어야 동작 ", padding=6)
        cf.pack(fill="x", padx=8, pady=(4, 0))
        self.var_ctrl = tk.BooleanVar(value=False)
        self.chk_ctrl = tk.Checkbutton(cf, text="🔓 제어 사용 (잠금 해제)", variable=self.var_ctrl, command=self.on_ctrl_toggle,
                                       font=("맑은 고딕", 10, "bold"), fg="#c62828")
        self.chk_ctrl.pack(side="left")
        self.lim = {}
        for key, lab, val in (("vdd_max", "Vdd 최대 V", "50"), ("vdd_imax", "Vdd 전류제한 최대 A", "10"),
                              ("g_min", "게이트 최소 V", "-8"), ("g_max", "게이트 최대 V", "0"),
                              ("g_imax", "게이트 전류제한 최대 A", "0.1")):
            ttk.Label(cf, text="  " + lab).pack(side="left")
            v = tk.StringVar(value=val)
            ttk.Entry(cf, textvariable=v, width=5).pack(side="left")
            self.lim[key] = v
        self.var_seq = tk.BooleanVar(value=True)
        ttk.Checkbutton(cf, text="  순서 경고 (게이트 먼저 ON · Vdd 먼저 OFF)", variable=self.var_seq).pack(side="left")
        ttk.Label(self.root, text="   다이얼: 마우스를 올리고 휠 위 = 올림, 아래 = 내림 (Shift + 휠 = 10배).  "
                                  "게이트 0.001 V · 0.001 A,  Vdd 0.1 V · 0.1 A 단위.  [전압]/[전류] 로 조정할 값 선택.",
                  foreground="#666").pack(anchor="w", padx=8)
        bf = ttk.LabelFrame(self.root, text=" 4. 읽기 ", padding=6)
        bf.pack(fill="x", padx=8, pady=4)
        ttk.Button(bf, text="한 번 읽기", command=self.read_once).pack(side="left", padx=4)
        self.btn_poll = ttk.Button(bf, text="▶ 계속 읽기", command=self.toggle_poll)
        self.btn_poll.pack(side="left", padx=4)
        ttk.Label(bf, text="간격(초, 최소 0.01)").pack(side="left", padx=(10, 2))
        self.var_dt = tk.StringVar(value="0.1")
        ttk.Entry(bf, textvariable=self.var_dt, width=5).pack(side="left")
        self.var_dt.trace_add("write", self.update_dt)
        self.lbl_rate = ttk.Label(bf, text="", foreground="#1f4f8f")
        self.lbl_rate.pack(side="left", padx=10)
        ttk.Label(bf, text="(측정값은 매번, 설정값 · 출력 상태는 1초마다 읽음)", foreground="#666").pack(side="left")
        ttk.Label(bf, text="   타임아웃(ms)").pack(side="left", padx=(10, 2))
        self.var_to = tk.StringVar(value="3000")
        ttk.Entry(bf, textvariable=self.var_to, width=6).pack(side="left")

        sf = ttk.LabelFrame(self.root, text=" 5. SCPI 직접 보내기 (주의: 쓰기 명령은 전원 설정을 바꿈) ", padding=6)
        sf.pack(fill="x", padx=8, pady=4)
        self.var_tgt = tk.StringVar(value="N6705C")
        ttk.Combobox(sf, textvariable=self.var_tgt, values=["E36155A", "N6705C"], state="readonly", width=9).pack(side="left")
        self.var_cmd = tk.StringVar(value="MEAS:VOLT? (@1,2,3)")
        e = ttk.Entry(sf, textvariable=self.var_cmd, width=50)
        e.pack(side="left", padx=4)
        e.bind("<Return>", lambda ev: self.send_cmd())
        ttk.Button(sf, text="보내기", command=self.send_cmd).pack(side="left", padx=4)
        ttk.Label(sf, text="'?' 로 끝나면 응답을 읽음", foreground="#666").pack(side="left", padx=6)

        lf = ttk.LabelFrame(self.root, text=" 기록 ", padding=4)
        lf.pack(fill="both", expand=True, padx=8, pady=(4, 8))
        self.log = tk.Text(lf, height=10, font=("Consolas", 9))
        self.log.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(lf, command=self.log.yview)
        sb.pack(side="right", fill="y")
        self.log.configure(yscrollcommand=sb.set)
        self.log.tag_configure("err", foreground="#c62828")
        self.log.tag_configure("ok", foreground="#2e7d32")

    # ------------------------------------------------ 동작
    def init_visa(self):
        def job():
            ok = self.visa.open_rm()
            self.post("visa", ok, self.visa.backend if ok else self.visa.err)
        self.worker.tasks.put(job)

    def scan(self):
        def job():
            if self.visa.rm is None and not self.visa.open_rm():
                self.post("log", self.visa.err, "err")
                self.post("found", [("DEMO::E36155A", "(장비 없이 시험)"), ("DEMO::N6705C", "(장비 없이 시험)")])
                return
            res = self.visa.list()
            self.post("log", "찾은 주소 %d개: %s" % (len(res), ", ".join(res) or "없음"), "ok" if res else "err")
            out = []
            for r in res:
                if r.upper().startswith("ASRL"):          # COM 포트는 건너뜀 (응답 없이 오래 걸림)
                    out.append((r, "(시리얼 포트 - 건너뜀)"))
                    continue
                try:
                    inst = self.visa.open(r, 1500)
                    idn = inst.query("*IDN?").strip()
                    inst.close()
                except Exception as e:
                    idn = "응답 없음 (%s)" % str(e)[:60]
                out.append((r, idn))
            out += [("DEMO::E36155A", "(장비 없이 시험)"), ("DEMO::N6705C", "(장비 없이 시험)")]
            self.post("found", out)
        self.post("log", "장비 찾는 중... (GPIB 는 몇 초 걸릴 수 있음)")
        self.worker.tasks.put(job)

    def pick_found(self, event=None):
        it = self.found.focus()
        if not it:
            return
        r, idn = self.found.item(it, "values")
        if "N67" in idn.upper() or "N67" in r.upper():
            self.var_n.set(r)
        elif "E361" in idn.upper() or "E361" in r.upper():
            self.var_e.set(r)
        else:
            self.var_n.set(r) if messagebox.askyesno(APP, "%s\n\nN6705C 칸에 넣을까요? (아니요 = E36155A 칸)" % idn) \
                else self.var_e.set(r)

    def connect(self, k):
        if self.inst[k] is not None:
            def job_close():
                try:
                    self.inst[k].close()
                except Exception:
                    pass
                self.inst[k] = None
                self.post("conn", k, False, "")
            self.worker.tasks.put(job_close)
            return
        var = self.var_e if k == "e" else self.var_n
        res = fix_addr(var.get())
        if res != var.get().strip():
            var.set(res)
            self.post("log", "주소 자동 수정: %s" % res)
        to = int(fnum(self.var_to.get()) or 3000)

        def job():
            try:
                inst = self.visa.open(res, to)
                idn = inst.query("*IDN?").strip()
            except Exception as e:
                self.post("log", "%s 연결 실패 (%s): %s" % ("E36155A" if k == "e" else "N6705C", res, e), "err")
                self.post("conn", k, False, "연결 실패: %s" % str(e)[:120])
                return
            self.inst[k] = inst
            want = "E361" if k == "e" else "N67"
            warn = "" if want in idn.upper() else "   ※ 예상한 장비가 아님 - 주소 확인"
            self.post("conn", k, True, idn + warn)
            self.post("log", "%s 연결: %s → %s" % ("E36155A" if k == "e" else "N6705C", res, idn), "ok")
            if k == "n":
                try:
                    mods = inst.query("SYST:CHAN:MOD? (@1:4)").strip()
                except Exception:
                    try:
                        mods = ",".join(inst.query("SYST:CHAN:MOD? (@%d)" % c).strip() for c in range(1, 5))
                    except Exception as e:
                        mods = ""
                        self.post("log", "N6705C 모듈 읽기 실패: %s" % e, "err")
                self.post("mods", [m.strip().strip('"') for m in mods.split(",")] if mods else [])
            self.read_job()
        self.post("log", "연결 중... %s" % res)
        self.worker.tasks.put(job)

    # ------------------------------------------------ 제어 (출력 / 다이얼)
    def on_ctrl_toggle(self):
        on = self.var_ctrl.get()
        self.chk_ctrl.configure(text=("🔓 제어 사용 중 (체크 해제 = 잠금)" if on else "🔒 제어 잠금 (체크하면 출력 · 다이얼 사용)"),
                                fg="#c62828" if on else "#555")
        for d in [self.e_dial] + list(self.n_dials.values()):
            d.set_enabled(on)

    def store_set(self, key, v):
        o = v["o"] in ("1", "ON")
        cur = self.sets.setdefault(key, {})
        cur["o"] = o
        if time.time() - self.edit_t.get(key, 0) > 1.5 and not self.pending.get(key):
            cur["v"], cur["i"] = v["vs"], v["is_"]

    def lim_val(self, k):
        return fnum(self.lim[k].get())

    def step_of(self, k, mode):
        return 0.1 if k == "e" else 0.001        # Vdd 0.1 V/A, 게이트 0.001 V/A

    def dial_mode(self, k, ch):
        mode = (self.var_e_dmode if k == "e" else self.var_n_dmode[ch]).get()
        st = self.step_of(k, mode)
        txt = "휠 ±%g %s" % (st, "V" if mode == "V" else "A")
        (self.lbl_e_step if k == "e" else self.lbl_n_step[ch]).configure(text=txt)
        self.refresh_entry(k, ch, force=True)

    def dial_turn(self, k, ch, d, mult):
        if not self.var_ctrl.get():
            self.post("log", "제어가 잠겨 있습니다 - 아래 '🔒 제어 잠금' 을 체크하세요.", "err")
            return False
        if self.inst[k] is None:
            self.post("log", "%s 가 연결되지 않았습니다." % ("E36155A" if k == "e" else "N6705C"), "err")
            return False
        key = (k, ch)
        cur = self.sets.get(key)
        mode = (self.var_e_dmode if k == "e" else self.var_n_dmode[ch]).get()
        fld = "v" if mode == "V" else "i"
        if not cur or cur.get(fld) is None or cur[fld] != cur[fld]:
            self.post("log", "먼저 [한 번 읽기] 로 지금 설정값을 읽으세요.", "err")
            return False
        st = self.step_of(k, mode) * mult
        nd = 1 if k == "e" else 3
        new = round(cur[fld] + d * st, nd)
        # 안전 한계
        if k == "e":
            lo, hi = (0.0, self.lim_val("vdd_max")) if fld == "v" else (0.0, self.lim_val("vdd_imax"))
        else:
            lo, hi = (self.lim_val("g_min"), self.lim_val("g_max")) if fld == "v" else (0.0, self.lim_val("g_imax"))
        if lo == lo and new < lo - 1e-9 or hi == hi and new > hi + 1e-9:
            self.post("log", "안전 한계 %s ~ %s 밖이라 멈춤 (%s %+.*f)" % (lo, hi, "전압" if fld == "v" else "전류", nd, new), "err")
            return False
        cur[fld] = new
        self.edit_t[key] = time.time()
        self.pending.setdefault(key, {})[fld] = new
        self.show_set(k, ch)
        if not getattr(self, "_flush_job", None):
            self._flush_job = self.root.after(150, self.flush)   # 휠을 빠르게 돌려도 마지막 값만 보냄
        return True

    def mode_of(self, k, ch):
        return (self.var_e_dmode if k == "e" else self.var_n_dmode[ch]).get()

    def refresh_entry(self, k, ch, force=False):
        """On/Off 아래 칸: 지금 조정 중인 값 (전압 또는 전류 제한)"""
        ent = self.e_entry if k == "e" else self.n_entry[ch]
        var = self.var_e_val if k == "e" else self.n_entry_var[ch]
        if not force and self.root.focus_get() is ent:
            return                      # 직접 입력 중이면 덮지 않음
        cur = self.sets.get((k, ch), {})
        fld = "v" if self.mode_of(k, ch) == "V" else "i"
        val = cur.get(fld)
        if val is None or val != val:
            var.set("")
            return
        nd = 1 if k == "e" else 3
        var.set(("%.*f %s" % (nd, val, "V" if fld == "v" else "A")))

    def key_turn(self, k, ch, d, e):
        self.dial_turn(k, ch, d, 10 if (e.state & 0x0001) else 1)
        self.refresh_entry(k, ch, force=True)
        return "break"

    def entry_set(self, k, ch):
        """칸에 값을 직접 쓰고 Enter → 그 값으로 (안전 한계 확인)"""
        var = self.var_e_val if k == "e" else self.n_entry_var[ch]
        txt = var.get().replace("V", "").replace("A", "").replace("v", "").replace("a", "").strip()
        try:
            val = float(txt)
        except ValueError:
            self.post("log", "숫자를 입력하세요: %s" % var.get(), "err")
            self.refresh_entry(k, ch, force=True)
            return
        cur = self.sets.get((k, ch))
        fld = "v" if self.mode_of(k, ch) == "V" else "i"
        if not cur or cur.get(fld) is None:
            self.post("log", "먼저 [한 번 읽기] 로 지금 설정값을 읽으세요.", "err")
            return
        st = self.step_of(k, self.mode_of(k, ch))
        d = round((val - cur[fld]) / st)
        if d == 0:
            self.refresh_entry(k, ch, force=True)
            return
        big = abs(val - cur[fld]) > (2.0 if k == "e" else 0.2) and fld == "v"
        if big and not messagebox.askyesno(APP, "%s 을(를) %.3f → %.3f 로 한 번에 바꿀까요?" % (
                "Vdd" if k == "e" else "게이트 CH%d" % ch, cur[fld], val)):
            self.refresh_entry(k, ch, force=True)
            return
        if self.dial_turn(k, ch, 1 if d > 0 else -1, abs(d)) is not False:
            (self.e_dial if k == "e" else self.n_dials[ch]).focus_set()
            self.refresh_entry(k, ch, force=True)

    def show_set(self, k, ch):
        self.refresh_entry(k, ch, force=True)
        cur = self.sets.get((k, ch), {})
        if k == "e":
            self.e_vals["vs"].configure(text="%.3f V" % cur.get("v", float("nan")), fg="#ffd54a")
            self.e_vals["is"].configure(text=self.fmt_a(cur.get("i", float("nan"))), fg="#ffd54a")
        else:
            row = self.n_vals[ch]
            row["vs"].configure(text="Set %+.3f V" % cur.get("v", float("nan")), fg=CH_COLORS[ch][0])
            row["is"].configure(text="Lim %s" % self.fmt_a(cur.get("i", float("nan"))), fg=CH_COLORS[ch][0])

    def flush(self):
        self._flush_job = None
        items = [(key, dict(p)) for key, p in self.pending.items() if p]
        self.pending.clear()
        if not items:
            return

        def job():
            for (k, ch), p in items:
                inst = self.inst[k]
                if inst is None:
                    continue
                sfx = "" if k == "e" else ",(@%d)" % ch
                for fld, val in p.items():
                    cmd = "%s %.*f%s" % ("VOLT" if fld == "v" else "CURR", 1 if k == "e" else 3, val, sfx)
                    inst.write(cmd)
                    err = inst.query("SYST:ERR?").strip()
                    ok = err.startswith(("+0", "0"))
                    self.post("log", "%s ← %s%s" % ("E36155A" if k == "e" else "N6705C CH%d" % ch, cmd,
                                                    "" if ok else "   ✖ 오류: " + err), "ok" if ok else "err")
            self.read_job()
        self.worker.tasks.put(job)

    def toggle_out(self, k, ch, _retry=False):
        name0 = "E36155A" if k == "e" else "N6705C CH%d" % ch
        self.post("log", "%s On/Off 버튼 누름" % name0)
        if not self.var_ctrl.get():
            if not messagebox.askyesno(APP, "제어가 잠겨 있습니다 (🔒).\n\n잠금을 풀고 계속할까요?"):
                return
            self.var_ctrl.set(True)
            self.on_ctrl_toggle()
        inst = self.inst[k]
        if inst is None:
            messagebox.showwarning(APP, "%s 가 연결되지 않았습니다. 먼저 [연결] 하세요." % ("E36155A" if k == "e" else "N6705C"))
            return
        if k == "n" and ch not in self.read_chs:
            self.ch_on[ch].set(True)
            self.dim_channels()
        cur = self.sets.get((k, ch))
        if not cur or "o" not in cur:
            if _retry:
                messagebox.showwarning(APP, "%s 의 지금 출력 상태를 읽지 못했습니다. 기록 창의 오류를 확인하세요." % name0)
                return

            def job():
                self.read_job(full=True)
                self.post("call", lambda: self.toggle_out(k, ch, _retry=True))
            self.worker.tasks.put(job)      # 지금 상태를 먼저 읽고 다시
            return
        turn_on = not cur.get("o")
        name = "Vdd (E36155A)" if k == "e" else "게이트 CH%d (N6705C %s)" % (ch, CH_COLORS[ch][1])
        msg = "%s 출력을 %s 할까요?\n\n설정: %+.3f V,  전류 제한 %s" % (name, "ON" if turn_on else "OFF",
                                                              cur.get("v", float("nan")), self.fmt_a(cur.get("i", float("nan"))))
        if self.var_seq.get():
            gates = [c for c in range(1, 5) if self.ch_on[c].get()]
            g_off = [c for c in gates if not self.sets.get(("n", c), {}).get("o")]
            vdd_on = self.sets.get(("e", None), {}).get("o")
            if k == "e" and turn_on and (self.inst["n"] is None or g_off):
                msg += "\n\n⚠ 게이트 바이어스가 아직 OFF 인 채널이 있습니다: %s\n   GaN 은 게이트(음전압)를 먼저 켜고 Vdd 를 켜야 합니다!" % (
                    ", ".join("CH%d" % c for c in g_off) or "N6705C 연결 안 됨")
            if k == "n" and not turn_on and vdd_on:
                msg += "\n\n⚠ Vdd 가 켜져 있습니다! 게이트를 먼저 끄면 소자가 손상될 수 있습니다.\n   Vdd 를 먼저 끄세요."
            if k == "n" and turn_on and cur.get("v", 0) > 0:
                msg += "\n\n⚠ 게이트 설정 전압이 양수(%+.3f V)입니다." % cur["v"]
        warn = "⚠" in msg
        if not (messagebox.askokcancel if not warn else messagebox.askyesno)(APP, msg + ("\n\n그래도 진행할까요?" if warn else "")):
            return
        cmd = "OUTP %s%s" % ("ON" if turn_on else "OFF", "" if k == "e" else ",(@%d)" % ch)

        def job():
            inst.write(cmd)
            err = inst.query("SYST:ERR?").strip()
            ok = err.startswith(("+0", "0"))
            self.post("log", "%s ← %s%s" % (name, cmd, "" if ok else "   ✖ 오류: " + err), "ok" if ok else "err")
            time.sleep(0.05)
            q = "OUTP?" if k == "e" else "OUTP? (@%d)" % ch
            st = inst.query(q).strip()
            now_on = st.split(",")[0].strip() in ("1", "ON")
            if now_on != turn_on:
                hint = ""
                try:
                    if k == "n":
                        cond = inst.query("STAT:QUES:COND? (@%d)" % ch).strip()
                        hint = " (보호/인히빗 상태 코드 %s - 장비 화면 확인, 보호 해제 OUTP:PROT:CLE (@%d))" % (cond, ch)
                    else:
                        cond = inst.query("STAT:QUES:COND?").strip()
                        hint = " (상태 코드 %s - 장비 화면의 보호(OVP/OCP) · 인히빗 확인)" % cond
                except Exception:
                    pass
                self.post("log", "✖ %s 출력이 바뀌지 않음: 지금 %s%s" % (name, "ON" if now_on else "OFF", hint), "err")
            else:
                self.post("log", "✔ %s 출력 %s 확인" % (name, "ON" if now_on else "OFF"), "ok")
            self.read_job(full=True)
        self.worker.tasks.put(job)

    def dim_channels(self):
        """체크 안 한 채널은 흐리게"""
        self.read_chs = [c for c in range(1, 5) if self.ch_on[c].get()]
        self.force_full = True
        if not hasattr(self, "n_cells"):
            return
        for ch, cell in self.n_cells.items():
            on = self.ch_on[ch].get()
            col = CH_COLORS[ch][0] if on else "#333"
            cell.configure(highlightbackground=col)
            for k in ("vm", "im"):
                self.n_vals[ch][k].configure(fg=(CH_COLORS[ch][0] if k == "vm" else "#e0e0e0") if on else "#444")

    def read_job(self, full=True):
        """full=False: 측정 전압 · 전류만 (빠르게), full=True: 설정값 · 출력 상태까지"""
        e = self.inst["e"]
        if e is not None:
            try:
                vals = dict(vm=fnum(e.query("MEAS:VOLT?")), im=fnum(e.query("MEAS:CURR?")))
                if full:
                    vals.update(vs=fnum(e.query("VOLT?")), is_=fnum(e.query("CURR?")), o=e.query("OUTP?").strip())
                self.post("e", vals)
            except Exception as ex:
                self.post("log", "E36155A 읽기 오류: %s" % ex, "err")
        n = self.inst["n"]
        chs = list(self.read_chs)
        if n is not None and chs:
            lst = "(@%s)" % ",".join(str(c) for c in chs)
            try:
                vm = flist(n.query("MEAS:VOLT? " + lst))
                im = flist(n.query("MEAS:CURR? " + lst))
                out = {c: dict(vm=vm[i], im=im[i]) for i, c in enumerate(chs)}
                if full:
                    vs = flist(n.query("VOLT? " + lst))
                    is_ = flist(n.query("CURR? " + lst))
                    o = n.query("OUTP? " + lst).strip().split(",")
                    for i, c in enumerate(chs):
                        out[c].update(vs=vs[i], is_=is_[i], o=o[i].strip() if i < len(o) else "?")
                self.post("n", out)
            except Exception as ex:
                self.post("log", "N6705C 읽기 오류: %s" % ex, "err")
        self.post("tick")

    def read_once(self):
        if self.inst["e"] is None and self.inst["n"] is None:
            self.post("log", "먼저 [연결] 하세요.", "err")
            return
        self.worker.tasks.put(self.read_job)

    def toggle_poll(self):
        self.update_dt()
        self.force_full = True
        self.polling = not self.polling
        self.btn_poll.configure(text="■ 계속 읽기 중지" if self.polling else "▶ 계속 읽기")
        self.rate_n, self.rate_t = 0, time.time()

    def update_dt(self, *a):
        v = fnum(self.var_dt.get())
        self.poll_dt = max(0.01, v) if v == v else 1.0     # 최소 0.01 초 (실제 속도는 장비 응답 속도까지)

    def send_cmd(self):
        k = "e" if self.var_tgt.get() == "E36155A" else "n"
        cmd = self.var_cmd.get().strip()
        if not cmd:
            return
        inst = self.inst[k]
        if inst is None:
            self.post("log", "%s 가 연결되지 않았습니다." % self.var_tgt.get(), "err")
            return
        if not cmd.endswith("?") and not cmd.upper().startswith(("*CLS", "SYST:ERR")):
            if not messagebox.askyesno(APP, "쓰기 명령입니다 (전원 설정이 바뀔 수 있음):\n\n%s → %s\n\n보낼까요?"
                                       % (cmd, self.var_tgt.get())):
                return

        def job():
            if cmd.endswith("?") or "?" in cmd.split()[0]:
                r = inst.query(cmd).strip()
                self.post("log", "%s ← %s : %s" % (self.var_tgt.get(), cmd, r), "ok")
            else:
                inst.write(cmd)
                err = inst.query("SYST:ERR?").strip()
                self.post("log", "%s ← %s  (SYST:ERR? %s)" % (self.var_tgt.get(), cmd, err),
                          "ok" if err.startswith(("+0", "0")) else "err")
        self.worker.tasks.put(job)

    # ------------------------------------------------ 결과 표시
    def pump(self):
        try:
            while True:
                m = self.q.get_nowait()
                self.handle(m)
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    def handle(self, m):
        kind = m[0]
        if kind == "call":
            m[1]()
            return
        if kind == "log":
            tag = m[2] if len(m) > 2 else ""
            self.log.insert("end", "%s  %s\n" % (datetime.datetime.now().strftime("%H:%M:%S"), m[1]), tag)
            self.log.see("end")
        elif kind == "visa":
            ok, txt = m[1], m[2]
            self.lbl_visa.configure(text=("VISA OK: " + txt) if ok else txt, foreground="#2e7d32" if ok else "#c62828")
            self.handle(("log", "VISA: " + txt, "ok" if ok else "err"))
        elif kind == "found":
            self.found.delete(*self.found.get_children())
            for r, idn in m[1]:
                self.found.insert("", "end", values=(r, idn))
        elif kind == "conn":
            k, ok, txt = m[1], m[2], m[3]
            (self.btn_e if k == "e" else self.btn_n).configure(text="연결 해제" if ok else "연결")
            (self.lbl_e_idn if k == "e" else self.lbl_n_idn).configure(
                text=txt or "연결 안 됨", fg="#8bc34a" if ok else "#ef5350")
        elif kind == "mods":
            for i, md in enumerate(m[1][:4]):
                self.n_vals[i + 1]["mod"].configure(text=md or "-")
        elif kind == "tick":
            self.rate_n += 1
            now = time.time()
            if now - self.rate_t >= 1.0:
                self.lbl_rate.configure(text="실제 %.1f 회/초" % (self.rate_n / (now - self.rate_t)) if self.polling else "")
                self.rate_n, self.rate_t = 0, now
        elif kind == "e":
            v = m[1]
            self.e_vals["vm"].configure(text="%.4f V" % v["vm"])
            self.e_vals["im"].configure(text=self.fmt_a(v["im"]))
            if "o" not in v:
                return
            self.store_set(("e", None), v)
            self.e_vals["vs"].configure(text="%.3f V" % v["vs"], fg="#e0e0e0")
            self.e_vals["is"].configure(text=self.fmt_a(v["is_"]), fg="#e0e0e0")
            self.refresh_entry("e", None)
            on = v["o"] in ("1", "ON")
            self.e_vals["o"].configure(text=" OUTPUT ON " if on else " OFF ", bg="#2e7d32" if on else "#333",
                                       fg="white" if on else "#999")
            self.e_led.configure(bg="#43a047" if on else "#555")
        elif kind == "n":
            for c, v in m[1].items():
                row = self.n_vals[c]
                row["vm"].configure(text="%+.4f V" % v["vm"])
                row["im"].configure(text=self.fmt_a(v["im"]))
                if "o" not in v:
                    continue
                self.store_set(("n", c), v)
                row["vs"].configure(text="Set %+.3f V" % v["vs"], fg="#5a6470")
                row["is"].configure(text="Lim %s" % self.fmt_a(v["is_"]), fg="#5a6470")
                self.refresh_entry("n", c)
                on = v["o"] in ("1", "ON")
                row["o"].configure(text="On" if on else "Off")
                self.n_leds[c].configure(bg="#43a047" if on else "#555")

    @staticmethod
    def fmt_a(a):
        if a != a:
            return "---"
        if abs(a) >= 1:
            return "%.4f A" % a
        if abs(a) >= 1e-3:
            return "%.3f mA" % (a * 1e3)
        return "%.2f µA" % (a * 1e6)

    def on_close(self):
        self.polling = False
        self.worker.alive = False
        for k in ("e", "n"):
            try:
                if self.inst[k] is not None:
                    self.inst[k].close()
            except Exception:
                pass
        self.root.destroy()


def main():
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
