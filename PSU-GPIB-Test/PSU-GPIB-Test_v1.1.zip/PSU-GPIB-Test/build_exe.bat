@echo off
cd /d %~dp0
echo ============================================
echo  PSU GPIB Test v1.1 - EXE build
echo ============================================
python --version
if errorlevel 1 (
  echo [ERROR] Python not found. Install Python 3.9+ ^(check "Add to PATH"^).
  pause
  exit /b 1
)
python -m pip install --upgrade pyinstaller pyvisa
if errorlevel 1 (
  echo [ERROR] package install failed. Check proxy / pip settings.
  pause
  exit /b 1
)
python -m PyInstaller --noconfirm --clean --onefile --windowed --name "PSU-GPIB-Test_v1.1" --collect-submodules pyvisa --copy-metadata pyvisa --hidden-import pyvisa.ctwrapper psu_gpib_test.py
if errorlevel 1 (
  echo [ERROR] Build failed.
  pause
  exit /b 1
)
echo.
echo  DONE:  dist\PSU-GPIB-Test_v1.1.exe
echo  (PC needs Keysight IO Libraries Suite or NI-VISA for GPIB)
echo.
pause
