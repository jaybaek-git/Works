# -*- coding: utf-8 -*-
"""PSU GPIB Test - 단독 실행 (화면 · 기능은 psu_panel.py, PA Bench Monitor v2.0 '파워서플라이' 화면과 같음)"""
import tkinter as tk

import psu_panel


def main():
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    psu_panel.App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
