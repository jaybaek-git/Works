@echo off
REM ============================================================
REM  PA Measurement Analyzer - build Windows program (.exe)
REM  Double-click this file (or run  .\build_exe.bat  in PowerShell)
REM  Result: dist\PA-Measurement-Analyzer-vX.Y-win64.zip
REM  Single exe:  build_exe.bat --onefile
REM
REM  Disk usage (v1.9.1+):
REM   * ONE shared Python environment for every version:  <drive>\PA-Analyzer-buildenv
REM     (same drive as this folder) -> new versions do not reinstall ~1 GB of packages
REM   * pip temp files go to the same drive, pip cache is not used
REM   * build\ is removed after a successful build
REM  Override the location:  set PA_BUILDENV=E:\somewhere  before running
REM ============================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set PA_SKIP_GUI_SMOKE=1
set PIP_NO_CACHE_DIR=1
set PIP_DISABLE_PIP_VERSION_CHECK=1

REM ---- shared build environment on the same drive as this folder
if not defined PA_BUILDENV set "PA_BUILDENV=%~d0\PA-Analyzer-buildenv"
mkdir "%PA_BUILDENV%" 2>nul
if not exist "%PA_BUILDENV%" set "PA_BUILDENV=%~dp0_buildenv"
mkdir "%PA_BUILDENV%\tmp" 2>nul
set "TEMP=%PA_BUILDENV%\tmp"
set "TMP=%PA_BUILDENV%\tmp"
set "VENV=%PA_BUILDENV%\venv"
echo Build environment: %PA_BUILDENV%

REM ---- free space check (needs about 3 GB the first time, about 1.5 GB afterwards)
set FREE_GB=
for /f %%A in ('powershell -NoProfile -Command "[math]::Floor((Get-Item '%~dp0').PSDrive.Free/1GB)" 2^>nul') do set FREE_GB=%%A
if defined FREE_GB (
    echo Free space on %~d0 : !FREE_GB! GB
    set NEED=3
    if exist "%VENV%\Scripts\python.exe" set NEED=2
    if !FREE_GB! LSS !NEED! (
        echo.
        echo [WARNING] Not enough free disk space on %~d0 ^(!FREE_GB! GB, need about !NEED! GB^).
        echo   - Delete old extracted versions ^(each old folder with .venv / build / dist is 1.5-2 GB^)
        echo   - Run  clean_build_files.bat  in old version folders
        echo   - Empty the Recycle Bin, then run build_exe.bat again
        echo.
        pause
        exit /b 1
    )
)

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
    python -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul && set "PY=python"
)
if not defined PY (
    echo.
    echo [ERROR] Python 3.10+ was not found.
    echo   1. Install Python from https://www.python.org/downloads/
    echo   2. In the installer, CHECK "Add python.exe to PATH"
    echo   3. Run build_exe.bat again
    echo.
    pause
    exit /b 1
)

if not exist "%VENV%\Scripts\python.exe" (
    echo [1/4] Creating shared build environment ^(first time only^)...
    %PY% -m venv "%VENV%"
    if errorlevel 1 goto :fail_venv
)

echo [2/4] Checking packages ^(first time: a few minutes^)...
"%VENV%\Scripts\python.exe" -m pip install --upgrade pip >nul
"%VENV%\Scripts\python.exe" -m pip install -r requirements-dev.txt
if errorlevel 1 goto :fail_pip

echo [3/4] Running tests...
"%VENV%\Scripts\python.exe" -m unittest discover -s tests
if errorlevel 1 goto :fail_test

echo [4/4] Building program...
"%VENV%\Scripts\python.exe" scripts\build_exe.py %*
if errorlevel 1 goto :fail_build

REM ---- tidy up: intermediate files are large and not needed after packaging
if exist build\smoke_test_exe_output.txt copy /y build\smoke_test_exe_output.txt dist\ >nul
rmdir /s /q build 2>nul
rmdir /s /q "%PA_BUILDENV%\tmp" 2>nul

echo.
echo ============================================================
echo  DONE:  dist\PA-Measurement-Analyzer-vX.Y-win64.zip  (version in the file name)
echo  Program: dist\PA-Measurement-Analyzer\PA-Measurement-Analyzer.exe
echo  Self-test log: dist\smoke_test_exe_output.txt
echo ============================================================
explorer dist
pause
exit /b 0

:fail_venv
echo [ERROR] Could not create the build environment in %PA_BUILDENV%.
goto :end
:fail_pip
echo [ERROR] Package install failed.
echo   - "No space left on device": free disk space ^(see clean_build_files.bat^) and run again
echo   - Proxy / firewall: try another network or ask IT for pip proxy settings
goto :end
:fail_test
echo [ERROR] Tests failed. Please send the messages above.
goto :end
:fail_build
echo [ERROR] Build failed. Please send the messages above.
:end
rmdir /s /q "%PA_BUILDENV%\tmp" 2>nul
echo.
pause
exit /b 1
