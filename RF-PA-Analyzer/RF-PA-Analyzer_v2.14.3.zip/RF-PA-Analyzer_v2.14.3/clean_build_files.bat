@echo off
REM ============================================================
REM  Remove large build files from THIS folder (an old version):
REM    .venv  (old per-folder Python environment, ~1 GB)
REM    _buildenv, build, dist
REM  Your data (projects .pam, sim_data, local_data) is NOT touched.
REM ============================================================
setlocal
cd /d "%~dp0"
echo This removes .venv, _buildenv, build and dist in:
echo   %~dp0
echo (Projects .pam, sim_data and local_data are kept.)
choice /m "Continue"
if errorlevel 2 exit /b 0
for %%D in (.venv _buildenv build dist) do (
    if exist "%%D" (
        echo Removing %%D ...
        rmdir /s /q "%%D"
    )
)
echo Done.
pause
