# Architecture

```
Excel / CSV ─► excel.reader ─► excel.sheet_parser ─► core.models.Dataset ─┐
 (workbook)     RawSheet grid   header · table ·        (Condition +        │
                                conditions · FREQ        columns)           │
                                                                            ▼
Simulation folder ─► simulation.repository ─► simulation.matching ─► app.controller ─► PlotRequest
                     (sets, split by FREQ)     (FREQ ±1 MHz)          (state, ranges,    │
                                                                       messages)          ▼
                                                     ui.main_window (Qt view) ◄── plotting.renderer
                                                     clipboard / PNG export ◄──── plotting.export
```

| Module | 역할 |
|---|---|
| `core/quantities.py` | 물리량(Pout, PAE, Gain, Pin, Idd, ACLR …)과 조건(FREQ, VGS …)의 Alias Registry |
| `core/models.py` | `Dataset`, `Condition`, `Series`, `PlotRequest` (출처와 무관한 공통 Interface) |
| `excel/` | 파일을 Grid로 읽기, Header·Table·조건 파싱, Long format FREQ 분리 |
| `measurement/loader.py` | Workbook → Sheet별 결과, Column Mapping / FREQ 재지정 |
| `simulation/` | Set 폴더 로드, Frequency 매칭 |
| `plotting/` | Graph Registry, Renderer(조건 Header 포함), Hover/Zoom, PNG Export |
| `app/controller.py` | 모든 상태와 로직 (GUI 없음 → 헤드리스 테스트 가능) |
| `ui/` | PySide6 화면, Column Mapping Dialog, Clipboard, GUI Smoke Test |

## 확장 방법

* **새 Graph:** `plotting/graph_types.py`에 `register_graph(GraphSpec("pout_vs_pin", "pin", "pout", …))`를 추가하면 UI 선택지가 자동으로 생깁니다.
* **새 물리량 / Header 별칭:** `core/quantities.py`의 `register_quantity` 또는 `aliases`를 수정합니다.
* **새 조건 항목:** `register_condition(...)`을 추가하면 자동 인식되어 Panel과 Plot 이미지에 표시됩니다.
* **Multi-curve:** `AppController.build_series()`가 `Series`를 여러 개 반환하면 Renderer가 색상을 순환하며 그립니다. Multi-Frequency와 Multi-Simulation은 이 함수만 확장하면 됩니다.
* **새 입력 형식(Touchstone 등):** 파일을 `Dataset`으로 만드는 Loader만 추가하면 Plot 쪽은 수정할 필요가 없습니다.
