"""Build the Windows program (PyInstaller) and package it as a zip.

    python scripts/build_exe.py            # folder build (fast start, recommended)
    python scripts/build_exe.py --onefile  # single .exe (slower start, ~5-10 s)

Result
    dist/PA-Measurement-Analyzer/PA-Measurement-Analyzer.exe
    dist/PA-Measurement-Analyzer-win64.zip      <- give this to users

After building, the .exe runs its own GUI smoke test (offscreen) so a broken
build is never shipped.
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = "PA-Measurement-Analyzer"
sys.path.insert(0, os.path.join(ROOT, "src"))
from version import VERSION_LABEL  # noqa: E402

for _s in (sys.stdout, sys.stderr):  # Korean Windows console (cp949) safety
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
SEP = ";" if os.name == "nt" else ":"


def build(onefile: bool) -> str:
    import PyInstaller.__main__
    args = [
        os.path.join(ROOT, "src", "main.py"),
        "--name", NAME, "--noconfirm", "--clean", "--windowed",
        "--paths", os.path.join(ROOT, "src"),
        "--icon", os.path.join(ROOT, "assets", "app.ico"),
        "--add-data", f"{os.path.join(ROOT, 'data', 'example')}{SEP}data/example",
        "--add-data", f"{os.path.join(ROOT, 'assets', 'app.ico')}{SEP}assets",
        "--distpath", os.path.join(ROOT, "dist"),
        "--workpath", os.path.join(ROOT, "build"),
        "--specpath", os.path.join(ROOT, "build"),
        "--exclude-module", "tkinter",
        "--exclude-module", "pandas",
        "--exclude-module", "PyQt5", "--exclude-module", "PyQt6",
    ]
    args.append("--onefile" if onefile else "--onedir")
    PyInstaller.__main__.run(args)
    exe = NAME + (".exe" if os.name == "nt" else "")
    return os.path.join(ROOT, "dist", exe) if onefile else os.path.join(ROOT, "dist", NAME, exe)


def smoke(exe: str, strict: bool = False) -> bool:
    env = dict(os.environ, QT_QPA_PLATFORM=os.environ.get("QT_QPA_PLATFORM", "offscreen"),
               PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    rc = subprocess.run([exe, "--smoke-test"], env=env, timeout=300).returncode
    keep = os.path.join(ROOT, "build", "smoke_test_exe_output.txt")
    os.makedirs(os.path.dirname(keep), exist_ok=True)
    text = ""
    for fn in ("smoke_test_result.txt", f"{NAME}.log"):
        f = os.path.join(os.path.dirname(exe), fn)
        if os.path.exists(f):
            text += f"===== {fn} =====\n" + open(f, encoding="utf-8", errors="replace").read() + "\n"
            os.remove(f)
    with open(keep, "w", encoding="utf-8") as fh:
        fh.write(text)
    print(text)
    if rc != 0:
        msg = (f"WARNING: automatic self-test of the built program reported a problem (exit {rc}).\n"
               f"         The program was still built. Log: {keep}")
        if strict:
            sys.exit(msg)
        print(msg)
        return False
    return True


def package(exe: str, onefile: bool) -> str:
    zpath = os.path.join(ROOT, "dist", f"{NAME}-{VERSION_LABEL}-win64.zip")
    src_dir = os.path.dirname(exe)
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        if onefile:
            z.write(exe, f"{NAME}/{os.path.basename(exe)}")
        else:
            for d, _, files in os.walk(src_dir):
                for f in files:
                    full = os.path.join(d, f)
                    z.write(full, os.path.join(NAME, os.path.relpath(full, src_dir)))
        z.write(os.path.join(ROOT, "docs", "USER_GUIDE.md"), f"{NAME}/사용법_PA.md")
        z.write(os.path.join(ROOT, "docs", "SPARAM_GUIDE.md"), f"{NAME}/사용법_S-Parameter.md")
    return zpath


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--onefile", action="store_true")
    ap.add_argument("--no-smoke", action="store_true")
    ap.add_argument("--strict", action="store_true", help="fail the build if the self-test fails")
    a = ap.parse_args()
    shutil.rmtree(os.path.join(ROOT, "dist"), ignore_errors=True)
    exe = build(a.onefile)
    if not a.no_smoke:
        smoke(exe, a.strict)
    print("Built:", exe)
    print("Package:", package(exe, a.onefile))
