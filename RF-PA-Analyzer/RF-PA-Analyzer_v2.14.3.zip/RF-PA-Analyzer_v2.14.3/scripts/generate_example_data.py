"""Generate SYNTHETIC example data (no real measurement / simulation data).

    python scripts/generate_example_data.py

Creates
    data/example/Measurement_Example.xlsx      (5 frequency sheets + Notes)
    data/example/simulation/typical/*.csv      (one CSV per frequency)
    data/example/simulation/corner_ss/corner_ss_sweep.csv  (long format, 3.4-3.7 GHz only)

The curves come from an ideal Doherty model with made-up scaling. Each
measurement sheet deliberately uses a *different layout* so the parser's
auto-detection is exercised.
"""
from __future__ import annotations

import csv
import os

import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "data", "example")
FONT = "Arial"
BANNER = "EXAMPLE DATA — synthetic, NOT a real measurement"

# per-frequency model parameters (all invented)
FREQS = {
    3.4: dict(psat=46.2, g0=31.6, eta=0.70, vca=-1.20, vpk=-1.35, vdrv=-1.10),
    3.5: dict(psat=46.5, g0=31.3, eta=0.71, vca=-1.22, vpk=-1.36, vdrv=-1.10),
    3.6: dict(psat=46.6, g0=31.0, eta=0.72, vca=-1.20, vpk=-1.35, vdrv=-1.10),
    3.7: dict(psat=46.3, g0=30.6, eta=0.70, vca=-1.18, vpk=-1.33, vdrv=-1.08),
    3.8: dict(psat=45.9, g0=30.1, eta=0.67, vca=-1.18, vpk=-1.32, vdrv=-1.08),
}


def doherty_curves(pout, psat, g0, eta):
    """Ideal symmetric Doherty efficiency (two peaks: Psat-6 dB and Psat) + soft compression."""
    v = np.sqrt(10 ** ((pout - psat) / 10.0))
    de = np.where(v <= 0.5, np.pi / 2 * v, np.pi / 2 * v ** 2 / np.maximum(3 * v - 1, 1e-9))
    de = np.minimum(de, np.pi / 4) * eta / (np.pi / 4) * 0.80
    # roll-off when pushed past saturation
    de *= 1 - 0.08 * np.clip(pout - psat + 0.5, 0, None)
    gain = (g0
            - 0.6 / (1 + np.exp(-(pout - (psat - 6.5)) / 1.2))       # peaking amp turn-on dip
            - 2.6 * np.log1p(np.exp((pout - psat + 1.2) / 0.7)) / 1.6)  # compression
    pae = de * (1 - 10 ** (-gain / 10)) * 100.0
    return pae, gain


def sim_table(f):
    p = FREQS[f]
    pout = np.round(np.arange(20.0, 47.01, 0.5), 2)
    pae, gain = doherty_curves(pout, p["psat"], p["g0"], p["eta"])
    return pout, pae, gain


def meas_table(f, seed):
    rng = np.random.default_rng(seed)
    p = FREQS[f]
    grid = np.arange(20.2, p["psat"] - 0.2, 0.9)
    pout = np.round(np.sort(grid + rng.normal(0, 0.12, len(grid))), 2)
    pae, gain = doherty_curves(pout, p["psat"] - 0.35, p["g0"] - 0.45, p["eta"] - 0.035)
    pae = np.round(pae + rng.normal(0, 0.5, len(pout)), 2)
    gain = np.round(gain + rng.normal(0, 0.06, len(pout)), 3)
    pin = np.round(pout - gain, 2)
    idd = np.round(10 ** (pout / 10) / 1000 / np.maximum(pae / 100, 0.02) / 48.0 * 1000, 1)  # mA @ 48 V
    return pin, pout, gain, pae, idd


def _banner(ws, cell="A1"):
    ws[cell] = BANNER
    ws[cell].font = Font(name=FONT, bold=True, color="C00000")
    ws[cell].fill = PatternFill("solid", fgColor="FFF2CC")


def _fmt(ws):
    for row in ws.iter_rows():
        for c in row:
            if c.font.name != FONT:
                c.font = Font(name=FONT)
    ws.column_dimensions["A"].width = 16
    for col in "BCDEFGHI":
        ws.column_dimensions[col].width = 13


def make_measurement_workbook(path):
    wb = Workbook()
    wb.remove(wb.active)

    # --- 3.4GHz: horizontal condition block (labels row / values row), table below
    f = 3.4; p = FREQS[f]
    ws = wb.create_sheet("3.4GHz")
    _banner(ws, "F1")
    for c, (k, v) in enumerate([("FREQ", "3.4 GHz"), ("VGS,CA", p["vca"]), ("VGS,PK", p["vpk"]), ("VGS,DRV", p["vdrv"])], 1):
        ws.cell(2, c, k).font = Font(name=FONT, bold=True)
        ws.cell(3, c, v)
    hdr = ["Pin (dBm)", "Pout (dBm)", "Gain (dB)", "PAE (%)", "Idd (mA)"]
    for c, h in enumerate(hdr, 1):
        ws.cell(6, c, h).font = Font(name=FONT, bold=True)
    for r, row in enumerate(zip(*meas_table(f, 1)), 7):
        for c, v in enumerate(row, 1):
            ws.cell(r, c, float(v))
    _fmt(ws)

    # --- 3.5GHz: vertical key/value block with separate unit column, header at row 9
    f = 3.5; p = FREQS[f]
    ws = wb.create_sheet("3.5GHz")
    _banner(ws)
    kv = [("FREQ", 3.5, "GHz"), ("VGS,CA", p["vca"], "V"), ("VGS,PK", p["vpk"], "V"),
          ("VGS,DRV", p["vdrv"], "V"), ("VDD", 48.0, "V"), ("Temperature", 25, "°C")]
    for r, (k, v, u) in enumerate(kv, 2):
        ws.cell(r, 1, k).font = Font(name=FONT, bold=True); ws.cell(r, 2, v); ws.cell(r, 3, u)
    pin, pout, gain, pae, idd = meas_table(f, 2)
    for c, h in enumerate(["Pout", "Gain", "PAE", "Pin"], 1):
        ws.cell(9, c, h).font = Font(name=FONT, bold=True)
    for c, u in enumerate(["dBm", "dB", "%", "dBm"], 1):
        ws.cell(10, c, u)  # unit row under the header (must be skipped)
    for r, row in enumerate(zip(pout, gain, pae, pin), 11):
        for c, v in enumerate(row, 1):
            ws.cell(r, c, float(v))
    _fmt(ws)

    # --- 3.6GHz: condition columns inside the table (A1: FREQ, B1: VGS,CA, ...)
    f = 3.6; p = FREQS[f]
    ws = wb.create_sheet("3.6GHz")
    hdr = ["FREQ (GHz)", "VGS,CA (V)", "VGS,PK (V)", "VGS,DRV (V)", "Pin (dBm)", "Pout (dBm)", "Gain (dB)", "PAE (%)"]
    for c, h in enumerate(hdr, 1):
        ws.cell(1, c, h).font = Font(name=FONT, bold=True)
    pin, pout, gain, pae, idd = meas_table(f, 3)
    for r, row in enumerate(zip(pin, pout, gain, pae), 2):
        for c, v in enumerate([f, p["vca"], p["vpk"], p["vdrv"], *map(float, row)], 1):
            ws.cell(r, c, v)
    _banner(ws, "J1")
    _fmt(ws)

    # --- 3.7GHz: "label = value" cells, PAE stored as a fraction, a few bad cells
    f = 3.7; p = FREQS[f]
    ws = wb.create_sheet("FREQ_3P7G")
    _banner(ws)
    ws["A2"] = "FREQ = 3700 MHz"
    ws["A3"] = f"VGS,CA = {p['vca']:.2f} V"
    ws["C3"] = f"VGS,PK = {p['vpk']:.2f} V"
    ws["E3"] = f"VGS,DRV = {p['vdrv']:.2f} V"
    ws["A4"] = "Mode = CW"
    for c, h in enumerate(["Index", "Pin_dBm", "Pout_dBm", "Gain_dB", "PAE"], 1):
        ws.cell(6, c, h).font = Font(name=FONT, bold=True)
    pin, pout, gain, pae, idd = meas_table(f, 4)
    for i, row in enumerate(zip(pin, pout, gain, pae / 100.0)):
        r = 7 + i
        ws.cell(r, 1, i + 1)
        for c, v in enumerate(row, 2):
            ws.cell(r, c, round(float(v), 4))
    ws.cell(7 + 3, 4, "N/A")        # non-numeric gain cell
    ws.cell(7 + 5, 5, "#DIV/0!")    # Excel error text in PAE
    _fmt(ws)

    # --- 3.8GHz: like 3.4GHz but VGS,DRV not recorded -> shown as N/A
    f = 3.8; p = FREQS[f]
    ws = wb.create_sheet("3800MHz")
    _banner(ws)
    for c, (k, v) in enumerate([("FREQ", "3.8GHz"), ("VGS,CA", p["vca"]), ("VGS,PK", p["vpk"])], 1):
        ws.cell(2, c, k).font = Font(name=FONT, bold=True)
        ws.cell(3, c, v)
    for c, h in enumerate(["Pin (dBm)", "Pout (dBm)", "Gain (dB)", "PAE (%)"], 1):
        ws.cell(5, c, h).font = Font(name=FONT, bold=True)
    pin, pout, gain, pae, idd = meas_table(f, 5)
    for r, row in enumerate(zip(pin, pout, gain, pae), 6):
        for c, v in enumerate(row, 1):
            ws.cell(r, c, float(v))
    _fmt(ws)

    # --- Notes sheet (no data -> must be reported, not crash)
    ws = wb.create_sheet("Notes")
    _banner(ws)
    notes = [
        "This workbook is SYNTHETIC example data generated by scripts/generate_example_data.py.",
        "Each sheet uses a different layout on purpose to test the auto-detection:",
        "  3.4GHz     : condition labels in one row, values in the row below; table header at row 6",
        "  3.5GHz     : vertical FREQ / VGS key-value block + VDD/Temperature; unit row under the header",
        "  3.6GHz     : FREQ and VGS columns inside the data table",
        "  FREQ_3P7G  : 'VGS,CA = -1.18 V' style cells, PAE stored as a fraction, some bad cells",
        "  3800MHz    : VGS,DRV missing (shown as N/A)",
    ]
    for r, t in enumerate(notes, 3):
        ws.cell(r, 1, t).font = Font(name=FONT)
    ws.column_dimensions["A"].width = 100
    wb.save(path)


def make_simulation(folder):
    typ = os.path.join(folder, "typical")
    ss = os.path.join(folder, "corner_ss")
    os.makedirs(typ, exist_ok=True)
    os.makedirs(ss, exist_ok=True)
    for f in FREQS:
        pout, pae, gain = sim_table(f)
        with open(os.path.join(typ, f"{f}GHz.csv"), "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["# EXAMPLE SIMULATION DATA (synthetic)"])
            w.writerow([f"# FREQ = {f} GHz"])
            w.writerow(["Pout (dBm)", "PAE (%)", "Gain (dB)"])
            for row in zip(pout, np.round(pae, 3), np.round(gain, 4)):
                w.writerow(row)
    # long format, slow-slow corner: 3.4-3.7 GHz only (3.8 GHz intentionally missing)
    with open(os.path.join(ss, "corner_ss_sweep.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["# EXAMPLE SIMULATION DATA (synthetic) - SS corner, 3.8 GHz intentionally missing"])
        w.writerow(["FREQ (GHz)", "Pout (dBm)", "PAE (%)", "Gain (dB)"])
        for f in (3.4, 3.5, 3.6, 3.7):
            p = FREQS[f]
            pout = np.round(np.arange(20.0, 47.01, 0.5), 2)
            pae, gain = doherty_curves(pout, p["psat"] - 0.6, p["g0"] - 0.8, p["eta"] - 0.05)
            for row in zip(pout, np.round(pae, 3), np.round(gain, 4)):
                w.writerow([f, *row])


def make_sim_txt(folder):
    """Notepad-style simulation files: one file per design variant, FREQ column + Pout/PAE/Gain."""
    os.makedirs(folder, exist_ok=True)
    variants = {  # name: (psat shift, gain shift, eta shift, header, separator, encoding)
        "3B": (0.0, 0.0, 0.00, ["주파수", "Pout", "PAE", "Gain"], "\t", "utf-8"),
        "3X": (0.4, 0.6, 0.02, ["Freq", "Pout", "PAE", "Gain"], "   ", "utf-8"),
        "3P": (-0.3, -0.5, -0.01, ["Freq(GHz)", "Pout(dBm)", "PAE(%)", "Gain(dB)"], "\t", "utf-8"),
        "3K": (0.2, 0.3, 0.03, ["주파수", "Pout", "PAE", "Gain"], "\t", "cp949"),   # Notepad 'ANSI'
    }
    for name, (dp, dg, de, hdr, sep, enc) in variants.items():
        if name == "3K":   # side-by-side groups, as copied from Excel (one Freq|Pout|PAE|Gain block per FREQ)
            blocks = []
            for f in FREQS:
                p = FREQS[f]
                pout = np.round(np.arange(20.0, 47.01, 0.5), 2)
                pae, gain = doherty_curves(pout, p["psat"] + dp, p["g0"] + dg, p["eta"] + de)
                blocks.append([[f"{f:.2f}", f"{a:.2f}", f"{b:.3f}", f"{g:.3f}"] for a, b, g in zip(pout, pae, gain)])
            lines = ["\t\t".join(["\t".join(hdr)] * len(blocks))]
            for i in range(max(len(b) for b in blocks)):
                lines.append("\t\t".join("\t".join(b[i]) if i < len(b) else "\t\t\t" for b in blocks))
            with open(os.path.join(folder, f"{name}.txt"), "w", encoding=enc, newline="\r\n") as fh:
                fh.write("\n".join(lines) + "\n")
            continue
        lines = [sep.join(hdr)]
        for f in FREQS:
            p = FREQS[f]
            pout = np.round(np.arange(20.0, 47.01, 0.5), 2)
            pae, gain = doherty_curves(pout, p["psat"] + dp, p["g0"] + dg, p["eta"] + de)
            for row in zip(pout, pae, gain):
                lines.append(sep.join([f"{f:.2f}", f"{row[0]:.2f}", f"{row[1]:.3f}", f"{row[2]:.3f}"]))
        with open(os.path.join(folder, f"{name}.txt"), "w", encoding=enc, newline="\r\n") as fh:
            fh.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    make_measurement_workbook(os.path.join(OUT, "Measurement_Example.xlsx"))
    make_simulation(os.path.join(OUT, "simulation"))
    make_sim_txt(os.path.join(OUT, "sim_data"))
    print("Example data written to", OUT)
