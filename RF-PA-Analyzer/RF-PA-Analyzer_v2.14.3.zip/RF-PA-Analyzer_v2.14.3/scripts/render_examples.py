"""Render README images from the example data (headless, same renderer as the GUI).

    python scripts/render_examples.py
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))

import matplotlib  # noqa: E402
matplotlib.use("Agg")
from matplotlib.backends.backend_agg import FigureCanvasAgg  # noqa: E402
from matplotlib.figure import Figure  # noqa: E402

from app.controller import AppController  # noqa: E402
from plotting.export import save_png  # noqa: E402
from plotting.renderer import PlotRenderer  # noqa: E402

c = AppController(sim_root=os.path.join(ROOT, "data", "example", "simulation"))
c.load_measurement(os.path.join(ROOT, "data", "example", "Measurement_Example.xlsx"))
fig = Figure(figsize=(8, 5.5), dpi=100)
FigureCanvasAgg(fig)
r = PlotRenderer(fig)
c.select_sheet("3.6GHz")
for key in ("pae_vs_pout", "gain_vs_pout"):
    c.select_graph(key)
    r.render(c.build_plot_request())
    print(save_png(fig, os.path.join(ROOT, "assets", f"example_{c.default_export_name()}"), scale=1.25))
c.select_sim_set("Corner SS"); c.select_sheet("3800MHz"); c.select_graph("pae_vs_pout")
r.render(c.build_plot_request())
print(save_png(fig, os.path.join(ROOT, "assets", "example_sim_mismatch.png"), scale=1.25))
