"""Pre-push security check.

    python scripts/security_check.py

Fails (exit 1) if files that would be pushed contain:
  * data files outside data/example/  (xlsx, csv, s2p, ...)
  * example workbooks without the 'EXAMPLE' banner
  * .env files, private keys, tokens, API keys, passwords
Enable automatically on every push:
    git config core.hooksPath .githooks
"""
from __future__ import annotations

import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_EXT = (".pam", ".xlsx", ".xlsm", ".xls", ".csv", ".s1p", ".s2p", ".s3p", ".s4p", ".snp",
            ".ds", ".mdf", ".citi", ".mat", ".h5", ".hdf5", ".npz", ".pkl")
ALLOWED_DATA_PREFIX = "data/example/"
TEXT_EXT = (".py", ".md", ".txt", ".toml", ".cfg", ".ini", ".json", ".yml", ".yaml", ".bat",
            ".sh", ".ps1", ".csv", "")
SECRET_PATTERNS = [
    ("GitHub token", re.compile(r"\b(ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{30,}\b|github_pat_[A-Za-z0-9_]{40,}")),
    ("AWS access key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("Slack token", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}")),
    ("Anthropic/OpenAI key", re.compile(r"\bsk-(ant-)?[A-Za-z0-9_-]{20,}")),
    ("Private key", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("Hard-coded secret", re.compile(
        r"(?i)\b(password|passwd|pwd|api[_-]?key|secret|access[_-]?token|auth[_-]?token)\b\s*[:=]\s*['\"][^'\"\s]{6,}['\"]")),
]


def files_to_push():
    """Tracked + untracked-but-not-ignored files (what `git add .` would include)."""
    try:
        out = subprocess.run(["git", "ls-files", "--cached", "--others", "--exclude-standard"],
                             cwd=ROOT, capture_output=True, text=True, check=True).stdout
        return [f for f in out.splitlines() if f]
    except Exception:
        found = []
        for d, dirs, files in os.walk(ROOT):
            dirs[:] = [x for x in dirs if x not in (".git", ".venv", "venv", "__pycache__", "local_data")]
            found += [os.path.relpath(os.path.join(d, f), ROOT).replace(os.sep, "/") for f in files]
        return found


def check() -> int:
    problems = []
    for rel in files_to_push():
        path = os.path.join(ROOT, rel)
        if not os.path.isfile(path):
            continue
        low = rel.lower()
        name = os.path.basename(low)
        if name == ".env" or name.startswith(".env."):
            problems.append((rel, ".env file"))
        if ("sim_data/" in rel or low.endswith(".dat")) and not rel.startswith(ALLOWED_DATA_PREFIX):
            problems.append((rel, "simulation data outside data/example/ (keep it in sim_data/ next to the program)"))
        if low.endswith(DATA_EXT) and not rel.startswith(ALLOWED_DATA_PREFIX):
            problems.append((rel, "data file outside data/example/ (real data must stay in local_data/)"))
        if low.endswith((".xlsx", ".xlsm")) and rel.startswith(ALLOWED_DATA_PREFIX):
            if not _has_example_banner(path):
                problems.append((rel, "example workbook without 'EXAMPLE' banner — is this real data?"))
        if low.endswith(TEXT_EXT) and os.path.getsize(path) < 2_000_000 and "security_check.py" not in rel:
            try:
                text = open(path, encoding="utf-8", errors="ignore").read()
            except OSError:
                continue
            for label, pat in SECRET_PATTERNS:
                if pat.search(text):
                    problems.append((rel, label))
    if problems:
        print("SECURITY CHECK FAILED:")
        for rel, why in problems:
            print(f"  - {rel}: {why}")
        return 1
    print("Security check passed: no real data, secrets or credentials found.")
    return 0


def _has_example_banner(path: str) -> bool:
    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        try:
            for ws in wb.worksheets:
                for row in ws.iter_rows(max_row=5, values_only=True):
                    if any(isinstance(v, str) and "EXAMPLE" in v.upper() for v in row):
                        return True
        finally:
            wb.close()
    except Exception:
        return False
    return False


if __name__ == "__main__":
    sys.exit(check())
