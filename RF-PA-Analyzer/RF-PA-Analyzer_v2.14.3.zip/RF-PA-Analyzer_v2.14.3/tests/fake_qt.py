"""Tiny functional stand-in for PySide6, used ONLY when PySide6 is not installed
(e.g. CI containers without a display). It lets the real MainWindow /
smoke-test code run headless so wiring bugs (typos, wrong state flow, broken
signal handlers) are caught. Real Qt behaviour is covered by
`python src/main.py --smoke-test` on a desktop, and by test_ui_real.py
whenever PySide6 is available.
"""
from __future__ import annotations

import io
import sys
import types


class Signal:
    def __init__(self):
        self._slots = []

    def connect(self, fn):
        self._slots.append(fn)

    def emit(self, *args):
        for fn in list(self._slots):
            fn(*args)


SIGNALS = {"windowTitleChanged", "currentChanged", "splitterMoved", "itemClicked", "timeout", "currentItemChanged", "customContextMenuRequested", "itemDoubleClicked", "editingFinished", "itemChanged", "clicked", "currentIndexChanged", "toggled", "returnPressed", "valueChanged",
           "accepted", "rejected", "buttonToggled", "triggered", "textChanged"}


class _Meta(type):
    def __getattr__(cls, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return Dummy()


class Dummy(metaclass=_Meta):
    """Accepts any call / attribute; signals are real (connect/emit)."""

    def __init__(self, *a, **k):
        object.__setattr__(self, "_signals", {})
        object.__setattr__(self, "_props", {})
        self._blocked = False

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        if name in SIGNALS:
            sig = self._signals.get(name)
            if sig is None:
                sig = self._signals[name] = Signal()
            return sig
        return Dummy()

    def __call__(self, *a, **k):
        return Dummy()

    def __or__(self, other):
        return self

    __ror__ = __and__ = __add__ = __radd__ = __sub__ = __mul__ = __or__

    def __bool__(self):
        return True

    def __float__(self):
        return 10.0

    def blockSignals(self, b):
        old, self._blocked = self._blocked, bool(b)
        return old

    def _emit(self, name, *args):
        if not self._blocked:
            getattr(self, name).emit(*args)

    def setProperty(self, k, v):
        self._props[k] = v

    def property(self, k):
        return self._props.get(k)


# ---------------------------------------------------------------- widgets
class QLineEdit(Dummy):
    def __init__(self, *a, **k):
        super().__init__()
        self._text = ""

    def setText(self, t):
        self._text = str(t)

    def text(self):
        return self._text


class QPlainTextEdit(QLineEdit):
    def setPlainText(self, t):
        self._text = t

    def toPlainText(self):
        return self._text


class QComboBox(Dummy):
    def __init__(self, *a, **k):
        super().__init__()
        self._items, self._idx = [], -1

    def addItem(self, text, data=None):
        self._items.append((text, data))
        if self._idx < 0:
            self._idx = 0
            self._emit("currentIndexChanged", 0)

    def clear(self):
        self._items, self._idx = [], -1
        self._emit("currentIndexChanged", -1)

    def count(self):
        return len(self._items)

    def findData(self, d):
        return next((i for i, (_, x) in enumerate(self._items) if x == d), -1)

    def itemData(self, i):
        return self._items[i][1] if 0 <= i < len(self._items) else None

    def itemText(self, i):
        return self._items[i][0]

    def currentData(self):
        return self.itemData(self._idx)

    def currentIndex(self):
        return self._idx

    def setCurrentIndex(self, i):
        if i != self._idx:
            self._idx = i
            self._emit("currentIndexChanged", i)


class QAbstractButton(Dummy):
    def __init__(self, text="", *a, **k):
        super().__init__()
        self._checked, self._group, self._text = False, None, text

    def isChecked(self):
        return self._checked

    def setChecked(self, v):
        v = bool(v)
        if v == self._checked:
            return
        if v and self._group is not None:
            for b in self._group._buttons:
                if b is not self and b._checked:
                    b._checked = False
                    b._emit("toggled", False)
                    self._group._emit("buttonToggled", b, False)
        self._checked = v
        self._emit("toggled", v)
        if self._group is not None:
            self._group._emit("buttonToggled", self, v)


class QRadioButton(QAbstractButton):
    pass


class QCheckBox(QAbstractButton):
    pass


class QTabWidget(Dummy):
    def __init__(self, *a, **k):
        super().__init__()
        self._pages, self._names, self._i = [], [], -1

    def addTab(self, w, name):
        self._pages.append(w); self._names.append(name)
        if self._i < 0:
            self._i = 0
        return len(self._pages) - 1

    def count(self):
        return len(self._pages)

    def tabText(self, i):
        return self._names[i]

    def currentIndex(self):
        return self._i

    def currentWidget(self):
        return self._pages[self._i]

    def setCurrentIndex(self, i):
        if i != self._i and 0 <= i < len(self._pages):
            self._i = i
            self._emit("currentChanged", i)


class QSplitter(Dummy):
    def __init__(self, *a, **k):
        super().__init__()
        self._sizes = [700, 170]

    def sizes(self):
        return list(self._sizes)

    def setSizes(self, s):
        self._sizes = list(s)


class QToolButton(QAbstractButton):
    pass


class QPushButton(QAbstractButton):
    def click(self):
        self._emit("clicked", False)


class QButtonGroup(Dummy):
    def __init__(self, *a, **k):
        super().__init__()
        self._buttons = []

    def addButton(self, b):
        b._group = self
        self._buttons.append(b)


class QSpinBox(Dummy):
    def __init__(self, *a, **k):
        super().__init__()
        self._v, self._min, self._max = 0, 0, 99

    def setRange(self, a, b):
        self._min, self._max = a, b

    def value(self):
        return self._v

    def setValue(self, v):
        v = max(self._min, min(self._max, int(v)))
        if v != self._v:
            self._v = v
            self._emit("valueChanged", v)


class _StatusBar(Dummy):
    last = ""

    def showMessage(self, text, *a):
        self.last = text


class QMainWindow(Dummy):
    def __init__(self, *a, **k):
        super().__init__()
        self._status = _StatusBar()
        self._title = ""

    def setWindowTitle(self, t):
        self._title = str(t)
        self._emit("windowTitleChanged", self._title)

    def windowTitle(self):
        return self._title

    def statusBar(self):
        return self._status


class QMessageBox(Dummy):
    calls = []
    Yes, No, Save, Discard, Cancel = 0x4000, 0x10000, 0x800, 0x800000, 0x400000
    answer = None

    @classmethod
    def question(cls, parent, title, text, buttons=None, *a):
        cls.calls.append(("question", text))
        if cls.answer is not None:
            return cls.answer
        return cls.Discard if "저장" in text else cls.Yes

    @classmethod
    def warning(cls, parent, title, text, *a):
        cls.calls.append(("warning", text))

    @classmethod
    def critical(cls, parent, title, text, *a):
        cls.calls.append(("critical", text))

    @classmethod
    def about(cls, *a):
        pass


class QSettings(Dummy):
    def __init__(self, *a, **k):
        super().__init__()
        self._d = {}

    def value(self, k, default=None):
        return self._d.get(k, default)

    def setValue(self, k, v):
        self._d[k] = v


class _QtNS(Dummy):
    Unchecked, PartiallyChecked, Checked = 0, 1, 2
    NoItemFlags, ItemIsSelectable, ItemIsEnabled, ItemIsDragEnabled = 0, 1, 32, 4
    NoModifier, ShiftModifier, ControlModifier = 0, 0x02000000, 0x04000000
    ItemIsUserCheckable = 16
    UserRole = 256
    Key_Escape, Key_Space, Key_Delete, Key_Backspace, Key_F2, Key_A = 0x01000000, 0x20, 0x01000007, 0x01000003, 0x01000031, 0x41


class QListWidgetItem(Dummy):
    def __init__(self, *a):
        super().__init__()
        self._text = a[-1] if a else ""
        self._data, self._check, self._sel, self._list, self._flags = {}, 0, False, None, 0

    def text(self):
        return self._text

    def setForeground(self, *a):
        pass

    def flags(self):
        return self._flags

    def setFlags(self, f):
        self._flags = f

    def setData(self, role, v):
        self._data[role] = v

    def data(self, role):
        return self._data.get(role)

    def checkState(self):
        return self._check

    def setCheckState(self, v):
        changed = v != self._check
        self._check = v
        if changed and self._list is not None:
            self._list._emit("itemChanged", self)

    def setSelected(self, v):
        self._sel = bool(v)

    def setHidden(self, v):
        self._hidden = bool(v)

    def isHidden(self):
        return getattr(self, "_hidden", False)

    def isSelected(self):
        return self._sel


class _ScrollBar:
    def __init__(self):
        self._v = 0

    def value(self):
        return self._v

    def setValue(self, v):
        self._v = int(v)


class QListWidget(Dummy):
    def __init__(self, *a):
        super().__init__()
        self._items = []
        self._vbar, self._hbar = _ScrollBar(), _ScrollBar()

    def verticalScrollBar(self):
        return self._vbar

    def horizontalScrollBar(self):
        return self._hbar

    def scrollToItem(self, it, *a):
        if it in self._items:
            self._vbar.setValue(self._items.index(it))

    def addItem(self, it):
        it._list = self
        self._items.append(it)

    def clear(self):
        self._items = []
        self._cur = None
        self._vbar.setValue(0)          # like Qt: emptying the list scrolls back to the top

    def count(self):
        return len(self._items)

    def item(self, i):
        return self._items[i]

    def selectedItems(self):
        return [i for i in self._items if i._sel]

    def hasFocus(self):
        return getattr(self, "_focus", False)

    def setFocus(self, *a):
        self._focus = True

    def clearFocus(self):
        self._focus = False

    def setCurrentItem(self, it, *mode):
        prev = getattr(self, "_cur", None)
        if not mode:                       # default command clears the selection and selects the item
            for x in self._items:
                x._sel = False
            if it is not None:
                it._sel = True
        self._cur = it
        if it is not prev:
            self._emit("currentItemChanged", it, prev)

    def currentItem(self):
        return getattr(self, "_cur", None)

    def clearSelection(self):
        for x in self._items:
            x._sel = False

    def setCurrentRow(self, row):
        self.setCurrentItem(self._items[row] if 0 <= row < len(self._items) else None, 0)

    def itemAt(self, pos):
        return self._items[pos] if isinstance(pos, int) and 0 <= pos < len(self._items) else None


class QTableWidgetItem(Dummy):
    def __init__(self, text=""):
        super().__init__()
        self._text = text

    def text(self):
        return self._text

    def setText(self, t):
        self._text = t

    def data(self, role):
        return self.__dict__.get("_data", {}).get(role)

    def setData(self, role, v):
        self.__dict__.setdefault("_data", {})[role] = v


class QTableWidget(Dummy):
    def __init__(self, *a):
        super().__init__()
        self._r = self._c = 0
        self._cells = {}

    def setRowCount(self, n):
        self._r = n

    def setColumnCount(self, n):
        self._c = n

    def rowCount(self):
        return self._r

    def columnCount(self):
        return self._c

    def setItem(self, r, c, it):
        self._cells[(r, c)] = it

    def item(self, r, c):
        return self._cells.get((r, c))

    def insertRow(self, r):
        self._cells = {((rr + 1 if rr >= r else rr), cc): it for (rr, cc), it in self._cells.items()}
        self._r += 1

    def removeRow(self, r):
        self._cells = {((rr - 1 if rr > r else rr), cc): it for (rr, cc), it in self._cells.items() if rr != r}
        self._r -= 1

    def setCurrentCell(self, r, c):
        self._cur = (r, c)

    def currentRow(self):
        return getattr(self, "_cur", (-1, -1))[0]

    def currentColumn(self):
        return getattr(self, "_cur", (-1, -1))[1]


class QAction(Dummy):
    def __init__(self, *a, **k):
        super().__init__()
        self._text = a[-1] if a and isinstance(a[-1], str) else (a[0] if a and isinstance(a[0], str) else "")

    def text(self):
        return self._text

    def setChecked(self, on):
        self._props["checked"] = bool(on)

    def isChecked(self):
        return bool(self._props.get("checked", False))

    def setEnabled(self, on):
        self._props["enabled"] = bool(on)

    def isEnabled(self):
        return bool(self._props.get("enabled", True))

    def trigger(self):
        self._emit("triggered", False)


class QMenu(Dummy):
    shown = []

    def __init__(self, *a, **k):
        super().__init__()
        self.items = []

    def addAction(self, *a):
        act = QAction(*a)
        self.items.append(act)
        return act

    def addMenu(self, *a):
        m = QMenu()
        self.items.append(m)
        return m

    def exec(self, *a):
        QMenu.shown.append(self)
        return None


class QColorDialog(Dummy):
    next_color = None

    @staticmethod
    def getColor(*a, **k):
        c = QColorDialog.next_color
        return type("C", (), {"isValid": lambda s: c is not None, "name": lambda s: c})()


# ---------------------------------------------------------------- gui / core
class QByteArray(bytes):
    pass


class QImage(Dummy):
    def __init__(self, png=b""):
        super().__init__()
        self._png = png
        self._w = self._h = 0
        if png:
            from PIL import Image
            with Image.open(io.BytesIO(png)) as im:
                self._w, self._h = im.size

    @staticmethod
    def fromData(data, fmt=None):
        return QImage(bytes(data))

    def isNull(self):
        return not self._png

    def width(self):
        return self._w

    def height(self):
        return self._h


class QMimeData(Dummy):
    def __init__(self):
        super().__init__()
        self.image, self._d, self._t = None, {}, ""

    def setImageData(self, img):
        self.image = img

    def setData(self, fmt, data):
        self._d[fmt] = bytes(data)

    def data(self, fmt):
        return self._d.get(fmt, b"")

    def hasFormat(self, fmt):
        return fmt in self._d

    def setText(self, t):
        self._t = t

    def text(self):
        return self._t


class _Clipboard:
    def __init__(self):
        self.mime = None
        self._text = ""

    def setText(self, t):
        self._text = t

    def text(self):
        return getattr(self, "_text", "")

    def clear(self):
        self.mime = None

    def setMimeData(self, m):
        self.mime = m
        if hasattr(m, "_t"):
            self._text = m._t

    def mimeData(self):
        return self.mime

    def image(self):
        return self.mime.image if self.mime and self.mime.image else QImage()


class QGuiApplication(Dummy):
    _clip = _Clipboard()

    @classmethod
    def clipboard(cls):
        return cls._clip


class QApplication(QGuiApplication):
    modifiers = 0

    @staticmethod
    def instance():
        return None

    @staticmethod
    def keyboardModifiers():
        return QApplication.modifiers

    @staticmethod
    def processEvents():
        pass


class QDialog(Dummy):
    Accepted, Rejected = 1, 0

    def accept(self):
        self._result = 1

    def reject(self):
        self._result = 0


# ---------------------------------------------------------------- install
def install():
    """Register fake PySide6 + a QtAgg backend replacement (Agg canvas)."""
    pkg = types.ModuleType("PySide6")
    core = types.ModuleType("PySide6.QtCore")
    gui = types.ModuleType("PySide6.QtGui")
    widgets = types.ModuleType("PySide6.QtWidgets")
    core.Qt = _QtNS()
    core.QSettings, core.QByteArray, core.QMimeData = QSettings, QByteArray, QMimeData
    core.QSize = Dummy
    core.QLocale = Dummy
    core.QItemSelectionModel = type("QItemSelectionModel", (Dummy,), {"NoUpdate": 0})
    core.QTimer = type("QTimer", (Dummy,), {"singleShot": staticmethod(lambda ms, fn: fn())})
    gui.QAction, gui.QKeySequence, gui.QFont = QAction, Dummy, Dummy
    gui.QCursor = Dummy
    gui.QBrush = Dummy
    gui.QPainter, gui.QPen = Dummy, Dummy
    gui.QColor, gui.QIcon, gui.QPixmap = Dummy, Dummy, Dummy
    gui.QGuiApplication, gui.QImage = QGuiApplication, QImage
    names = dict(QButtonGroup=QButtonGroup, QCheckBox=QCheckBox, QComboBox=QComboBox, QLineEdit=QLineEdit,
                 QMainWindow=QMainWindow, QMessageBox=QMessageBox, QPlainTextEdit=QPlainTextEdit,
                 QPushButton=QPushButton, QRadioButton=QRadioButton, QSpinBox=QSpinBox,
                 QApplication=QApplication, QDialog=QDialog, QListWidget=QListWidget,
                 QListWidgetItem=QListWidgetItem, QTableWidget=QTableWidget, QTableWidgetItem=QTableWidgetItem,
                 QMenu=QMenu, QColorDialog=QColorDialog, QToolButton=QToolButton,
                 QSplitter=QSplitter, QTabWidget=QTabWidget)
    for n in ("QFileDialog", "QFrame", "QGridLayout", "QGroupBox", "QHBoxLayout", "QInputDialog", "QLabel",
              "QSizePolicy", "QAbstractItemView", "QScrollArea", "QVBoxLayout", "QWidget", "QDialogButtonBox", "QFormLayout",
              "QStyledItemDelegate"):
        names[n] = type(n, (Dummy,), {})
    for k, v in names.items():
        setattr(widgets, k, v)
    pkg.QtCore, pkg.QtGui, pkg.QtWidgets = core, gui, widgets
    sys.modules.update({"PySide6": pkg, "PySide6.QtCore": core, "PySide6.QtGui": gui,
                        "PySide6.QtWidgets": widgets})

    from matplotlib.backends.backend_agg import FigureCanvasAgg
    qtagg = types.ModuleType("matplotlib.backends.backend_qtagg")

    class FigureCanvasQTAgg(FigureCanvasAgg):
        def __getattr__(self, name):  # Qt widget methods -> no-op
            if name.startswith("__"):
                raise AttributeError(name)
            return lambda *a, **k: None

    class NavigationToolbar2QT(Dummy):
        def __init__(self, canvas, parent=None):
            super().__init__()
            self.mode = ""

        def update(self):
            pass

    qtagg.FigureCanvasQTAgg, qtagg.NavigationToolbar2QT = FigureCanvasQTAgg, NavigationToolbar2QT
    sys.modules["matplotlib.backends.backend_qtagg"] = qtagg
