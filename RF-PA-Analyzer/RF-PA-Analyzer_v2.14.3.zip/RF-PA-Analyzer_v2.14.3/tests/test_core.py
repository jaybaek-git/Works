"""Headless tests (no GUI needed).  Run:  python -m unittest discover -s tests -v"""
import math
import os
import sys
import tempfile
import unittest

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))

import matplotlib  # noqa: E402
matplotlib.use("Agg")
from matplotlib.backends.backend_agg import FigureCanvasAgg  # noqa: E402
from matplotlib.figure import Figure  # noqa: E402

from app.controller import AppController  # noqa: E402
from core.models import Level, Source  # noqa: E402
from core.quantities import match_condition, match_quantity  # noqa: E402
from excel.reader import RawSheet, ReaderError, column_letter, read_workbook  # noqa: E402
from excel.sheet_parser import parse_sheet  # noqa: E402
from measurement.loader import load_measurement_file  # noqa: E402
from plotting.export import default_png_name, figure_png_bytes, save_png  # noqa: E402
from plotting.interaction import nearest_point, zoom_limits  # noqa: E402
from plotting.renderer import PlotRenderer  # noqa: E402
from simulation.repository import load_simulation_repository  # noqa: E402
from utils.freq import format_freq, freq_tag, parse_frequency  # noqa: E402
from utils.numeric import to_float  # noqa: E402

EXAMPLE_XLSX = os.path.join(ROOT, "data", "example", "Measurement_Example.xlsx")
SIM_ROOT = os.path.join(ROOT, "data", "example", "simulation")
GHz = 1e9


def errors(res):
    return [m.text for m in res.messages if m.level == Level.ERROR]


class TestFrequency(unittest.TestCase):
    def test_naming_conventions(self):
        cases = {"3.6GHz": 3.6, "3.6 GHz": 3.6, "3600MHz": 3.6, "FREQ_3P6G": 3.6, "FREQ_3600": 3.6,
                 "3p6GHz": 3.6, "F3.6G": 3.6, "3600M": 3.6, "PA_3.45G_meas": 3.45, "3.6e9": 3.6,
                 "3600": 3.6, 3.6: 3.6, 3600: 3.6, 3.6e9: 3.6}
        for text, ghz in cases.items():
            self.assertAlmostEqual(parse_frequency(text) / GHz, ghz, 6, msg=repr(text))

    def test_not_frequencies(self):
        for text in ("Sheet1", "Notes", "Summary 2024", "", None, "VGS -1.2V"):
            self.assertIsNone(parse_frequency(text), msg=repr(text))

    def test_format_and_tag(self):
        self.assertEqual(format_freq(3.6e9), "3.60 GHz")
        self.assertEqual(freq_tag(3.6e9), "3p6GHz")
        self.assertEqual(freq_tag(3.45e9), "3p45GHz")
        self.assertEqual(format_freq(None), "N/A")


class TestAliases(unittest.TestCase):
    def test_quantities(self):
        for h, q in {"Pout (dBm)": "pout", "Pout_dBm": "pout", "POUT[dBm]": "pout", "PAE (%)": "pae",
                     "PAE": "pae", "Gain (dB)": "gain", "Gain_dB": "gain", "Pin": "pin"}.items():
            self.assertEqual(match_quantity(h), q, h)
        self.assertIsNone(match_quantity("VGS,CA"))

    def test_conditions(self):
        for h, k in {"VGS,CA": "vgs_ca", "Vgs_CA (V)": "vgs_ca", "VGS CA": "vgs_ca", "VGS,PK": "vgs_pk",
                     "VGS,DRV": "vgs_drv", "FREQ": "freq", "Frequency (GHz)": "freq",
                     "Freq_MHz": "freq", "VDD": "vdd", "Temperature": "temp"}.items():
            self.assertEqual(match_condition(h), k, h)

    def test_numbers(self):
        self.assertEqual(to_float("-1.20 V"), -1.2)
        self.assertEqual(to_float("54.2 %"), 54.2)
        self.assertTrue(math.isnan(to_float("N/A")))
        self.assertTrue(math.isnan(to_float("#DIV/0!")))
        self.assertTrue(math.isnan(to_float(None)))
        self.assertTrue(math.isnan(to_float(True)))
        self.assertEqual(column_letter(0), "A")
        self.assertEqual(column_letter(27), "AB")


class TestSheetParser(unittest.TestCase):
    def test_header_not_on_first_row(self):
        rows = [["Title"], [], ["FREQ", 3.6], ["VGS,CA", "-1.2 V"], [],
                ["Pout", "Gain", "PAE"], [30, 14, 20], [31, 13.9, 22], ["junk"], [32, 13.8, "N/A"]]
        res = parse_sheet(RawSheet("anything", rows))
        self.assertTrue(res.ok, res.messages)
        self.assertEqual(res.header_row, 5)
        ds = res.dataset
        self.assertAlmostEqual(ds.freq_hz, 3.6e9)
        self.assertEqual(ds.condition.get("vgs_ca"), -1.2)
        self.assertEqual(ds.condition.format_value("vgs_pk"), "N/A")
        np.testing.assert_allclose(ds.columns["pout"], [30, 31, 32])
        self.assertTrue(math.isnan(ds.columns["pae"][2]))

    def test_condition_columns_in_table(self):
        rows = [["FREQ", "VGS,CA", "VGS,PK", "VGS,DRV", "Pout", "PAE", "Gain"]] + \
               [[3500, -1.2, -1.35, -1.1, 30 + i, 20 + i, 14] for i in range(5)]
        res = parse_sheet(RawSheet("Sheet1", rows))
        c = res.dataset.condition
        self.assertAlmostEqual(c.freq_hz, 3.5e9)
        self.assertEqual(c.freq_source, "column")
        self.assertEqual((c.get("vgs_ca"), c.get("vgs_pk"), c.get("vgs_drv")), (-1.2, -1.35, -1.1))

    def test_freq_from_sheet_name(self):
        rows = [["Pout", "PAE", "Gain"], [30, 20, 14], [31, 22, 14]]
        res = parse_sheet(RawSheet("FREQ_3P7G", rows))
        self.assertAlmostEqual(res.freq_hz, 3.7e9)
        self.assertEqual(res.dataset.condition.freq_source, "sheet_name")

    def test_freq_unknown_is_warning_not_error(self):
        res = parse_sheet(RawSheet("Sheet1", [["Pout", "PAE"], [30, 20]]))
        self.assertTrue(res.ok)
        self.assertIsNone(res.freq_hz)
        self.assertTrue(any("FREQ 자동 인식" in m.text for m in res.messages))

    def test_missing_pae_is_warning(self):
        res = parse_sheet(RawSheet("3.6GHz", [["Pout", "Gain"], [30, 14], [31, 13.9]]))
        self.assertTrue(res.ok)
        self.assertTrue(any("PAE column을 찾을 수 없습니다" in m.text for m in res.messages))

    def test_missing_pout_is_error(self):
        res = parse_sheet(RawSheet("3.6GHz", [["PAE", "Gain"], [30, 14]]))
        self.assertFalse(res.ok)
        self.assertTrue(errors(res))

    def test_empty_and_text_only(self):
        self.assertIn("빈 Sheet입니다.", errors(parse_sheet(RawSheet("x", []))))
        self.assertTrue(errors(parse_sheet(RawSheet("x", [["hello"], ["world"]]))))
        self.assertTrue(errors(parse_sheet(RawSheet("x", [["Pout", "PAE"], ["a", "b"]]))))

    def test_user_column_mapping(self):
        rows = [["Col1", "Col2", "Col3"], [30, 20, 14], [31, 22, 13.8]]
        self.assertFalse(parse_sheet(RawSheet("3.6GHz", rows)).ok)
        res = parse_sheet(RawSheet("3.6GHz", rows), header_row=0, mapping={"pout": 0, "pae": 1, "gain": 2})
        self.assertTrue(res.ok)
        np.testing.assert_allclose(res.dataset.columns["gain"], [14, 13.8])

    def test_freq_override(self):
        res = parse_sheet(RawSheet("Sheet1", [["Pout", "PAE"], [30, 20]]), freq_override_hz=3.55e9)
        self.assertAlmostEqual(res.freq_hz, 3.55e9)
        self.assertEqual(res.dataset.condition.freq_source, "user")


class TestExampleWorkbook(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mf = load_measurement_file(EXAMPLE_XLSX)

    def test_all_sheets_listed(self):
        names = [s.sheet_name for s in self.mf.sheets]
        self.assertEqual(names, ["3.4GHz", "3.5GHz", "3.6GHz", "FREQ_3P7G", "3800MHz", "Notes"])
        self.assertEqual(len(self.mf.datasets), 5)
        self.assertFalse(self.mf.sheet("Notes").ok)

    def test_frequencies_and_conditions(self):
        exp = {"3.4GHz": (3.4, -1.20, -1.35, -1.10), "3.5GHz": (3.5, -1.22, -1.36, -1.10),
               "3.6GHz": (3.6, -1.20, -1.35, -1.10), "FREQ_3P7G": (3.7, -1.18, -1.33, -1.08),
               "3800MHz": (3.8, -1.18, -1.32, None)}
        for name, (f, ca, pk, drv) in exp.items():
            c = self.mf.sheet(name).dataset.condition
            self.assertAlmostEqual(c.freq_hz / GHz, f, 6, name)
            self.assertAlmostEqual(c.get("vgs_ca"), ca, 6, name)
            self.assertAlmostEqual(c.get("vgs_pk"), pk, 6, name)
            if drv is None:
                self.assertEqual(c.format_value("vgs_drv"), "N/A")
            else:
                self.assertAlmostEqual(c.get("vgs_drv"), drv, 6, name)

    def test_pae_fraction_converted(self):
        pae = self.mf.sheet("FREQ_3P7G").dataset.columns["pae"]
        self.assertGreater(np.nanmax(pae), 30)

    def test_ordered_by_frequency(self):
        self.assertEqual(self.mf.ordered_sheet_names()[-1], "Notes")
        self.assertEqual(self.mf.default_sheet_name(), "3.4GHz")

    def test_disguised_files(self):
        d = tempfile.mkdtemp()
        # tab-separated text saved with .xlsx extension (typical instrument export)
        tsv = os.path.join(d, "meas_3.6GHz.xlsx")
        with open(tsv, "w", encoding="utf-8") as f:
            f.write("VGS,CA\t-1.2\nPout\tPAE\tGain\n30\t20\t14\n31\t22\t13.9\n")
        mf = load_measurement_file(tsv)
        self.assertEqual(len(mf.datasets), 1)
        self.assertAlmostEqual(mf.datasets[0].freq_hz, 3.6e9)
        # OLE2 container (.xls / password / DRM) -> clear message, no crash
        ole = os.path.join(d, "old.xlsx")
        with open(ole, "wb") as f:
            f.write(b"\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1" + b"\0" * 600)
        with self.assertRaises(ReaderError) as cm:
            read_workbook(ole)
        self.assertIn("다른 이름으로 저장", str(cm.exception))
        drm = os.path.join(d, "drm.xlsx")
        with open(drm, "wb") as f:
            f.write(b"\x00\x01<## FASOO DRM ##>" + bytes(range(256)) * 4)
        with self.assertRaises(ReaderError) as cm:
            read_workbook(drm)
        self.assertIn("DRM", str(cm.exception))

    def test_bad_files(self):
        with self.assertRaises(ReaderError):
            read_workbook("does_not_exist.xlsx")
        with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f:
            f.write(bytes(range(256)) * 8)  # corrupt binary
        try:
            with self.assertRaises(ReaderError):
                read_workbook(f.name)
        finally:
            os.unlink(f.name)


class TestSimulation(unittest.TestCase):
    def test_repository_and_matching(self):
        repo = load_simulation_repository(SIM_ROOT)
        self.assertEqual(repo.set_names, ["Typical", "Corner SS"])
        typ = repo.get("Typical")
        self.assertEqual(len(typ.frequencies()), 5)
        self.assertIsNotNone(typ.find(3.6e9))
        self.assertIsNotNone(typ.find(3.6004e9))       # within 1 MHz
        self.assertIsNone(typ.find(3.65e9))
        self.assertIsNone(repo.get("Corner SS").find(3.8e9))   # intentionally missing

    def test_missing_folder(self):
        repo = load_simulation_repository("/no/such/folder")
        self.assertEqual(repo.set_names, [])


class TestControllerAndPlot(unittest.TestCase):
    def setUp(self):
        self.c = AppController(sim_root=SIM_ROOT)
        self.c.load_measurement(EXAMPLE_XLSX)

    def test_overlay_and_auto_match(self):
        self.c.select_sheet("3.6GHz")
        req = self.c.build_plot_request()
        self.assertEqual([s.role for s in req.series], [Source.SIMULATION, Source.MEASUREMENT])
        self.assertEqual(req.title, "PAE vs. Pout")
        self.assertIn("VG_CA = -1.20 V", req.condition_grid[0])
        self.assertIn("VG_DRV = -1.10 V", req.condition_grid[0])
        # independent sampling, no interpolation
        sim, meas = req.series
        self.assertEqual(sim.x[0], 20.0)
        self.assertNotEqual(len(sim.x), len(meas.x))

    def test_frequency_change_updates_everything(self):
        self.c.select_sheet("3.4GHz")
        a = self.c.build_plot_request()
        self.c.select_sheet("FREQ_3P7G")
        b = self.c.build_plot_request()
        self.assertIn("VG_CA = -1.18 V", b.condition_grid[0])
        self.assertIn("Typical @ 3.70 GHz", self.c.simulation_dataset().name)
        self.assertFalse(np.array_equal(a.series[1].y, b.series[1].y))

    def test_graph_defaults_and_ranges(self):
        self.assertEqual(self.c.ranges().ylim, (0.0, 70.0))
        self.c.select_graph("gain_vs_pout")
        self.assertEqual(self.c.ranges().ylim, (20.0, 40.0))
        self.assertEqual(self.c.ranges().xlim, (26.0, 52.0))
        self.c.set_ranges((25, 45), (5, 18))
        self.assertEqual(self.c.build_plot_request().xlim, (25.0, 45.0))
        self.assertTrue(self.c.set_ranges((50, 40), None))     # invalid -> warning
        self.c.select_graph("pae_vs_pout")
        self.assertEqual(self.c.ranges().xlim, (26.0, 54.0))   # per-graph ranges
        self.c.select_graph("gain_vs_pout")
        self.c.reset_ranges()
        self.assertEqual(self.c.ranges().xlim, (26.0, 52.0))

    def test_auto_scale(self):
        self.c.select_sheet("3.6GHz")
        r = self.c.auto_scale()
        self.assertLess(r.xlim[0], 20.5)
        self.assertGreater(r.ylim[1], 50)
        self.assertGreaterEqual(r.ylim[0], 0)

    def test_simulation_mismatch_message(self):
        self.c.select_sim_set("Corner SS")
        self.c.select_sheet("3800MHz")
        msgs = [m.text for m in self.c.status_messages()]
        self.assertIn("3.80 GHz Simulation Dataset을 찾을 수 없습니다 (Corner SS).", msgs)
        req = self.c.build_plot_request()
        self.assertEqual([s.role for s in req.series], [Source.MEASUREMENT])
        self.assertTrue(req.notice)

    def test_render_export_and_filename(self):
        self.c.select_sheet("3.6GHz")
        fig = Figure(figsize=(8, 5.5), dpi=100)
        FigureCanvasAgg(fig)
        r = PlotRenderer(fig)
        ax = r.render(self.c.build_plot_request())
        texts = [t.get_text() for t in fig.texts]
        self.assertIn("PAE vs. Pout", texts)
        self.assertTrue(any("VG_CA = -1.20 V" in t for t in texts))
        self.assertEqual(ax.get_xlim(), (26.0, 54.0))
        self.assertEqual([t.get_text() for t in ax.get_legend().get_texts()],
                         ["Simulation (Typical)", "Measurement"])
        png = figure_png_bytes(fig, scale=1.0)
        self.assertEqual(png[:8], b"\x89PNG\r\n\x1a\n")
        self.assertEqual(self.c.default_export_name(), "PAE_vs_Pout_3p6GHz.png")
        with tempfile.TemporaryDirectory() as d:
            p = save_png(fig, os.path.join(d, self.c.default_export_name()))
            self.assertTrue(os.path.getsize(p) > 10000)
            from PIL import Image  # pillow is a matplotlib dependency
            with Image.open(p) as im:
                w, h = im.size
            self.assertEqual((w, h), (1600, 1100))  # same layout as screen, 2x resolution

    def test_nearest_point_and_zoom(self):
        self.c.select_sheet("3.6GHz")
        fig = Figure(figsize=(8, 5.5), dpi=100)
        FigureCanvasAgg(fig)
        ax = PlotRenderer(fig).render(self.c.build_plot_request())
        fig.canvas.draw()
        line = ax.get_lines()[1]
        x, y = line.get_xdata()[5], line.get_ydata()[5]
        px, py = ax.transData.transform((x, y))
        hit = nearest_point(ax, px + 2, py - 2)
        self.assertIsNotNone(hit)
        self.assertEqual(hit[0].get_label(), "Measurement")
        self.assertEqual(hit[1], 5)
        self.assertIsNone(nearest_point(ax, 0, 0))
        self.assertEqual(zoom_limits(20, 50, 35, 0.5), (27.5, 42.5))

    def test_default_name_unknown_freq(self):
        self.assertEqual(default_png_name("Gain_vs_Pout", None, "Sheet 1"), "Gain_vs_Pout_Sheet_1.png")


class TestRawLabColumns(unittest.TestCase):
    HDR = ["SG Pout (dBm)", "SA Pin (dBm)", "DUT_Pin (dBm)", "DUT_Pout (dBm)", "IDC_Driver (mA)", "IDC_CA (mA)",
           "IDC_PK mA)", "Gain", "Pin(mW)", "Pout(mW)", "DC_Power(mW)", "DC_Power_Main(mW)", "PAE(%)", "DE(%)"]

    def test_raw_header_mapping(self):
        rows = [self.HDR] + [[5 + i, 4 + i, 3 + i, 17 + i, 50, 100, 10, 14 - 0.1 * i, 1, 50, 2000, 1500, 20 + i, 25 + i]
                             for i in range(10)]
        r = parse_sheet(RawSheet("raw", rows))
        self.assertTrue(r.ok)
        self.assertEqual(r.mapping["pout"], 3)      # DUT_Pout (dBm), not SG Pout / Pout(mW)
        self.assertEqual(r.mapping["pin"], 2)
        self.assertEqual(r.mapping["gain"], 7)
        self.assertEqual(r.mapping["pae"], 12)
        self.assertEqual(r.mapping["pout_mw"], 9)
        self.assertFalse([m for m in r.messages if "여러 개" in m.text])

    def test_markers_backoff(self):
        c = AppController(sim_root=SIM_ROOT)
        c.load_measurement(EXAMPLE_XLSX)
        c.select_sheet("3.6GHz")
        c.add_v_marker(38.04); c.add_h_marker(41.3)
        self.assertEqual((c.v_markers, c.cur_h), ([38.0], [41.5]))
        c.select_graph("gain_vs_pout"); c.add_h_marker(30.34)
        self.assertEqual(c.cur_h, [30.3])
        c.select_marker(("h", 0)); c.nudge_selected(1, "y")
        self.assertEqual(c.cur_h, [30.4])
        self.assertEqual(len(c.v_readout(38.0)), 2)
        self.assertIn("dBm", c.h_readout(30.0)[0].text)
        self.assertFalse(c.set_backoffs("6, 8"))
        rows = c.backoff_rows()
        self.assertEqual(len(rows), 4)
        self.assertTrue(c.set_backoffs("abc"))
        self.assertIn("Psat", c.backoff_tsv())


class TestLabConditionBlock(unittest.TestCase):
    def test_condition_block_above_raw_table(self):
        top = ("Freq\tVDD main\tPulse Duty\tInput Loss\tOutput Loss\tVG_DRV\tVG_CA\tVG_PK\tIQ_DRV\tIQ_CA\n"
               "3.6\t48\t10%\t0.35\t0.42\t-1.10\t-1.20\t-1.35\t55.0\t120.5\n\n")
        hdr = "\t".join(TestRawLabColumns.HDR) + "\n"
        rows = "".join("\t".join(str(x) for x in [5 + i, 4 + i, 3 + i, 17 + i, 50, 100, 10, 30, 1, 50, 2000, 1500,
                                                   20 + i, 25 + i]) + "\n" for i in range(10))
        c = AppController()
        name, _ = c.paste_text(top + hdr + rows)
        self.assertAlmostEqual(c.current_freq_hz, 3.6e9)
        self.assertEqual(c.condition_panel_items(), [("VG_DRV", "-1.10 V"), ("VG_CA", "-1.20 V"), ("VG_PK", "-1.35 V"),
                                                     ("IQ_DRV", "55.0 mA"), ("IQ_CA", "120.5 mA")])
        self.assertEqual(c.measurement_dataset.condition.get("vdd"), 48.0)   # read but not shown
        c.condition_keys = ["freq", "vgs_ca", "duty"]
        self.assertEqual(c.condition_lines(), ["FREQ = 3.60 GHz", "VG_CA = -1.20 V", "Pulse Duty = 10.0 %"])

    def test_gan_bias_negative_and_grid(self):
        c = AppController()
        c.paste_text("VG_DRV\tVG_CA\tVG_PK\tIQ_DRV\tIQ_CA\n1.1\t1.2\t-1.35\t55\t120\n\nPout\tGain\tPAE\n30\t30\t20\n31\t30\t22\n")
        cond = c.measurement_dataset.condition
        self.assertEqual((cond.get("vgs_drv"), cond.get("vgs_ca"), cond.get("vgs_pk")), (-1.1, -1.2, -1.35))
        grid, extra = c.condition_grid()
        self.assertEqual(grid, [["VG_DRV = -1.10 V", "VG_CA = -1.20 V", "VG_PK = -1.35 V"],
                                ["IQ_DRV = 55.0 mA", "IQ_CA = 120.0 mA", ""]])
        self.assertEqual(extra, [])
        c.condition_keys = ["vgs_ca", "iq_ca", "freq"]
        grid, extra = c.condition_grid()
        self.assertEqual(grid, [["VG_CA = -1.20 V"], ["IQ_CA = 120.0 mA"]])
        self.assertEqual(extra, ["FREQ = N/A"])

    def test_sim_toggle(self):
        c = AppController(sim_root=SIM_ROOT)
        c.load_measurement(EXAMPLE_XLSX)
        c.select_sheet("3.6GHz")
        self.assertEqual([d.name for d in c.visible_sims()], ["Typical @ 3.60 GHz"])
        c.toggle_sim("Typical @ 3.60 GHz", False)
        self.assertEqual(c.visible_sims(), [])
        c.toggle_sim("Corner SS @ 3.40 GHz", True)
        self.assertEqual([d.name for d in c.visible_sims()], ["Corner SS @ 3.40 GHz"])
        c.sim_enabled = False
        self.assertEqual(c.build_series()[0].role, Source.MEASUREMENT)
        self.assertEqual(len(c.build_series()), 1)

    def test_styles_on_many(self):
        c = AppController(sim_root=SIM_ROOT)
        c.load_measurement(EXAMPLE_XLSX)
        c.checked = ["3.4GHz", "3.5GHz", "3.6GHz"]
        c.set_styles(["3.4GHz", "3.6GHz"], color="#000000", linewidth=2.4, linestyle="--")
        meas = {s.label.split(" ·")[0]: s for s in c.build_series() if s.role == Source.MEASUREMENT}
        self.assertEqual(meas["3.4GHz"].style["color"], "#000000")
        self.assertEqual(meas["3.6GHz"].style["linewidth"], 2.4)
        self.assertNotIn("linewidth", meas["3.5GHz"].style)


class TestNotepadSimFiles(unittest.TestCase):
    FILES = [os.path.join(ROOT, "data", "example", "sim_data", f"{n}.txt") for n in ("3B", "3X", "3P", "3K")]

    def test_txt_variants(self):
        c = AppController()
        msgs = c.load_simulation_files(self.FILES)
        self.assertFalse([m for m in msgs if m.level != Level.INFO], msgs)
        self.assertEqual(c.simulation.set_names, ["3B", "3X", "3P", "3K"])      # user's order kept
        for n in c.simulation.set_names:
            freqs = [round(f / 1e9, 2) for f in c.simulation.get(n).frequencies()]
            self.assertEqual(freqs, [3.4, 3.5, 3.6, 3.7, 3.8], n)
        d = c.simulation.get("3K").find(3.6e9)                                    # cp949 + '주파수'
        x, g = d.xy("pout", "gain")
        self.assertTrue(len(x) > 40 and 25 < g[0] < 40)

    def test_all_sets_matching_and_project(self):
        c = AppController()
        c.load_simulation_files(self.FILES)
        c.load_measurement(EXAMPLE_XLSX)
        c.select_sheet("3.6GHz")
        self.assertEqual(c.sim_set, "*")
        self.assertEqual(len(c.visible_sims()), 4)
        c.select_sim_set("3X")
        self.assertEqual([d.group for d in c.visible_sims()], ["3X"])
        with tempfile.TemporaryDirectory() as tmp:
            p = c.save_project(os.path.join(tmp, "s"))
            c2 = AppController(sim_root=SIM_ROOT)
            c2.load_measurement(p)
            self.assertEqual(c2.simulation.set_names, ["3B", "3X", "3P", "3K"])
            self.assertEqual(c2.sim_set, "3X")

    def test_user_header_and_foldback(self):
        p = os.path.join(tempfile.mkdtemp(), "3X.txt")
        with open(p, "w", encoding="utf-8") as f:
            f.write("Freq Po_dBm PAE Gain\n3.6 44.0 50 30\n3.6 45.0 52 29\n3.6 45.5 53 28\n"
                    "3.6 45.2 51 27\n3.6 44.8 49 26\n3.4 44.0 48 31\n3.4 44.5 49 30\n")
        c = AppController()
        msgs = c.load_simulation_files([p])
        d = c.simulation.get("3X").find(3.6e9)
        np.testing.assert_allclose(d.columns["pout"], [44.0, 45.0, 45.5])      # 45.2 / 44.8 removed
        np.testing.assert_allclose(d.columns["gain"], [30, 29, 28])
        self.assertTrue(any("2개 점 제외" in m.text for m in msgs))
        self.assertEqual(len(c.simulation.get("3X").find(3.4e9).columns["pout"]), 2)

    def test_side_by_side_groups(self):
        hdr = "\t\t".join(["Freq\tPo_dBm\tPAE\tGain"] * 3)
        lines = [hdr]
        for i in range(4):
            g3 = f"3.6\t{40 + i}\t{42 + i}\t28" if i < 2 else "\t\t\t"          # shorter 3rd group
            lines.append("\t\t".join([f"3.4\t{40 + i}\t{40 + i}\t30", f"3.5\t{40 + i}\t{41 + i}\t29", g3]))
        p = os.path.join(tempfile.mkdtemp(), "3W.txt")
        with open(p, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        c = AppController()
        c.load_simulation_files([p])
        sset = c.simulation.get("3W")
        self.assertEqual([round(f / 1e9, 2) for f in sset.frequencies()], [3.4, 3.5, 3.6])
        np.testing.assert_allclose(sset.find(3.5e9).columns["pae"], [41, 42, 43, 44])
        self.assertEqual(len(sset.find(3.6e9).columns["pout"]), 2)
        # space-separated, all groups complete
        p2 = os.path.join(tempfile.mkdtemp(), "3V.txt")
        with open(p2, "w", encoding="utf-8") as f:
            f.write("Freq Po_dBm PAE Gain Freq Po_dBm PAE Gain\n3.4 40 40 30 3.6 40 42 28\n3.4 41 41 30 3.6 41 43 28\n")
        c.load_simulation_files([p2])
        self.assertEqual([round(f / 1e9, 2) for f in c.simulation.get("3V").frequencies()], [3.4, 3.6])

    def test_whitespace_and_korean_header(self):
        p = os.path.join(tempfile.mkdtemp(), "9Z.txt")
        with open(p, "w", encoding="cp949") as f:
            f.write("주파수  Pout  PAE  Gain\n3.6  30.0  20.0  31.0\n3.6  31.0  22.0  30.9\n")
        c = AppController()
        c.load_simulation_files([p])
        self.assertEqual(c.simulation.set_names, ["9Z"])
        self.assertAlmostEqual(c.simulation.get("9Z").datasets[0].freq_hz, 3.6e9)


class TestPasteAndProject(unittest.TestCase):
    TSV = ("EXAMPLE\r\nFREQ\t3,600 MHz\r\nVGS,CA\t-1.20 V\r\nVGS,PK\t-1.35\r\n\r\n"
           "Pout (dBm)\tGain (dB)\tPAE (%)\r\n30.10\t14.0\t16.5%\r\n31.00\t13.9\t18.0%\r\n32.0\t13.8\t\r\n")

    def test_paste_and_roundtrip(self):
        c = AppController(sim_root=SIM_ROOT)
        name, msgs = c.paste_text(self.TSV)
        self.assertEqual(name, "Paste_1")
        ds = c.measurement_dataset
        self.assertAlmostEqual(ds.freq_hz, 3.6e9)
        self.assertEqual(ds.condition.get("vgs_ca"), -1.2)
        np.testing.assert_allclose(ds.columns["pae"][:2], [16.5, 18.0])
        self.assertIsNotNone(c.simulation_dataset())          # matched to Typical 3.6 GHz
        self.assertTrue(c.unsaved)
        # second paste, no FREQ -> user override, then column mapping
        name2, _ = c.paste_text("Col1\tCol2\tCol3\n30\t20\t14\n31\t22\t13.9\n")
        self.assertFalse(c.sheet_result.ok)
        c.measurement.apply_mapping(name2, 0, {"pout": 0, "pae": 1, "gain": 2})
        c.measurement.set_frequency(name2, 3.7e9)
        c.select_graph("gain_vs_pout"); c.set_ranges((25, 35), (10, 15))
        with tempfile.TemporaryDirectory() as d:
            path = c.save_project(os.path.join(d, "proj"))
            self.assertFalse(c.unsaved)
            c2 = AppController(sim_root=SIM_ROOT)
            msgs = c2.load_measurement(path)
            self.assertFalse([m for m in msgs if m.level == Level.ERROR])
            self.assertEqual([s.sheet_name for s in c2.measurement.sheets], ["Paste_1", "Paste_2"])
            r2 = c2.measurement.sheet("Paste_2")
            self.assertTrue(r2.ok and r2.user_mapping)
            self.assertAlmostEqual(r2.freq_hz, 3.7e9)
            self.assertEqual(c2.graph_key, "gain_vs_pout")
            self.assertEqual(c2.ranges().xlim, (25.0, 35.0))
            self.assertEqual(c2.sheet_name, "Paste_2")

    def test_duplicate_display_names(self):
        c = AppController()
        tsv = "Pout\tGain\tPAE\n30\t30\t20\n31\t30\t22\n"
        k1, _ = c.paste_text(tsv); c.rename_sheet(k1, "Board7")
        k2, _ = c.paste_text(tsv); c.rename_sheet(k2, "Board7")
        self.assertNotEqual(k1, k2)
        self.assertEqual([c.measurement.sheet(k).label for k in (k1, k2)], ["Board7", "Board7"])
        with tempfile.TemporaryDirectory() as d:
            p = c.save_project(os.path.join(d, "dup"))
            c2 = AppController(); c2.load_measurement(p)
            self.assertEqual([s.label for s in c2.measurement.sheets], ["Board7", "Board7"])

    def test_reorder_saved(self):
        c = AppController(sim_root=SIM_ROOT)
        c.load_measurement(EXAMPLE_XLSX)
        names = [r.sheet_name for r in c.measurement.sheets]
        c.reorder_sheets(list(reversed(names)))
        self.assertEqual([r.sheet_name for r in c.measurement.sheets], list(reversed(names)))
        self.assertTrue(c.unsaved)
        c.checked = ["3.4GHz", "3.6GHz"]
        self.assertEqual([v.sheet_name for v in c.visible_sheets()], ["3.6GHz", "3.4GHz"])   # legend follows
        with tempfile.TemporaryDirectory() as d:
            p = c.save_project(os.path.join(d, "o"))
            c2 = AppController(); c2.load_measurement(p)
            self.assertEqual([r.sheet_name for r in c2.measurement.sheets], list(reversed(names)))

    def test_paste_errors(self):
        c = AppController()
        name, msgs = c.paste_text("   ")
        self.assertIsNone(name)
        self.assertTrue(msgs and msgs[0].level == Level.ERROR)

    def test_bad_project(self):
        p = os.path.join(tempfile.mkdtemp(), "x.pam")
        with open(p, "w") as f:
            f.write("{}")
        c = AppController()
        self.assertEqual(c.load_measurement(p)[0].level, Level.ERROR)




class TestDataEditorCells(unittest.TestCase):
    def test_cells(self):
        from utils.cells import fmt_cell, to_cell
        self.assertEqual(to_cell("1,234.5"), 1234.5)
        self.assertEqual(to_cell("  "), None)
        self.assertEqual(to_cell("Pout"), "Pout")
        self.assertEqual(fmt_cell(30.0), "30")
        self.assertEqual(fmt_cell(float("nan")), "")
        for v in (0.123456789, 12.3456789012, -1.35, 1e-7, 30.0):     # editing never rounds the data
            self.assertEqual(to_cell(fmt_cell(v)), v)


class TestFormula(unittest.TestCase):
    def test_eval_and_refs(self):
        from utils.formula import evaluate_all, col_name, col_index
        self.assertEqual([col_name(i) for i in (0, 25, 26, 27)], ["A", "Z", "AA", "AB"])
        self.assertEqual(col_index("AB"), 27)
        cells = {(0, 0): 10.0, (0, 1): 4.0, (1, 0): "=A1+B1*2", (1, 1): "=(A2-A1)/B1", (2, 0): "=-A1+3",
                 (2, 1): "=B2*$A$1", (3, 0): "=A1/0", (3, 1): "=C9+1", (4, 0): "=A5", (4, 1): "=x1+",
                 (5, 0): "Pout", (5, 1): "=A6*2"}
        v = evaluate_all(cells)
        self.assertEqual(v[(1, 0)], 18.0)
        self.assertEqual(v[(1, 1)], 2.0)
        self.assertEqual(v[(2, 0)], -7.0)
        self.assertEqual(v[(2, 1)], 20.0)
        self.assertTrue(str(v[(3, 0)]).startswith("#ERR"))         # / 0
        self.assertEqual(v[(3, 1)], 1.0)                             # empty cell = 0
        self.assertTrue(str(v[(4, 0)]).startswith("#ERR"))          # circular
        self.assertTrue(str(v[(4, 1)]).startswith("#ERR"))
        self.assertTrue(str(v[(5, 1)]).startswith("#ERR"))          # text * 2

    def test_shift(self):
        from utils.formula import shift_formula
        self.assertEqual(shift_formula("=A1+B2*$C$3-$D4+E$5", 2, 1), "=B3+C4*$C$3-$D6+F$5")
        self.assertEqual(shift_formula("=A1", -1, 0), "=#REF!")


class TestMappingPresets(unittest.TestCase):
    def test_make_and_resolve(self):
        from measurement.mapping_presets import make_preset, resolve, upsert, next_name
        from excel.reader import RawSheet
        from excel.sheet_parser import parse_sheet
        from core.models import Source
        a = parse_sheet(RawSheet("A", [["x", "출력", "효율", "이득"], [1, 30, 20, 14], [2, 31, 22, 13.9]], "a"),
                        Source.MEASUREMENT, 0, {"pout": 1, "pae": 2, "gain": 3})
        p = make_preset("맵핑1", a, 0, {"pout": 1, "pae": 2, "gain": 3})
        self.assertEqual(p["text"], {"pout": "출력", "pae": "효율", "gain": "이득"})
        # other data: same header texts, columns moved -> found by text
        b = parse_sheet(RawSheet("B", [["이득", "효율", "출력"], [14, 20, 30], [13.9, 22, 31]], "b"), Source.MEASUREMENT)
        self.assertEqual(resolve(p, b), (0, {"pout": 2, "pae": 1, "gain": 0}))
        # other data: no matching header text -> same column numbers
        c = parse_sheet(RawSheet("C", [["a", "b", "c", "d"], [1, 30, 20, 14]], "c"), Source.MEASUREMENT)
        self.assertEqual(resolve(p, c), (0, {"pout": 1, "pae": 2, "gain": 3}))
        self.assertEqual(next_name([p]), "맵핑2")
        self.assertEqual(len(upsert([p], dict(p, header_row=1))), 1)

if __name__ == "__main__":
    unittest.main(verbosity=2)
