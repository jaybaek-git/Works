"""Headless tests.  python -m unittest discover -s tests -v"""
import math
import os
import sys
import tempfile
import unittest

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
import matplotlib  # noqa: E402
matplotlib.use("Agg")

from sparam.app.controller import Controller  # noqa: E402
from sparam.core.models import LoadError  # noqa: E402
from sparam.loaders import load_file  # noqa: E402
from sparam.loaders.files import text_rows  # noqa: E402
from sparam.loaders.table import parse_table  # noqa: E402
from sparam.loaders.touchstone import parse_touchstone  # noqa: E402
from sparam.utils.freq import parse_freq_input  # noqa: E402

EX = os.path.join(ROOT, "data", "example", "sparam")


def write(name, text, mode="w"):
    p = os.path.join(tempfile.mkdtemp(), name)
    with open(p, mode, **({} if "b" in mode else {"encoding": "utf-8"})) as f:
        f.write(text)
    return p


class TestTable(unittest.TestCase):
    def test_default_order_no_header(self):
        d = parse_table(text_rows("3.4,14,-10,-12,-40\n3.5,14.2,-15,-13,-41\n3.6,14.1,-20,-14,-42\n"), "x")
        np.testing.assert_allclose(d.freq_hz, [3.4e9, 3.5e9, 3.6e9])
        np.testing.assert_allclose(d.db["s21"], [14, 14.2, 14.1])
        np.testing.assert_allclose(d.db["s11"], [-10, -15, -20])
        np.testing.assert_allclose(d.db["s22"], [-12, -13, -14])
        np.testing.assert_allclose(d.db["s12"], [-40, -41, -42])

    def test_units(self):
        mhz = parse_table(text_rows("3400\t14\n3500\t14\n"), "m")
        hz = parse_table(text_rows("3.4e9;14\n3.5e9;14\n"), "h")
        hdr = parse_table(text_rows("Freq(MHz),S21\n3.4,1\n3.5,2\n"), "u")  # header unit wins (odd but explicit)
        self.assertAlmostEqual(mhz.freq_hz[0], 3.4e9)
        self.assertAlmostEqual(hz.freq_hz[0], 3.4e9)
        self.assertAlmostEqual(hdr.freq_hz[0], 3.4e6)

    def test_header_names_override_order(self):
        d = parse_table(text_rows("freq,dB(S(1,1)),dB(S(2,1)),S21 phase\n1,-10,15,30\n2,-11,14,40\n"), "n")
        np.testing.assert_allclose(d.db["s11"], [-10, -11])
        np.testing.assert_allclose(d.db["s21"], [15, 14])
        np.testing.assert_allclose(d.phase["s21"], [30, 40])

    def test_partial_columns_and_bad_cells(self):
        d = parse_table(text_rows("Freq,S21\n3.4,14\n3.5,N/A\n3.6,13\n"), "p")
        self.assertEqual(d.params, ["s21"])
        self.assertTrue(math.isnan(d.db["s21"][1]))
        self.assertAlmostEqual(d.value_at("s21", 3.45e9), 13.75)  # NaN point skipped, linear interp
        self.assertTrue(math.isnan(d.value_at("s21", 5e9)))     # outside band

    def test_errors(self):
        with self.assertRaises(LoadError):
            parse_table(text_rows("hello\nworld\n"), "e")


class TestTouchstone(unittest.TestCase):
    def test_ma_db_ri(self):
        ma = "# GHz S MA R 50\n1.0 0.1 0 10 90 0.01 0 0.5 -45\n2.0 0.1 0 10 80 0.01 0 0.5 -45\n"
        d = parse_touchstone(ma, "ma")
        self.assertAlmostEqual(d.db["s21"][0], 20.0)
        self.assertAlmostEqual(d.db["s11"][0], -20.0)
        self.assertAlmostEqual(d.db["s12"][0], -40.0)
        self.assertAlmostEqual(d.phase["s21"][1], 80)
        self.assertAlmostEqual(d.freq_hz[1], 2e9)
        db = parse_touchstone("# MHz S DB R 50\n3600 -20 0 15 10 -40 0 -12 0\n3700 -21 0 14 9 -40 0 -12 0\n", "db")
        self.assertAlmostEqual(db.freq_hz[0], 3.6e9)
        self.assertAlmostEqual(db.db["s22"][0], -12)
        ri = parse_touchstone("# Hz S RI\n1e9 0 0.1 3 4 0 0 0 0\n2e9 0 0.1 3 4 0 0 0 0\n", "ri")
        self.assertAlmostEqual(ri.db["s21"][0], 20 * np.log10(5))

    def test_wrapped_lines_and_noise_block(self):
        txt = "! c\n# GHz S DB R 50\n1 -10 0 10 0\n -40 0 -12 0\n2 -11 0 11 0 -40 0 -12 0\n! noise\n1 1 0.5 10 0.1\n"
        d = parse_touchstone(txt, "w")
        self.assertEqual(len(d.freq_hz), 2)
        np.testing.assert_allclose(d.db["s21"], [10, 11])

    def test_s1p(self):
        d = parse_touchstone("# GHz S DB R 50\n1 -10 0\n2 -12 0\n", "one", n_ports=1)
        self.assertEqual(d.params, ["s11"])


class TestFilesAndController(unittest.TestCase):
    def test_examples(self):
        c = Controller()
        n, errs = c.add_files([os.path.join(EX, f) for f in sorted(os.listdir(EX))])
        self.assertEqual((n, errs), (5, []))
        kinds = sorted(e.data.kind for e in c.entries)
        self.assertEqual(kinds, ["csv", "csv", "excel", "excel", "touchstone"])
        for e in c.entries:
            self.assertAlmostEqual(e.data.f_min, 2.8e9, delta=1e6)
        self.assertEqual(len(c.build_series()), 5)
        c.set_param("s11", True)
        self.assertEqual(len(c.build_series()), 10)
        c.set_visible(c.entries[0].uid, False)
        self.assertEqual(len(c.build_series()), 8)
        c.fmt = "phase"
        self.assertEqual(len(c.build_series()), 2)  # only the s2p has phase
        self.assertTrue(c.missing_params_messages())

    def test_markers_and_export_name(self):
        c = Controller()
        c.add_files([os.path.join(EX, "Board_A.csv"), os.path.join(EX, "S2P_Example.s2p")])
        c.add_marker(parse_freq_input("3.6")); c.add_marker(parse_freq_input("3500MHz"))
        c.add_marker(3.6e9)  # duplicate ignored
        header, rows = c.marker_table()
        self.assertEqual(header[2:], ["M1 3.6 GHz (dB)", "M2 3.5 GHz (dB)"])  # numbered in the order added
        self.assertEqual(len(rows), 2)
        self.assertIn("\t", c.marker_table_tsv())
        self.assertEqual(c.default_export_name(), "S21_dB_2files.png")

    def test_same_name_twice(self):
        c = Controller()
        p = os.path.join(EX, "Board_A.csv")
        c.add_files([p, p])
        self.assertEqual([e.data.name for e in c.entries], ["Board_A", "Board_A (2)"])

    def test_bad_inputs(self):
        c = Controller()
        ole = write("x.xlsx", b"\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1" + b"\0" * 600, "wb")
        n, errs = c.add_files([ole, "missing.csv", write("a.pdf", "x"), write("t.csv", "a\nb\n")])
        self.assertEqual(n, 0)
        self.assertEqual(len(errs), 4)
        # .xlsx that is really tab-separated text
        n, errs = c.add_files([write("txt.xlsx", "Freq\tS21\n3.4\t14\n3.5\t14\n")])
        self.assertEqual((n, errs), (1, []))

    def test_ranges(self):
        c = Controller()
        c.add_files([os.path.join(EX, "Board_A.csv")])
        self.assertTrue(c.set_ranges((4, 3), None))
        c.auto_scale()
        self.assertAlmostEqual(c.xlim[0], 2.8)
        c.reset_ranges()
        self.assertIsNone(c.xlim)


class TestStylesAndNudge(unittest.TestCase):
    def test_nudge_and_db_snap(self):
        c = Controller()
        c.add_files([os.path.join(EX, "Board_A.csv")])
        c.add_marker(c.snap(3.537e9)); c.add_h_marker(-10.26)
        self.assertEqual(c.h_markers, [-10.5])
        self.assertFalse(c.nudge_selected(1, "x"))
        c.select_marker(("v", 0))
        self.assertTrue(c.nudge_selected(1, "x"))
        self.assertAlmostEqual(c.markers_hz[0], 3.6e9)
        self.assertFalse(c.nudge_selected(1, "y"))       # vertical marker ignores up/down
        c.select_marker(("h", 0))
        c.nudge_selected(1, "y"); c.nudge_selected(1, "y")
        self.assertEqual(c.h_markers, [-9.5])
        c.remove_marker("h", 0)
        self.assertIsNone(c.selected)

    def test_style_priority(self):
        c = Controller()
        c.add_files([os.path.join(EX, "Board_A.csv")])
        e = c.entries[0]
        c.params = {"s21", "s11"}
        self.assertEqual(c.style_for(e, "s11")[1], "--")
        c.set_curve_style((e.uid, "s11"), color="#123456", linewidth=2.6)
        s = {x.key[1]: x for x in c.build_series()}
        self.assertEqual((s["s11"].color, s["s11"].linewidth), ("#123456", 2.6))
        self.assertEqual(s["s21"].color, e.color)
        c.set_file_style(e.uid, color="#000000", linestyle=":")
        s = {x.key[1]: x for x in c.build_series()}
        self.assertEqual((s["s11"].color, s["s11"].linestyle, s["s21"].linestyle), ("#000000", ":", ":"))
        self.assertEqual(s["s11"].linewidth, 2.6)            # untouched curve setting kept
        c.reset_style(e.uid)
        s = {x.key[1]: x for x in c.build_series()}
        self.assertEqual((s["s11"].linestyle, s["s11"].linewidth), ("--", 1.6))
        self.assertEqual(c.v_readout(3.6e9)[0].color, "#000000")


class TestMarkersSmithFit(unittest.TestCase):
    def setUp(self):
        self.c = Controller()
        self.c.add_files([os.path.join(EX, "Board_A.csv"), os.path.join(EX, "S2P_Example.s2p")])

    def test_fit_returns_to_home(self):
        c = self.c
        c.set_ranges((3.2, 4.0), (0, 16))
        c.set_view((3.4, 3.5), (10, 12))
        self.assertEqual(c.build_plot_request().xlim, (3.4, 3.5))
        c.fit()
        self.assertEqual(c.build_plot_request().xlim, (3.2, 4.0))
        self.assertEqual(c.build_plot_request().ylim, (0.0, 16.0))
        c.reset_ranges()
        self.assertIsNone(c.build_plot_request().xlim)

    def test_h_marker_crossings(self):
        c = self.c
        c.params = {"s11"}
        c.add_h_marker(-10)
        r = c.h_readout(-10)
        self.assertEqual(len(r), 2)
        self.assertIn("GHz", r[0].text)
        self.assertEqual(r[0].linestyle, "--")  # S11 dashed
        f = [float(x) for x in r[0].text.replace(" GHz", "").split(",")]
        self.assertEqual(len(f), 2)
        self.assertTrue(2.9 < f[0] < 3.2 and 4.0 < f[1] < 4.3, f)

    def test_v_readout_colors(self):
        c = self.c
        r = c.v_readout(3.6e9)
        self.assertEqual([x.color for x in r], [e.color for e in c.entries])
        self.assertTrue(all(x.text.endswith("dB") for x in r))

    def test_smith(self):
        c = self.c
        c.params = {"s11", "s22"}
        c.add_h_marker(-10)
        c.set_format("smith")
        self.assertEqual(c.h_markers, [])
        s = c.build_series()
        self.assertEqual(len(s), 2)                    # CSV has no phase -> skipped
        self.assertTrue(np.all(np.hypot(s[0].x, s[0].y) <= 1.0))
        self.assertTrue(c.missing_params_messages())
        hz = c.snap_freq_smith(s[0].x[50], s[0].y[50])
        self.assertAlmostEqual(hz, s[0].freq_ghz[50] * 1e9)
        c.add_marker(hz)
        self.assertIn("Z=", c.v_readout(hz)[0].text)
        self.assertIn("∠", c.marker_table()[1][0][2])
        self.assertIsNone(c.add_h_marker(-3))
        self.assertTrue(c.default_export_name().startswith("S11_S22_Smith"))

    def test_render_smith_and_overlay(self):
        from matplotlib.backends.backend_agg import FigureCanvasAgg
        from matplotlib.figure import Figure
        from sparam.plotting.markers import MarkerOverlay
        from sparam.plotting.renderer import PlotRenderer
        c = self.c
        fig = Figure(figsize=(8, 6)); FigureCanvasAgg(fig)
        r, m = PlotRenderer(fig), MarkerOverlay(c)
        c.add_marker(3.6e9); c.add_h_marker(5)
        m.attach(r.render(c.build_plot_request()))
        fig.canvas.draw()
        self.assertEqual(m.hit(*r.ax.transData.transform((3.6, 0))), ("v", 0))
        self.assertEqual(m.hit(*r.ax.transData.transform((3.0, 5))), ("h", 0))
        c.show_marker_values = False
        m.draw()
        self.assertEqual(len(m.artists), 4)            # 2 lines + 2 tags, no panel
        c.set_format("smith"); c.params = {"s11"}
        m.attach(r.render(c.build_plot_request()))
        fig.canvas.draw()
        self.assertEqual(r.mode, "smith")


if __name__ == "__main__":
    unittest.main(verbosity=2)
