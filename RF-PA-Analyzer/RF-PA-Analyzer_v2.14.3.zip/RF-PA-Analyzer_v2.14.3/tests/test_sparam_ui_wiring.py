"""Run the real MainWindow + GUI smoke test on a fake Qt when PySide6 is absent."""
import importlib.util
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


@unittest.skipIf(importlib.util.find_spec("PySide6") is not None, "real PySide6 -> test_ui_real")
class TestSParamUiWiring(unittest.TestCase):
    def test_smoke(self):
        import matplotlib
        matplotlib.use("Agg")
        import fake_qt
        fake_qt.install()
        from sparam.app.controller import Controller
        from sparam.ui.main_window import MainWindow
        from sparam.ui.smoke_test import run_smoke_test
        rc, report = run_smoke_test(fake_qt.QApplication, MainWindow(Controller()))
        self.assertEqual(rc, 0, report)
        self.assertEqual([t for k, t in fake_qt.QMessageBox.calls if k == "critical"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
