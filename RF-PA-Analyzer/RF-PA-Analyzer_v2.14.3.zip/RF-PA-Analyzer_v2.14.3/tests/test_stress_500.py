"""Stress: 500 measurement datasets in the PA tab (paste, list, plot, highlight, search,
sort, undo, copy/paste, project save/load, Excel export). Fake Qt + real matplotlib."""
import importlib.util
import os
import sys
import tempfile
import time
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

N = 500
TIMES = {}


def _timed(name):
    class T:
        def __enter__(self):
            self.t = time.perf_counter()

        def __exit__(self, *a):
            TIMES[name] = time.perf_counter() - self.t
    return T()


@unittest.skipIf(importlib.util.find_spec("PySide6") is not None, "fake-Qt test")
@unittest.skipUnless(os.environ.get("RUN_STRESS"), "slow (~6 min): set RUN_STRESS=1")
class TestStress500(unittest.TestCase):
    def test_500_datasets(self):
        import matplotlib
        matplotlib.use("Agg")
        import fake_qt
        fake_qt.install()
        import numpy as np
        from app.controller import AppController
        from ui.main_window import MainWindow
        from ui.smoke_test import raw_tsv
        c = AppController(sim_root=os.path.join(ROOT, "data", "example", "simulation"))
        win = MainWindow(c)
        win.open_file(os.path.join(ROOT, "data", "example", "Measurement_Example.xlsx"))
        pout = np.linspace(20, 45, 26)
        with _timed(f"붙여넣기 {N}개"):
            for i in range(N):
                g = 15 - 0.004 * i - 0.01 * (pout - 20)
                e = 20 + 0.03 * i + 1.2 * (pout - 20)
                win.paste_text(raw_tsv(pout, g, e), ask_freq=False, name=f"보드{i % 50:02d}",
                               freq_hz=3.3e9 + (i * 7919 % 13) * 0.05e9)
        mf = c.measurement
        self.assertGreaterEqual(len([r for r in mf.sheets if r.ok]), N)
        with _timed("모두 체크 + Plot (500 곡선)"):
            win.set_all_checked(True)
            win.refresh(rerender=True)
            win.canvas.draw()
        ax = win.views[0].renderer.ax
        n_lines = len([l for l in ax.get_lines() if l.get_gid() and not str(l.get_gid()).startswith("sim:")])
        self.assertGreaterEqual(n_lines, N)
        leg = ax.get_legend()
        self.assertTrue(leg is None or len(leg.get_texts()) <= 120, "legend must stay compact")
        with _timed("Datasets 목록 채우기"):
            win.refresh_list() if hasattr(win, "refresh_list") else win.refresh()
        self.assertGreaterEqual(win.data_list.count(), N)
        with _timed("여러 개 선택 강조 (200개)"):
            names = [r.sheet_name for r in mf.sheets if r.ok][:200]
            c.set_highlight_multi(names)
            win.refresh(rerender=True)
        c.clear_highlight()
        with _timed("검색 '보드07' + 결과만 Plot"):
            win.filter_edit.setText("보드07")
            win.on_filter_changed("보드07") if hasattr(win, "on_filter_changed") else None
            win.on_filter_show_only()
        self.assertEqual(len(c.checked), N // 50 + 0, c.checked[:3])
        win.filter_edit.setText("")
        win.on_filter_changed("") if hasattr(win, "on_filter_changed") else None
        with _timed("↕ 정렬"):
            win.on_sort_datasets()
        labels = [r.label for r in mf.sheets if r.label.startswith("보드")]
        grp = [r for r in mf.sheets if r.label == "보드00"]
        f = [r.dataset.freq_hz for r in grp]
        self.assertEqual(f, sorted(f))
        win._history_flush()
        with _timed("Ctrl+Z / Ctrl+Y"):
            win.on_undo()
            win.on_redo()
        with _timed("Ctrl+C / Ctrl+V 100개"):
            cut = [r.sheet_name for r in mf.sheets if r.ok][:100]
            n0 = len(mf.sheets)
            win._copy_names(cut)
            win.on_paste()
        self.assertEqual(len(mf.sheets), n0 + 100)
        d = tempfile.mkdtemp()
        with _timed("프로젝트 저장 (.pam)"):
            path = win.on_save_project(path=os.path.join(d, "stress.pam"))
        from measurement.project import load_project
        with _timed("프로젝트 열기"):
            mf2 = load_project(path)
        self.assertEqual(len(mf2.sheets), len(mf.sheets))
        win.set_all_checked(True)
        win.refresh(rerender=True)
        with _timed("Excel 내보내기 (600 곡선)"):
            xp = win.export_excel(os.path.join(d, "stress"))
        from openpyxl import load_workbook
        wb = load_workbook(xp)
        for ws in wb.worksheets:
            for ch in ws._charts:
                self.assertLessEqual(len(ch.series), 255, "Excel chart limit is 255 series")
        with _timed("PNG 저장"):
            win.save_all_png(os.path.join(d, "stress.png"))
        print("\n".join(f"  {k}: {v:.2f}s" for k, v in TIMES.items()))


if __name__ == "__main__":
    unittest.main()
