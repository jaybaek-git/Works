"""PA tab + S-Parameter tab in one window (fake Qt, headless)."""
import importlib.util
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


@unittest.skipIf(importlib.util.find_spec("PySide6") is not None, "real PySide6 -> covered by --smoke-test")
class TestSuite(unittest.TestCase):
    def test_tabs_and_both_tools(self):
        import matplotlib
        matplotlib.use("Agg")
        import fake_qt
        fake_qt.install()
        from app.controller import AppController
        from sparam.app.controller import Controller as SPC
        from sparam.ui.main_window import MainWindow as SPWindow
        from sparam.ui.smoke_test import run_smoke_test as sp_smoke
        from ui.main_window import MainWindow
        from ui.suite_window import SuiteWindow
        settings = fake_qt.QSettings()
        pa = MainWindow(AppController(sim_root=os.path.join(ROOT, "data", "example", "simulation")), settings)
        sp = SPWindow(SPC(), fake_qt.QSettings())
        suite = SuiteWindow(pa, sp, settings)
        self.assertEqual(suite.tabs.count(), 2)
        self.assertTrue(suite.windowTitle().startswith("RF PA Analyzer v"))
        self.assertIn("PA", suite.windowTitle())
        suite.show_tool("sparam")
        self.assertIs(suite.current_tool, sp)
        self.assertIn("S-Parameter", suite.windowTitle())
        self.assertEqual(settings.value("suite/tab"), 1)
        rc, report = sp_smoke(fake_qt.QApplication, sp)          # S-Parameter tool works inside the suite
        self.assertEqual(rc, 0, report)
        suite.show_tool("pa")
        pa.open_file(os.path.join(ROOT, "data", "example", "Measurement_Example.xlsx"))
        self.assertIn("Measurement_Example.xlsx", suite.windowTitle())
        # both tools have their own data; S-Parameter loaders don't touch PA modules
        self.assertEqual(len(pa.c.measurement.datasets), 5)
        import app.controller as pa_ctrl
        import sparam.app.controller as sp_ctrl
        self.assertIsNot(pa_ctrl, sp_ctrl)


    def test_one_project_for_both_tabs(self):
        """Save PA (pasted + renamed datasets) and S-Parameter (files, colours, markers) in ONE .pam,
        open it in a fresh program -> everything is back, including the latest names."""
        import tempfile
        import matplotlib
        matplotlib.use("Agg")
        import fake_qt
        fake_qt.install()
        from app.controller import AppController
        from sparam.app.controller import Controller as SPC
        from sparam.ui.main_window import MainWindow as SPWindow
        import ui.main_window as mw
        from ui.suite_window import SuiteWindow
        sim = os.path.join(ROOT, "data", "example", "simulation")

        def make():
            st = fake_qt.QSettings()
            pa, sp = mw.MainWindow(AppController(sim_root=sim), st), SPWindow(SPC(), fake_qt.QSettings())
            for w in [pa] + pa.views:
                w.render = lambda *a: None
            return pa, sp, SuiteWindow(pa, sp, st)
        pa, sp, _suite = make()
        pa.open_file(os.path.join(ROOT, "data", "example", "Measurement_Example.xlsx"))
        ds = pa.c.measurement.sheet("3.6GHz").dataset
        x, g = ds.xy("pout", "gain")
        _x, e = ds.xy("pout", "pae")
        tsv = "Pout\tGain\tPAE\n" + "\n".join(f"{a}\t{b}\t{c}" for a, b, c in zip(x, g, e))
        for i in range(45):
            pa.paste_text(tsv, ask_freq=False, name=f"D{i}", freq_hz=3.6e9)
        sp.on_example()
        uid = sp.store.entries[1].uid
        sp.build_file_menu(uid)[1]["color:#000000"].trigger()
        sp.panes[0].c.add_marker(3.6e9)
        n0 = len(pa.c.measurement.sheets)
        proj = os.path.join(tempfile.mkdtemp(), "both.pam")
        orig_save, orig_text = mw.QFileDialog.getSaveFileName, mw.QInputDialog.getText
        try:
            mw.QFileDialog.getSaveFileName = staticmethod(lambda *a, **k: (proj, ""))
            self.assertEqual(pa.on_save_project(), proj)
            pa2, sp2, _s2 = make()                           # reopen, add more, rename several, save again
            pa2.open_file(proj)
            self.assertEqual(len(pa2.c.measurement.sheets), n0)
            self.assertEqual(len(sp2.store.entries), len(sp.store.entries))
            for i in range(5):
                pa2.paste_text(tsv, ask_freq=False, name=f"NEW{i}", freq_hz=3.7e9)
            names = [r.sheet_name for r in pa2.c.measurement.sheets][:3]
            mw.QInputDialog.getText = staticmethod(lambda *a, **k: ("바꾼이름", True))
            pa2.on_batch_rename(names)
            self.assertEqual(pa2.on_save_project(), proj)
            pa3, sp3, _s3 = make()
            pa3.open_file(proj)
        finally:
            mw.QFileDialog.getSaveFileName, mw.QInputDialog.getText = orig_save, orig_text
        self.assertEqual(len(pa3.c.measurement.sheets), n0 + 5)
        self.assertEqual([pa3.c.measurement.sheet(n).label for n in names], ["바꾼이름"] * 3)
        self.assertEqual(sp3.c.entry(uid).color, "#000000")
        self.assertEqual(sp3.panes[0].c.markers_hz, [3.6e9])
        self.assertEqual([e.data.name for e in sp3.store.entries], [e.data.name for e in sp.store.entries])

    def test_save_survives_a_locked_file(self):
        """os.replace refused (file locked by DRM / antivirus) -> written in place, verified, .bak kept."""
        import tempfile
        from unittest import mock
        from measurement import project
        from measurement.loader import MeasurementFile
        from excel.reader import RawSheet
        from excel.sheet_parser import parse_sheet
        from core.models import Source
        mf = MeasurementFile("x")
        raw = RawSheet("A", [["Pout", "Gain", "PAE"], [30, 14, 20], [31, 13.9, 22]], "x")
        mf.sheets.append(parse_sheet(raw, Source.MEASUREMENT))
        path = os.path.join(tempfile.mkdtemp(), "p.pam")
        project.save_project(mf, path)
        mf.sheets[0].display_name = "새이름"
        with mock.patch("os.replace", side_effect=PermissionError("locked")), mock.patch("time.sleep"):
            project.save_project(mf, path)
        self.assertEqual(project.load_project(path).sheets[0].display_name, "새이름")
        self.assertTrue(os.path.isfile(path + ".bak"))


    def test_copy_paste_datasets_between_two_programs(self):
        """Ctrl+C on several datasets in one program, Ctrl+V in a SECOND, fresh program:
        exactly those datasets arrive (name, FREQ, numbers, style). Same for S-Parameter files."""
        import matplotlib
        matplotlib.use("Agg")
        import fake_qt
        fake_qt.install()
        from app.controller import AppController
        from sparam.app.controller import Controller as SPC
        from sparam.ui.main_window import MainWindow as SPWindow
        import ui.main_window as mw
        sim = os.path.join(ROOT, "data", "example", "simulation")

        def pa():
            w = mw.MainWindow(AppController(sim_root=sim), fake_qt.QSettings())
            for v in [w] + w.views:
                v.render = lambda *a: None
            return w
        a = pa()
        a.open_file(os.path.join(ROOT, "data", "example", "Measurement_Example.xlsx"))
        a.c.rename_sheet("3.6GHz", "보드A")
        a.c.set_styles(["3.6GHz"], color="#000000", linewidth=2.4)
        for i in range(a.data_list.count()):
            it = a.data_list.item(i)
            it.setSelected(it.data(256) in ("3.4GHz", "3.6GHz"))
        a.on_copy_datasets()                                  # Ctrl+C in the list
        self.assertIn("보드A", fake_qt.QGuiApplication.clipboard().text())   # Excel gets the numbers
        b = pa()                                              # another copy of the program, empty
        b.on_paste()                                          # Ctrl+V
        self.assertEqual(len(b.c.measurement.sheets), 2)
        labels = sorted(r.label for r in b.c.measurement.sheets)
        self.assertEqual(labels, sorted([a.c.measurement.sheet("3.4GHz").label, "보드A"]))
        src, dst = a.c.measurement.sheet("3.6GHz"), [r for r in b.c.measurement.sheets if r.label == "보드A"][0]
        self.assertEqual(dst.dataset.freq_hz, src.dataset.freq_hz)
        self.assertEqual(list(dst.dataset.columns["pae"]), list(src.dataset.columns["pae"]))
        self.assertEqual(b.c.style_of_dataset(dst.sheet_name).get("color"), "#000000")
        self.assertEqual(sorted(b.c.checked), sorted(r.sheet_name for r in b.c.measurement.sheets))
        b.on_paste()                                          # pasting again -> two more (unique keys)
        self.assertEqual(len(b.c.measurement.sheets), 4)
        sa, sb = SPWindow(SPC(), fake_qt.QSettings()), SPWindow(SPC(), fake_qt.QSettings())
        sa.on_example()
        uids = [e.uid for e in sa.store.entries][:2]
        sa.c.set_file_style(uids[0], color="#123456")
        for i in range(sa.file_list.count()):
            it = sa.file_list.item(i)
            it.setSelected(it.data(256) in uids)
        sa.on_copy_files()
        sb.on_paste_files()
        self.assertEqual([e.data.name for e in sb.store.entries], [sa.c.entry(u).data.name for u in uids])
        self.assertEqual(sb.store.entries[0].color, "#123456")
        self.assertEqual(list(sb.store.entries[1].data.freq_hz), list(sa.c.entry(uids[1]).data.freq_hz))


if __name__ == "__main__":
    unittest.main(verbosity=2)
