"""Real-Qt GUI smoke test (runs only when PySide6 is installed).

Uses the offscreen platform so it also works without a visible window.
Full output is saved to build/smoke_test_output.txt for diagnosis.
"""
import importlib.util
import os
import subprocess
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


@unittest.skipUnless(importlib.util.find_spec("PySide6"), "PySide6 not installed")
@unittest.skipIf(os.environ.get("PA_SKIP_GUI_SMOKE"), "skipped by build_exe.bat (exe is smoke-tested after build)")
class TestRealQtSmoke(unittest.TestCase):
    def test_smoke(self):
        env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
        env.setdefault("QT_QPA_PLATFORM", "offscreen")
        p = subprocess.run([sys.executable, os.path.join(ROOT, "src", "main.py"), "--smoke-test"],
                           env=env, capture_output=True, timeout=300)
        out = p.stdout.decode("utf-8", "replace") + "\n--- stderr ---\n" + p.stderr.decode("utf-8", "replace")
        log_dir = os.path.join(ROOT, "build")
        os.makedirs(log_dir, exist_ok=True)
        log = os.path.join(log_dir, "smoke_test_output.txt")
        with open(log, "w", encoding="utf-8") as f:
            f.write(out)
        self.assertEqual(p.returncode, 0,
                         f"GUI smoke test failed (exit {p.returncode}). Full log: {log}\n" + out[-2500:])


if __name__ == "__main__":
    unittest.main(verbosity=2)
