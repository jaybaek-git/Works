"""Run the real MainWindow + GUI smoke test on a fake Qt (when PySide6 is absent).

Checks the Python wiring of the UI layer headless. With PySide6 installed this
test is skipped and test_ui_real.py runs the same smoke test on real Qt.
"""
import importlib.util
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

HAS_QT = importlib.util.find_spec("PySide6") is not None


@unittest.skipIf(HAS_QT, "real PySide6 available -> covered by test_ui_real")
class TestUiWiringFakeQt(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import matplotlib
        matplotlib.use("Agg")
        import fake_qt
        fake_qt.install()
        cls.fake = fake_qt
        from app.controller import AppController
        from ui.main_window import MainWindow
        cls.AppController, cls.MainWindow = AppController, MainWindow

    def make(self):
        self.fake.QMessageBox.calls.clear()
        c = self.AppController(sim_root=os.path.join(ROOT, "data", "example", "simulation"))
        return c, self.MainWindow(c)

    def test_paste_dialog_flow(self):
        from ui import main_window as mw
        c, win = self.make()
        win.open_file(os.path.join(ROOT, "data", "example", "Measurement_Example.xlsx"))
        tsv = "Pout\tGain\tPAE\n30\t14\t20\n31\t13.9\t22\n"

        class FakeDialog:
            ok = True

            def __init__(self, result, parent=None):
                self.result = result

            def exec(self):
                return FakeDialog.ok

            def values(self):
                return "Board X", 3.7e9
        orig = mw.PasteDialog
        mw.PasteDialog = FakeDialog
        try:
            win.paste_text(tsv)                         # dialog -> name + FREQ applied
            self.assertEqual(c.sheet_result.label, "Board X")
            self.assertAlmostEqual(c.current_freq_hz, 3.7e9)
            self.assertIn(c.sheet_name, c.checked)
            n = len(c.measurement.sheets)
            FakeDialog.ok = False
            win.paste_text(tsv)                         # cancel -> nothing added
            self.assertEqual(len(c.measurement.sheets), n)
        finally:
            mw.PasteDialog = orig
            FakeDialog.ok = True

    def test_smoke_test_passes(self):
        from ui.smoke_test import run_smoke_test
        c, win = self.make()
        rc = run_smoke_test(self.fake.QApplication, win)
        self.assertEqual(rc, 0)
        crit = [t for k, t in self.fake.QMessageBox.calls if k == "critical"]
        self.assertEqual(crit, [])

    @staticmethod
    def _item(win, name):
        return next(win.data_list.item(i) for i in range(win.data_list.count())
                    if win.data_list.item(i).data(256) == name)

    def test_column_mapping_and_freq_override(self):
        from ui.column_mapping_dialog import ColumnMappingDialog
        from ui import main_window as mw
        c, win = self.make()
        win.open_file(os.path.join(ROOT, "data", "example", "Measurement_Example.xlsx"))
        # select the broken 'Notes' sheet -> no crash, error shown
        win.data_list.setCurrentItem(self._item(win, "Notes"))
        self.assertEqual(c.sheet_name, "Notes")
        self.assertIn("Header", win.msg_view.toPlainText())
        # dialog on a good sheet: auto mapping preselected
        win.data_list.setCurrentItem(self._item(win, "3.5GHz"))
        dlg = ColumnMappingDialog(c.sheet_result)
        hr, mapping = dlg.values()
        self.assertEqual(hr, 8)
        self.assertEqual(mapping["pout"], 0)
        self.assertEqual(mapping["pae"], 2)
        # swap PAE/Gain via the dialog combos and apply through the window
        dlg.combos["pae"].setCurrentIndex(dlg.combos["pae"].findData(1))
        dlg.combos["gain"].setCurrentIndex(dlg.combos["gain"].findData(2))
        orig_cls = mw.ColumnMappingDialog
        mw.ColumnMappingDialog = lambda *a, **k: type("D", (), {"exec": lambda s: 1, "values": lambda s: dlg.values()})()
        try:
            win.on_column_mapping()
        finally:
            mw.ColumnMappingDialog = orig_cls
        self.assertTrue(c.sheet_result.user_mapping)
        self.assertTrue(25 < max(c.measurement_dataset.columns["pae"]) < 35)  # now gain values
        # FREQ override
        mw.QInputDialog.getText = staticmethod(lambda *a, **k: ("3.55 GHz", True))
        win.on_set_freq()
        self.assertAlmostEqual(c.current_freq_hz, 3.55e9)
        self.assertIn("3.55 GHz", self._item(win, "3.5GHz").text())
        self.assertTrue(c.sheet_result.user_mapping)  # mapping kept after FREQ override
        # bad file
        win.open_file(os.path.join(ROOT, "README.md"))
        self.assertTrue(any(k == "warning" for k, _ in self.fake.QMessageBox.calls))
        self.assertEqual(c.measurement.file_name, "Measurement_Example.xlsx")


if __name__ == "__main__":
    unittest.main(verbosity=2)
