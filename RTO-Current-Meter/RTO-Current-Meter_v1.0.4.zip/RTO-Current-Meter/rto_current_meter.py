# -*- coding: utf-8 -*-
"""
RTO Current Meter v1.0.4
R&S RTO2000 (RTO2044 등) 오실로스코프에서 전류 측정값을 실시간으로 읽어
PC 화면에 디지털 숫자로 크게 띄워주는 프로그램.

- 장비에는 아무것도 설치하지 않음 (LAN, SCPI raw socket 5025 포트 사용)
- 오실로스코프 자체의 자동 측정(MEASurement 슬롯)을 이용:
  채널 / 측정 종류(평균, 최대 ...) / 읽는 시간 구간(Gate)을 PC에서 설정
- IP 칸에 demo 라고 입력하면 장비 없이 화면 동작 확인 가능
"""
import array
import csv
import datetime
import json
import math
import os
import queue
import random
import socket
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

APP_NAME = "RTO Current Meter"
VERSION = "v1.0.4"

MEAS_TYPES = [
    ("평균 (MEAN)", "MEAN"),
    ("RMS", "RMS"),
    ("최대 (MAX)", "MAXimum"),
    ("최소 (MIN)", "MINimum"),
    ("High (Top)", "HIGH"),
    ("Low (Base)", "LOW"),
    ("Amplitude", "AMPLitude"),
    ("Peak-Peak", "PDELta"),
]
TIME_UNITS = {"ns": 1e-9, "µs": 1e-6, "ms": 1e-3, "s": 1.0}
CALC_MODES = ["PC 계산 (파형 직접 읽기, 권장)", "장비 측정 (Meas 슬롯)"]
TRIG_MODES = ["Auto (권장)", "Normal", "장비 설정 유지"]
CONV_MODES = ["A 그대로 (전류 프로브)", "션트 저항 (Ω)", "배율 (A/V)"]
DISP_UNITS = ["자동", "A", "mA", "µA"]
INVALID_LIMIT = 1e30  # R&S 장비는 결과 없음 시 9.91E37 반환


def settings_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(base, "RTOCurrentMeter")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "settings.json")


DEFAULTS = {
    "host": "192.168.0.10",
    "port": 5025,
    "channel": 1,
    "meas_label": MEAS_TYPES[0][0],
    "slot": 8,
    "calc_mode": CALC_MODES[0],
    "trk_on": True,
    "trk_start": "200",
    "trk_ratio": "90",
    "trk_floor": "100",
    "trk_settrig": True,
    "trk_mode": TRIG_MODES[0],
    "gate_on": True,
    "gate_start": "10",
    "gate_stop": "50",
    "gate_unit": "µs",
    "conv_mode": CONV_MODES[0],
    "conv_value": "1",
    "interval_ms": 200,
    "disp_unit": "자동",
    "digits": 2,
    "topmost": False,
    "show_settings": True,
    "geometry": "",
}


def load_settings():
    s = dict(DEFAULTS)
    try:
        with open(settings_path(), "r", encoding="utf-8") as f:
            s.update(json.load(f))
    except Exception:
        pass
    return s


def save_settings(s):
    try:
        with open(settings_path(), "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


# ----------------------------------------------------------------- 통신
class ScpiSocket:
    """SCPI raw socket (TCP 5025). VISA 설치 필요 없음."""

    def __init__(self, host, port=5025, timeout=10.0):
        self.sock = socket.create_connection((host, int(port)), timeout=timeout)
        self.sock.settimeout(timeout)
        self.timeout = timeout
        self.buf = b""

    def write(self, cmd):
        self.sock.sendall((cmd + "\n").encode("ascii"))

    def query(self, cmd):
        self.write(cmd)
        while b"\n" not in self.buf:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise ConnectionError("장비와의 연결이 끊어졌습니다.")
            self.buf += chunk
        line, self.buf = self.buf.split(b"\n", 1)
        return line.decode("ascii", "replace").strip()

    def _read_exact(self, n):
        while len(self.buf) < n:
            chunk = self.sock.recv(1 << 20)
            if not chunk:
                raise ConnectionError("장비와의 연결이 끊어졌습니다.")
            self.buf += chunk
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def query_block(self, cmd):
        """IEEE488.2 binary block (#<n><len><data>) 수신."""
        self.write(cmd)
        while True:
            c = self._read_exact(1)
            if c == b"#":
                break
        nd = int(self._read_exact(1))
        if nd == 0:  # 길이 미정 블록: 줄바꿈까지
            data = b""
            while b"\n" not in self.buf:
                chunk = self.sock.recv(1 << 20)
                if not chunk:
                    raise ConnectionError("장비와의 연결이 끊어졌습니다.")
                self.buf += chunk
            data, self.buf = self.buf.split(b"\n", 1)
            return data
        ln = int(self._read_exact(nd))
        data = self._read_exact(ln)
        if self.buf[:1] == b"\n":
            self.buf = self.buf[1:]
        else:
            try:
                self.sock.settimeout(0.2)
                self._read_exact(1)
            except Exception:
                pass
            finally:
                self.sock.settimeout(self.timeout)
        return data

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass


class DemoScope:
    """장비 없이 화면 확인용 가상 오실로스코프 (IP = demo)."""

    def __init__(self):
        self.main = "MEAN"
        self.start = -1e-6
        self.stop = 1e-6
        self.trig = 0.0
        self.t0 = time.time()
        self.last = None

    def _amp(self):
        # 시간에 따라 0.2 A → 1.2 A → 0.2 A 로 천천히 변하는 펄스 전류
        return 0.7 + 0.5 * math.sin((time.time() - self.t0) / 8)

    def write(self, cmd):
        c = cmd.upper()
        val = cmd.split(" ", 1)[1] if " " in cmd else ""
        if ":MAIN " in c:
            self.main = val.strip().upper()
        elif ":ABSOLUTE:START " in c:
            self.start = float(val)
        elif ":ABSOLUTE:STOP " in c:
            self.stop = float(val)
        elif c.startswith("TRIGGER1:LEVEL") and ":VALUE " in c:
            self.trig = float(val)
        elif c.startswith("TRIGGER1:MODE "):
            self.mode = "AUTO" if val.strip().upper().startswith("AUTO") else "NORM"

    def query(self, cmd):
        c = cmd.upper()
        time.sleep(0.01)
        if c == "*IDN?":
            return "Rohde&Schwarz,RTO2044 (DEMO),1332.2531K44/000000,5.50"
        if c.startswith("SYST") and "ERR" in c:
            return '0,"No error"'
        if c == "*OPC?":
            return "1"
        if c.startswith("TRIGGER1:LEVEL") and c.endswith("?"):
            return "%.6E" % self.trig
        if c == "TRIGGER1:MODE?":
            return getattr(self, "mode", "AUTO")
        if ":DATA:HEADER?" in c:
            return "-5.0E-05,5.0E-05,20000,1"
        if ":ABSOLUTE:START?" in c:
            return "%.6E" % self.start
        if ":ABSOLUTE:STOP?" in c:
            return "%.6E" % self.stop
        if ":RESULT" in c:
            base = 0.850 + 0.02 * math.sin((time.time() - self.t0) / 3)
            noise = random.gauss(0, 0.002)
            factor = {"MAXIMUM": 1.05, "MINIMUM": 0.95, "RMS": 1.01,
                      "AMPLITUDE": 0.84, "PDELTA": 0.9, "LOW": 0.01}.get(self.main, 1.0)
            return "%.6E" % ((base + noise) * factor)
        return ""

    def query_block(self, cmd):
        # 가상 펄스 파형: -50 µs ~ 50 µs, 펄스 ON 0 ~ 40 µs
        n = 20000
        xs, xe = -50e-6, 50e-6
        dt = (xe - xs) / n
        base = self._amp()
        if self.trig > base and self.last is not None and getattr(self, "mode", "AUTO") == "NORM":
            return self.last  # 트리거 레벨이 펄스보다 높으면 새 파형 없음 (Normal 모드)
        vals = array.array("f")
        for i in range(n):
            t = xs + i * dt
            v = base if 0 <= t < 40e-6 else 0.02
            vals.append(v + random.gauss(0, 0.004))
        self.last = vals.tobytes()
        return self.last

    def close(self):
        pass


def calc_stat(seg, meas):
    n = len(seg)
    if n == 0:
        return float("nan")
    if meas == "MEAN":
        return math.fsum(seg) / n
    if meas == "RMS":
        return math.sqrt(math.fsum(x * x for x in seg) / n)
    mx, mn = max(seg), min(seg)
    if meas == "MAXimum":
        return mx
    if meas == "MINimum":
        return mn
    if meas == "PDELta":
        return mx - mn
    # HIGH / LOW / AMPLitude: 중간값 기준 위/아래 그룹의 중앙값
    mid = (mx + mn) / 2
    hi = sorted(x for x in seg if x >= mid)
    lo = sorted(x for x in seg if x < mid) or hi
    high = hi[len(hi) // 2]
    low = lo[len(lo) // 2]
    if meas == "HIGH":
        return high
    if meas == "LOW":
        return low
    return high - low


class Worker(threading.Thread):
    """모든 장비 통신을 하나의 스레드에서 처리 (명령이 섞이지 않도록)."""

    def __init__(self, out_q):
        super().__init__(daemon=True)
        self.out = out_q
        self.tasks = queue.Queue()
        self.inst = None
        self.polling = False
        self.interval = 0.2
        self.slot = 8
        self.cfg = None
        self.trk = None
        self.alive = True

    def post(self, *msg):
        self.out.put(msg)

    def _close(self):
        if self.inst:
            self.inst.close()
        self.inst = None
        self.polling = False

    def _errors(self):
        errs = []
        for _ in range(20):
            e = self.inst.query("SYSTem:ERRor?")
            if e.startswith("0") or e.startswith("+0"):
                break
            errs.append(e)
        return errs

    def _do(self, task):
        kind = task[0]
        if kind == "connect":
            _, host, port = task
            self._close()
            self.post("status", "연결 중... %s" % host, "#b8860b")
            if host.strip().lower() == "demo":
                self.inst = DemoScope()
            else:
                self.inst = ScpiSocket(host.strip(), port)
            idn = self.inst.query("*IDN?")
            self.inst.write("*CLS")
            self.post("connected", idn)
        elif kind == "disconnect":
            self._close()
            self.post("disconnected")
        elif kind == "apply":
            cfg = task[1]
            if not self.inst:
                raise ConnectionError("먼저 장비에 연결하세요.")
            self.cfg = cfg
            if cfg["pc_calc"]:
                self._apply_pc(cfg)
                return
            m = cfg["slot"]
            cmds = [
                "MEASurement%d:ENABle ON" % m,
                "MEASurement%d:SOURce C%dW1" % (m, cfg["channel"]),
                "MEASurement%d:MAIN %s" % (m, cfg["meas"]),
            ]
            if cfg["gate_on"]:
                cmds += [
                    "MEASurement%d:GATE:MODE ABS" % m,
                    "MEASurement%d:GATE:ABSolute:STARt %.9E" % (m, cfg["t_start"]),
                    "MEASurement%d:GATE:ABSolute:STOP %.9E" % (m, cfg["t_stop"]),
                    # 시작/끝 순서에 따른 장비 자동 보정 방지용으로 한 번 더 설정
                    "MEASurement%d:GATE:ABSolute:STARt %.9E" % (m, cfg["t_start"]),
                    "MEASurement%d:GATE:STATe ON" % m,
                ]
            else:
                cmds += ["MEASurement%d:GATE:STATe OFF" % m]
            for c in cmds:
                self.inst.write(c)
            self.inst.query("*OPC?")
            errs = self._errors()
            actual = None
            if cfg["gate_on"]:
                try:
                    a = float(self.inst.query("MEASurement%d:GATE:ABSolute:STARt?" % m))
                    b = float(self.inst.query("MEASurement%d:GATE:ABSolute:STOP?" % m))
                    actual = (a, b)
                except Exception:
                    actual = None
            self.slot = m
            self.post("applied", errs, actual)
        elif kind == "track_start":
            t = dict(task[1])
            if not self.inst:
                raise ConnectionError("먼저 장비에 연결하세요.")
            ch = t["channel"]
            self.inst.write("RUN")  # 스코프가 STOP 상태면 연속 측정으로
            if t["settrig"]:
                for c in ["TRIGger1:SOURce CHAN%d" % ch, "TRIGger1:TYPE EDGE",
                          "TRIGger1:EDGE:SLOPe POSitive"]:
                    self.inst.write(c)
            if t["mode"] == "AUTO":
                self.inst.write("TRIGger1:MODE AUTO")
            elif t["mode"] == "NORM":
                self.inst.write("TRIGger1:MODE NORMal")
            try:
                t["mode_actual"] = self.inst.query("TRIGger1:MODE?").upper()
            except Exception:
                t["mode_actual"] = ""
            t["level"] = max(t["start"] * t["ratio"], t["floor"])
            t["last_set"] = 0.0
            t["last_sig"] = None
            t["stale_since"] = None
            self.trk = t
            self._set_level(t["level"], "측정 시작 레벨")
            errs = self._errors()
            if errs:
                self.post("error", "트리거 설정 오류: " + " / ".join(errs))
        elif kind == "track_stop":
            self.trk = None
        elif kind == "poll":
            self.polling = task[1]
            self.interval = task[2]

    # ---------- 트리거 레벨 자동 추적 ----------
    def _set_level(self, level, why):
        t = self.trk
        self.inst.write("TRIGger1:LEVel%d:VALue %.6E" % (t["channel"], level))
        t["level"] = level
        t["last_set"] = time.time()
        actual = None
        try:
            actual = float(self.inst.query("TRIGger1:LEVel%d:VALue?" % t["channel"]))
        except Exception:
            pass
        self.post("trig", level, why, actual)

    def _track(self, v, sig):
        t = self.trk
        if not t:
            return
        now = time.time()
        if sig is not None and sig == t["last_sig"]:
            # 파형이 그대로 = 새 트리거 없음
            if t["stale_since"] is None:
                t["stale_since"] = now
            if now - t["stale_since"] < 1.5:
                return  # 스코프 갱신 주기가 느린 경우 오판 방지
            auto = t.get("mode_actual", "").startswith("AUTO")
            self.post("stale", "auto" if auto else True)
            if auto:
                return  # Auto 모드에서 파형이 안 바뀌면 스코프 STOP 상태 → 레벨은 건드리지 않음
            if now - t["last_set"] > 1.0:
                new = t["floor"]  # 바로 최저 레벨로 내려 트리거를 다시 잡은 뒤 추적 재개
                if new < t["level"] * 0.999:
                    self._set_level(new, "트리거 없음 → 최저 레벨로 내려 다시 잡음")
            return
        t["last_sig"] = sig
        t["stale_since"] = None
        self.post("stale", False)
        if not math.isfinite(v) or v <= 0:
            return
        target = max(v * t["ratio"], t["floor"])
        if abs(target - t["level"]) > 0.05 * max(t["level"], 1e-12) and now - t["last_set"] > 0.3:
            self._set_level(target, "측정값 따라 이동")

    # ---------- PC 계산 모드 ----------
    def _apply_pc(self, cfg):
        ch = cfg["channel"]
        self.inst.write("FORMat:DATA REAL,32")
        self.inst.write("FORMat:BORDer LSBFirst")
        errs = self._errors()
        self.export_part = False
        if cfg["gate_on"]:
            # 전송량 줄이기: 구간 부분만 받아오도록 시도 (안 되면 전체 파형을 받아 PC에서 자름)
            self.inst.write("EXPort:WAVeform:SCOPe MANual")
            self.inst.write("EXPort:WAVeform:STARt %.9E" % (cfg["t_start"] - 1e-9))
            self.inst.write("EXPort:WAVeform:STOP %.9E" % (cfg["t_stop"] + 1e-9))
            self.inst.query("*OPC?")
            if self._errors():
                self.inst.write("EXPort:WAVeform:SCOPe WFM")
                self.inst.write("*CLS")
            else:
                self.export_part = True
        else:
            self.inst.write("EXPort:WAVeform:SCOPe WFM")
            self.inst.query("*OPC?")
            self._errors()
        hdr = self.inst.query("CHANnel%d:DATA:HEADer?" % ch)
        info = None
        try:
            xs, xe, n = [float(x) for x in hdr.split(",")[:3]]
            info = (xs, xe, int(n))
        except Exception:
            errs.append("파형 헤더 읽기 실패: " + hdr)
        self.post("applied_pc", errs, info, self.export_part)

    def _read_pc(self, cfg):
        ch = cfg["channel"]
        hdr = self.inst.query("CHANnel%d:DATA:HEADer?" % ch)
        parts = hdr.split(",")
        xs, xe, n = float(parts[0]), float(parts[1]), int(float(parts[2]))
        vps = int(float(parts[3])) if len(parts) > 3 else 1
        raw = self.inst.query_block("CHANnel%d:DATA?" % ch)
        self.last_sig = hash(raw)
        vals = array.array("f")
        vals.frombytes(raw[: len(raw) // 4 * 4])
        if n <= 0 or len(vals) == 0:
            return float("nan"), "파형 데이터 없음 (채널이 꺼져 있거나 트리거 전)"
        if vps > 1:  # 피크검출/엔벨로프: 값 쌍
            n = len(vals) // vps
        dt = (xe - xs) / n
        if cfg["gate_on"]:
            t1, t2 = cfg["t_start"], cfg["t_stop"]
            if t2 < xs or t1 > xe:
                return float("nan"), "구간이 파형 범위(%s ~ %s) 밖입니다 - 스코프 시간축/Position 확인" % (
                    fmt_time(xs), fmt_time(xe))
            i1 = max(0, int(math.ceil((t1 - xs) / dt - 1e-9)))
            i2 = min(n, int(math.floor((t2 - xs) / dt + 1e-9)) + 1)
            if i2 <= i1:
                return float("nan"), "구간 안에 샘플이 없습니다 (구간을 넓히세요)"
            seg = vals[i1 * vps: i2 * vps]
            clipped = t1 < xs or t2 > xe
        else:
            seg = vals
            clipped = False
        v = calc_stat(seg, cfg["meas"])
        diag = "파형 %s ~ %s · 구간 내 %s pt" % (fmt_time(xs), fmt_time(xe), format(len(seg) // vps, ","))
        if clipped:
            diag += " · ⚠ 구간 일부가 파형 범위 밖"
        return v, diag

    def run(self):
        while self.alive:
            t0 = time.time()
            try:
                while True:
                    try:
                        task = self.tasks.get_nowait()
                    except queue.Empty:
                        break
                    self._do(task)
                if self.polling and self.inst and self.cfg and self.cfg["pc_calc"]:
                    v, diag = self._read_pc(self.cfg)
                    self.post("value", v, time.time())
                    self._track(v, self.last_sig)
                    if diag:
                        self.post("diag", diag)
                elif self.polling and self.inst:
                    r = self.inst.query("MEASurement%d:RESult:ACTual?" % self.slot)
                    try:
                        v = float(r)
                    except ValueError:
                        v = float("nan")
                    if not math.isfinite(v) or abs(v) > INVALID_LIMIT:
                        v = float("nan")
                    self.post("value", v, time.time())
                    self._track(v, r)
            except (socket.timeout, TimeoutError):
                self.post("error", "응답 시간 초과 - 연결을 다시 하세요. (IP / LAN 확인)")
                self._close()
                self.post("disconnected")
            except Exception as e:
                self.post("error", str(e))
                if isinstance(e, (ConnectionError, OSError)):
                    self._close()
                    self.post("disconnected")
            wait = (self.interval if self.polling else 0.05) - (time.time() - t0)
            if wait > 0:
                time.sleep(wait)


# ----------------------------------------------------------------- 화면
def fmt_time(sec):
    a = abs(sec)
    if a >= 1:
        return "%g s" % sec
    if a >= 1e-3:
        return "%g ms" % round(sec * 1e3, 6)
    if a >= 1e-6:
        return "%g µs" % round(sec * 1e6, 6)
    return "%g ns" % round(sec * 1e9, 6)


class App:
    def __init__(self, root):
        self.root = root
        self.s = load_settings()
        self.q = queue.Queue()
        self.worker = Worker(self.q)
        self.worker.start()
        self.connected = False
        self.running = False
        self.log_file = None
        self.log_writer = None
        self.reset_stats()

        root.title("%s %s" % (APP_NAME, VERSION))
        root.minsize(380, 200)
        if self.s.get("geometry"):
            try:
                root.geometry(self.s["geometry"])
            except Exception:
                pass
        else:
            root.geometry("760x700")

        style = ttk.Style()
        try:
            style.theme_use("vista")
        except Exception:
            pass
        ui_font = ("맑은 고딕", 9)
        root.option_add("*Font", ui_font)

        self.build_display()
        self.build_settings()
        self.root.after(10, self.apply_visibility)
        root.attributes("-topmost", bool(self.s["topmost"]))
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(50, self.pump)

    # --------------------------------------------- 큰 숫자 표시부
    def build_display(self):
        self.disp = tk.Frame(self.root, bg="#0b0f14")
        self.disp.pack(side="top", fill="both", expand=True)
        self.lbl_info = tk.Label(self.disp, text="", bg="#0b0f14", fg="#7d8a99",
                                 font=("맑은 고딕", 10), anchor="w")
        self.lbl_info.pack(side="top", fill="x", padx=10, pady=(6, 0))
        self.lbl_value = tk.Label(self.disp, text="---", bg="#0b0f14", fg="#39ff88",
                                  font=("Consolas", 60, "bold"))
        self.lbl_value.pack(side="top", fill="both", expand=True)
        self.lbl_stats = tk.Label(self.disp, text="", bg="#0b0f14", fg="#9aa7b4",
                                  font=("Consolas", 10), anchor="w")
        self.lbl_stats.pack(side="top", fill="x", padx=10)
        bar = tk.Frame(self.disp, bg="#0b0f14")
        bar.pack(side="bottom", fill="x", padx=6, pady=4)
        self.lbl_status = tk.Label(bar, text="연결 안 됨", bg="#0b0f14", fg="#c0504d",
                                   font=("맑은 고딕", 9), anchor="w")
        self.lbl_status.pack(side="left", fill="x", expand=True)
        self.btn_toggle_set = tk.Button(bar, text="설정 숨기기", command=self.toggle_settings,
                                        bg="#1c2530", fg="#c8d3de", relief="flat", padx=8)
        self.btn_toggle_set.pack(side="right")
        self.btn_run2 = tk.Button(bar, text="▶ 측정 시작", command=self.on_run,
                                  bg="#1f6f3f", fg="#ffffff", relief="flat", padx=10,
                                  activebackground="#2a8f52", activeforeground="#ffffff")
        self.btn_run2.pack(side="right", padx=6)
        self.var_top = tk.BooleanVar(value=bool(self.s["topmost"]))
        tk.Checkbutton(bar, text="항상 위", variable=self.var_top, command=self.on_topmost,
                       bg="#0b0f14", fg="#c8d3de", selectcolor="#1c2530",
                       activebackground="#0b0f14", activeforeground="#ffffff").pack(side="right", padx=6)
        self.disp.bind("<Configure>", self.on_resize)
        self.lbl_value.bind("<Double-Button-1>", lambda e: self.toggle_settings())

    def on_resize(self, event=None):
        w = max(self.disp.winfo_width(), 100)
        h = max(self.disp.winfo_height() - 80, 40)
        n = max(len(self.lbl_value.cget("text")), 8)
        size = int(min(h * 0.55, w / n * 1.45))
        size = max(14, min(size, 260))
        self.lbl_value.configure(font=("Consolas", size, "bold"))

    # --------------------------------------------- 설정부
    def build_settings(self):
        s = self.s
        f = ttk.Frame(self.root, padding=8)
        self.setf = f
        pad = dict(padx=4, pady=3)

        # 연결
        g1 = ttk.LabelFrame(f, text=" 장비 연결 (LAN) ", padding=6)
        g1.pack(fill="x", pady=(0, 4))
        ttk.Label(g1, text="IP").grid(row=0, column=0, sticky="e", **pad)
        self.var_host = tk.StringVar(value=s["host"])
        ttk.Entry(g1, textvariable=self.var_host, width=18).grid(row=0, column=1, **pad)
        ttk.Label(g1, text="Port").grid(row=0, column=2, sticky="e", **pad)
        self.var_port = tk.StringVar(value=str(s["port"]))
        ttk.Entry(g1, textvariable=self.var_port, width=6).grid(row=0, column=3, **pad)
        self.btn_conn = ttk.Button(g1, text="연결", command=self.on_connect, width=8)
        self.btn_conn.grid(row=0, column=4, **pad)
        self.lbl_idn = ttk.Label(g1, text="(IP에 demo 입력 시 장비 없이 테스트)", foreground="#666")
        self.lbl_idn.grid(row=1, column=0, columnspan=6, sticky="w", **pad)

        # 측정 설정
        g2 = ttk.LabelFrame(f, text=" 전류 읽는 위치 / 방식 ", padding=6)
        g2.pack(fill="x", pady=4)
        ttk.Label(g2, text="채널").grid(row=0, column=0, sticky="e", **pad)
        self.var_ch = tk.StringVar(value="CH%d" % s["channel"])
        ttk.Combobox(g2, textvariable=self.var_ch, values=["CH1", "CH2", "CH3", "CH4"],
                     width=6, state="readonly").grid(row=0, column=1, sticky="w", **pad)
        ttk.Label(g2, text="측정").grid(row=0, column=2, sticky="e", **pad)
        self.var_meas = tk.StringVar(value=s["meas_label"])
        ttk.Combobox(g2, textvariable=self.var_meas, values=[m[0] for m in MEAS_TYPES],
                     width=14, state="readonly").grid(row=0, column=3, sticky="w", **pad)
        ttk.Label(g2, text="장비 측정 슬롯").grid(row=0, column=4, sticky="e", **pad)
        self.var_slot = tk.StringVar(value=str(s["slot"]))
        ttk.Spinbox(g2, from_=1, to=8, textvariable=self.var_slot, width=4,
                    state="readonly").grid(row=0, column=5, sticky="w", **pad)

        self.var_gate = tk.BooleanVar(value=bool(s["gate_on"]))
        ttk.Checkbutton(g2, text="구간 지정 (Gate)", variable=self.var_gate,
                        command=self.update_gate_state).grid(row=1, column=0, columnspan=2, sticky="w", **pad)
        ttk.Label(g2, text="시작").grid(row=1, column=2, sticky="e", **pad)
        self.var_t1 = tk.StringVar(value=s["gate_start"])
        self.ent_t1 = ttk.Entry(g2, textvariable=self.var_t1, width=10)
        self.ent_t1.grid(row=1, column=3, sticky="w", **pad)
        ttk.Label(g2, text="끝").grid(row=1, column=4, sticky="e", **pad)
        self.var_t2 = tk.StringVar(value=s["gate_stop"])
        self.ent_t2 = ttk.Entry(g2, textvariable=self.var_t2, width=10)
        self.ent_t2.grid(row=1, column=5, sticky="w", **pad)
        self.var_tu = tk.StringVar(value=s["gate_unit"])
        self.cmb_tu = ttk.Combobox(g2, textvariable=self.var_tu, values=list(TIME_UNITS),
                                   width=4, state="readonly")
        self.cmb_tu.grid(row=1, column=6, sticky="w", **pad)
        ttk.Label(g2, text="※ 시간 기준 = 오실로스코프 화면의 트리거 지점(0 s). 음수 입력 가능.",
                  foreground="#666").grid(row=2, column=0, columnspan=7, sticky="w", **pad)
        ttk.Label(g2, text="계산 방식").grid(row=3, column=0, sticky="e", **pad)
        self.var_calc = tk.StringVar(value=s.get("calc_mode", CALC_MODES[0]))
        ttk.Combobox(g2, textvariable=self.var_calc, values=CALC_MODES, width=28,
                     state="readonly").grid(row=3, column=1, columnspan=4, sticky="w", **pad)
        ttk.Label(g2, text="(장비 측정 슬롯은 '장비 측정' 방식에서만 사용)",
                  foreground="#666").grid(row=3, column=5, columnspan=2, sticky="w", **pad)
        self.lbl_applied = ttk.Label(g2, text="", foreground="#1f6f3f")
        self.lbl_applied.grid(row=4, column=0, columnspan=7, sticky="w", **pad)

        # 트리거 자동 추적
        gt = ttk.LabelFrame(f, text=" 트리거 레벨 자동 추적 ", padding=6)
        gt.pack(fill="x", pady=4)
        self.var_trk = tk.BooleanVar(value=bool(s.get("trk_on", True)))
        ttk.Checkbutton(gt, text="사용", variable=self.var_trk).grid(row=0, column=0, sticky="w", **pad)
        ttk.Label(gt, text="시작 전류").grid(row=0, column=1, sticky="e", **pad)
        self.var_trk_start = tk.StringVar(value=s.get("trk_start", "200"))
        ttk.Entry(gt, textvariable=self.var_trk_start, width=7).grid(row=0, column=2, sticky="w", **pad)
        ttk.Label(gt, text="mA").grid(row=0, column=3, sticky="w")
        ttk.Label(gt, text="레벨 = 측정값 ×").grid(row=0, column=4, sticky="e", **pad)
        self.var_trk_ratio = tk.StringVar(value=s.get("trk_ratio", "90"))
        ttk.Entry(gt, textvariable=self.var_trk_ratio, width=5).grid(row=0, column=5, sticky="w", **pad)
        ttk.Label(gt, text="%").grid(row=0, column=6, sticky="w")
        ttk.Label(gt, text="최저").grid(row=0, column=7, sticky="e", **pad)
        self.var_trk_floor = tk.StringVar(value=s.get("trk_floor", "100"))
        ttk.Entry(gt, textvariable=self.var_trk_floor, width=7).grid(row=0, column=8, sticky="w", **pad)
        ttk.Label(gt, text="mA").grid(row=0, column=9, sticky="w")
        self.var_trk_set = tk.BooleanVar(value=bool(s.get("trk_settrig", True)))
        ttk.Checkbutton(gt, text="트리거 소스를 측정 채널 · 상승 에지로 설정",
                        variable=self.var_trk_set).grid(row=1, column=0, columnspan=5, sticky="w", **pad)
        ttk.Label(gt, text="트리거 모드").grid(row=1, column=5, columnspan=2, sticky="e", **pad)
        self.var_trk_mode = tk.StringVar(value=s.get("trk_mode", TRIG_MODES[0]))
        ttk.Combobox(gt, textvariable=self.var_trk_mode, values=TRIG_MODES, width=14,
                     state="readonly").grid(row=1, column=7, columnspan=3, sticky="w", **pad)
        self.lbl_trig = ttk.Label(gt, text="현재 트리거 레벨: ---", foreground="#1f4f8f")
        self.lbl_trig.grid(row=2, column=0, columnspan=10, sticky="w", **pad)

        # 환산 / 표시
        g3 = ttk.LabelFrame(f, text=" 환산 / 표시 ", padding=6)
        g3.pack(fill="x", pady=4)
        ttk.Label(g3, text="환산").grid(row=0, column=0, sticky="e", **pad)
        self.var_conv = tk.StringVar(value=s["conv_mode"])
        ttk.Combobox(g3, textvariable=self.var_conv, values=CONV_MODES, width=20,
                     state="readonly").grid(row=0, column=1, sticky="w", **pad)
        ttk.Label(g3, text="값").grid(row=0, column=2, sticky="e", **pad)
        self.var_convv = tk.StringVar(value=s["conv_value"])
        ttk.Entry(g3, textvariable=self.var_convv, width=8).grid(row=0, column=3, sticky="w", **pad)
        ttk.Label(g3, text="갱신(ms)").grid(row=0, column=4, sticky="e", **pad)
        self.var_int = tk.StringVar(value=str(s["interval_ms"]))
        ttk.Spinbox(g3, from_=50, to=10000, increment=50, textvariable=self.var_int,
                    width=6, command=self.on_interval).grid(row=0, column=5, sticky="w", **pad)
        ttk.Label(g3, text="표시 단위").grid(row=1, column=0, sticky="e", **pad)
        self.var_du = tk.StringVar(value=s["disp_unit"])
        ttk.Combobox(g3, textvariable=self.var_du, values=DISP_UNITS, width=6,
                     state="readonly").grid(row=1, column=1, sticky="w", **pad)
        ttk.Label(g3, text="소수 자리").grid(row=1, column=2, sticky="e", **pad)
        self.var_dig = tk.StringVar(value=str(s["digits"]))
        ttk.Spinbox(g3, from_=0, to=6, textvariable=self.var_dig, width=4,
                    state="readonly").grid(row=1, column=3, sticky="w", **pad)

        # 버튼
        g4 = ttk.Frame(f)
        g4.pack(fill="x", pady=(6, 0))
        self.btn_apply = ttk.Button(g4, text="장비에 적용", command=self.on_apply)
        self.btn_apply.pack(side="left", padx=3)
        self.btn_run = ttk.Button(g4, text="▶ 측정 시작", command=self.on_run)
        self.btn_run.pack(side="left", padx=3)
        ttk.Button(g4, text="통계 리셋", command=self.on_reset).pack(side="left", padx=3)
        self.btn_log = ttk.Button(g4, text="CSV 기록 시작", command=self.on_log)
        self.btn_log.pack(side="left", padx=3)
        ttk.Label(g4, text=VERSION, foreground="#999").pack(side="right")

        self.update_gate_state()
        self.update_info()

    def update_gate_state(self):
        st = "normal" if self.var_gate.get() else "disabled"
        self.ent_t1.configure(state=st)
        self.ent_t2.configure(state=st)
        self.cmb_tu.configure(state="readonly" if self.var_gate.get() else "disabled")

    def apply_visibility(self):
        if self.s.get("show_settings", True):
            self.setf.pack(side="bottom", fill="x", before=self.disp)
            self.btn_toggle_set.configure(text="설정 숨기기")
            self.fit_window()
        else:
            self.setf.pack_forget()
            self.btn_toggle_set.configure(text="설정 보기")

    def fit_window(self):
        """저장된 창 크기가 작아도 설정/버튼이 잘리지 않도록 높이를 늘림."""
        self.root.update_idletasks()
        need_h = self.setf.winfo_reqheight() + 220
        need_w = self.setf.winfo_reqwidth()
        try:
            size = self.root.geometry().split("+")[0]
            w, h = [int(x) for x in size.split("x")]
        except Exception:
            return
        if w > 1 and (h < need_h or w < need_w):
            self.root.geometry("%dx%d" % (max(w, need_w), max(h, need_h)))

    def set_run_text(self, txt):
        self.btn_run.configure(text=txt)
        self.btn_run2.configure(text=txt)

    def toggle_settings(self):
        self.s["show_settings"] = not self.s.get("show_settings", True)
        self.apply_visibility()

    def on_topmost(self):
        self.s["topmost"] = self.var_top.get()
        self.root.attributes("-topmost", bool(self.s["topmost"]))

    # --------------------------------------------- 설정 읽기
    def read_cfg(self):
        meas = dict(MEAS_TYPES)[self.var_meas.get()]
        ch = int(self.var_ch.get().replace("CH", ""))
        cfg = {"channel": ch, "meas": meas, "slot": int(self.var_slot.get()),
               "gate_on": self.var_gate.get(),
               "pc_calc": self.var_calc.get() == CALC_MODES[0]}
        if cfg["gate_on"]:
            k = TIME_UNITS[self.var_tu.get()]
            try:
                a = float(self.var_t1.get()) * k
                b = float(self.var_t2.get()) * k
            except ValueError:
                raise ValueError("구간 시작/끝에 숫자를 입력하세요.")
            if b <= a:
                raise ValueError("구간의 끝이 시작보다 커야 합니다.")
            cfg["t_start"], cfg["t_stop"] = a, b
        return cfg

    def conv_factor(self):
        mode = self.var_conv.get()
        try:
            v = float(self.var_convv.get())
        except ValueError:
            v = 1.0
        if mode == CONV_MODES[1]:
            return 1.0 / v if v != 0 else float("nan")
        if mode == CONV_MODES[2]:
            return v
        return 1.0

    def interval_s(self):
        try:
            return max(50, int(float(self.var_int.get()))) / 1000.0
        except ValueError:
            return 0.2

    def update_info(self):
        try:
            cfg = self.read_cfg()
            txt = "%s · %s" % (self.var_ch.get(), self.var_meas.get())
            txt += " · PC계산" if cfg["pc_calc"] else " · 장비측정"
            if cfg["gate_on"]:
                txt += " · 구간 %s ~ %s" % (fmt_time(cfg["t_start"]), fmt_time(cfg["t_stop"]))
            else:
                txt += " · 화면 전체"
        except Exception:
            txt = "%s · %s" % (self.var_ch.get(), self.var_meas.get())
        self.lbl_info.configure(text=txt)

    # --------------------------------------------- 버튼 동작
    def on_connect(self):
        if self.connected:
            self.running = False
            self.set_run_text("▶ 측정 시작")
            self.worker.tasks.put(("disconnect",))
            return
        try:
            port = int(self.var_port.get())
        except ValueError:
            port = 5025
        self.worker.tasks.put(("connect", self.var_host.get(), port))

    def on_apply(self):
        if not self.connected:
            messagebox.showinfo(APP_NAME, "먼저 장비에 연결하세요.")
            return
        try:
            cfg = self.read_cfg()
        except ValueError as e:
            messagebox.showwarning(APP_NAME, str(e))
            return
        self.update_info()
        self.reset_stats()
        self.worker.tasks.put(("apply", cfg))

    def on_run(self):
        if not self.connected:
            messagebox.showinfo(APP_NAME, "먼저 장비에 연결하세요.")
            return
        if not self.running:
            # 처음 시작할 때는 현재 설정을 장비에 먼저 적용
            try:
                cfg = self.read_cfg()
            except ValueError as e:
                messagebox.showwarning(APP_NAME, str(e))
                return
            trk = None
            if self.var_trk.get():
                try:
                    k = self.conv_factor()  # 장비값 × k = A
                    trk = {"channel": cfg["channel"],
                           "start": float(self.var_trk_start.get()) * 1e-3 / k,
                           "ratio": float(self.var_trk_ratio.get()) / 100.0,
                           "floor": float(self.var_trk_floor.get()) * 1e-3 / k,
                           "settrig": self.var_trk_set.get(),
                           "mode": {TRIG_MODES[0]: "AUTO", TRIG_MODES[1]: "NORM"}.get(
                               self.var_trk_mode.get(), "KEEP")}
                    if not (0 < trk["ratio"] <= 1.5) or trk["start"] <= 0:
                        raise ValueError
                except (ValueError, ZeroDivisionError):
                    messagebox.showwarning(APP_NAME, "트리거 추적의 시작 전류 / 비율 / 최저 값을 확인하세요.")
                    return
            self.update_info()
            self.worker.tasks.put(("apply", cfg))
            if trk:
                self.worker.tasks.put(("track_start", trk))
            else:
                self.worker.tasks.put(("track_stop",))
            self.stale = False
            self.running = True
            self.set_run_text("■ 정지")
        else:
            self.worker.tasks.put(("track_stop",))
            self.running = False
            self.set_run_text("▶ 측정 시작")
        self.worker.tasks.put(("poll", self.running, self.interval_s()))

    def on_interval(self):
        if self.running:
            self.worker.tasks.put(("poll", True, self.interval_s()))

    def reset_stats(self):
        self.n = 0
        self.vsum = 0.0
        self.vmin = float("inf")
        self.vmax = float("-inf")

    def on_reset(self):
        self.reset_stats()
        self.lbl_stats.configure(text="")

    def on_log(self):
        if self.log_file:
            self.log_file.close()
            self.log_file = None
            self.log_writer = None
            self.btn_log.configure(text="CSV 기록 시작")
            return
        name = "current_log_%s.csv" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=name,
                                            filetypes=[("CSV", "*.csv")])
        if not path:
            return
        self.log_file = open(path, "w", newline="", encoding="utf-8-sig")
        self.log_writer = csv.writer(self.log_file)
        self.log_writer.writerow(["time", "current_A", "channel", "measure", "gate"])
        self.btn_log.configure(text="CSV 기록 중지")

    # --------------------------------------------- 값 표시
    def format_value(self, amps):
        if not math.isfinite(amps):
            return "---"
        unit = self.var_du.get()
        try:
            dig = int(self.var_dig.get())
        except ValueError:
            dig = 2
        if unit == "자동":
            a = abs(amps)
            unit = "A" if a >= 1 else ("mA" if a >= 1e-3 else "µA")
        k = {"A": 1, "mA": 1e3, "µA": 1e6}[unit]
        return "%.*f %s" % (dig, amps * k, unit)

    def show_value(self, raw, t):
        amps = raw * self.conv_factor() if math.isfinite(raw) else float("nan")
        txt = self.format_value(amps)
        old_len = len(self.lbl_value.cget("text"))
        color = "#39ff88" if math.isfinite(amps) else "#c0504d"
        if getattr(self, "stale", False) and math.isfinite(amps):
            color = "#7d8a99"  # 새 트리거 없음 (마지막 값 유지)
        self.lbl_value.configure(text=txt, fg=color)
        if len(txt) != old_len:
            self.on_resize()
        if math.isfinite(amps):
            self.n += 1
            self.vsum += amps
            self.vmin = min(self.vmin, amps)
            self.vmax = max(self.vmax, amps)
            self.lbl_stats.configure(text="평균 %s   최소 %s   최대 %s   (n=%d)" % (
                self.format_value(self.vsum / self.n), self.format_value(self.vmin),
                self.format_value(self.vmax), self.n))
        if self.log_writer:
            self.log_writer.writerow([
                datetime.datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
                ("%.9g" % amps) if math.isfinite(amps) else "",
                self.var_ch.get(), self.var_meas.get(), self.lbl_info.cget("text")])

    def set_status(self, text, color):
        self.lbl_status.configure(text=text, fg=color)

    def pump(self):
        last_value = None
        try:
            while True:
                msg = self.q.get_nowait()
                kind = msg[0]
                if kind == "value":
                    if self.running:
                        last_value = msg
                        if self.log_writer:
                            self.show_value(msg[1], msg[2])
                            last_value = None
                elif kind == "status":
                    self.set_status(msg[1], msg[2])
                elif kind == "connected":
                    self.connected = True
                    self.btn_conn.configure(text="연결 해제")
                    self.lbl_idn.configure(text=msg[1], foreground="#1f4f8f")
                    self.set_status("연결됨  %s" % self.var_host.get(), "#39ff88")
                elif kind == "disconnected":
                    self.connected = False
                    self.running = False
                    self.btn_conn.configure(text="연결")
                    self.set_run_text("▶ 측정 시작")
                    if not self.lbl_status.cget("text").startswith("오류"):
                        self.set_status("연결 안 됨", "#c0504d")
                elif kind == "applied":
                    errs, actual = msg[1], msg[2]
                    if errs:
                        self.lbl_applied.configure(text="장비 오류: " + " / ".join(errs),
                                                   foreground="#c0504d")
                    elif actual:
                        self.lbl_applied.configure(
                            text="장비에 적용됨: 구간 %s ~ %s" % (fmt_time(actual[0]), fmt_time(actual[1])),
                            foreground="#1f6f3f")
                    else:
                        self.lbl_applied.configure(text="장비에 적용됨", foreground="#1f6f3f")
                elif kind == "applied_pc":
                    errs, info, part = msg[1], msg[2], msg[3]
                    if errs:
                        self.lbl_applied.configure(text="장비 오류: " + " / ".join(errs),
                                                   foreground="#c0504d")
                    elif info:
                        self.lbl_applied.configure(
                            text="PC 계산 준비됨 · 파형 %s ~ %s, %s pt%s" % (
                                fmt_time(info[0]), fmt_time(info[1]), format(info[2], ","),
                                " (구간 부분만 전송)" if part else ""),
                            foreground="#1f6f3f")
                elif kind == "trig":
                    k = self.conv_factor()
                    txt = "현재 트리거 레벨: %s   (%s)" % (self.format_value(msg[1] * k), msg[2])
                    if msg[3] is not None:
                        txt += "   · 장비 확인값 %s" % self.format_value(msg[3] * k)
                        if abs(msg[3] - msg[1]) > 0.05 * max(abs(msg[1]), 1e-9):
                            txt += "  ⚠ 설정값과 다름 (채널 범위/단위 확인)"
                    self.lbl_trig.configure(text=txt)
                elif kind == "stale":
                    if msg[1] != getattr(self, "stale", False):
                        self.stale = msg[1]
                        if self.running:
                            self.set_status(("파형 갱신 없음 - 스코프 RUN 상태 확인" if msg[1] == "auto"
                                             else "트리거 대기 중 (새 파형 없음)") if msg[1] else
                                            "측정 중  %s" % self.var_host.get(),
                                            "#d4a017" if msg[1] else "#39ff88")
                elif kind == "diag":
                    if self.running:
                        warn = "밖" in msg[1] or "없" in msg[1]
                        self.lbl_applied.configure(text=msg[1],
                                                   foreground="#c0504d" if warn else "#1f6f3f")
                elif kind == "error":
                    self.set_status("오류: " + msg[1], "#ff6b6b")
        except queue.Empty:
            pass
        if last_value:
            self.show_value(last_value[1], last_value[2])
        self.root.after(50, self.pump)

    # --------------------------------------------- 종료
    def collect_settings(self):
        s = self.s
        s["host"] = self.var_host.get()
        try:
            s["port"] = int(self.var_port.get())
        except ValueError:
            pass
        s["channel"] = int(self.var_ch.get().replace("CH", ""))
        s["meas_label"] = self.var_meas.get()
        s["slot"] = int(self.var_slot.get())
        s["gate_on"] = self.var_gate.get()
        s["calc_mode"] = self.var_calc.get()
        s["trk_on"] = self.var_trk.get()
        s["trk_start"] = self.var_trk_start.get()
        s["trk_ratio"] = self.var_trk_ratio.get()
        s["trk_floor"] = self.var_trk_floor.get()
        s["trk_settrig"] = self.var_trk_set.get()
        s["trk_mode"] = self.var_trk_mode.get()
        s["gate_start"] = self.var_t1.get()
        s["gate_stop"] = self.var_t2.get()
        s["gate_unit"] = self.var_tu.get()
        s["conv_mode"] = self.var_conv.get()
        s["conv_value"] = self.var_convv.get()
        s["interval_ms"] = int(self.interval_s() * 1000)
        s["disp_unit"] = self.var_du.get()
        s["digits"] = int(self.var_dig.get())
        s["geometry"] = self.root.geometry()

    def on_close(self):
        try:
            self.collect_settings()
            save_settings(self.s)
        except Exception:
            pass
        if self.log_file:
            self.log_file.close()
        self.worker.alive = False
        self.worker._close()
        self.root.destroy()


def main():
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)  # 고해상도 모니터에서 글자 선명하게
    except Exception:
        pass
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
