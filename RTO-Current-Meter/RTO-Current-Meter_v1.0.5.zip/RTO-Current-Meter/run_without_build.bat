@echo off
cd /d %~dp0
python rto_current_meter.py
if errorlevel 1 pause
