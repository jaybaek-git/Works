@echo off
cd /d %~dp0
echo ============================================
echo  RTO Current Meter v1.0 - EXE build
echo ============================================
python --version
if errorlevel 1 (
  echo [ERROR] Python not found. Install Python 3.9+ ^(check "Add to PATH"^).
  pause
  exit /b 1
)
python -m pip install --upgrade pyinstaller
if errorlevel 1 (
  echo [ERROR] pyinstaller install failed. Check proxy / pip settings.
  pause
  exit /b 1
)
python -m PyInstaller --noconfirm --clean --onefile --windowed --name "RTO-Current-Meter_v1.0" rto_current_meter.py
if errorlevel 1 (
  echo [ERROR] Build failed.
  pause
  exit /b 1
)
echo.
echo  DONE:  dist\RTO-Current-Meter_v1.0.exe
echo.
pause
